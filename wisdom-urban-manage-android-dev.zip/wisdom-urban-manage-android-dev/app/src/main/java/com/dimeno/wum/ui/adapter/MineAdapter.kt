package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.wum.ui.adapter.holder.MineViewHolder
import com.dimeno.wum.ui.bean.MineBean

/**
 * CasePictureAdapter
 * Created by wangzhen on 2020/9/16.
 */
class MineAdapter(list: List<MineBean>) : RecyclerAdapter<MineBean>(list) {
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MineViewHolder(parent)
    }
}