package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.network.util.JsonUtils;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.TaskType;
import com.dimeno.wum.entity.SpecialCensusDetailsEntity;
import com.dimeno.wum.network.task.SpecialCensusDetailsTask;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

import org.jetbrains.annotations.Nullable;

/**
 * CensusDetailsActivity
 * Created by sdg on 2020/10/9.
 * 专项普查的任务详情页
 */
public class CensusDetailsActivity extends BaseActivity implements View.OnClickListener {

    private TextView census_time;
    private TextView census_range;
    private TextView task_address;
    private TextView census_content;
    private TextView photo_requirements;
    private TextView attention;
    private ImageView iv_map_manage;
    private int taskType;
    private RelativeLayout rl_satrt_census;
    private TextView tv_start_census;
    private String id;
    private String coordinateList;
    private SpecialCensusDetailsEntity currentData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_census_details);
        fitDarkStatusBar(true);

        census_time = findViewById(R.id.census_time);
        census_range = findViewById(R.id.census_range);
        task_address = findViewById(R.id.task_address);
        census_content = findViewById(R.id.census_content);
        photo_requirements = findViewById(R.id.photo_requirements);
        attention = findViewById(R.id.attention);
        rl_satrt_census = findViewById(R.id.rl_satrt_census);
        tv_start_census = findViewById(R.id.tv_start_census);
        iv_map_manage = findViewById(R.id.iv_map_manage);
        iv_map_manage.setOnClickListener(this::onClick);
        tv_start_census.setOnClickListener(this::onClick);

        id = getIntent().getStringExtra("id");
        taskType = getIntent().getIntExtra(IKey.TASK_TYPE, TaskType.REMAIN_DEAL);
        if (taskType == TaskType.REMAIN_DEAL) {
            rl_satrt_census.setVisibility(View.VISIBLE);
        } else {
            rl_satrt_census.setVisibility(View.GONE);
        }

        getMyGeneralSurveyDetail();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "任务详情");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_map_manage:
                Intent intent = new Intent(CensusDetailsActivity.this, TaskMapActivity.class);
                intent.putExtra("data", coordinateList);
                startActivity(intent);
                break;
            case R.id.tv_start_census:
                Intent censusIntent = new Intent(CensusDetailsActivity.this, ReportActivity.class);
                censusIntent.putExtra(IKey.GENERAL_SURVEY_ID, id);
                censusIntent.putExtra(IKey.PRESET, true);
                censusIntent.putExtra(IKey.CASE_TYPE_NAME, currentData.data.caseTypeName);
                censusIntent.putExtra(IKey.CASE_TYPE_CODE, String.valueOf(currentData.data.caseType));
                censusIntent.putExtra(IKey.CASE_BIG_CLASS_NAME, currentData.data.bigClassName);
                censusIntent.putExtra(IKey.CASE_BIG_CLASS_CODE, currentData.data.bigClass);
                censusIntent.putExtra(IKey.CASE_SMALL_CLASS_NAME, currentData.data.smallClassName);
                censusIntent.putExtra(IKey.CASE_SMALL_CLASS_CODE, currentData.data.smallClass);
                startActivity(censusIntent);
                break;
        }
    }

    private void getMyGeneralSurveyDetail() {
        new SpecialCensusDetailsTask(new LoadingCallback<SpecialCensusDetailsEntity>() {
            @Override
            public void onSuccess(SpecialCensusDetailsEntity data) {
                if (data.data == null) return;
                currentData = data;
                coordinateList = JsonUtils.toJsonString(data.data.coordinateList);
                census_time.setText(data.data.createTime);
                census_range.setText(data.data.surveyRangeName);
                task_address.setText(data.data.address);
                census_content.setText(data.data.surveyContext);
                photo_requirements.setText(data.data.photographRequire);
                attention.setText(data.data.noteMatter);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

        }).setTag(this)
                .put("id", id)
                .exe();
    }
}