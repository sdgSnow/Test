package com.dimeno.wum.ui.bean;

public class SpinnerQueryDealResultBean {

    public String dealResultName;//处理结果名称
}
