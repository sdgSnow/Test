package com.dimeno.wum.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.L;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.WebUrl;
import com.dimeno.wum.entity.DaySpinnerEntity;
import com.dimeno.wum.widget.toolbar.AppCaseManageToolbar;
import com.just.agentweb.AgentWeb;
import com.wangzhen.router.Router;

import org.jetbrains.annotations.Nullable;

public class CaseManageSpinnerActivity extends BaseActivity implements AppCaseManageToolbar.SpinnerListener {

    private LinearLayout ll_web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_manage_spinner);
        fitDarkStatusBar(true);
        ll_web = findViewById(R.id.ll_web);
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        AppCaseManageToolbar toolbar = new AppCaseManageToolbar(this, "案件管理");
        toolbar.setOnItemSelected(this::onItemSelected);
        return toolbar;
    }

    @Override
    public void onItemSelected(DaySpinnerEntity entity) {
        String format = "http://zhcg.dimenosys.com/custom/#/caseManage?days=";
        String url = String.format(format + "%s", entity.day);
        L.e("案件管理url= " + url);
        loadUrl(url);
    }

    private void loadUrl(String url) {
        AgentWeb mAgentWeb = AgentWeb.with(this)
                .setAgentWebParent(ll_web, new LinearLayout.LayoutParams(-1, -1))
                .useDefaultIndicator()
                .createAgentWeb()
                .ready()
                .go(url);

        WebSettings webSettings = mAgentWeb.getAgentWebSettings().getWebSettings();
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
    }
}