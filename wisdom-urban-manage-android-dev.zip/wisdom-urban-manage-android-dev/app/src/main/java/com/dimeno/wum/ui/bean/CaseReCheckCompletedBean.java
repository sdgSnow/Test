package com.dimeno.wum.ui.bean;

public class CaseReCheckCompletedBean {

    public String address;
    public String latitude;
    public int assignType;
    public String description;
    public String updateUser;
    public String updateTime;
    public String caseCoding;
    public int source;
    public int caseNo;
    public int caseType;
    public String assignTypeName;
    public String smallClassName;
    public String smallClass;
    public String caseTypeName;
    public String bigClassName;
    public String createTime;
    public String statusName;
    public String createUser;
    public String id;
    public Object taskId;
    public String bigClass;
    public String longitude;
    public int status;
}
