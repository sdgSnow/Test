package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseRemainDealEntity;
import com.dimeno.wum.network.task.CaseQueryListTask;
import com.dimeno.wum.network.task.CaseVerifyListTask;
import com.dimeno.wum.network.task.CaseVerifyTask;
import com.dimeno.wum.ui.adapter.holder.CaseQueryHolder;
import com.dimeno.wum.ui.adapter.holder.CaseRemainDealHolder;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.ui.bean.CaseRemainDealBean;

import java.util.ArrayList;
import java.util.List;

public class CaseRemainDealAdapter extends LoadRecyclerAdapter<CaseRemainDealBean> {

    private int page = 1;

    public CaseRemainDealAdapter(List<CaseRemainDealBean> list,RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseRemainDealHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new CaseVerifyListTask(new LoadingCallback<CaseRemainDealEntity>() {
            @Override
            public void onSuccess(CaseRemainDealEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<CaseRemainDealBean> addList = new ArrayList<>();
                    for (CaseRemainDealEntity.DataBean datum : data.data) {
                        CaseRemainDealBean caseRemainDealBean = new CaseRemainDealBean();
                        caseRemainDealBean.address = datum.address;
                        caseRemainDealBean.latitude = datum.latitude;
                        caseRemainDealBean.assignType = datum.assignType;
                        caseRemainDealBean.description = datum.description;
                        caseRemainDealBean.updateUser = datum.updateUser;
                        caseRemainDealBean.updateTime = datum.updateTime;
                        caseRemainDealBean.caseCoding = datum.caseCoding;
                        caseRemainDealBean.source = datum.source;
                        caseRemainDealBean.caseNo = datum.caseNo;
                        caseRemainDealBean.caseType = datum.caseType;
                        caseRemainDealBean.assignTypeName = datum.assignTypeName;
                        caseRemainDealBean.smallClassName = datum.smallClassName;
                        caseRemainDealBean.smallClass = datum.smallClass;
                        caseRemainDealBean.caseTypeName = datum.caseTypeName;
                        caseRemainDealBean.bigClassName = datum.bigClassName;
                        caseRemainDealBean.createTime = datum.createTime;
                        caseRemainDealBean.statusName = datum.statusName;
                        caseRemainDealBean.createUser = datum.createUser;
                        caseRemainDealBean.id = datum.id;
                        caseRemainDealBean.taskId = datum.taskId;
                        caseRemainDealBean.bigClass = datum.bigClass;
                        caseRemainDealBean.longitude = datum.longitude;
                        caseRemainDealBean.status = datum.status;
                        addList.add(caseRemainDealBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
//                .put("assignType", AssignType.CASE_EXAMINE)
                .put("status", CasePro.CASE_REMAIN_DEAL)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
