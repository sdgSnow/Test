package com.dimeno.wum.network.interceptor

import com.dimeno.commons.utils.L
import okhttp3.Interceptor
import okhttp3.RequestBody
import okhttp3.Response
import okio.Buffer
import okio.EOFException
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset

/**
 * request interceptor
 * Created by wangzhen on 2020/9/27.
 */
class RequestInterceptor : Interceptor {
    private val defaultCharset: Charset = Charset.forName("UTF-8")
    override fun intercept(chain: Interceptor.Chain): Response {
        // request
        val request = chain.request()
//        L.e("-> network ╔═══════════════════════════════════════════════════════════════════════════════════════")
//        L.e("-> network ${request.method} ${request.url}")
//        L.e("-> network ${bodyString(request.body)}")

        // response
        val response = chain.proceed(request)
        response.body?.let { body ->
            val source = body.source()
            source.request(Long.MAX_VALUE)
            val charset = body.contentType()?.charset(defaultCharset) ?: defaultCharset
            val buffer = source.buffer
            if (isPlainText(buffer)) {
                format(buffer.clone().readString(charset))
            }
        }
//        L.e("-> network ╚═══════════════════════════════════════════════════════════════════════════════════════")
        return response
    }

    private fun bodyString(requestBody: RequestBody?): String {
        requestBody?.let { body ->
            try {
                val buffer = Buffer()
                body.writeTo(buffer)
                val charset = body.contentType()?.charset(defaultCharset) ?: defaultCharset
                return buffer.readString(charset)
            } catch (ignore: Exception) {

            }
        }
        return "{}"
    }

    private fun format(msg: String) {
        when {
            msg.startsWith("{") -> {
                JSONObject(msg).toString(4)
            }
            msg.startsWith("[") -> {
                JSONArray(msg).toString(4)
            }
            else -> {
                msg
            }
        }.split(System.getProperty("line.separator")).forEach {
//            L.e("-> network $it")
        }
    }

    private fun isPlainText(buffer: Buffer): Boolean {
        return try {
            val prefix = Buffer()
            val byteCount = if (buffer.size < 64) buffer.size else 64.toLong()
            buffer.copyTo(prefix, 0, byteCount)
            for (i in 0..15) {
                if (prefix.exhausted()) {
                    break
                }
                val codePoint = prefix.readUtf8CodePoint()
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false
                }
            }
            true
        } catch (e: EOFException) {
            false // Truncated UTF-8 sequence.
        }
    }
}