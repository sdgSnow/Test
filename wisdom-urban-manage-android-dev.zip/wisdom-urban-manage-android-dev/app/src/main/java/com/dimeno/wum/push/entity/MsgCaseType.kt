package com.dimeno.wum.push.entity

/**
 * notification message case type
 * Created by wangzhen on 2020/9/24.
 */
class MsgCaseType {
    companion object {
        const val VERIFY = 1 // 核实
        const val CHECK = 2 // 核查
        const val INSPECTION = 3 // 巡查
        const val REGISTER = 4 // 立案
        const val CLOSED = 5 // 结案
        const val VOID = 6 // 作废
    }
}