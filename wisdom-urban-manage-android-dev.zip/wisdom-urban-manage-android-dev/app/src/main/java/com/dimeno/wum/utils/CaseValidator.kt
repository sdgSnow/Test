package com.dimeno.wum.utils

import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.utils.SpatialRelationUtil

/**
 * case data validator
 * Created by wangzhen on 2020/9/23.
 */
class CaseValidator {
    companion object {
        fun inRegion(list: MutableList<LatLng>?, latLng: LatLng): Boolean {
            return list != null && SpatialRelationUtil.isPolygonContainsPoint(list, latLng)
        }
    }
}