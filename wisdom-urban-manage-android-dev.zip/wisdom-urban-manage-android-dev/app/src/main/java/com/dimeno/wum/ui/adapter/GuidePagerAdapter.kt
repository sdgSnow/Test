package com.dimeno.wum.ui.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.dimeno.wum.ui.fragment.GuideOneFragment
import com.dimeno.wum.ui.fragment.GuideThreeFragment
import com.dimeno.wum.ui.fragment.GuideTwoFragment

/**
 * guide pager adapter
 * Created by wangzhen on 2020/9/25.
 */
class GuidePagerAdapter(manager: FragmentManager) : FragmentPagerAdapter(manager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val list = mutableListOf<Fragment>().apply {
        add(GuideOneFragment())
        add(GuideTwoFragment())
        add(GuideThreeFragment())
    }

    override fun getCount(): Int = list.size

    override fun getItem(position: Int): Fragment = list[position]
}