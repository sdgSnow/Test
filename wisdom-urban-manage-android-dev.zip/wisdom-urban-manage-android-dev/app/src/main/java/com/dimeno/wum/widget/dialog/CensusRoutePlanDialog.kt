package com.dimeno.wum.widget.dialog

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.baidu.mapapi.search.route.DrivingRouteLine
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.entity.CensusMapRouteEntity
import com.dimeno.wum.ui.adapter.CensusMapRouteAdapter
import kotlinx.android.synthetic.main.dialog_census_map_route_layout.*

/**
 * census route plan dialog
 * Created by wangzhen on 2020/10/28.
 */
class CensusRoutePlanDialog : BaseDialogFragment() {
    private var adapter: CensusMapRouteAdapter? = null
    private var routes: MutableList<CensusMapRouteEntity>? = null
    private var callback: Callback? = null
    private val gap = AppUtils.dip2px(0.33f)

    override fun layoutId(): Int = R.layout.dialog_census_map_route_layout

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)

        CensusMapRouteAdapter(routes).apply {
            adapter = this
            setOnClickCallback { _, position ->
                select(position)
                callback?.onRouteSelect(datas[position].data!!)
            }
            recycler.adapter = this
            select(0)
        }
    }

    private fun initViews(view: View) {
        recycler.layoutManager = LinearLayoutManager(view.context)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ContextCompat.getColor(view.context, R.color.color_cccccc)
        }
        recycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                outRect.set(outRect.left, outRect.top, outRect.right, gap)
                super.getItemOffsets(outRect, view, parent, state)
            }

            override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child != null) {
                        c.drawRect(Rect(child.left, child.bottom, child.right, child.bottom + gap), paint)
                    }
                }
                super.onDraw(c, parent, state)
            }
        })

        btn_navigation.setOnClickListener {
            adapter?.selectedItem?.let {
                callback?.onNavigation(it.data!!)
                dismiss()
            }
        }
    }

    fun setCallback(callback: Callback): CensusRoutePlanDialog {
        this.callback = callback
        return this
    }

    fun setRoutes(routes: MutableList<DrivingRouteLine>): CensusRoutePlanDialog {
        this.routes = mutableListOf<CensusMapRouteEntity>().apply {
            routes.forEach {
                add(CensusMapRouteEntity().apply {
                    data = it
                })
            }
        }
        return this
    }

    override fun isBottom(): Boolean = true

    override fun windowWidth(): Int {
        return AppUtils.getScreenWidthPixels()
    }

    override fun dimAmount(): Float = 0.2f

    override fun dimBehind(): Boolean = false

    override fun onStart() {
        super.onStart()
        dialog?.let {
            it.setCancelable(true)
            it.setCanceledOnTouchOutside(true)
        }
    }

    interface Callback {
        fun onRouteSelect(line: DrivingRouteLine)

        fun onNavigation(line: DrivingRouteLine)
    }
}