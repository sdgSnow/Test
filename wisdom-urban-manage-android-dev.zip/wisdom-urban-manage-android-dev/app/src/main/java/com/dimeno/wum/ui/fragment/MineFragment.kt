package com.dimeno.wum.ui.fragment

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.MineType
import com.dimeno.wum.ui.activity.LoginActivity
import com.dimeno.wum.ui.adapter.MineAdapter
import com.dimeno.wum.ui.bean.MineBean
import com.dimeno.wum.widget.dialog.ConfirmDialog
import kotlinx.android.synthetic.main.fragment_mine.*

/**
 * MineFragment
 * Created by wangzhen on 2020/9/15.
 */
class MineFragment : Fragment() {

    private var adapter: MineAdapter? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_mine, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tv_exit.setOnClickListener {
            activity?.supportFragmentManager?.let {
                ConfirmDialog().setTitle("提示").setMessage("是否退出登录?").setCallback(object : ConfirmDialog.Callback {
                    override fun onCancel() {

                    }

                    override fun onConfirm() {
                        UserBiz.get().clear()
                        activity?.finish()
                        startActivity(Intent(activity, LoginActivity::class.java))
                    }

                }).show(it)
            }
        }

        rv_mine.layoutManager = LinearLayoutManager(context)
        rv_mine.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                super.getItemOffsets(outRect, view, parent, state)
                outRect.bottom = AppUtils.dip2px(0.33f)
            }
        })

        tv_username.setText(UserBiz.get().userAccount)

        initData()

    }

    private fun initData() {
        val mines = arrayListOf<MineBean>();
        mines.add(MineBean(MineType.MANAGEMENT_SYSTEM, R.mipmap.ic_mine_management_system, getString(R.string.mine_management_system)))
        mines.add(MineBean(MineType.MESSAGE, R.mipmap.ic_mine_message, getString(R.string.mine_message)))
        mines.add(MineBean(MineType.NOTICE, R.mipmap.ic_mine_notice, getString(R.string.mine_notice)))
        mines.add(MineBean(MineType.HELP, R.mipmap.ic_mine_help, getString(R.string.mine_help)))
        mines.add(MineBean(MineType.ABOUT, R.mipmap.ic_mine_about, getString(R.string.mine_about)))
        mines.add(MineBean(MineType.CHANGE_PSW, R.mipmap.wode_mima, getString(R.string.change_psw)))

        adapter = MineAdapter(mines).apply {
            setEmpty(object : RecyclerItem() {
                override fun layout(): Int = R.layout.global_empty_layout

                override fun onViewCreated(itemView: View) {

                }
            }.onCreateView(rv_mine))
        }
        rv_mine.adapter = adapter;
    }
}