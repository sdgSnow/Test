package com.dimeno.wum.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.dimeno.wum.R
import com.dimeno.wum.common.IKey
import kotlinx.android.synthetic.main.fragment_picture_preview.*

/**
 * picture preview fragment
 * Created by wangzhen on 2020/9/25.
 */
class PicturePreviewFragment : Fragment() {
    private var url: String? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_picture_preview, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        url = arguments?.getString(IKey.PREVIEW_URL)
        iv.setOnPhotoTapListener { _, _, _ ->
            activity?.finish()
        }
        Glide.with(view.context).load(url)
                .apply(RequestOptions().placeholder(R.drawable.picture_preview_default).error(R.drawable.picture_preview_default))
                .into(iv)
    }
}