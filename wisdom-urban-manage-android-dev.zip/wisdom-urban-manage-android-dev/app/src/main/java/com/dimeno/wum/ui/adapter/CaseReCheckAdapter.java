package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseCheckInfoViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseReCheckViewHolder;
import com.dimeno.wum.ui.bean.CaseCheckInfoBean;
import com.dimeno.wum.ui.bean.CaseReCheckBean;

import java.util.List;

public class CaseReCheckAdapter extends RecyclerAdapter<CaseReCheckBean> {
    public CaseReCheckAdapter(List<CaseReCheckBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseReCheckViewHolder(parent);
    }
}
