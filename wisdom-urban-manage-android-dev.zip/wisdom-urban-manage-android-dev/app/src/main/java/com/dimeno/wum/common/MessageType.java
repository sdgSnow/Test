package com.dimeno.wum.common;

public class MessageType {

    public static final int MESSAGE_CASE = 1;//案件类
    public static final int MESSAGE_NEWS = 2;//新闻类
}
