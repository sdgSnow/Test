package com.dimeno.wum.ui.bean;

public class IndexHeaderBean {

    public String imageUrl;
}
