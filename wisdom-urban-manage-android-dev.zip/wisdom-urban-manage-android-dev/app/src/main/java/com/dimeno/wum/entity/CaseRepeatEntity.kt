package com.dimeno.wum.entity

import java.io.Serializable

/**
 * case repeat entity
 * Created by wangzhen on 2020/10/27.
 */
class CaseRepeatEntity : Serializable {
    var address: String? = null
    var bigClass: String? = null
    var caseCoding: String? = null
    var caseFilesList: Any? = null
    var caseNo: String? = null
    var caseType: Int = 0
    var createTime: String? = null
    var createUser: String? = null
    var description: String? = null
    var id: String? = null
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var smallClass: String? = null
    var smallClassOtherName: String? = null
    var source: Int = 0
    var status: Int = 0
    var taskId: String? = null
    var updateTime: String? = null
    var updateUser: String? = null
}