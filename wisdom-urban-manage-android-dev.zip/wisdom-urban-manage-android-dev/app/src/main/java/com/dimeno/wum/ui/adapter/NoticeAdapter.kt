package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.LoadRecyclerAdapter
import com.dimeno.adapter.annotation.LoadMoreState
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.entity.NewsEntity
import com.dimeno.wum.ui.adapter.holder.NoticeViewHolder

/**
 * notice adapter
 * Created by wangzhen on 2020/9/27.
 */
class NoticeAdapter(list: MutableList<NewsEntity.DataBean>?, parent: ViewGroup) : LoadRecyclerAdapter<NewsEntity.DataBean>(list, parent) {
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NoticeViewHolder(parent)
    }

    override fun onLoadMore() {
        AppUtils.getHandler().postDelayed({
            setState(LoadMoreState.NO_MORE)
        }, 500)
    }
}