package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.LoadRecyclerAdapter
import com.dimeno.adapter.annotation.LoadMoreState
import com.dimeno.wum.entity.MessageEntity
import com.dimeno.wum.ui.adapter.holder.MessageTimeViewHolder
import com.dimeno.wum.ui.adapter.holder.MessageViewHolder

/**
 * message adapter
 * Created by wangzhen on 2020/9/27.
 */
class MessageAdapter(list: MutableList<MessageEntity>, parent: ViewGroup) : LoadRecyclerAdapter<MessageEntity>(list, parent) {
    override fun getAbsItemViewType(position: Int): Int {
        return mDatas[position].type()
    }

    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            MessageEntity.TYPE_TIME -> MessageTimeViewHolder(parent)
            else -> MessageViewHolder(parent)
        }
    }

    override fun onLoadMore() {
        setState(LoadMoreState.NO_MORE)
    }
}