package com.dimeno.wum.entity

/**
 * message entity
 * Created by wangzhen on 2020/9/27.
 */
interface MessageEntity {
    companion object {
        const val TYPE_TIME = 0
        const val TYPE_DATA = 1
    }

    fun type(): Int
}