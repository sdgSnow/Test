package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class CaseDetailsEntity implements Serializable {

    public int code;
    public DataBean data;
    public String message;
    public boolean success;

    public static class DataBean implements Serializable{

        public String latitude;
        public String description;
        public String caseCoding;
        public int source;
        public int caseType;
        public String smallClassName;
        public String caseTypeName;
        public String statusName;
        public String id;
        public String bigClass;
        public String longitude;
        public String address;
        public String updateUser;
        public CaseOperationBean caseOperation;
        public String updateTime;
        public int caseNo;
        public String smallClass;
        public String createTime;
        public String bigClassName;
        public String createUser;
        public String sourceName;
        public String unitName;
        public Object taskId;
        public int status;
        public List<VerifyFilesListBean> verifyFilesList;//处理前
        public List<CaseFilesListBean> caseFilesList;
        public List<RectifyFilesListBean> rectifyFilesList;//处理后
        public List<CheckFilesListBean> checkFilesList;

        public static class CaseOperationBean implements Serializable{
            /**
             * address : 中国广东省深圳市罗湖区桂园街道宝安南路3083号1405-1406
             * caseFilesList : null
             * caseReportId : 1309305147637907457
             * createTime : 2020-09-25 09:50:19
             * createUser : 1308613965165461505
             * id : 1309309218289631234
             * latitude : 22.560911
             * longitude : 114.115139
             * operationDescription : gggg
             * operationType : 7
             * passFailed : 2
             * updateTime : 2020-09-25 09:50:19
             * updateUser : 1308613965165461505
             */

            public String address;
            public Object caseFilesList;
            public String caseReportId;
            public String createTime;
            public String createUser;
            public String id;
            public String latitude;
            public String longitude;
            public String operationDescription;
            public int operationType;
            public int passFailed;
            public String updateTime;
            public String updateUser;

        }

        public static class CaseFilesListBean implements Serializable{
            /**
             * caseReportId : 1309305147637907457
             * createTime : 2020-09-25 09:34:08
             * createUser : 1308613965165461505
             * fileShowUrl : https://publicoss.dimenosys.com/wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg?Expires=1601020925&OSSAccessKeyId=LTAI4FwRosaByiTNJDUdefmD&Signature=SH3rnVrkfrIhG0Vho5LHPnzvdS4%3D
             * fileSource : 1
             * fileUrl : wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg
             * id : 1309305147646296065
             * updateTime : 2020-09-25 09:34:08
             * updateUser : 1308613965165461505
             */

            public String caseReportId;
            public String createTime;
            public String createUser;
            public String fileShowUrl;
            public int fileSource;
            public String fileUrl;
            public String id;
            public String updateTime;
            public String updateUser;

        }

        public static class RectifyFilesListBean implements Serializable{
            /**
             * caseReportId : 1309305147637907457
             * createTime : 2020-09-25 09:46:15
             * createUser : 1306485785650155521
             * fileShowUrl : https://publicoss.dimenosys.com/wisdom-urban-manage/temp/rectifyImage/20200925094555_756.jpg?Expires=1601020925&OSSAccessKeyId=LTAI4FwRosaByiTNJDUdefmD&Signature=nvmt8KSxGuY0ue1pm%2FGEbvnDhDg%3D
             * fileSource : 5
             * fileUrl : wisdom-urban-manage/temp/rectifyImage/20200925094555_756.jpg
             * id : 1309308197341511682
             * updateTime : 2020-09-25 09:46:15
             * updateUser : 1306485785650155521
             */

            public String caseReportId;
            public String createTime;
            public String createUser;
            public String fileShowUrl;
            public int fileSource;
            public String fileUrl;
            public String id;
            public String updateTime;
            public String updateUser;

        }

        public static class CheckFilesListBean implements Serializable{
            /**
             * caseReportId : 1309305147637907457
             * createTime : 2020-09-25 09:50:15
             * createUser : 1308613965165461505
             * fileShowUrl : https://publicoss.dimenosys.com/wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg?Expires=1601020925&OSSAccessKeyId=LTAI4FwRosaByiTNJDUdefmD&Signature=SH3rnVrkfrIhG0Vho5LHPnzvdS4%3D
             * fileSource : 3
             * fileUrl : wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg
             * id : 1309309218302214145
             * updateTime : 2020-09-25 09:50:15
             * updateUser : 1308613965165461505
             */

            public String caseReportId;
            public String createTime;
            public String createUser;
            public String fileShowUrl;
            public int fileSource;
            public String fileUrl;
            public String id;
            public String updateTime;
            public String updateUser;

        }

        public static class VerifyFilesListBean implements Serializable{
            /**
             * caseReportId : 1309305147637907457
             * createTime : 2020-09-25 09:50:15
             * createUser : 1308613965165461505
             * fileShowUrl : https://publicoss.dimenosys.com/wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg?Expires=1601020925&OSSAccessKeyId=LTAI4FwRosaByiTNJDUdefmD&Signature=SH3rnVrkfrIhG0Vho5LHPnzvdS4%3D
             * fileSource : 3
             * fileUrl : wisdom-urban-manage/wisdom.urban.manage/android/1600927665632.jpg
             * id : 1309309218302214145
             * updateTime : 2020-09-25 09:50:15
             * updateUser : 1308613965165461505
             */

            public String caseReportId;
            public String createTime;
            public String createUser;
            public String fileShowUrl;
            public int fileSource;
            public String fileUrl;
            public String id;
            public String updateTime;
            public String updateUser;

        }
    }
}
