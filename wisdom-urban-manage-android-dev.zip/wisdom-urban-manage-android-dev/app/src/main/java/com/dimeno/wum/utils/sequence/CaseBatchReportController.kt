package com.dimeno.wum.utils.sequence

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.dimeno.commons.json.JsonUtils
import com.dimeno.commons.utils.T
import com.dimeno.network.base.Task
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.MainActivity
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.FileSource
import com.dimeno.wum.entity.CaseReportFileEntity
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.network.task.CaseReportTask
import com.dimeno.wum.ui.adapter.CaseStashAdapter
import com.dimeno.wum.utils.ActivityManager
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.OSSManager
import com.dimeno.wum.viewmodel.CaseStashViewModel
import com.dimeno.wum.viewmodel.IndexViewModel
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceTask
import java.io.File

/**
 * CaseBatchReportController
 * Created by wangzhen on 2020/9/18.
 */
class CaseBatchReportController(val list: MutableList<CaseStashEntity>, val adapter: CaseStashAdapter?) : SequenceTask() {
    private var total: Int = 0
    private var size: Int = 0

    override fun run() {
        total = list.size
        for (i in list.indices) {
            report(list[i])
        }
    }

    private fun report(entity: CaseStashEntity) {
        CaseReportTask(object : LoadingCallback<String>() {
            override fun onSuccess(data: String) {
                size++
                if (size >= total) {
                    DialogManager.get().stopLoading()
                    T.show("上报成功")
                    DBLoader.load(CaseStashEntity::class.java).remove(list)
                    adapter?.run {
                        datas.removeAll(list)
                        notifyDataSetChanged()
                    }
                    // 同步更新操作按钮状态
                    ViewModelProvider(activity() as ViewModelStoreOwner).get(CaseStashViewModel::class.java).onMultiCheckChange()
                    // 同步刷新首页数据
                    ActivityManager.get(MainActivity::class.java)?.let {
                        ViewModelProvider(it as ViewModelStoreOwner).get(IndexViewModel::class.java).refreshIndex()
                    }
                }
            }

            override fun onError(code: Int, message: String) {
                T.show(message)
                DialogManager.get().stopLoading()
            }
        }).setTag(activity()).apply {
            buildParams(this, entity)
        }.exe()
    }

    private fun buildParams(task: Task, entity: CaseStashEntity): Task {
        return task.put("caseType", entity.typeCode)
                .put("bigClass", entity.bigClassCode)
                .put("smallClass", entity.smallClassCode)
                .put("smallClassOtherName", entity.smallClassName)
                .put("address", entity.address)
                .put("latitude", entity.latitude)
                .put("longitude", entity.longitude)
                .put("description", entity.description)
                .put("caseFilesList", fileList(entity.pictures))
                .put("createUser", entity.userId)
                .put("createTime", entity.createTime)
                .put("updateUser", entity.userId)
                .put("updateTime", entity.updateTime)
                .put("taskId", entity.taskId)
                .put("id", entity.caseId)
                .put("generalSurveyId", entity.generalSurveyId)
    }

    private fun fileList(files: String): MutableList<CaseReportFileEntity> {
        val fileList: MutableList<CaseReportFileEntity> = mutableListOf()
        JsonUtils.parseArray(files, String::class.java)?.let {
            for (i in it.indices) {
                fileList.add(CaseReportFileEntity().apply {
                    fileUrl = "${OSSManager.get().directory}${File.separator}android${File.separator}${File(it[i]).name}"
                    createUser = UserBiz.get().userId
                    createTime = System.currentTimeMillis().toString()
                    updateUser = createUser
                    updateTime = createTime
                    fileSource = FileSource.REPORT
                })
            }
        }
        return fileList
    }
}