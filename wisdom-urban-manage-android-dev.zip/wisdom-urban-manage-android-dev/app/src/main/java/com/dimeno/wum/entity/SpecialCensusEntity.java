package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class SpecialCensusEntity implements Serializable {


    /**
     * code : 200
     * data : [{"address":"大连市中山区学士街与春生街交叉路口往西约50米(春德小区)","alreadyNum":0,"surveyTimeEnd":"2020-10-10 00:00:00","surveyTimeStart":"2020-10-09 00:00:00","surveyContext":"wrrrrrrer","updateUser":null,"updateTime":null,"surveyUserid":"1309031748068024321","caseType":1,"smallClassName":"上水井盖","smallClass":"A1","caseTypeName":"部件","bigClassName":"市政公用设施","uploadTimeEnd":"2020-10-11 00:00:00","photographRequire":"ewefdsff","createTime":null,"taskArea":"210202001002","noteMatter":"ttrettert","createUser":null,"id":"1314406010479616001","descriptionFormat":"aaa","bigClass":"01","status":0},{"address":"大连市中山区海军广场街道春景社区居民委员会","alreadyNum":0,"surveyTimeEnd":"2020-10-10 00:00:00","surveyTimeStart":"2020-10-09 00:00:00","surveyContext":"问问","updateUser":"1","updateTime":"2020-10-09 15:27:52","surveyUserid":"1309031748068024321","caseType":1,"smallClassName":"上水井盖","smallClass":"A1","caseTypeName":"部件","bigClassName":"市政公用设施","uploadTimeEnd":"2020-10-09 00:00:00","photographRequire":"额额人人","createTime":"2020-10-09 15:27:52","taskArea":"210202001003","noteMatter":" 恰逢剃光头谷歌 ","createUser":"1","id":"1314467598339284994","descriptionFormat":"           各方托付给","bigClass":"01","status":0}]
     * message : 请求成功
     * success : true
     */

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;

    public static class DataBean implements Serializable {
        /**
         * address : 大连市中山区学士街与春生街交叉路口往西约50米(春德小区)
         * alreadyNum : 0
         * surveyTimeEnd : 2020-10-10 00:00:00
         * surveyTimeStart : 2020-10-09 00:00:00
         * surveyContext : wrrrrrrer
         * updateUser : null
         * updateTime : null
         * surveyUserid : 1309031748068024321
         * caseType : 1
         * smallClassName : 上水井盖
         * smallClass : A1
         * caseTypeName : 部件
         * bigClassName : 市政公用设施
         * uploadTimeEnd : 2020-10-11 00:00:00
         * photographRequire : ewefdsff
         * createTime : null
         * taskArea : 210202001002
         * noteMatter : ttrettert
         * createUser : null
         * id : 1314406010479616001
         * descriptionFormat : aaa
         * bigClass : 01
         * status : 0
         */

        public String address;
        public int alreadyNum;
        public String surveyTimeEnd;
        public String surveyTimeStart;
        public String surveyContext;
        public String updateUser;
        public String updateTime;
        public String surveyUserid;
        public int caseType;
        public String smallClassName;
        public String smallClass;
        public String caseTypeName;
        public String bigClassName;
        public String uploadTimeEnd;
        public String photographRequire;
        public String createTime;
        public String taskArea;
        public String noteMatter;
        public String createUser;
        public String id;
        public String descriptionFormat;
        public String bigClass;
        public int status;
        public double latitude;
        public double longitude;
    }
}
