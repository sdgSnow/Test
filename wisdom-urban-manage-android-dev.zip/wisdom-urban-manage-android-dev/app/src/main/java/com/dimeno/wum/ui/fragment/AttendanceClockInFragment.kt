package com.dimeno.wum.ui.fragment

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dimeno.commons.utils.T
import com.dimeno.permission.PermissionManager
import com.dimeno.permission.callback.AbsPermissionCallback
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.Code
import com.dimeno.wum.entity.db.AttendanceHistory
import com.dimeno.wum.entity.db.AttendanceHistory_
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.DateUtils
import com.dimeno.wum.utils.location.LocationManager
import com.dimeno.wum.widget.dialog.ConfirmDialog
import com.dimeno.wum.widget.dialog.DialogManager
import io.objectbox.Box
import kotlinx.android.synthetic.main.fragment_attendance_clock_in_layout.*
import java.util.*

/**
 * 打卡
 * Created by wangzhen on 2020/9/19.
 */
class AttendanceClockInFragment : Fragment() {
    private var requireGoWork: Long = 0 // 08:30
    private var clockInGoWork: Long = 0
    private var addressGoWork: String? = null

    private var requireOffWork: Long = 0 // 17:30
    private var clockInOffWork: Long = 0
    private var addressOffWork: String? = null

    private val box: Box<AttendanceHistory> = DBLoader.load(AttendanceHistory::class.java)
    private var entity: AttendanceHistory? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_attendance_clock_in_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        request()
        location()
        handler.sendEmptyMessage(0x01)
    }

    private fun request() {
        // 查询打卡记录
        box.query().apply {
            equal(AttendanceHistory_.userId, UserBiz.get().userId)
            equal(AttendanceHistory_.dateString, DateUtils.format(System.currentTimeMillis(), "yyyy-MM-dd"))
        }.build().findFirst()?.let { record ->
            this@AttendanceClockInFragment.entity = record
            if (record.requireGoWork > 0)
                requireGoWork = record.requireGoWork
            clockInGoWork = record.clockInGoWork
            addressGoWork = record.addressGoWork

            if (record.requireOffWork > 0)
                requireOffWork = record.requireOffWork
            clockInOffWork = record.clockInOffWork
            addressOffWork = record.addressOffWork
        }

        // 上班时间
        tv_require_go_work.text = String.format("上班时间%s", DateUtils.format(requireGoWork, "HH:mm"))
        if (clockInGoWork == 0L) {
            tv_clock_in_go_work.text = "未打卡"
            tv_address_go_work.visibility = View.GONE
            tv_go_work_status.visibility = View.GONE
        } else {
            tv_go_work_status.visibility = View.VISIBLE
            tv_address_go_work.visibility = View.VISIBLE

            tv_clock_in_go_work.text = String.format("打卡时间%s", DateUtils.format(clockInGoWork, "HH:mm"))
            tv_address_go_work.text = addressGoWork

            tv_go_work_status.text = if (clockInGoWork <= requireGoWork) "正常" else "迟到"
            tv_go_work_status.setBackgroundResource(if (clockInGoWork <= requireGoWork) R.drawable.attendance_clock_in_normal else R.drawable.attendance_clock_in_abnormal)
        }

        // 下班时间
        tv_require_off_work.text = String.format("下班时间%s", DateUtils.format(requireOffWork, "HH:mm"))
        if (clockInOffWork == 0L) {
            tv_clock_in_off_work.text = "未打卡"
            tv_address_off_work.visibility = View.GONE
            tv_off_work_status.visibility = View.GONE
        } else {
            tv_address_off_work.visibility = View.VISIBLE
            tv_off_work_status.visibility = View.VISIBLE

            tv_clock_in_off_work.text = String.format("打卡时间%s", DateUtils.format(clockInOffWork, "HH:mm"))
            tv_address_off_work.text = addressOffWork

            tv_off_work_status.text = if (clockInOffWork >= requireOffWork) "正常" else "早退"
            tv_off_work_status.setBackgroundResource(if (clockInOffWork >= requireOffWork) R.drawable.attendance_clock_in_normal else R.drawable.attendance_clock_in_abnormal)
        }
    }

    private fun initViews() {
        requireGoWork = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        requireOffWork = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 17)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        btn_clock_in.setOnClickListener { handle() }
    }

    private fun handle() {
        // 判断工作时间是否过半
        val overHalf = (System.currentTimeMillis() - requireGoWork) > (requireOffWork - requireGoWork) / 2
        if (!overHalf) {
            // 上班打卡
            if (clockInGoWork == 0L) {
                DialogManager.get().showLoading()
                LocationManager.get().callback { location ->
                    DialogManager.get().stopLoading()
                    box.put(AttendanceHistory().apply {
                        userId = UserBiz.get().userId

                        requireGoWork = this@AttendanceClockInFragment.requireGoWork
                        requireOffWork = this@AttendanceClockInFragment.requireOffWork

                        clockInGoWork = System.currentTimeMillis()
                        addressGoWork = location.address

                        createTime = clockInGoWork
                        updateTime = createTime
                        dateString = DateUtils.format(createTime, "yyyy-MM-dd")
                    })
                    request()
                    T.show("上班打卡成功")
                }.locate()
            } else {
                T.show("已经打过上班卡啦")
            }
        } else {
            // 下班打卡
            entity?.let {
                DialogManager.get().showLoading()
                LocationManager.get().callback { location ->
                    DialogManager.get().stopLoading()
                    box.put(it.apply {
                        clockInOffWork = System.currentTimeMillis()
                        addressOffWork = location.address
                        updateTime = clockInOffWork
                    })
                    request()
                    T.show("下班打卡成功")
                }.locate()
            } ?: let {
                // 上班缺卡，新建下班打卡记录
                DialogManager.get().showLoading()
                LocationManager.get().callback { location ->
                    DialogManager.get().stopLoading()
                    box.put(AttendanceHistory().apply {
                        userId = UserBiz.get().userId
                        requireGoWork = this@AttendanceClockInFragment.requireGoWork
                        requireOffWork = this@AttendanceClockInFragment.requireOffWork

                        clockInOffWork = System.currentTimeMillis()
                        addressOffWork = location.address

                        createTime = clockInOffWork
                        updateTime = clockInOffWork
                        dateString = DateUtils.format(createTime, "yyyy-MM-dd")
                    })
                    request()
                    T.show("下班打卡成功")
                }.locate()
            }
        }
    }

    private fun location() {
        PermissionManager.request(this, object : AbsPermissionCallback() {
            override fun onGrant(permissions: Array<out String>?) {
                DialogManager.get().showLoading()
                LocationManager.get().callback {
                    DialogManager.get().stopLoading()
                    tv_address.text = it.address
                }.locate()
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                activity?.supportFragmentManager?.let {
                    ConfirmDialog().setTitle("权限提示").setMessage("为了正常打卡，请授予定位权限").setRightText("授予权限")
                            .setCallback(object : ConfirmDialog.Callback {
                                override fun onCancel() {
                                    activity?.finish()
                                }

                                override fun onConfirm() {
                                    startActivityForResult(PermissionManager.getSettingIntent(context), Code.CODE_SETTING)
                                }
                            })
                            .show(it)
                }
            }
        }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            tv_time_tick.text = DateUtils.format(System.currentTimeMillis(), "HH:mm:ss")
            sendEmptyMessageDelayed(0x01, 1000)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Code.CODE_SETTING) {
            location()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeMessages(0x01)
    }
}