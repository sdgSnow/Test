package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseCheckProcedureBean;
import com.dimeno.wum.ui.bean.CaseDetailsBean;

public class CaseCheckProcedureViewHolder extends RecyclerViewHolder<CaseCheckProcedureBean> {

    private final TextView tv_case_details_name;
    private final TextView case_details_desc;

    public CaseCheckProcedureViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_case_check_procedure);
        tv_case_details_name = findViewById(R.id.tv_case_details_name);
        case_details_desc = findViewById(R.id.case_details_desc);
    }

    @Override
    public void bind() {
        tv_case_details_name.setText(mData.name);
        case_details_desc.setText(mData.desc);
    }
}
