package com.dimeno.wum.common;

/**
 * IndexTaskType
 * Created by sdg on 2020/9/19.
 * 首页的任务列表点击事件
 */
public class IndexTaskType {

    public static final int ATTENDANCE = 0;//考勤打卡
    public static final int CASE_QUERY = 1;//案件查询
    public static final int CASE_CHECK = 2;//案件核实
    public static final int CASE_RE_CHECK = 3;//案件复核
    public static final int MY_TASK = 4;//我的任务
    public static final int MAP_MANAGER = 5;//地图管理
    public static final int SPECIAL_CENSUS = 6;//专项普查

    public static final int CASE_MANAGER = 10;//案件管理
    public static final int CASE_STATISTIC = 20;//案件统计
    public static final int LEADER_MAP_MANAGER = 30;//领导端地图管理
    public static final int ASSESSMENT_EVALUATION = 40;//考核评价
    public static final int CITY_QUES = 50;//城市问题
}
