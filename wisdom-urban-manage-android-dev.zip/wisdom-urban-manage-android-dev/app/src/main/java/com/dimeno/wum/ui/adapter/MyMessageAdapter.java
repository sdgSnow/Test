package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.MessageEntity;
import com.dimeno.wum.entity.MyMessageEntity;
import com.dimeno.wum.entity.MyTaskEntity;
import com.dimeno.wum.network.task.MyTaskTask;
import com.dimeno.wum.ui.adapter.holder.MessageTimeViewHolder;
import com.dimeno.wum.ui.adapter.holder.MessageViewHolder;
import com.dimeno.wum.ui.adapter.holder.MyMessageHolder;
import com.dimeno.wum.ui.adapter.holder.MyTaskHolder;
import com.dimeno.wum.ui.bean.MyMessageBean;

import java.util.ArrayList;
import java.util.List;

public class MyMessageAdapter extends LoadRecyclerAdapter<MyMessageBean> {

    private int page = 1;

    public MyMessageAdapter(List<MyMessageBean> list, RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
//        switch (viewType){
//            case MessageEntity.TYPE_TIME:
//                return new MessageTimeViewHolder(parent);
//            case MessageEntity.TYPE_DATA:
//                return new MessageViewHolder(parent);
//        }
        return new MyMessageHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new MyTaskTask(new LoadingCallback<MyMessageEntity>() {
            @Override
            public void onSuccess(MyMessageEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<MyMessageBean> addList = new ArrayList<>();
                    for (MyMessageEntity.DataBean datum : data.data) {
                        MyMessageBean myMessageBean = new MyMessageBean();
                        myMessageBean.msg = datum.msg;
                        myMessageBean.caseReportId = datum.caseReportId;
                        myMessageBean.caseMsgType = datum.caseMsgType;
                        myMessageBean.msgType = datum.msgType;
                        myMessageBean.createTime = datum.createTime;
                        myMessageBean.updateUser = datum.updateUser;
                        myMessageBean.createUser = datum.createUser;
                        myMessageBean.updateTime = datum.updateTime;
                        myMessageBean.id = datum.id;
                        myMessageBean.title = datum.title;
                        myMessageBean.userId = datum.userId;
                        myMessageBean.url = datum.url;
                        addList.add(myMessageBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
