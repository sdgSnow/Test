package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseQueryEntity;
import com.dimeno.wum.entity.MyTaskEntity;
import com.dimeno.wum.network.task.CaseQueryListTask;
import com.dimeno.wum.network.task.MyTaskTask;
import com.dimeno.wum.ui.adapter.holder.CaseQueryHolder;
import com.dimeno.wum.ui.adapter.holder.MyTaskHolder;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.ui.bean.MyTaskBean;

import java.util.ArrayList;
import java.util.List;

public class MyTaskAdapter extends LoadRecyclerAdapter<MyTaskBean> {

    private int page = 1;

    public MyTaskAdapter(List<MyTaskBean> list,RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyTaskHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new MyTaskTask(new LoadingCallback<MyTaskEntity>() {
            @Override
            public void onSuccess(MyTaskEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<MyTaskBean> addList = new ArrayList<>();
                    for (MyTaskEntity.DataBean datum : data.data) {
                        MyTaskBean myTaskBean = new MyTaskBean();
                        myTaskBean.reportNum = datum.reportNum;
                        myTaskBean.address = datum.address;
                        myTaskBean.alreadyNum = datum.alreadyNum;
                        myTaskBean.assignUserId = datum.assignUserId;
                        myTaskBean.description = datum.description;
                        myTaskBean.updateUser = datum.updateUser;
                        myTaskBean.updateTime = datum.updateTime;
                        myTaskBean.caseType = datum.caseType;
                        myTaskBean.timeLimit = datum.timeLimit;
                        myTaskBean.smallClassName = datum.smallClassName;
                        myTaskBean.smallClass = datum.smallClass;
                        myTaskBean.caseTypeName = datum.caseTypeName;
                        myTaskBean.bigClassName = datum.bigClassName;
                        myTaskBean.createTime = datum.createTime;
                        myTaskBean.taskArea = datum.taskArea;
                        myTaskBean.taskName = datum.taskName;
                        myTaskBean.createUser = datum.createUser;
                        myTaskBean.id = datum.id;
                        myTaskBean.bigClass = datum.bigClass;
                        myTaskBean.status = datum.status;
                        addList.add(myTaskBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
