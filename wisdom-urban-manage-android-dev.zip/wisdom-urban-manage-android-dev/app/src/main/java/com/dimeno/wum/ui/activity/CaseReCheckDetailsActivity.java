package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.Code;
import com.dimeno.wum.common.DealStatus;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.Verify;
import com.dimeno.wum.entity.CaseDetailsEntity;
import com.dimeno.wum.network.task.CaseDetailsTask;
import com.dimeno.wum.ui.bean.CaseCheckDetailsHeaderBean;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;
import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.listener.OnPageChangeListener;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseCheckDetailsActivity
 * Created by sdg on 2020/9/17.
 * 案件核实详情
 */
public class CaseReCheckDetailsActivity extends BaseActivity implements View.OnClickListener {

    private Banner banner;
    private List<CaseCheckDetailsHeaderBean> caseCheckDetailsHeaderBeans;
    private TextView tv_select_picture;
    private TextView tv_deal_ago;
    private TextView tv_deal_after;
    private String id;
    private TextView case_type_name;
    private TextView case_responsible_unit;
    private TextView case_check_location;
    private TextView case_check_procedure_time;
    private TextView case_result_desc;
    private LinearLayout ll_case_re_check_un_pass;
    private LinearLayout ll_case_re_check_pass;
    private View tv_step;
    private ImageView iv_re_check_un_pass;
    private ImageView iv_re_check_pass;
    private int passValue = 0;
    private int dealType = 0;//处理状态：0为处理前；1为处理后

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_recheck_details);
        fitDarkStatusBar(true);
        banner = findViewById(R.id.banner_picture);
        tv_select_picture = findViewById(R.id.tv_select_picture);
        tv_deal_ago = findViewById(R.id.tv_deal_ago);
        tv_deal_after = findViewById(R.id.tv_deal_after);
        case_type_name = findViewById(R.id.case_type_name);
        case_responsible_unit = findViewById(R.id.case_responsible_unit);
        case_check_location = findViewById(R.id.case_check_location);
        case_check_procedure_time = findViewById(R.id.case_check_procedure_time);
        case_result_desc = findViewById(R.id.case_result_desc);
        ll_case_re_check_un_pass = findViewById(R.id.ll_case_re_check_un_pass);
        ll_case_re_check_pass = findViewById(R.id.ll_case_re_check_pass);
        tv_step = findViewById(R.id.tv_next_step);
        tv_step.setEnabled(false);
        iv_re_check_un_pass = findViewById(R.id.iv_re_check_un_pass);
        iv_re_check_pass = findViewById(R.id.iv_re_check_pass);

        ll_case_re_check_un_pass.setOnClickListener(this::onClick);
        ll_case_re_check_pass.setOnClickListener(this::onClick);
        tv_deal_ago.setOnClickListener(this::onClick);
        tv_deal_after.setOnClickListener(this::onClick);
        tv_step.setOnClickListener(this::onClick);

        id = getIntent().getStringExtra("id");
        getCaseDetail();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案件复核详情");
    }

    /**
     * 获取案例详情
     */
    private void getCaseDetail() {
        new CaseDetailsTask(new LoadingCallback<CaseDetailsEntity>() {
            @Override
            public void onSuccess(CaseDetailsEntity data) {
                if (data.data != null) {
                    case_type_name.setText(data.data.caseTypeName);
                    case_responsible_unit.setText(data.data.unitName);
                    case_check_location.setText(data.data.address);
                    case_check_procedure_time.setText(data.data.createTime);
                    case_result_desc.setText(data.data.description);
                    if (dealType == 0) {
                        initDealAgo(data);
                    } else {
                        initDealAfter(data);
                    }
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("id", id)
                .exe();
    }

    //初始化处理前的图片列表数据
    private void initDealAgo(CaseDetailsEntity data) {
        caseCheckDetailsHeaderBeans = new ArrayList<>();
        if (data.data.caseFilesList != null) {
            for (CaseDetailsEntity.DataBean.CaseFilesListBean caseFilesListBean : data.data.caseFilesList) {
                CaseCheckDetailsHeaderBean caseCheckDetailsHeaderBean = new CaseCheckDetailsHeaderBean();
                caseCheckDetailsHeaderBean.caseReportId = caseFilesListBean.caseReportId;
                caseCheckDetailsHeaderBean.createTime = caseFilesListBean.createTime;
                caseCheckDetailsHeaderBean.createUser = caseFilesListBean.createUser;
                caseCheckDetailsHeaderBean.fileShowUrl = caseFilesListBean.fileShowUrl;
                caseCheckDetailsHeaderBean.fileSource = caseFilesListBean.fileSource;
                caseCheckDetailsHeaderBean.fileUrl = caseFilesListBean.fileUrl;
                caseCheckDetailsHeaderBean.id = caseFilesListBean.id;
                caseCheckDetailsHeaderBean.updateTime = caseFilesListBean.updateTime;
                caseCheckDetailsHeaderBean.updateUser = caseFilesListBean.updateUser;
                caseCheckDetailsHeaderBeans.add(caseCheckDetailsHeaderBean);
            }
        }
        String format = String.format("%s/%s", 1, caseCheckDetailsHeaderBeans.size());
        tv_select_picture.setText(format);
        showBanner();
    }

    //初始化处理后的图片列表数据
    private void initDealAfter(CaseDetailsEntity data) {
        caseCheckDetailsHeaderBeans = new ArrayList<>();
        if (data.data.rectifyFilesList != null) {
            for (CaseDetailsEntity.DataBean.RectifyFilesListBean rectifyFilesListBean : data.data.rectifyFilesList) {
                CaseCheckDetailsHeaderBean caseCheckDetailsHeaderBean = new CaseCheckDetailsHeaderBean();
                caseCheckDetailsHeaderBean.caseReportId = rectifyFilesListBean.caseReportId;
                caseCheckDetailsHeaderBean.createTime = rectifyFilesListBean.createTime;
                caseCheckDetailsHeaderBean.createUser = rectifyFilesListBean.createUser;
                caseCheckDetailsHeaderBean.fileShowUrl = rectifyFilesListBean.fileShowUrl;
                caseCheckDetailsHeaderBean.fileSource = rectifyFilesListBean.fileSource;
                caseCheckDetailsHeaderBean.fileUrl = rectifyFilesListBean.fileUrl;
                caseCheckDetailsHeaderBean.id = rectifyFilesListBean.id;
                caseCheckDetailsHeaderBean.updateTime = rectifyFilesListBean.updateTime;
                caseCheckDetailsHeaderBean.updateUser = rectifyFilesListBean.updateUser;
                caseCheckDetailsHeaderBeans.add(caseCheckDetailsHeaderBean);
            }
        }
        String format = String.format("%s/%s", 1, caseCheckDetailsHeaderBeans.size());
        tv_select_picture.setText(format);
        showBanner();
    }

    private void showBanner() {
        banner.isAutoLoop(false);//禁止自动滑动
        banner.setAdapter(new BannerImageAdapter<CaseCheckDetailsHeaderBean>(caseCheckDetailsHeaderBeans) {
            @Override
            public void onBindView(BannerImageHolder holder, CaseCheckDetailsHeaderBean data, int position, int size) {
                //图片加载自己实现
                Glide.with(holder.itemView)
                        .load(data.fileShowUrl)
                        .into(holder.imageView);
            }
        }).setIndicator(new CircleIndicator(CaseReCheckDetailsActivity.this));
        banner.setOnBannerListener((_data, position) -> {
            if (caseCheckDetailsHeaderBeans == null)
                return;
            ArrayList<String> urls = new ArrayList<>();
            for (CaseCheckDetailsHeaderBean bean : caseCheckDetailsHeaderBeans)
                urls.add(bean.fileShowUrl);
            startActivity(new Intent(CaseReCheckDetailsActivity.this, PicturePreviewActivity.class)
                    .putStringArrayListExtra(IKey.DATA, urls).putExtra(IKey.POSITION, position));
        });
        banner.addOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                String format = String.format("%s/%s", position + 1, caseCheckDetailsHeaderBeans.size());
                tv_select_picture.setText(format);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_case_re_check_un_pass:
                iv_re_check_un_pass.setImageResource(R.mipmap.ic_checkbox_check);
                iv_re_check_pass.setImageResource(R.mipmap.ic_checkbox_uncheck);
                passValue = Verify.NO_PASS;
                tv_step.setEnabled(true);
                break;
            case R.id.ll_case_re_check_pass:
                iv_re_check_pass.setImageResource(R.mipmap.ic_checkbox_check);
                iv_re_check_un_pass.setImageResource(R.mipmap.ic_checkbox_uncheck);
                passValue = Verify.PASS;
                tv_step.setEnabled(true);
                break;
            case R.id.tv_next_step:
                if (passValue == Verify.NO_PASS) {
                    Intent intent = new Intent(CaseReCheckDetailsActivity.this, UnVerifyActivity.class);
                    intent.putExtra("caseReportId", id);
                    intent.putExtra("type", Verify.TYPE_RECHECK);
                    intent.putExtra("verifyType", Verify.NO_PASS);
                    startActivityForResult(intent, Code.CODE_UNPASS_REPORT);
                } else if (passValue == Verify.PASS) {
                    Intent intent = new Intent(CaseReCheckDetailsActivity.this, UnVerifyActivity.class);
                    intent.putExtra("caseReportId", id);
                    intent.putExtra("type", Verify.TYPE_RECHECK);
                    intent.putExtra("verifyType", Verify.PASS);
                    startActivityForResult(intent, Code.CODE_REPORT);
                }
                break;
            case R.id.tv_deal_ago:
                if (dealType != DealStatus.DEAL_AGO) {
                    dealType = DealStatus.DEAL_AGO;
                    tv_deal_ago.setBackgroundResource(R.drawable.btn_deal_choose);
                    tv_deal_after.setBackgroundResource(R.drawable.btn_deal_unchoose);
                    getCaseDetail();
                }
                break;
            case R.id.tv_deal_after:
                if (dealType != DealStatus.DEAL_AFTER) {
                    dealType = DealStatus.DEAL_AFTER;
                    tv_deal_ago.setBackgroundResource(R.drawable.btn_deal_unchoose);
                    tv_deal_after.setBackgroundResource(R.drawable.btn_deal_choose);
                    getCaseDetail();
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @androidx.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Code.CODE_REPORT) {
            if (resultCode == Code.CODE_REPORT_SUCCESS) {
                startActivity(new Intent(CaseReCheckDetailsActivity.this, CaseReCheckActivity.class));
            }
        }
        if (requestCode == Code.CODE_UNPASS_REPORT) {
            if (resultCode == Code.CODE_REPORT_SUCCESS) {
                startActivity(new Intent(CaseReCheckDetailsActivity.this, CaseReCheckActivity.class));
            }
        }
    }
}