package com.dimeno.wum.utils;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;

/**
 *  recycleview的间距设置
 * */
public class SpaceItemDecoration extends RecyclerView.ItemDecoration {
    private HashMap<String, Integer> mSpaceValueMap;
    public static final String TOP_DECORATION = "top_decoration";
    public static final String BOTTOM_DECORATION = "bottom_decoration";
    public static final String LEFT_DECORATION = "left_decoration";
    public static final String RIGHT_DECORATION = "right_decoration";
    public SpaceItemDecoration(HashMap<String, Integer> mSpaceValueMap){
        this.mSpaceValueMap = mSpaceValueMap;
    }
    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        if (mSpaceValueMap.get(TOP_DECORATION) != null)
            outRect.top = mSpaceValueMap.get(TOP_DECORATION);
        if (mSpaceValueMap.get(LEFT_DECORATION) != null)
            outRect.left = mSpaceValueMap.get(LEFT_DECORATION);
        if (mSpaceValueMap.get(RIGHT_DECORATION) != null)
            outRect.right = mSpaceValueMap.get(RIGHT_DECORATION);
        if (mSpaceValueMap.get(BOTTOM_DECORATION) != null)
            outRect.bottom = mSpaceValueMap.get(BOTTOM_DECORATION);
    }

    public static RecyclerView.ItemDecoration setItemDecoration(Context mContext, int top, int bottom, int left, int right){
        HashMap<String, Integer> stringIntegerHashMap = new HashMap<>();
        stringIntegerHashMap.put(SpaceItemDecoration.TOP_DECORATION, DensityUtil.px2dip(mContext, top));//top间距
        stringIntegerHashMap.put(SpaceItemDecoration.BOTTOM_DECORATION, DensityUtil.px2dip(mContext, bottom));//底部间距
        stringIntegerHashMap.put(SpaceItemDecoration.LEFT_DECORATION, DensityUtil.px2dip(mContext, left));//左间距
        stringIntegerHashMap.put(SpaceItemDecoration.RIGHT_DECORATION, DensityUtil.px2dip(mContext, right));//右间距
        return new SpaceItemDecoration(stringIntegerHashMap);
    }
}
