package com.dimeno.wum.ui.activity

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.entity.MessageDataEntity
import com.dimeno.wum.entity.MessageEntity
import com.dimeno.wum.entity.MessageTimeEntity
import com.dimeno.wum.ui.adapter.MessageAdapter
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import com.wangzhen.refresh.callback.OnRefreshCallback
import kotlinx.android.synthetic.main.activity_message.*

/**
 * message activity
 * Created by wangzhen on 2020/9/27.
 */
class MessageActivity : BaseActivity(), OnRefreshCallback {
    private var adapter: MessageAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)
        fitDarkStatusBar(true)
        initViews()
        request()
    }

    private fun request() {
        val list = mutableListOf<MessageEntity>().apply {
            for (i in 0 until 10) {
                if (i % 2 == 0)
                    add(MessageTimeEntity().apply {
                        time = System.currentTimeMillis()
                    })
                add(MessageDataEntity().apply {
                    content = "您提交的案件编号：深城管2020字第1001号已立案，感谢您的工作支持"
                })
            }
        }
        adapter?.setData(list) ?: let {
            recycler.adapter = MessageAdapter(list, recycler).apply {
                adapter = this
                setEmpty(object : RecyclerItem() {
                    override fun layout(): Int = R.layout.global_empty_layout

                    override fun onViewCreated(itemView: View?) {

                    }
                }.onCreateView(recycler))
            }
        }
        refresh_layout.refreshComplete()
    }

    private fun initViews() {
        refresh_layout.startRefresh()
        refresh_layout.setOnRefreshCallback(this)
        recycler.layoutManager = LinearLayoutManager(this)
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, getString(R.string.mine_message))
    }

    override fun onRefresh() {
        request()
    }
}