package com.dimeno.wum.entity.db

import io.objectbox.annotation.Entity
import io.objectbox.annotation.Id
import java.io.Serializable

/**
 * case big class entity
 * Created by wangzhen on 2020/9/23.
 */
@Entity
class CaseBigClassEntity : Serializable {
    @Id
    var id: Long = 0
    var code: String? = null
    var name: String? = null
    var topcode: String? = null
}