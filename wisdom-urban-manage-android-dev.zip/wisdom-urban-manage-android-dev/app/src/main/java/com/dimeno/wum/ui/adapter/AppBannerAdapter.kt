package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.ui.bean.IndexHeaderBean
import com.wangzhen.circle.CircleImageView
import com.youth.banner.adapter.BannerImageAdapter
import com.youth.banner.holder.BannerImageHolder

/**
 * app banner adapter
 * Created by wangzhen on 2020/9/22.
 */
class AppBannerAdapter(list: MutableList<IndexHeaderBean>) : BannerImageAdapter<IndexHeaderBean>(list) {
    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BannerImageHolder {
        return BannerImageHolder(CircleImageView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setRadius(AppUtils.dip2px(3.3f).toFloat())
            val padding = AppUtils.dip2px(5f)
            setPadding(padding, padding, padding, padding)
        })
    }

    override fun onBindView(holder: BannerImageHolder, data: IndexHeaderBean, position: Int, size: Int) {
        Glide.with(holder.itemView)
                .load(data.imageUrl)
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(RequestOptions().placeholder(R.drawable.index_banner_picture_default).error(R.drawable.index_banner_picture_default))
                .into(holder.imageView)
    }
}