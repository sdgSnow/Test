package com.dimeno.wum.entity

import com.baidu.mapapi.search.route.DrivingRouteLine
import java.io.Serializable

/**
 * census map route entity
 * Created by wangzhen on 2020/10/28.
 */
class CensusMapRouteEntity : Serializable {
    var isSelected = false
    var data: DrivingRouteLine? = null
}