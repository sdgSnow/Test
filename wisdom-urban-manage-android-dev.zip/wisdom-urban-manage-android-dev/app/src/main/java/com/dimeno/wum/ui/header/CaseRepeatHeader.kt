package com.dimeno.wum.ui.header

import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.wum.R

/**
 * case repeat header
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatHeader : RecyclerItem() {
    override fun layout(): Int = R.layout.case_repeat_confirm_header
}