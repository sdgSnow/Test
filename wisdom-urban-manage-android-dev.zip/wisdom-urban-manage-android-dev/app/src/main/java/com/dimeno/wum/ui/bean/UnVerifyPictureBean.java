package com.dimeno.wum.ui.bean;

/**
 * UnVerifyPictureBean
 * Created by sdg on 2020/9/21.
 */
public class UnVerifyPictureBean {

    public String caseReportId;
    public String createTime;
    public String createUser;
    public String fileShowUrl;
    public int fileSource;
    public String fileUrl;
    public String fileLocalUrl;
    public String id;
    public String updateTime;
    public String updateUser;
}
