package com.dimeno.wum.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.common.TaskType;
import com.dimeno.wum.entity.CaseCompletedEntity;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.MyTaskEntity;
import com.dimeno.wum.entity.SpecialCensusEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseSmallClassEntity;
import com.dimeno.wum.entity.db.CaseSmallClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.network.task.CaseVerifyListTask;
import com.dimeno.wum.network.task.MyTaskTask;
import com.dimeno.wum.network.task.SpecialCensusTask;
import com.dimeno.wum.ui.activity.CaseCheckDetailsActivity;
import com.dimeno.wum.ui.activity.CensusDetailsActivity;
import com.dimeno.wum.ui.adapter.CaseCompletedAdapter;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.adapter.SpecialCensusAdapter;
import com.dimeno.wum.ui.bean.CaseCompletedBean;
import com.dimeno.wum.ui.bean.MyTaskBean;
import com.dimeno.wum.ui.bean.SpecialCensusBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseInfoFragment
 * Created by sdg on 2020/9/16.
 * 已办任务
 */
public class TaskCompletedFragment extends Fragment implements View.OnClickListener , OnRefreshCallback {

    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private String mCaseTypeCode = null;
    private String mBigClassCode = null;
    private List<CommonSpinnerEntity> typeList;
    private List<CommonSpinnerEntity> bigClassList;
    private RecyclerView rv_task_completed;
    private List<SpecialCensusBean> specialCensusBeans;
    private SpecialCensusAdapter specialCensusAdapter;
    private RefreshLayout refresh_layout;

    public static TaskCompletedFragment newInstance() {
        TaskCompletedFragment fragment = new TaskCompletedFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_task_completed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv_task_completed = view.findViewById(R.id.rv_task_completed);
        spinner_type = view.findViewById(R.id.spinner_type);
        spinner_big_class = view.findViewById(R.id.spinner_big_class);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        refresh_layout.startRefresh();

        initSpinner1();
        initSpinner2();
        initSelectListener();

        getMyTask();

    }

    private void initSpinner1() {
        //初始化案件类型数据
        typeList = createTypeList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                typeList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter1 = new CommonSpinnerAdapter(getActivity(), typeList);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化大类数据
        bigClassList = createBigClassList();
        if (mCaseTypeCode != null) {
            List<CaseBigClassEntity> caseBigClassEntities = DBLoader.load(CaseBigClassEntity.class).query().equal(CaseBigClassEntity_.topcode, mCaseTypeCode).build().find();
            if (caseBigClassEntities != null) {
                for (CaseBigClassEntity caseBigClassEntity : caseBigClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseBigClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseBigClassEntity.getName());
                    bigClassList.add(caseSpinnerEntity);
                }

            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter2 = new CommonSpinnerAdapter(getActivity(), bigClassList);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSelectListener() {
        //spineer的点击事件
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = typeList.get(i).getCode();
                mBigClassCode = null;
                initSpinner2();
                if(i == 0){
                    getMyTask();
                }
                if(mCaseTypeCode != null) {
                    getMyTask();
                }
            }
        });

        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mBigClassCode = bigClassList.get(i).getCode();
                if(i == 0){
                    getMyTask();
                }
                if(mBigClassCode != null) {
                    getMyTask();
                }
            }
        });

    }

    private List<CommonSpinnerEntity> createTypeList() {
        List<CommonSpinnerEntity> caseTypeList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity1 = new CommonSpinnerEntity();
        caseSpinnerEntity1.setName("案件类型");
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<CommonSpinnerEntity> createBigClassList() {
        List<CommonSpinnerEntity> bigClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity2 = new CommonSpinnerEntity();
        caseSpinnerEntity2.setName("案件大类");
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private void getMyTask() {
        new SpecialCensusTask(new LoadingCallback<SpecialCensusEntity>() {
            @Override
            public void onSuccess(SpecialCensusEntity data) {
                initTaskCompleted(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("caseType", mCaseTypeCode)
                .put("bigClass", mBigClassCode)
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("status", TaskType.STATUS_COMPLETED)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }


    private void initTaskCompleted(SpecialCensusEntity data) {
        specialCensusBeans = new ArrayList<>();
        if(data.data != null){
            for (SpecialCensusEntity.DataBean task : data.data) {
                SpecialCensusBean specialCensusBean = new SpecialCensusBean();
                specialCensusBean.address = task.address;
                specialCensusBean.alreadyNum = task.alreadyNum;
                specialCensusBean.alreadyNum = task.alreadyNum;
                specialCensusBean.surveyTimeStart = task.surveyTimeStart;
                specialCensusBean.surveyContext = task.surveyContext;
                specialCensusBean.updateUser = task.updateUser;
                specialCensusBean.updateTime = task.updateTime;
                specialCensusBean.surveyUserid = task.surveyUserid;
                specialCensusBean.caseType = task.caseType;
                specialCensusBean.smallClassName = task.smallClassName;
                specialCensusBean.smallClass = task.smallClass;
                specialCensusBean.caseTypeName = task.caseTypeName;
                specialCensusBean.bigClassName = task.bigClassName;
                specialCensusBean.uploadTimeEnd = task.uploadTimeEnd;
                specialCensusBean.photographRequire = task.photographRequire;
                specialCensusBean.createTime = task.createTime;
                specialCensusBean.createUser = task.createUser;
                specialCensusBean.taskArea = task.taskArea;
                specialCensusBean.noteMatter = task.noteMatter;
                specialCensusBean.id = task.id;
                specialCensusBean.descriptionFormat = task.descriptionFormat;
                specialCensusBean.bigClass = task.bigClass;
                specialCensusBean.status = task.status;
                specialCensusBeans.add(specialCensusBean);
            }
        }
        showTaskRemainDealList();
    }

    private void showTaskRemainDealList() {
        rv_task_completed.setLayoutManager(new GridLayoutManager(getActivity(),1,GridLayoutManager.VERTICAL,false));
        specialCensusAdapter = new SpecialCensusAdapter(specialCensusBeans,rv_task_completed);
        specialCensusAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_task_completed));
        rv_task_completed.setAdapter(specialCensusAdapter);
        specialCensusAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                Intent intent = new Intent(getActivity(), CensusDetailsActivity.class);
                intent.putExtra("id",specialCensusBeans.get(position).id);
                intent.putExtra(IKey.TASK_TYPE, TaskType.COMPLETED);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

        }
    }

    @Override
    public void onRefresh() {
        getMyTask();
    }
}