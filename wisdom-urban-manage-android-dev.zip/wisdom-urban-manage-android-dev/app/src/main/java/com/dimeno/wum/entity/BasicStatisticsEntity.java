package com.dimeno.wum.entity;

import java.io.Serializable;

public class BasicStatisticsEntity implements Serializable {


    /**
     * code : 200
     * data : {"curDayReportNum":1,"curWeekCloseNum":0,"curWeekReportNum":2,"curWeekCaseNum":0}
     * message : 请求成功！
     * success : true
     */

    public int code;
    public DataBean data;
    public String message;
    public boolean success;

    public static class DataBean implements Serializable{
        /**
         * curDayReportNum : 1
         * curWeekCloseNum : 0
         * curWeekReportNum : 2
         * curWeekCaseNum : 0
         */

        public int curDayReportNum;
        public int curWeekCloseNum;
        public int curWeekReportNum;
        public int curWeekCaseNum;

    }
}
