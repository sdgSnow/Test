package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.appcompat.widget.AppCompatEditText;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.entity.ChangePswEntity;
import com.dimeno.wum.network.task.ChangePswTask;
import com.dimeno.wum.widget.dialog.ConfirmDialog;
import com.dimeno.wum.widget.toolbar.AppTextMenuToolbar;
import com.dimeno.wum.widget.toolbar.OnToolbarCallback;

import org.jetbrains.annotations.Nullable;

public class ChangePswActivity extends BaseActivity {

    private AppCompatEditText et_old_psw;
    private AppCompatEditText et_new_psw;
    private AppCompatEditText et_new_psw_again;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_psw);
        fitDarkStatusBar(true);
        et_old_psw = findViewById(R.id.et_old_psw);
        et_new_psw = findViewById(R.id.et_new_psw);
        et_new_psw_again = findViewById(R.id.et_new_psw_again);
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        AppTextMenuToolbar toolbar = new AppTextMenuToolbar(this, "修改密码", "保存");
        toolbar.setCallback(new OnToolbarCallback() {
            @Override
            public void onMenuClick() {
                String oldPsw = et_old_psw.getText().toString().trim();
                String newPsw = et_new_psw.getText().toString().trim();
                String againPsw = et_new_psw_again.getText().toString().trim();
                if (TextUtils.isEmpty(oldPsw)) {
                    T.show("请输入旧密码");
                    return;
                }
                if (TextUtils.isEmpty(newPsw)) {
                    T.show("请输入新密码");
                    return;
                }
                if (TextUtils.isEmpty(againPsw)) {
                    T.show("请再次输入新密码");
                    return;
                }
                if (oldPsw.equals(newPsw)) {
                    T.show("新密码必须与旧密码不一致");
                    return;
                }
                if (!newPsw.equals(againPsw)) {
                    T.show("两次密码不一致");
                    return;
                }
                new ConfirmDialog().setTitle("提示").setMessage("是否确定更改密码?").setCallback(new ConfirmDialog.Callback() {
                    @Override
                    public void onCancel() {

                    }

                    @Override
                    public void onConfirm() {
                        changePwd(oldPsw, againPsw);
                    }
                }).show(ChangePswActivity.this.getSupportFragmentManager());

            }
        });
        return toolbar;
    }

    //获取新闻列表
    private void changePwd(String oldPsw, String againPsw) {
        new ChangePswTask(new LoadingCallback<ChangePswEntity>() {
            @Override
            public void onSuccess(ChangePswEntity data) {
                if (data != null) {
                    T.show(data.message);
                    UserBiz.get().clear();
                    finish();
                    startActivity(new Intent(ChangePswActivity.this, LoginActivity.class));
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("newPwd", againPsw)
                .put("oldPwd", oldPsw)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}