package com.dimeno.wum.ui.activity

import android.os.Bundle
import androidx.core.content.ContextCompat
import com.baidu.mapapi.map.*
import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.search.geocode.*
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.IKey
import com.dimeno.wum.widget.toolbar.AppTextMenuToolbar
import com.dimeno.wum.widget.toolbar.OnToolbarCallback
import kotlinx.android.synthetic.main.activity_case_report_map.*
import kotlinx.android.synthetic.main.activity_map_manage.map_view

/**
 * 案件上报修改位置
 * Created by wangzhen on 2020/9/23.
 */
class CaseReportMapActivity : BaseActivity() {
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_case_report_map)
        fitDarkStatusBar(true)
        initArgs()
        config()
        bind()
    }

    private fun initArgs() {
        latitude = intent.getDoubleExtra(IKey.LATITUDE, 0.0)
        longitude = intent.getDoubleExtra(IKey.LONGITUDE, 0.0)
        searchPoi()
    }

    private fun searchPoi() {
        GeoCoder.newInstance().run {
            setOnGetGeoCodeResultListener(object : OnGetGeoCoderResultListener {
                override fun onGetGeoCodeResult(result: GeoCodeResult) {

                }

                override fun onGetReverseGeoCodeResult(result: ReverseGeoCodeResult) {
                    val address = result.address + result.sematicDescription
                    tv_address.text = address
                }
            })
            reverseGeoCode(ReverseGeoCodeOption().location(LatLng(latitude, longitude)))
        }
    }

    private fun config() {
        map_view.apply {
            showZoomControls(false)
            map.setOnMapStatusChangeListener(object : BaiduMap.OnMapStatusChangeListener {
                override fun onMapStatusChangeStart(status: MapStatus) {

                }

                override fun onMapStatusChangeStart(status: MapStatus, reason: Int) {

                }

                override fun onMapStatusChange(status: MapStatus) {

                }

                override fun onMapStatusChangeFinish(status: MapStatus) {
                    latitude = status.target.latitude
                    longitude = status.target.longitude
                    searchPoi()
                }
            })
        }
    }

    private fun bind() {
        map_view.map.animateMapStatus(
                MapStatusUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15f)
        )
        UserBiz.get().coordinates?.map { entity ->
            LatLng(entity.latitude, entity.longitude)
        }?.let {
            if (it.size >= 3) {
                val colorSolid = ContextCompat.getColor(this, R.color.colorAccent)
                val colorStroke = ContextCompat.getColor(this, R.color.colorPrimary)
                map_view.map.apply {
                    addOverlay(PolygonOptions().points(it).fillColor(colorSolid).stroke(Stroke(5, colorStroke)))
                }
            }
        }
    }

    override fun createToolbar(): Toolbar? {
        return AppTextMenuToolbar(this, "修改位置", "确定").apply {
            setCallback(object : OnToolbarCallback() {
                override fun onMenuClick() {
                    setResult(Code.CODE_CHANGE_LOCATION_SUCCESS, intent.apply {
                        putExtra(IKey.ADDRESS, tv_address.text.toString())
                        putExtra(IKey.LATITUDE, latitude)
                        putExtra(IKey.LONGITUDE, longitude)
                    })
                    finish()
                }

            })
        }
    }
}