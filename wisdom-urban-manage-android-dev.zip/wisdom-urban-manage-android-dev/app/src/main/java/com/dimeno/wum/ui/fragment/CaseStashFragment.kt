package com.dimeno.wum.ui.fragment

import android.graphics.Rect
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.baidu.mapapi.model.LatLng
import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.commons.json.JsonUtils
import com.dimeno.commons.structure.IList
import com.dimeno.commons.utils.AppUtils
import com.dimeno.commons.utils.T
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.entity.CommonSpinnerEntity
import com.dimeno.wum.entity.db.*
import com.dimeno.wum.ui.adapter.CaseStashAdapter
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter
import com.dimeno.wum.utils.CaseValidator
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.sequence.CaseBatchPictureController
import com.dimeno.wum.utils.sequence.CaseBatchReportController
import com.dimeno.wum.viewmodel.CaseStashViewModel
import com.dimeno.wum.widget.abs.AbsItemSelectedListener
import com.dimeno.wum.widget.dialog.ConfirmDialog
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceController
import com.wangzhen.sequence.SequenceControllerImpl
import kotlinx.android.synthetic.main.fragment_case_stash.*

/**
 * 待报案件
 * Created by wangzhen on 2020/9/16.
 */
class CaseStashFragment : Fragment(), View.OnClickListener {
    private var mTypeCode: String? = null
    private var mBigClassCode: String? = null
    private var mSmallClassCode: String? = null
    private var adapter: CaseStashAdapter? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_case_stash, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        bindSpinner()
        initObserver()
    }

    private fun initViews() {
        spinner_type.onItemSelectedListener = object : AbsItemSelectedListener() {
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                adapterView?.let {
                    mTypeCode = (it.adapter as CommonSpinnerAdapter).getItem(position).code
                    mBigClassCode = null
                    mSmallClassCode = null
                    spinner_big_class.adapter = CommonSpinnerAdapter(context, createBigClassList())
                    spinner_small_class.adapter = CommonSpinnerAdapter(context, createSmallClassList())

                    bindBigSpinner()
                    loadStash()
                }
            }
        }
        spinner_big_class.onItemSelectedListener = object : AbsItemSelectedListener() {
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                adapterView?.let {
                    mBigClassCode = (it.adapter as CommonSpinnerAdapter).getItem(position).code
                    mSmallClassCode = null
                    spinner_small_class.adapter = CommonSpinnerAdapter(context, createSmallClassList())

                    bindSmallSpinner()
                    loadStash()
                }
            }
        }
        spinner_small_class.onItemSelectedListener = object : AbsItemSelectedListener() {
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                adapterView?.let {
                    mSmallClassCode = (it.adapter as CommonSpinnerAdapter).getItem(position).code
                    loadStash()
                }
            }
        }
        recycler.layoutManager = LinearLayoutManager(context)
        recycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                super.getItemOffsets(outRect, view, parent, state)
                outRect.bottom = AppUtils.dip2px(5f)
            }
        })

        checkbox_mode.setOnCheckedChangeListener { _, checked ->
            adapter?.checkMode(checked)
            btn_delete.visibility = if (checked) View.VISIBLE else View.GONE
            btn_report.visibility = if (checked) View.VISIBLE else View.GONE
        }
        btn_delete.visibility = View.GONE
        btn_report.visibility = View.GONE
        btn_delete.isEnabled = false
        btn_delete.setOnClickListener(this)
        btn_report.isEnabled = false
        btn_report.setOnClickListener(this)
    }

    private fun loadStash() {
        val stashes = DBLoader.load(CaseStashEntity::class.java).query().apply {
            equal(CaseStashEntity_.userId, UserBiz.get().userId)
            mTypeCode?.let {
                equal(CaseStashEntity_.typeCode, it)
            }
            mBigClassCode?.let {
                equal(CaseStashEntity_.bigClassCode, it)
            }
            mSmallClassCode?.let {
                equal(CaseStashEntity_.smallClassCode, it)
            }
            orderDesc(CaseStashEntity_.updateTime)
        }.build().find()
        adapter = CaseStashAdapter(stashes).apply {
            setEmpty(object : RecyclerItem() {
                override fun layout(): Int = R.layout.global_empty_layout

                override fun onViewCreated(itemView: View) {

                }
            }.onCreateView(recycler))
        }
        recycler.adapter = adapter
    }

    private fun bindSmallSpinner() {
        val list = createSmallClassList().apply {
            mTypeCode?.let { type ->
                mBigClassCode?.let { big ->
                    DBLoader.load(CaseSmallClassEntity::class.java).query().apply {
                        equal(CaseSmallClassEntity_.topcode, type)
                        equal(CaseSmallClassEntity_.pcode, big)
                    }.build().find().forEach { item ->
                        add(CommonSpinnerEntity().apply {
                            code = item.code.toString()
                            name = item.name
                        })
                    }
                }
            }
        }
        spinner_small_class.adapter = CommonSpinnerAdapter(context, list)
    }

    private fun bindBigSpinner() {
        val list = createBigClassList().apply {
            mTypeCode?.let {
                DBLoader.load(CaseBigClassEntity::class.java).query()
                        .equal(CaseBigClassEntity_.topcode, it).build().find().forEach { item ->
                            add(CommonSpinnerEntity().apply {
                                code = item.code.toString()
                                name = item.name
                            })
                        }
            }
        }
        spinner_big_class.adapter = CommonSpinnerAdapter(context, list)
    }

    private fun bindSpinner() {
        spinner_type.adapter = CommonSpinnerAdapter(context, createTypeList().apply {
            val list = DBLoader.load(CaseTypeEntity::class.java).all
            for (i in 0 until list.size) {
                add(CommonSpinnerEntity().apply {
                    code = list[i].code.toString()
                    name = list[i].name
                })
            }
        })
        spinner_big_class.adapter = CommonSpinnerAdapter(context, createBigClassList())
        spinner_small_class.adapter = CommonSpinnerAdapter(context, createSmallClassList())
    }

    private fun createTypeList(): MutableList<CommonSpinnerEntity> {
        return mutableListOf<CommonSpinnerEntity>().apply {
            add(CommonSpinnerEntity().apply {
                name = "全部类型"
            })
        }
    }

    private fun createBigClassList(): MutableList<CommonSpinnerEntity> {
        return mutableListOf<CommonSpinnerEntity>().apply {
            add(CommonSpinnerEntity().apply {
                name = "全部大类"
            })
        }
    }

    private fun createSmallClassList(): MutableList<CommonSpinnerEntity> {
        return mutableListOf<CommonSpinnerEntity>().apply {
            add(CommonSpinnerEntity().apply {
                name = "全部小类"
            })
        }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_delete -> {
                batchDelete()
            }
            R.id.btn_report -> {
                adapter?.getCheckedList()?.let {
                    if (!checkIntegrity(it)) {
                        T.show("案件不完整")
                        return
                    }
                    batchReport(it)
                }
            }
        }
    }

    private fun batchReport(list: MutableList<CaseStashEntity>) {
        activity?.supportFragmentManager?.let {
            var allInRegion = true
            for (i in list.indices) {
                if (!CaseValidator.inRegion(UserBiz.get().coordinates?.map { data ->
                            LatLng(data.latitude, data.longitude)
                        }?.toMutableList(), LatLng(list[i].latitude, list[i].longitude))) {
                    allInRegion = false
                    break
                }
            }
            val message: String
            val leftText: String
            val rightText: String
            if (allInRegion) {
                message = getString(R.string.case_dialog_report_text)
                leftText = getString(R.string.case_dialog_cancel)
                rightText = getString(R.string.case_dialog_report_confirm)
            } else {
                message = getString(R.string.case_dialog_out_of_region_multi_tip)
                leftText = getString(R.string.case_dialog_out_of_region_cancel)
                rightText = getString(R.string.case_dialog_out_of_region_confirm)
            }
            ConfirmDialog().setTitle(getString(R.string.case_dialog_title)).setMessage(message).setLeftText(leftText).setRightText(rightText)
                    .setCallback(object : ConfirmDialog.Callback {
                        override fun onCancel() {

                        }

                        override fun onConfirm() {
                            DialogManager.get().showLoading()
                            val controller: SequenceController = SequenceControllerImpl(activity)
                            controller.enqueue(CaseBatchPictureController(list))
                            controller.enqueue(CaseBatchReportController(list, adapter))
                            controller.proceed()
                        }
                    }).show(it)
        }
    }

    private fun checkIntegrity(list: MutableList<CaseStashEntity>): Boolean {
        for (i in list.indices) {
            val entity = list[i]
            if (TextUtils.isEmpty(entity.typeCode)) return false
            if (TextUtils.isEmpty(entity.bigClassCode)) return false
            if (TextUtils.isEmpty(entity.smallClassCode)) return false
            if (TextUtils.isEmpty(entity.address)) return false
            if (TextUtils.isEmpty(entity.description)) return false
            val pictures = JsonUtils.parseArray(entity.pictures, String::class.java)
            if (IList.isEmpty(pictures)) return false
        }
        return true
    }

    private fun batchDelete() {
        adapter?.getCheckedList()?.let {
            if (activity is FragmentActivity)
                ConfirmDialog().setTitle("警告").setMessage("确定要删除选中案件吗？")
                        .setLeftText("取消").setRightText("删除")
                        .setCallback(object : ConfirmDialog.Callback {
                            override fun onCancel() {

                            }

                            override fun onConfirm() {
                                DBLoader.load(CaseStashEntity::class.java).remove(it)
                                adapter!!.run {
                                    datas.removeAll(it)
                                    notifyDataSetChanged()
                                }
                                T.show("删除成功")
                                ViewModelProvider(context as ViewModelStoreOwner).get(CaseStashViewModel::class.java).onMultiCheckChange()
                            }

                        }).show((activity as FragmentActivity).supportFragmentManager)
        }
    }

    private fun initObserver() {
        ViewModelProvider(context as ViewModelStoreOwner).get(CaseStashViewModel::class.java).apply {
            getMultiCheckLiveData().observe(viewLifecycleOwner, Observer {
                adapter?.getCheckedList()?.let {
                    btn_delete.isEnabled = IList.isNotEmpty(it)
                    btn_report.isEnabled = IList.isNotEmpty(it)
                }
            })
            getRefreshStashLiveData().observe(viewLifecycleOwner, Observer { loadStash() })
        }
    }

}