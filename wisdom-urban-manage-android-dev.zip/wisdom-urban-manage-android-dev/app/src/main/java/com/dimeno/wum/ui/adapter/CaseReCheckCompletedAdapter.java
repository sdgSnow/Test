package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseReCheckEntity;
import com.dimeno.wum.network.task.CaseReCheckListTask;
import com.dimeno.wum.ui.adapter.holder.CaseCompleteHolder;
import com.dimeno.wum.ui.adapter.holder.CaseReCheckCompleteHolder;
import com.dimeno.wum.ui.bean.CaseCompletedBean;
import com.dimeno.wum.ui.bean.CaseReCheckCompletedBean;
import com.dimeno.wum.ui.bean.CaseReCheckRemainDealBean;

import java.util.ArrayList;
import java.util.List;

public class CaseReCheckCompletedAdapter extends LoadRecyclerAdapter<CaseReCheckCompletedBean> {

    private int page = 1;

    public CaseReCheckCompletedAdapter(List<CaseReCheckCompletedBean> list,RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseReCheckCompleteHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new CaseReCheckListTask(new LoadingCallback<CaseReCheckEntity>() {
            @Override
            public void onSuccess(CaseReCheckEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<CaseReCheckCompletedBean> addList = new ArrayList<>();
                    for (CaseReCheckEntity.DataBean datum : data.data) {
                        CaseReCheckCompletedBean caseReCheckCompletedBean = new CaseReCheckCompletedBean();
                        caseReCheckCompletedBean.address = datum.address;
                        caseReCheckCompletedBean.latitude = datum.latitude;
                        caseReCheckCompletedBean.assignType = datum.assignType;
                        caseReCheckCompletedBean.description = datum.description;
                        caseReCheckCompletedBean.updateUser = datum.updateUser;
                        caseReCheckCompletedBean.updateTime = datum.updateTime;
                        caseReCheckCompletedBean.caseCoding = datum.caseCoding;
                        caseReCheckCompletedBean.source = datum.source;
                        caseReCheckCompletedBean.caseNo = datum.caseNo;
                        caseReCheckCompletedBean.caseType = datum.caseType;
                        caseReCheckCompletedBean.assignTypeName = datum.assignTypeName;
                        caseReCheckCompletedBean.smallClassName = datum.smallClassName;
                        caseReCheckCompletedBean.smallClass = datum.smallClass;
                        caseReCheckCompletedBean.caseTypeName = datum.caseTypeName;
                        caseReCheckCompletedBean.bigClassName = datum.bigClassName;
                        caseReCheckCompletedBean.createTime = datum.createTime;
                        caseReCheckCompletedBean.statusName = datum.statusName;
                        caseReCheckCompletedBean.createUser = datum.createUser;
                        caseReCheckCompletedBean.id = datum.id;
                        caseReCheckCompletedBean.taskId = datum.taskId;
                        caseReCheckCompletedBean.bigClass = datum.bigClass;
                        caseReCheckCompletedBean.longitude = datum.longitude;
                        caseReCheckCompletedBean.status = datum.status;
                        addList.add(caseReCheckCompletedBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
//                .put("assignType", AssignType.CASE_EXAMINE)
                .put("status", CasePro.CASE_REMAIN_DEAL)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
