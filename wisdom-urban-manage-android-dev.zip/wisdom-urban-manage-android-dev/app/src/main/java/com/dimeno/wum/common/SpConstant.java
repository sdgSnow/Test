package com.dimeno.wum.common;

public class SpConstant {
    public static final String SP_ACCOUNT = "account";//记住账号
    public static final String SP_PSW = "psw";//记住密码
    public static final String SP_NAME = "name";//用户名
    public static final String SP_USER_ID = "user_id";//记住用户id
    public static final String SP_IS_LOGIN = "is_login";//是否自动登录
    public static final String SP_IS_FIRST_RUNNING = "is_first_run";//是否首次运行
    public static final String SP_USER_TYPE = "user_type";//用户角色
    public static final String SP_USER_COORDINATES = "coordinates";//用户所属区划经纬度列表
}
