package com.dimeno.wum.entity

import java.io.Serializable

/**
 * common spinner entity
 * Created by wangzhen on 2020/9/15.
 */
class CommonSpinnerEntity : Serializable {
    var code: String? = null
    var name: String? = null
}