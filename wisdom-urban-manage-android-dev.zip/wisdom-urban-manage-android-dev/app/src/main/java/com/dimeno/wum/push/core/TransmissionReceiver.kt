package com.dimeno.wum.push.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import cn.jpush.android.api.JPushInterface
import com.dimeno.commons.json.JsonUtils
import com.dimeno.wum.push.NotificationHelper
import com.dimeno.wum.push.entity.NotificationEntity
import com.dimeno.wum.push.entity.NotificationExtra

/**
 * transmission message receiver
 * Created by wangzhen on 2020/9/24.
 */
class TransmissionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (JPushInterface.ACTION_MESSAGE_RECEIVED == intent.action) {
            intent.extras?.let {
                NotificationHelper.get(context).send(NotificationEntity.Builder().apply {
                    setTitle(it.getString(JPushInterface.EXTRA_TITLE))
                    setContent(it.getString(JPushInterface.EXTRA_MESSAGE))
                    setBigTextStyle(true)
                    JsonUtils.parseObject(it.getString(JPushInterface.EXTRA_EXTRA), NotificationExtra::class.java)?.let { extra ->
                        setId(extra.id)
                        setMsgType(extra.msgType)
                        setCaseMsgType(extra.caseMsgType)
                        setUrl(extra.url)
                    }
                }.build())
            }
        }
    }
}