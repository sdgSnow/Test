package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseCheckInfoViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseDetailsViewHolder;
import com.dimeno.wum.ui.bean.CaseCheckInfoBean;
import com.dimeno.wum.ui.bean.CaseDetailsBean;

import java.util.List;

public class CaseCheckInfoAdapter extends RecyclerAdapter<CaseCheckInfoBean> {
    public CaseCheckInfoAdapter(List<CaseCheckInfoBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseCheckInfoViewHolder(parent);
    }
}
