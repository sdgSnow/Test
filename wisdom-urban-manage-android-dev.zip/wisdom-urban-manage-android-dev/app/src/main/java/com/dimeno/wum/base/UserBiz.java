package com.dimeno.wum.base;

import android.text.TextUtils;

import com.dimeno.commons.json.JsonUtils;
import com.dimeno.commons.storage.SPHelper;
import com.dimeno.commons.utils.AppUtils;
import com.dimeno.wum.common.SpConstant;
import com.dimeno.wum.entity.LatLngEntity;

import java.util.List;

import cn.jpush.android.api.JPushInterface;

/**
 * user biz
 * Created by wangzhen on 2020/9/17.
 */
public class UserBiz {
    private static UserBiz sInstance;

    private String userId;
    private String userAccount;
    private String userPwd;
    private String userName;
    private boolean login;
    private int userType;
    private String coordinates;

    public static UserBiz get() {
        if (sInstance == null)
            sInstance = new UserBiz();
        return sInstance;
    }

    private UserBiz() {
        SPHelper helper = getHelper();
        userId = helper.get(SpConstant.SP_USER_ID, "");
        userAccount = helper.get(SpConstant.SP_ACCOUNT, "");
        userPwd = helper.get(SpConstant.SP_PSW, "");
        userName = helper.get(SpConstant.SP_NAME, "");
        login = helper.get(SpConstant.SP_IS_LOGIN, false);
        userType = helper.get(SpConstant.SP_USER_TYPE, 0);
        coordinates = helper.get(SpConstant.SP_USER_COORDINATES, "");
        userType = helper.get(SpConstant.SP_USER_TYPE, 1);
    }

    private SPHelper getHelper() {
        return SPHelper.get();
    }

    public void clear() {
        userId = null;
        userAccount = null;
        userPwd = null;
        userName = null;
        login = false;
        userType = 0;
        coordinates = null;

        getHelper()
                .put(SpConstant.SP_USER_ID, userId)
                .put(SpConstant.SP_ACCOUNT, userAccount)
                .put(SpConstant.SP_PSW, userPwd)
                .put(SpConstant.SP_NAME, userName)
                .put(SpConstant.SP_IS_LOGIN, login)
                .put(SpConstant.SP_USER_COORDINATES, coordinates)
                .put(SpConstant.SP_USER_TYPE, userType)
                .commit();
    }

    public void setUserId(String id) {
        if (!TextUtils.equals(userId, id)) {
            userId = id;
            getHelper().put(SpConstant.SP_USER_ID, id).commit();
            if (!TextUtils.isEmpty(userId)) {
                JPushInterface.setAlias(AppUtils.getContext(), 0, userId);
            }
        }
    }

    public String getUserId() {
        return userId;
    }

    public void setUserAccount(String account) {
        if (!TextUtils.equals(userAccount, account)) {
            userAccount = account;
            getHelper().put(SpConstant.SP_ACCOUNT, account).commit();
        }
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserPwd(String pwd) {
        if (!TextUtils.equals(userPwd, pwd)) {
            userPwd = pwd;
            getHelper().put(SpConstant.SP_PSW, pwd).commit();
        }
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserName(String name) {
        if (!TextUtils.equals(userName, name)) {
            userName = name;
            getHelper().put(SpConstant.SP_NAME, name).commit();
        }
    }

    public String getUserName() {
        return userName;
    }

    public void setLogin(boolean auto) {
        if (login != auto) {
            login = auto;
            getHelper().put(SpConstant.SP_IS_LOGIN, auto).commit();
        }
    }

    public boolean isLogin() {
        return login;
    }

    public void setUserType(int setUserType) {
        if (userType != setUserType) {
            userType = setUserType;
            getHelper().put(SpConstant.SP_USER_TYPE, userType).commit();
        }
    }

    public int getUserType() {
        return userType;
    }

    public void setCoordinates(List<LatLngEntity> list) {
        String value = JsonUtils.toJsonString(list);
        if (!TextUtils.equals(value, coordinates)) {
            coordinates = value;
            getHelper().put(SpConstant.SP_USER_COORDINATES, value).commit();
        }
    }

    public List<LatLngEntity> getCoordinates() {
        return JsonUtils.parseArray(coordinates, LatLngEntity.class);
    }
}
