package com.dimeno.wum.ui.bean;

public class SpinnerQueryAllTypeBean {

    public String typeName;//类型名称
}
