package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.MainActivity;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.Code;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.Verify;
import com.dimeno.wum.entity.CaseDetailsEntity;
import com.dimeno.wum.network.task.CaseDetailsTask;
import com.dimeno.wum.ui.bean.CaseCheckDetailsHeaderBean;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;
import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.listener.OnPageChangeListener;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseCheckDetailsActivity
 * Created by sdg on 2020/9/17.
 * 案件核实详情
 */
public class CaseCheckDetailsActivity extends BaseActivity implements View.OnClickListener {

    private Banner banner;
    private List<CaseCheckDetailsHeaderBean> caseCheckDetailsHeaderBeans;
    private TextView tv_select_picture;
    private String id;
    private TextView case_type_name;
    private TextView case_case_address;
    private TextView case_case_time;
    private TextView case_case_desc;
    private TextView case_case_status;
    private LinearLayout ll_un_verified;
    private LinearLayout ll_verified;
    private TextView tv_step;
    private ImageView iv_verified;
    private ImageView iv_un_verified;
    private int verifiedValue = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_check_details);
        fitDarkStatusBar(true);
        banner = findViewById(R.id.banner_picture);
        tv_select_picture = findViewById(R.id.tv_select_picture);
        tv_select_picture = findViewById(R.id.tv_select_picture);
        case_type_name = findViewById(R.id.case_type_name);
        case_case_address = findViewById(R.id.case_case_address);
        case_case_time = findViewById(R.id.case_case_time);
        case_case_desc = findViewById(R.id.case_case_desc);
        case_case_status = findViewById(R.id.case_case_status);
        ll_un_verified = findViewById(R.id.ll_un_verified);
        ll_verified = findViewById(R.id.ll_verified);
        tv_step = findViewById(R.id.tv_next_step);
        tv_step.setEnabled(false);
        iv_verified = findViewById(R.id.iv_verified);
        iv_un_verified = findViewById(R.id.iv_un_verified);

        ll_un_verified.setOnClickListener(this::onClick);
        ll_verified.setOnClickListener(this::onClick);
        tv_step.setOnClickListener(this::onClick);

        id = getIntent().getStringExtra("id");
        getCaseDetail();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案件核实详情");
    }

    /**
     * 获取案例详情
     */
    private void getCaseDetail() {
        new CaseDetailsTask(new LoadingCallback<CaseDetailsEntity>() {
            @Override
            public void onSuccess(CaseDetailsEntity data) {
                case_type_name.setText(data.data.caseTypeName);
                case_case_address.setText(data.data.address);
                case_case_time.setText(data.data.createTime);
                case_case_desc.setText(data.data.description);
                case_case_status.setText(data.data.statusName);
                initBanner(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("id", id)
                .exe();
    }

    private void initBanner(CaseDetailsEntity data) {
        caseCheckDetailsHeaderBeans = new ArrayList<>();
        caseCheckDetailsHeaderBeans = new ArrayList<>();
        if (data.data.caseFilesList != null) {
            for (CaseDetailsEntity.DataBean.CaseFilesListBean caseFilesListBean : data.data.caseFilesList) {
                CaseCheckDetailsHeaderBean caseCheckDetailsHeaderBean = new CaseCheckDetailsHeaderBean();
                caseCheckDetailsHeaderBean.caseReportId = caseFilesListBean.caseReportId;
                caseCheckDetailsHeaderBean.createTime = caseFilesListBean.createTime;
                caseCheckDetailsHeaderBean.createUser = caseFilesListBean.createUser;
                caseCheckDetailsHeaderBean.fileShowUrl = caseFilesListBean.fileShowUrl;
                caseCheckDetailsHeaderBean.fileSource = caseFilesListBean.fileSource;
                caseCheckDetailsHeaderBean.fileUrl = caseFilesListBean.fileUrl;
                caseCheckDetailsHeaderBean.id = caseFilesListBean.id;
                caseCheckDetailsHeaderBean.updateTime = caseFilesListBean.updateTime;
                caseCheckDetailsHeaderBean.updateUser = caseFilesListBean.updateUser;
                caseCheckDetailsHeaderBeans.add(caseCheckDetailsHeaderBean);
            }
        }
        String format = String.format("%s/%s", 1, caseCheckDetailsHeaderBeans.size());
        tv_select_picture.setText(format);
        banner.isAutoLoop(false);//禁止自动滑动
        banner.setAdapter(new BannerImageAdapter<CaseCheckDetailsHeaderBean>(caseCheckDetailsHeaderBeans) {
            @Override
            public void onBindView(BannerImageHolder holder, CaseCheckDetailsHeaderBean data, int position, int size) {
                //图片加载自己实现
                Glide.with(holder.itemView)
                        .load(data.fileShowUrl)
                        .into(holder.imageView);
            }
        }).setIndicator(new CircleIndicator(CaseCheckDetailsActivity.this));
        banner.setOnBannerListener((_data, position) -> {
            if (caseCheckDetailsHeaderBeans == null)
                return;
            ArrayList<String> urls = new ArrayList<>();
            for (CaseCheckDetailsHeaderBean bean : caseCheckDetailsHeaderBeans)
                urls.add(bean.fileShowUrl);
            startActivity(new Intent(CaseCheckDetailsActivity.this, PicturePreviewActivity.class)
                    .putStringArrayListExtra(IKey.DATA, urls).putExtra(IKey.POSITION, position));
        });
        banner.addOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                String format = String.format("%s/%s", position + 1, caseCheckDetailsHeaderBeans.size());
                tv_select_picture.setText(format);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_un_verified:
                iv_un_verified.setImageResource(R.mipmap.ic_checkbox_check);
                iv_verified.setImageResource(R.mipmap.ic_checkbox_uncheck);
                verifiedValue = Verify.UN_VERIFY;
                tv_step.setEnabled(true);
                break;
            case R.id.ll_verified:
                iv_verified.setImageResource(R.mipmap.ic_checkbox_check);
                iv_un_verified.setImageResource(R.mipmap.ic_checkbox_uncheck);
                verifiedValue = Verify.VERIFY;
                tv_step.setEnabled(true);
                break;
            case R.id.tv_next_step:
                if (verifiedValue == Verify.UN_VERIFY) {
                    Intent intent = new Intent(CaseCheckDetailsActivity.this, UnVerifyActivity.class);
                    intent.putExtra("caseReportId", id);
                    intent.putExtra("type", Verify.TYPE_CHECK);
                    intent.putExtra("verifyType", Verify.UN_VERIFY);
                    startActivity(intent);
                } else if (verifiedValue == Verify.VERIFY) {
                    Intent intent = new Intent(CaseCheckDetailsActivity.this, VerifyActivity.class);
                    intent.putExtra("caseReportId", id);
                    intent.putExtra("type", Verify.TYPE_CHECK);
                    intent.putExtra("verifyType", Verify.VERIFY);
                    startActivityForResult(intent, Code.CODE_REPORT);
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @androidx.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Code.CODE_REPORT) {
            if (resultCode == Code.CODE_REPORT_SUCCESS) {
                startActivity(new Intent(CaseCheckDetailsActivity.this, MainActivity.class));
            }
        }
    }
}