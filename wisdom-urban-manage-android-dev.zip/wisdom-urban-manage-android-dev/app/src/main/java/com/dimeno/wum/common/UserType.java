package com.dimeno.wum.common;

public class UserType {
    public static final int ADMIN_ROLE = 10;//超级管理员
    public static final int SUPERCISOR = 20;//监督员
    public static final int SUPERCISOR_CENTER = 30;//受理员
    public static final int WATCHMAN = 40;//值班长
    public static final int COMMAND_CENTER = 50;//派遣员
    public static final int SYS_RECTIFIER = 60;//执法员
    public static final int LEADER = 70;//领导层
}
