package com.dimeno.wum.ui.adapter.holder

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.adapter.callback.OnHolderClickCallback
import com.dimeno.wum.R
import com.dimeno.wum.common.IKey
import com.dimeno.wum.entity.CasePictureEntity
import com.dimeno.wum.ui.activity.PicturePreviewActivity
import com.dimeno.wum.ui.adapter.CasePictureAdapter
import com.dimeno.wum.widget.dialog.ConfirmDialog

/**
 * CasePictureViewHolder
 * Created by wangzhen on 2020/9/16.
 */
class CasePictureViewHolder(parent: ViewGroup) : RecyclerViewHolder<CasePictureEntity>(parent, R.layout.case_file_picture_item_layout), OnHolderClickCallback {
    init {
        findViewById<View>(R.id.btn_delete).setOnClickListener {
            if (itemView.context is FragmentActivity) {
                ConfirmDialog().setTitle("删除").setMessage("确定删除当前图片？").setRightText("删除").setCallback(object : ConfirmDialog.Callback {
                    override fun onCancel() {

                    }

                    override fun onConfirm() {
                        if (itemView.parent is RecyclerView) {
                            val adapter = (itemView.parent as RecyclerView).adapter
                            if (adapter is RecyclerAdapter<*>) {
                                adapter.datas?.let {
                                    it.remove(mData)
                                    adapter.notifyItemRemoved(adapterPosition)
                                }
                            }
                        }
                    }
                }).show((itemView.context as FragmentActivity).supportFragmentManager)
            }
        }
    }

    override fun bind() {
        val imageView = findViewById<ImageView>(R.id.iv)
        Glide.with(itemView.context).load(mData.url)
                .apply(RequestOptions().placeholder(R.drawable.case_upload_photo_place_holder).error(R.drawable.case_upload_photo_place_holder))
                .into(imageView)
    }

    override fun onItemClick(itemView: View, position: Int) {
        if (itemView.parent is RecyclerView) {
            val adapter = (itemView.parent as RecyclerView).adapter
            if (adapter is CasePictureAdapter) {
                adapter.datas?.let { data ->
                    val array = arrayListOf<String>()
                    data.forEach {
                        array.add(it.url)
                    }
                    itemView.context.apply {
                        startActivity(Intent(this, PicturePreviewActivity::class.java).apply {
                            putStringArrayListExtra(IKey.DATA, array)
                            putExtra(IKey.POSITION, position)
                        })
                    }
                }
            }
        }
    }
}