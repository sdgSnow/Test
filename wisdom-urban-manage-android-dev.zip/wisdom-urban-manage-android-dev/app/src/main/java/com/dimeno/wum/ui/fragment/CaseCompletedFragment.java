package com.dimeno.wum.ui.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.AssignType;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseCompletedEntity;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseSmallClassEntity;
import com.dimeno.wum.entity.db.CaseSmallClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.network.task.CaseVerifyListTask;
import com.dimeno.wum.ui.adapter.CaseCompletedAdapter;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.bean.CaseCompletedBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseInfoFragment
 * Created by sdg on 2020/9/16.
 * 核实的待办案件
 */
public class CaseCompletedFragment extends Fragment implements View.OnClickListener , OnRefreshCallback {

    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private Spinner spinner_small_class;
    private String mCaseTypeCode = null;
    private String mBigClassCode = null;
    private String mSmallClassCode = null;
    private List<CommonSpinnerEntity> typeList;
    private List<CommonSpinnerEntity> bigClassList;
    private List<CommonSpinnerEntity> smallClassList;
    private RecyclerView rv_case_completed;
    private List<CaseCompletedBean> caseCompletedBeans;
    private CaseCompletedAdapter caseCompletedAdapter;
    private EditText et_search;
    private ImageView iv_search;
    private RefreshLayout refresh_layout;

    public static CaseCompletedFragment newInstance() {
        CaseCompletedFragment fragment = new CaseCompletedFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_case_completed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv_case_completed = view.findViewById(R.id.rv_case_completed);
        spinner_type = view.findViewById(R.id.spinner_type);
        spinner_big_class = view.findViewById(R.id.spinner_big_class);
        spinner_small_class = view.findViewById(R.id.spinner_small_class);
        et_search = view.findViewById(R.id.et_search);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        refresh_layout.startRefresh();

        initSpinner1();
        initSpinner2();
        initSpinner3();
        initSelectListener();

        getCaseVerifyList();

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                getCaseVerifyList();
            }
        });
    }

    private void initSpinner1() {
        //初始化案件类型数据
        typeList = createTypeList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                typeList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter1 = new CommonSpinnerAdapter(getActivity(), typeList);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化大类数据
        bigClassList = createBigClassList();
        if (mCaseTypeCode != null) {
            List<CaseBigClassEntity> caseBigClassEntities = DBLoader.load(CaseBigClassEntity.class).query().equal(CaseBigClassEntity_.topcode, mCaseTypeCode).build().find();
            if (caseBigClassEntities != null) {
                for (CaseBigClassEntity caseBigClassEntity : caseBigClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseBigClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseBigClassEntity.getName());
                    bigClassList.add(caseSpinnerEntity);
                }

            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter2 = new CommonSpinnerAdapter(getActivity(), bigClassList);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSpinner3() {
        //初始化小类数据
        smallClassList = createSmallClassList();
        if (mCaseTypeCode != null && mBigClassCode != null) {
            List<CaseSmallClassEntity> caseSmallClassEntities = DBLoader.load(CaseSmallClassEntity.class).query().equal(CaseSmallClassEntity_.topcode, mCaseTypeCode).equal(CaseSmallClassEntity_.pcode, mBigClassCode).build().find();
            if (caseSmallClassEntities != null) {
                for (CaseSmallClassEntity caseSmallClassEntity : caseSmallClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseSmallClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseSmallClassEntity.getName());
                    smallClassList.add(caseSpinnerEntity);
                }
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter3 = new CommonSpinnerAdapter(getActivity(), smallClassList);
        spinner_small_class.setAdapter(caseSpinnerAdapter3);
    }

    private void initSelectListener() {
        //spineer的点击事件
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = typeList.get(i).getCode();
                mBigClassCode = null;
                mSmallClassCode = null;
                initSpinner2();
                initSpinner3();
                if(i == 0){
                    getCaseVerifyList();
                }
                if(mCaseTypeCode != null) {
                    getCaseVerifyList();
                }
            }
        });

        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mBigClassCode = bigClassList.get(i).getCode();
                mSmallClassCode = null;
                initSpinner3();
                if(i == 0){
                    getCaseVerifyList();
                }
                if(mBigClassCode != null) {
                    getCaseVerifyList();
                }
            }
        });

        spinner_small_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mSmallClassCode = smallClassList.get(i).getCode();
                if(i == 0){
                    getCaseVerifyList();
                }
                if(mSmallClassCode != null) {
                    getCaseVerifyList();
                }
            }
        });
    }

    private List<CommonSpinnerEntity> createTypeList() {
        List<CommonSpinnerEntity> caseTypeList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity1 = new CommonSpinnerEntity();
        caseSpinnerEntity1.setName("案件类型");
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<CommonSpinnerEntity> createBigClassList() {
        List<CommonSpinnerEntity> bigClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity2 = new CommonSpinnerEntity();
        caseSpinnerEntity2.setName("案件大类");
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private List<CommonSpinnerEntity> createSmallClassList() {
        List<CommonSpinnerEntity> smallClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity3 = new CommonSpinnerEntity();
        caseSpinnerEntity3.setName("案件小类");
        smallClassList.add(caseSpinnerEntity3);
        return smallClassList;
    }

    private void getCaseVerifyList() {
        new CaseVerifyListTask(new LoadingCallback<CaseCompletedEntity>() {
            @Override
            public void onSuccess(CaseCompletedEntity data) {
                initCaseRemainDeal(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("caseType", mCaseTypeCode)
                .put("bigClass", mBigClassCode)
                .put("smallClass", mSmallClassCode)
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("keyword", et_search.getText().toString().trim())
                .put("status", CasePro.CASE_COMPLETE)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    private void initCaseRemainDeal(CaseCompletedEntity caseCompletedEntity) {
        caseCompletedBeans = new ArrayList<>();
        if(caseCompletedEntity.data != null){
            for (CaseCompletedEntity.DataBean datum : caseCompletedEntity.data) {
                CaseCompletedBean caseCompletedBean = new CaseCompletedBean();
                caseCompletedBean.address = datum.address;
                caseCompletedBean.latitude = datum.latitude;
                caseCompletedBean.assignType = datum.assignType;
                caseCompletedBean.description = datum.description;
                caseCompletedBean.updateUser = datum.updateUser;
                caseCompletedBean.updateTime = datum.updateTime;
                caseCompletedBean.caseCoding = datum.caseCoding;
                caseCompletedBean.source = datum.source;
                caseCompletedBean.caseNo = datum.caseNo;
                caseCompletedBean.caseType = datum.caseType;
                caseCompletedBean.assignTypeName = datum.assignTypeName;
                caseCompletedBean.smallClassName = datum.smallClassName;
                caseCompletedBean.smallClass = datum.smallClass;
                caseCompletedBean.caseTypeName = datum.caseTypeName;
                caseCompletedBean.bigClassName = datum.bigClassName;
                caseCompletedBean.createTime = datum.createTime;
                caseCompletedBean.statusName = datum.statusName;
                caseCompletedBean.createUser = datum.createUser;
                caseCompletedBean.id = datum.id;
                caseCompletedBean.taskId = datum.taskId;
                caseCompletedBean.bigClass = datum.bigClass;
                caseCompletedBean.longitude = datum.longitude;
                caseCompletedBean.status = datum.status;
                caseCompletedBeans.add(caseCompletedBean);
            }
        }
        showCaseRemainDealList();
    }

    private void showCaseRemainDealList() {
        rv_case_completed.setLayoutManager(new GridLayoutManager(getActivity(),1,GridLayoutManager.VERTICAL,false));
        caseCompletedAdapter = new CaseCompletedAdapter(caseCompletedBeans,rv_case_completed);
        caseCompletedAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_case_completed));
        rv_case_completed.setAdapter(caseCompletedAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

        }
    }

    @Override
    public void onRefresh() {
        getCaseVerifyList();
    }
}