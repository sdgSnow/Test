package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.dimeno.commons.storage.SPHelper;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.MainActivity;
import com.dimeno.wum.R;
import com.dimeno.wum.base.AppInitializer;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.base.BaseApplication;
import com.dimeno.wum.base.EnvBiz;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.SpConstant;
import com.dimeno.wum.entity.LoginEntity;
import com.dimeno.wum.network.task.LoginTask;
import com.dimeno.wum.utils.ActivityManager;
import com.dimeno.wum.widget.abs.AbsTextWatcher;
import com.dimeno.wum.widget.dialog.DialogManager;
import com.wangzhen.router.Router;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private EditText et_user;
    private EditText et_psw;
    private boolean isRememberAccount = false;
    private boolean isRememberPsw = false;
    private ImageView iv_remember_account;
    private ImageView iv_remember_psw;
    private View btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initEnv();
        initView();
        initData();
    }

    private void initEnv() {
        if (getIntent().getBooleanExtra("init", false)) {
            UserBiz.get().setLogin(false);
            ActivityManager.closeExclude(this);
            if (getApplication() instanceof BaseApplication) {
                ((BaseApplication) getApplication()).initNetwork();
            }
        }
    }

    private void initView() {
        et_user = findViewById(R.id.et_user);
        et_psw = findViewById(R.id.et_psw);
        iv_remember_account = findViewById(R.id.iv_remember_account);
        iv_remember_psw = findViewById(R.id.iv_remember_psw);
        (btnLogin = findViewById(R.id.btn_login)).setOnClickListener(this);
        findViewById(R.id.ll_remember_account).setOnClickListener(this);
        findViewById(R.id.ll_remember_psw).setOnClickListener(this);
        et_user.addTextChangedListener(watcher);
        et_psw.addTextChangedListener(watcher);
        if (EnvBiz.isDebug()) {
            findViewById(R.id.header).setOnLongClickListener(view -> {
                Router.with(LoginActivity.this).toPath("/developer");
                return false;
            });
        }
    }

    private void initData() {
        String account = SPHelper.get().get(SpConstant.SP_ACCOUNT, "");
        String psw = SPHelper.get().get(SpConstant.SP_PSW, "");
        et_user.setText(account);
        et_psw.setText(psw);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                login();
                break;
            case R.id.ll_remember_account:
                isRememberAccount = !isRememberAccount;
                if (isRememberAccount) {
                    iv_remember_account.setImageResource(R.mipmap.password);
                    UserBiz.get().setUserAccount(et_user.getText().toString().trim());
                } else {
                    iv_remember_account.setImageResource(R.mipmap.username);
                    UserBiz.get().setUserAccount("");
                }
                break;
            case R.id.ll_remember_psw:
                isRememberPsw = !isRememberPsw;
                if (isRememberPsw) {
                    iv_remember_psw.setImageResource(R.mipmap.password);
                    UserBiz.get().setUserPwd(et_psw.getText().toString().trim());
                } else {
                    iv_remember_psw.setImageResource(R.mipmap.username);
                    UserBiz.get().setUserPwd("");
                }
                break;
        }
    }

    public void login() {
        new LoginTask(new LoadingCallback<LoginEntity>() {
            @Override
            public void onStart() {
                DialogManager.Companion.get().showLoading();
            }

            @Override
            public void onSuccess(LoginEntity data) {
                if (data.data != null) {
                    UserBiz.get().setLogin(true);
                    UserBiz.get().setUserId(data.data.userId);
                    UserBiz.get().setUserType(data.data.userType);
                    UserBiz.get().setUserAccount(data.data.account);
                    UserBiz.get().setUserName(data.data.name);
                    UserBiz.get().setCoordinates(data.data.coordinateList);
                    AppInitializer.Companion.prepareTaskArea();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    T.show(data.message);
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                DialogManager.Companion.get().stopLoading();
            }
        }).setTag(this)
                .put("aa", et_user.getText().toString())
                .put("ab", et_psw.getText().toString())
                .exe();

    }

    private TextWatcher watcher = new AbsTextWatcher() {
        @Override
        public void afterTextChanged(Editable editable) {
            btnLogin.setEnabled(et_user.getText().length() > 0 && et_psw.getText().length() > 0);
        }
    };
}