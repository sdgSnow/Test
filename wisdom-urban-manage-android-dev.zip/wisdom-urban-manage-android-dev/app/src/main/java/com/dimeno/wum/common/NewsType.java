package com.dimeno.wum.common;

public class NewsType {

    public static final int SPLASH = 1;//闪屏页
    public static final int NEWS = 2;//新闻轮播
    public static final int NOTICE = 3;//通知
    public static final int HELP = 4;//帮助中心
    public static final int GUIDE = 5;//操作指引
}
