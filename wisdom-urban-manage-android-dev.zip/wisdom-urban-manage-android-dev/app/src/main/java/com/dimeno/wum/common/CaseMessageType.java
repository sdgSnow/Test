package com.dimeno.wum.common;

public class CaseMessageType {

    public static final int MESSAGE_CHECK = 1;//案件核实（任务
    public static final int MESSAGE_RECHECK = 2;//案件核查（任务）
    public static final int MESSAGE_LOOK = 3;//案件巡查（任务）
    public static final int MESSAGE_FILING = 4;//案件立案（通知）
    public static final int MESSAGE_CLOSE = 5;//案件结案（通知）
    public static final int MESSAGE_INVALID = 6;//案件作废（通知）
    public static final int MESSAGE_ACCEPTANCE = 7;//案件受理（通知）
}
