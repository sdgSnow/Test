package com.dimeno.wum.entity.db;

import java.io.Serializable;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;

@Entity
public class TaskArea implements Serializable {
    @Id
    public Long id;
    public String code;
    public String createTime;
    public String createUser;
    public String name;
    public String pcode;
    public String remark;
    public String top;
    public String updateTime;
    public String updateUser;
}
