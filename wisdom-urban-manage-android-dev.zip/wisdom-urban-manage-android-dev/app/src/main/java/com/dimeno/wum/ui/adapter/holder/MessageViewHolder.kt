package com.dimeno.wum.ui.adapter.holder

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.commons.utils.T
import com.dimeno.wum.R
import com.dimeno.wum.entity.MessageDataEntity

/**
 * message view holder
 * Created by wangzhen on 2020/9/27.
 */
class MessageViewHolder(parent: ViewGroup) : RecyclerViewHolder<MessageDataEntity>(parent, R.layout.message_item_layout) {
    override fun bind() {
        findViewById<TextView>(R.id.tv_title).text = if (adapterPosition % 2 == 0) "案件已立案" else "案件已作废"
        findViewById<TextView>(R.id.tv_content).text = mData.content
        findViewById<View>(R.id.btn_see).setOnClickListener {
            T.show("案件详情")
        }
    }
}