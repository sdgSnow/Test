package com.dimeno.wum.ui.activity

import android.os.Bundle
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.widget.toolbar.AppCommonToolbar

/**
 * case manage activity
 * Created by wangzhen on 2020/9/24.
 */
class CaseManageActivity : BaseActivity() {
    private var areaCode: String? = null
    private var days: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_case_manage)
        fitDarkStatusBar(true)
        initArgs()
    }

    private fun initArgs() {
        intent.data?.let {
            areaCode = it.getQueryParameter("areaCode")
            it.getQueryParameter("days")?.let { v ->
                try {
                    days = v.toInt()
                } catch (e: Exception) {
                }
            }
        }
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, "案件管理列表")
    }
}