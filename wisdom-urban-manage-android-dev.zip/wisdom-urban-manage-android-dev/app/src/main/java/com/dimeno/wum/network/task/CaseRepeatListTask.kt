package com.dimeno.wum.network.task

import com.dimeno.network.callback.LoadingCallback
import com.dimeno.network.task.PostJsonTask

/**
 * case repeat list task
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatListTask(callback: LoadingCallback<*>?) : PostJsonTask(callback) {
    override fun getApi(): String {
        return "/wisdomurbanmanagecore/api/getRepeatCaseList"
    }
}