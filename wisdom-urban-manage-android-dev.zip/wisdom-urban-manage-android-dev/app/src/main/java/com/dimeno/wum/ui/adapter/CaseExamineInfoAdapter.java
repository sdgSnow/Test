package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseDetailsViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseExamineInfoViewHolder;
import com.dimeno.wum.ui.bean.CaseDetailsBean;
import com.dimeno.wum.ui.bean.CaseExamineInfoBean;

import java.util.List;

public class CaseExamineInfoAdapter extends RecyclerAdapter<CaseExamineInfoBean> {
    public CaseExamineInfoAdapter(List<CaseExamineInfoBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseExamineInfoViewHolder(parent);
    }
}
