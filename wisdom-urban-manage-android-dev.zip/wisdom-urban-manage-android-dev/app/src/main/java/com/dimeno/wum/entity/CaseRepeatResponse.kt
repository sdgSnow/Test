package com.dimeno.wum.entity

import java.io.Serializable

/**
 * case repeat response
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatResponse : Serializable {
    var code = 0
    var message: String? = null
    var success: Boolean = false
    var data: DataEntity? = null

    class DataEntity : Serializable {
        var caseList: MutableList<CaseRepeatEntity>? = null
    }
}