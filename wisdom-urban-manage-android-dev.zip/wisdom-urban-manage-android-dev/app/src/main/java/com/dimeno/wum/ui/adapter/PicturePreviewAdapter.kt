package com.dimeno.wum.ui.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.dimeno.wum.common.IKey
import com.dimeno.wum.ui.fragment.PicturePreviewFragment

/**
 * picture preview adapter
 * Created by wangzhen on 2020/9/25.
 */
class PicturePreviewAdapter(val list: MutableList<String>, manager: FragmentManager) : FragmentStatePagerAdapter(manager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    override fun getCount(): Int = list.size

    override fun getItem(position: Int): Fragment {
        return PicturePreviewFragment().apply {
            arguments = Bundle().apply {
                putString(IKey.PREVIEW_URL, list[position])
            }
        }
    }
}