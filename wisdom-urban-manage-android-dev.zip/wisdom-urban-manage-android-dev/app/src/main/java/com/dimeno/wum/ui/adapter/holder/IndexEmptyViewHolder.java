package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.IndexBean;

/**
 * 首页空白占位
 * Created by wangzhen on 2020/9/22.
 */
public class IndexEmptyViewHolder extends RecyclerViewHolder<IndexBean> {
    public IndexEmptyViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_index_empty);
    }

    @Override
    public void bind() {

    }
}
