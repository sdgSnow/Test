package com.dimeno.wum.ui.bean;

public class MineBean {

    public int type;
    public int icon;
    public String name;

    public MineBean(int type, int icon, String name) {
        this.type = type;
        this.icon = icon;
        this.name = name;
    }
}
