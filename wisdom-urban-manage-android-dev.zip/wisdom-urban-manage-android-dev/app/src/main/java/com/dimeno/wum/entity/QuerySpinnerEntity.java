package com.dimeno.wum.entity;

import java.io.Serializable;

public class QuerySpinnerEntity implements Serializable {

    public Integer code;
    public String name;
}
