package com.dimeno.wum.widget.toolbar

import android.app.Activity
import android.view.View
import android.widget.TextView
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R

/**
 * app common toolbar
 * Created by wangzhen on 2020/9/19.
 */
class AppCommonToolbar(activity: Activity, private val title: String) : Toolbar(activity) {
    private var tvTitle: TextView? = null
    override fun layoutRes(): Int = R.layout.toolbar_app_common_layout
    override fun onViewCreated(view: View) {
        view.findViewById<View>(R.id.back).apply {
            setOnClickListener {
                activity.finish()
            }
        }
        tvTitle = view.findViewById<TextView>(R.id.title).apply {
            text = title
        }
    }

    fun setTitle(text: String) {
        tvTitle?.text = text
    }
}