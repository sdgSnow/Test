package com.dimeno.wum.entity;

import java.io.Serializable;

/**
 * CoordinateEntity
 * Created by wangzhen on 2020/9/21.
 */
public class CoordinateEntity implements Serializable {
    /**
     * areaCode : 210202001002
     * createTime : 2020-09-19 08:53:57
     * createUser : 1
     * id : 1307120708287827970
     * latitude : 38.92416066460569
     * longitude : 121.66388511657713
     * updateTime : 2020-09-19 08:53:57
     * updateUser : 1
     */

    public String areaCode;
    public String createTime;
    public String createUser;
    public String id;
    public String latitude;
    public String longitude;
    public String updateTime;
    public String updateUser;
}
