package com.dimeno.wum.utils

/**
 * app format utils
 * Created by wangzhen on 2020/10/29.
 */
class AppFormat {
    companion object {
        private val CN_CHARS = arrayOf("零", "一", "二", "三", "四", "五", "六", "七", "八", "九")

        fun getChineseChar(num: Int): String {
            var src = num
            var result = ""
            if (src <= 0) {
                result = CN_CHARS[0]
            } else {
                var digit = 0
                while (src > 0) {
                    digit = src % 10
                    result = CN_CHARS[digit] + result
                    src /= 10
                }
            }
            return result
        }

        fun formatDistance(distance: Int): String {
            val value = if (distance < 0) 0 else distance
            return if (value < 1000)
                "${value}米"
            else
                "${distance * 1f / 1000}公里"
        }

        fun formatTimeCost(seconds: Int): String {
            var value = "${seconds}秒"
            if (seconds > 60) {
                var minute = seconds / 60
                value = "${minute}分钟"
                if (minute > 60) {
                    var hour = minute / 60
                    minute %= 60
                    value = "${hour}小时${minute}分钟"
                    if (hour > 24) {
                        val day = hour / 24
                        hour %= 24
                        value = "${day}天${hour}小时${minute}分钟"
                    }
                }
            }
            return value
        }
    }
}