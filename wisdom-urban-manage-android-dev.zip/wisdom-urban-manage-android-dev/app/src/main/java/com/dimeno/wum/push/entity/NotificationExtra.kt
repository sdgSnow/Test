package com.dimeno.wum.push.entity

import java.io.Serializable

/**
 * notification extra
 * Created by wangzhen on 2020/9/24.
 */
class NotificationExtra : Serializable {
    val id: String? = null
    val msgType: Int = 0
    val caseMsgType: Int = 0
    val url: String? = null
}