package com.dimeno.wum.utils.sequence

import com.dimeno.commons.json.JsonUtils
import com.dimeno.commons.utils.T
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.entity.OssTokenEntity
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.network.task.GetOssTokenTask
import com.dimeno.wum.utils.OSSManager
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceTask

/**
 * CaseBatchPictureController
 * Created by wangzhen on 2020/9/18.
 */
class CaseBatchPictureController(val list: MutableList<CaseStashEntity>) : SequenceTask() {
    val pictures: MutableList<String> = mutableListOf()
    var total: Int = 0
    var size: Int = 0
    override fun run() {
        for (i in list.indices)
            JsonUtils.parseArray(list[i].pictures, String::class.java)?.let {
                pictures.addAll(it)
                total += it.size
            }
        for (i in pictures.indices) {
            GetOssTokenTask(object : LoadingCallback<OssTokenEntity>() {
                override fun onSuccess(data: OssTokenEntity) {
                    OSSManager.get()
                            .accessKeyId(data.AccessKeyId)
                            .accessKeySecret(data.AccessKeySecret)
                            .securityToken(data.SecurityToken)
                            .endPoint(data.endpoint)
                            .bucket(data.BucketName)
                            .directory(data.Directory)
                            .file(pictures[i])
                            .callback(object : OSSManager.Callback {
                                override fun onSuccess() {
                                    size++
                                    if (size >= total) {
                                        controller().proceed()
                                    }
                                }

                                override fun onFailure(message: String) {
                                    onFail(message)
                                }

                            }).upload()
                }

                override fun onError(code: Int, message: String) {
                    onFail(message)
                }
            }).setTag(activity()).exe()
        }
    }

    private fun onFail(msg: String) {
        T.show(msg)
        DialogManager.get().stopLoading()
    }
}