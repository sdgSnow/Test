package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseQueryEntity;
import com.dimeno.wum.entity.CaseTypeResponse;
import com.dimeno.wum.network.task.CaseQueryListTask;
import com.dimeno.wum.ui.adapter.holder.CaseQueryHolder;
import com.dimeno.wum.ui.adapter.holder.CaseTypeViewHolder;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.ui.bean.SpinnerQueryCaseTypeBean;

import java.util.ArrayList;
import java.util.List;

public class CaseQueryAdapter extends LoadRecyclerAdapter<CaseQueryBean> {
    private List<CaseQueryBean> beanList;
    private int page = 1;

    public CaseQueryAdapter(List<CaseQueryBean> list,RecyclerView parent) {
        super(list,parent);
        this.beanList = list;
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseQueryHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new CaseQueryListTask(new LoadingCallback<CaseQueryEntity>() {
            @Override
            public void onSuccess(CaseQueryEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<CaseQueryBean> addList = new ArrayList<>();
                    for (CaseQueryEntity.DataBean datum : data.data) {
                        CaseQueryBean caseQueryBean = new CaseQueryBean();
                        caseQueryBean.address = datum.address;
                        caseQueryBean.latitude = datum.latitude;
                        caseQueryBean.assignType = datum.assignType;
                        caseQueryBean.description = datum.description;
                        caseQueryBean.updateUser = datum.updateUser;
                        caseQueryBean.updateTime = datum.updateTime;
                        caseQueryBean.caseCoding = datum.caseCoding;
                        caseQueryBean.source = datum.source;
                        caseQueryBean.caseNo = datum.caseNo;
                        caseQueryBean.caseType = datum.caseType;
                        caseQueryBean.assignTypeName = datum.assignTypeName;
                        caseQueryBean.smallClassName = datum.smallClassName;
                        caseQueryBean.smallClass = datum.smallClass;
                        caseQueryBean.caseTypeName = datum.caseTypeName;
                        caseQueryBean.bigClassName = datum.bigClassName;
                        caseQueryBean.createTime = datum.createTime;
                        caseQueryBean.statusName = datum.statusName;
                        caseQueryBean.createUser = datum.createUser;
                        caseQueryBean.id = datum.id;
                        caseQueryBean.taskId = datum.taskId;
                        caseQueryBean.bigClass = datum.bigClass;
                        caseQueryBean.longitude = datum.longitude;
                        caseQueryBean.status = datum.status;
                        addList.add(caseQueryBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();

    }
}
