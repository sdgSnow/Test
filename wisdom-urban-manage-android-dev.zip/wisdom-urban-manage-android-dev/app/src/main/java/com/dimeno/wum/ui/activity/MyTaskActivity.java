package com.dimeno.wum.ui.activity;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.AbsPermissionCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.ui.fragment.MyTaskListFragment;
import com.dimeno.wum.ui.fragment.TaskMapRouteFragment;
import com.dimeno.wum.viewmodel.MapRouteViewModel;
import com.dimeno.wum.widget.dialog.ConfirmDialog;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

import org.jetbrains.annotations.Nullable;

public class MyTaskActivity extends BaseActivity {
    private int mCurIndex;
    private Fragment mCurFragment;
    private View mBtnSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_task);
        fitDarkStatusBar(true);

        if (savedInstanceState != null) {
            mCurIndex = savedInstanceState.getInt("index");
        }

        initViews();
        initFragment(0);
    }

    private void initViews() {
        mBtnSwitch = findViewById(R.id.btn_switch);
        mBtnSwitch.setOnClickListener((v) -> {
            if (mCurIndex > 0) {
                --mCurIndex;
                mBtnSwitch.setSelected(false);
                initFragment(mCurIndex);
            } else {
                PermissionManager.request(getContext(), new AbsPermissionCallback() {
                    @Override
                    public void onGrant(String[] permissions) {
                        ++mCurIndex;
                        mBtnSwitch.setSelected(true);
                        initFragment(mCurIndex);
                        if (getContext() instanceof ViewModelStoreOwner) {
                            new ViewModelProvider((ViewModelStoreOwner) getContext()).get(MapRouteViewModel.class).sync();
                        }
                    }

                    @Override
                    public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                        new ConfirmDialog().setTitle("权限提示").setMessage("请授予定位权限").setRightText("授予权限").setCallback(new ConfirmDialog.Callback() {
                            @Override
                            public void onCancel() {

                            }

                            @Override
                            public void onConfirm() {
                                startActivity(PermissionManager.getSettingIntent(getContext()));
                            }
                        }).show(getSupportFragmentManager());
                    }
                }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
            }
        });
    }

    private void initFragment(int index) {
        mCurIndex = index;
        String tag = String.valueOf(index);
        FragmentManager manager = getSupportFragmentManager();
        Fragment fragment = manager.findFragmentByTag(tag);
        FragmentTransaction transaction = manager.beginTransaction();
        if (fragment == null) {
            fragment = newTab(index);
            transaction.add(R.id.container, fragment);
        } else {
            transaction.show(fragment);
        }
        if (mCurFragment != null && mCurFragment != fragment) {
            transaction.hide(mCurFragment);
        }
        transaction.commitAllowingStateLoss();
        mCurFragment = fragment;
    }

    private Fragment newTab(int index) {
        Fragment fragment;
        if (index == 0) {
            fragment = new MyTaskListFragment();
        } else {
            fragment = new TaskMapRouteFragment();
        }
        return fragment;
    }

    private Context getContext() {
        return this;
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt("index", mCurIndex);
        super.onSaveInstanceState(outState);
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "我的任务");
    }

}