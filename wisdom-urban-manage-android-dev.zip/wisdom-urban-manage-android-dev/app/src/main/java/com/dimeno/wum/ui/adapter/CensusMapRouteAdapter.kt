package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.wum.entity.CensusMapRouteEntity
import com.dimeno.wum.ui.adapter.holder.CensusMapRouteViewHolder

/**
 * census map route adapter
 * Created by wangzhen on 2020/10/28.
 */
class CensusMapRouteAdapter(list: MutableList<CensusMapRouteEntity>?) : RecyclerAdapter<CensusMapRouteEntity>(list) {
    var selectedItem: CensusMapRouteEntity? = null
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CensusMapRouteViewHolder(parent)
    }

    fun select(pos: Int) {
        mDatas.forEach { it.isSelected = false }
        mDatas[pos].apply {
            selectedItem = this
            isSelected = true
        }
        notifyDataSetChanged()
    }
}