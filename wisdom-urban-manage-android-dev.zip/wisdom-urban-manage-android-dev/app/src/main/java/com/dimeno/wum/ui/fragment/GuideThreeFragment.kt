package com.dimeno.wum.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dimeno.commons.storage.SPHelper
import com.dimeno.wum.MainActivity
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.SpConstant
import com.dimeno.wum.ui.activity.LoginActivity
import kotlinx.android.synthetic.main.fragment_guide_three.*

/**
 * guide three fragment
 * Created by wangzhen on 2020/9/25.
 */
class GuideThreeFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_guide_three, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_open.setOnClickListener {
            SPHelper.get().put(SpConstant.SP_IS_FIRST_RUNNING, false).commit()
            startActivity(Intent(context, if (UserBiz.get().isLogin) MainActivity::class.java else LoginActivity::class.java))
            activity?.finish()
        }
    }
}