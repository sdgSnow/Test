package com.dimeno.wum.widget.toolbar

import android.app.Activity
import android.view.View
import android.widget.TextView
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R

/**
 * toolbar for index page
 * Created by wangzhen on 2020/9/18.
 */
class AppIndexToolbar(activity: Activity) : Toolbar(activity) {
    private var tvTitle: TextView? = null
    override fun layoutRes(): Int = R.layout.toolbar_app_index_layout

    override fun onViewCreated(view: View) {
        super.onViewCreated(view)
        tvTitle = view.findViewById(R.id.title)
    }

    fun setTitle(title: String) {
        tvTitle?.text = title
    }

}