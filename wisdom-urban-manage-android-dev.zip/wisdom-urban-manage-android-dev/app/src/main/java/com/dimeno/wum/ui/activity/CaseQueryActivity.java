package com.dimeno.wum.ui.activity;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.AssignType;
import com.dimeno.wum.common.CaseStatus;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseQueryEntity;
import com.dimeno.wum.entity.QuerySpinnerEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseSmallClassEntity;
import com.dimeno.wum.entity.db.CaseSmallClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.network.task.CaseQueryListTask;
import com.dimeno.wum.ui.adapter.CaseQueryAdapter;
import com.dimeno.wum.ui.adapter.QuerySpinnerAdapter;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;
import com.dimeno.wum.widget.toolbar.AppTextMenuToolbar;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CaseQueryActivity extends BaseActivity implements OnRefreshCallback {

    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private Spinner spinner_small_class;
    private RecyclerView rv_case_query;
    private List<CaseQueryBean> caseQueryBeans;
    private Integer mAssingTypeCode = null;
    private Integer mCaseTypeCode = null;
    private Integer mDealResultCode = null;
    private List<QuerySpinnerEntity> spinner1List;
    private List<QuerySpinnerEntity> spinner2List;
    private List<QuerySpinnerEntity> spinner3List;
    private int[] assingTypeCodes = new int[]{AssignType.CASE_REPORT, AssignType.CASE_EXAMINE, AssignType.CASE_RECHECK, AssignType.CASE_INSPECTION};
    private String[] assignTypes = new String[]{"案件上报", "案件核实", "案件复核", "案件巡查"};
    private int[] dealResultCodes = new int[]{CaseStatus.REGISTRATION, CaseStatus.FILING_CASE, CaseStatus.CLOSED, CaseStatus.VOIDED};
    private String[] dealResults = new String[]{"未办结", "已立案", "已结案", "作废"};
    private EditText et_search;
    private RefreshLayout refresh_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_query);
        fitDarkStatusBar(true);

        spinner_type = findViewById(R.id.spinner_type);
        spinner_big_class = findViewById(R.id.spinner_big_class);
        spinner_small_class = findViewById(R.id.spinner_small_class);
        rv_case_query = findViewById(R.id.rv_case_query);
        et_search = findViewById(R.id.et_search);
        refresh_layout = findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        refresh_layout.startRefresh();

        getCaseQueryList();

        initSpinner1();
        initSpinner2();
        initSpinner3();
        initSelectListener();

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                getCaseQueryList();
            }
        });
    }

    /**
     * 请求接口获取案例列表
     */
    private void getCaseQueryList() {
        new CaseQueryListTask(new LoadingCallback<CaseQueryEntity>() {
            @Override
            public void onSuccess(CaseQueryEntity data) {
                initRcy(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("assignType", mAssingTypeCode)
                .put("caseType", mCaseTypeCode)
                .put("status", mDealResultCode)
                .put("keyword", et_search.getText().toString().trim())
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案件查询");
    }

    private void initSpinner1() {
        //初始化全部案件数据
        spinner1List = createTypeList();
        for (int i = 0; i < assignTypes.length; i++) {
            QuerySpinnerEntity caseSpinnerEntity = new QuerySpinnerEntity();
            caseSpinnerEntity.code = assingTypeCodes[i];
            caseSpinnerEntity.name = assignTypes[i];
            spinner1List.add(caseSpinnerEntity);
        }

        QuerySpinnerAdapter caseSpinnerAdapter1 = new QuerySpinnerAdapter(CaseQueryActivity.this, spinner1List);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化全部类型数据
        spinner2List = createBigClassList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                QuerySpinnerEntity caseSpinnerEntity = new QuerySpinnerEntity();
                caseSpinnerEntity.code = allType.code;
                caseSpinnerEntity.name = allType.name;
                spinner2List.add(caseSpinnerEntity);
            }
        }
        QuerySpinnerAdapter caseSpinnerAdapter2 = new QuerySpinnerAdapter(CaseQueryActivity.this, spinner2List);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSpinner3() {
        //初始化处理结果数据
        spinner3List = createSmallClassList();
        for (int i = 0; i < dealResults.length; i++) {
            QuerySpinnerEntity caseSpinnerEntity = new QuerySpinnerEntity();
            caseSpinnerEntity.code = dealResultCodes[i];
            caseSpinnerEntity.name = dealResults[i];
            spinner3List.add(caseSpinnerEntity);
        }
        QuerySpinnerAdapter caseSpinnerAdapter3 = new QuerySpinnerAdapter(CaseQueryActivity.this, spinner3List);
        spinner_small_class.setAdapter(caseSpinnerAdapter3);
    }

    private void initSelectListener() {
        //spineer的点击事件
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mAssingTypeCode = spinner1List.get(i).code;
                if(i == 0){
                    getCaseQueryList();
                }
                if(mAssingTypeCode != null) {
                    getCaseQueryList();
                }
            }
        });

        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = spinner2List.get(i).code;
                if(i == 0){
                    getCaseQueryList();
                }
                if(mCaseTypeCode != null) {
                    getCaseQueryList();
                }
            }
        });

        spinner_small_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mDealResultCode = spinner3List.get(i).code;
                if(i == 0){
                    getCaseQueryList();
                }
                if(mDealResultCode != null) {
                    getCaseQueryList();
                }
            }
        });
    }

    private List<QuerySpinnerEntity> createTypeList() {
        List<QuerySpinnerEntity> caseTypeList = new ArrayList<>();
        QuerySpinnerEntity caseSpinnerEntity1 = new QuerySpinnerEntity();
        caseSpinnerEntity1.code = null;
        caseSpinnerEntity1.name = "全部案件";
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<QuerySpinnerEntity> createBigClassList() {
        List<QuerySpinnerEntity> bigClassList = new ArrayList<>();
        QuerySpinnerEntity caseSpinnerEntity2 = new QuerySpinnerEntity();
        caseSpinnerEntity2.code = null;
        caseSpinnerEntity2.name = "案件类型";
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private List<QuerySpinnerEntity> createSmallClassList() {
        List<QuerySpinnerEntity> smallClassList = new ArrayList<>();
        QuerySpinnerEntity caseSpinnerEntity3 = new QuerySpinnerEntity();
        caseSpinnerEntity3.code = null;
        caseSpinnerEntity3.name = "处理结果";
        smallClassList.add(caseSpinnerEntity3);
        return smallClassList;
    }

    private void initRcy(CaseQueryEntity caseQueryEntity) {
        caseQueryBeans = new ArrayList<>();
        if (caseQueryEntity.data != null) {
            for (CaseQueryEntity.DataBean datum : caseQueryEntity.data) {
                CaseQueryBean caseQueryBean = new CaseQueryBean();
                caseQueryBean.address = datum.address;
                caseQueryBean.latitude = datum.latitude;
                caseQueryBean.assignType = datum.assignType;
                caseQueryBean.description = datum.description;
                caseQueryBean.updateUser = datum.updateUser;
                caseQueryBean.updateTime = datum.updateTime;
                caseQueryBean.caseCoding = datum.caseCoding;
                caseQueryBean.source = datum.source;
                caseQueryBean.caseNo = datum.caseNo;
                caseQueryBean.caseType = datum.caseType;
                caseQueryBean.assignTypeName = datum.assignTypeName;
                caseQueryBean.smallClassName = datum.smallClassName;
                caseQueryBean.smallClass = datum.smallClass;
                caseQueryBean.caseTypeName = datum.caseTypeName;
                caseQueryBean.bigClassName = datum.bigClassName;
                caseQueryBean.createTime = datum.createTime;
                caseQueryBean.statusName = datum.statusName;
                caseQueryBean.createUser = datum.createUser;
                caseQueryBean.id = datum.id;
                caseQueryBean.taskId = datum.taskId;
                caseQueryBean.bigClass = datum.bigClass;
                caseQueryBean.longitude = datum.longitude;
                caseQueryBean.status = datum.status;
                caseQueryBeans.add(caseQueryBean);
            }
        }

        showCaseList();

    }

    public void showCaseList() {
        rv_case_query.setLayoutManager(new GridLayoutManager(CaseQueryActivity.this, 1, GridLayoutManager.VERTICAL, false));
        CaseQueryAdapter caseQueryAdapter = new CaseQueryAdapter(caseQueryBeans, rv_case_query);
        caseQueryAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_case_query));
        rv_case_query.setAdapter(caseQueryAdapter);
        caseQueryAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                Intent intent = new Intent(CaseQueryActivity.this, CaseDetailsActivity.class);
                intent.putExtra("id", caseQueryBeans.get(position).id);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRefresh() {
        getCaseQueryList();
    }
}