package com.dimeno.wum.entity.db;

import java.io.Serializable;

/**
 * case dict entity
 * Created by wangzhen on 2020/9/17.
 */
public class CaseDictEntity implements Serializable {
    public String code;
    public String pcode;
    public int topCode;
    public String name;
    public int sort;
}
