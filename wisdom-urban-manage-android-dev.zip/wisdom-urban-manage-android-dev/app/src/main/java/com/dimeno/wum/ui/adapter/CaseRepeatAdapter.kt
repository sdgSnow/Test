package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.wum.entity.CaseRepeatEntity
import com.dimeno.wum.entity.CaseRepeatResponse
import com.dimeno.wum.ui.adapter.holder.CaseRepeatViewHolder

/**
 * case repeat adapter
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatAdapter(list: MutableList<CaseRepeatEntity>?) : RecyclerAdapter<CaseRepeatEntity>(list) {
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CaseRepeatViewHolder(parent)
    }
}