package com.dimeno.wum.ui.activity

import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.recyclerview.widget.LinearLayoutManager
import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.commons.storage.DataHelper
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.commons.utils.T
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.MainActivity
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.IKey
import com.dimeno.wum.entity.CaseRepeatEntity
import com.dimeno.wum.network.task.CaseReportTask
import com.dimeno.wum.ui.adapter.CaseRepeatAdapter
import com.dimeno.wum.ui.header.CaseRepeatHeader
import com.dimeno.wum.utils.ActivityManager
import com.dimeno.wum.utils.sequence.CaseReportController
import com.dimeno.wum.viewmodel.IndexViewModel
import com.dimeno.wum.widget.dialog.DialogManager
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import kotlinx.android.synthetic.main.activity_case_repeat_confirm.*

/**
 * case report confirm activity
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatConfirmActivity : BaseActivity() {
    private var adapter: CaseRepeatAdapter? = null
    private var controller: Any? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_case_repeat_confirm)
        fitDarkStatusBar(true)
        initViews()
        bindData()
    }

    private fun bindData() {
        val extra = intent.getSerializableExtra(IKey.DATA)
        if (extra is ArrayList<*>) {
            try {
                val list: ArrayList<CaseRepeatEntity> = extra as ArrayList<CaseRepeatEntity>
                adapter?.setData(list)
            } catch (e: Exception) {
            }
        }
    }

    private fun initViews() {
        btn_back.setOnClickListener { finish() }
        btn_report.setOnClickListener { report() }

        recycler.layoutManager = LinearLayoutManager(this)
        adapter = CaseRepeatAdapter(null).apply {
            addHeader(CaseRepeatHeader().onCreateView(recycler))
            setEmpty(object : RecyclerItem() {
                override fun layout(): Int = R.layout.global_empty_layout
            }.onCreateView(recycler))
        }
        recycler.adapter = adapter

        controller = DataHelper.get().getData("case_controller")
    }

    private fun report() {
        DialogManager.get().showLoading()
        CaseReportTask(object : LoadingCallback<String>() {
            override fun onSuccess(data: String) {
                T.show("上报成功")
                // 同步刷新首页数据
                ActivityManager.get(MainActivity::class.java)?.let {
                    ViewModelProvider(it as ViewModelStoreOwner).get(IndexViewModel::class.java).refreshIndex()
                }
                // 通知案件核实上报成功
                setResult(Code.CODE_REPORT_SUCCESS)
                finish()
            }

            override fun onError(code: Int, message: String) {
                T.show(message)
            }

            override fun onComplete() {
                DialogManager.get().stopLoading()
            }
        }).setTag(this).apply {
            if (controller is CaseReportController) {
                (controller as CaseReportController).buildParams(this)
            }
        }.exe()
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, getString(R.string.case_repeat_confirm_title))
    }
}