package com.dimeno.wum.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dimeno.wum.entity.db.CaseStashEntity

/**
 * CaseStashViewModel
 * Created by wangzhen on 2020/9/18.
 */
class CaseStashViewModel : ViewModel() {
    private val stashEditLiveData = MutableLiveData<CaseStashEntity>()
    private val multiCheckLiveData = MutableLiveData<Any>()
    private val refreshLiveData = MutableLiveData<Any>()

    /**
     * observe edit stash data
     */
    fun getEditLiveData(): MutableLiveData<CaseStashEntity> = stashEditLiveData
    fun edit(data: CaseStashEntity) {
        stashEditLiveData.value = data
    }

    /**
     * observe multi check status change
     */
    fun getMultiCheckLiveData(): MutableLiveData<Any> = multiCheckLiveData
    fun onMultiCheckChange() {
        multiCheckLiveData.value = null
    }

    /**
     * observe refresh stash data event
     */
    fun getRefreshStashLiveData(): MutableLiveData<Any> = refreshLiveData
    fun refreshStash() {
        refreshLiveData.value = null
    }

}