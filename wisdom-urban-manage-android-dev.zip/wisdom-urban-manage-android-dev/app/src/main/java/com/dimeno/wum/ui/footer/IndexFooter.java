package com.dimeno.wum.ui.footer;

import android.view.View;
import android.widget.TextView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.wum.R;
import com.dimeno.wum.entity.BasicStatisticsEntity;

public class IndexFooter extends RecyclerItem {

    private TextView tv_footer_1;
    private TextView tv_footer_2;
    private TextView tv_footer_3;
    private TextView tv_footer_4;

    @Override
    public int layout() {
        return R.layout.item_index_footer_extra;
    }

    @Override
    public void onViewCreated(View itemView) {
        tv_footer_1 = itemView.findViewById(R.id.tv_footer_1);
        tv_footer_2 = itemView.findViewById(R.id.tv_footer_2);
        tv_footer_3 = itemView.findViewById(R.id.tv_footer_3);
        tv_footer_4 = itemView.findViewById(R.id.tv_footer_4);
        setData(null);
    }

    public void setData(BasicStatisticsEntity.DataBean data){
        tv_footer_1.setText(String.valueOf(data == null ? 0 : data.curDayReportNum));
        tv_footer_2.setText(String.valueOf(data == null ? 0 : data.curWeekReportNum));
        tv_footer_3.setText(String.valueOf(data == null ? 0 : data.curWeekCaseNum));
        tv_footer_4.setText(String.valueOf(data == null ? 0 : data.curWeekCloseNum));
    }
}
