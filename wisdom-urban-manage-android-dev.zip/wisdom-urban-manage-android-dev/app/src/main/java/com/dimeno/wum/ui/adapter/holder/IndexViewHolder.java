package com.dimeno.wum.ui.adapter.holder;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.adapter.callback.OnHolderClickCallback;
import com.dimeno.commons.utils.T;
import com.dimeno.wum.R;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.IndexTaskType;
import com.dimeno.wum.common.WebUrl;
import com.dimeno.wum.ui.activity.AttendanceActivity;
import com.dimeno.wum.ui.activity.CaseCheckActivity;
import com.dimeno.wum.ui.activity.CaseManageSpinnerActivity;
import com.dimeno.wum.ui.activity.CaseQueryActivity;
import com.dimeno.wum.ui.activity.CaseReCheckActivity;
import com.dimeno.wum.ui.activity.MyTaskActivity;
import com.dimeno.wum.ui.activity.SpecialCensusActivity;
import com.dimeno.wum.ui.activity.WebActivity;
import com.dimeno.wum.ui.bean.IndexBean;

public class IndexViewHolder extends RecyclerViewHolder<IndexBean> implements OnHolderClickCallback {

    private final ImageView iv_index_icon;
    private final TextView tv_index_title;

    public IndexViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_index);
        iv_index_icon = findViewById(R.id.iv_index_icon);
        tv_index_title = findViewById(R.id.tv_index_title);
    }

    @Override
    public void bind() {
        iv_index_icon.setImageResource(mData.icon);
        tv_index_title.setText(mData.name);
    }

    @Override
    public void onItemClick(View itemView, int position) {
        switch (mData.type) {
            case IndexTaskType.ATTENDANCE:
                startActivity(AttendanceActivity.class);
                break;
            case IndexTaskType.CASE_QUERY:
                startActivity(CaseQueryActivity.class);
                break;
            case IndexTaskType.CASE_CHECK:
                startActivity(CaseCheckActivity.class);
                break;
            case IndexTaskType.CASE_RE_CHECK:
                startActivity(CaseReCheckActivity.class);
                break;
            case IndexTaskType.MY_TASK:
                startActivity(MyTaskActivity.class);
                break;
            case IndexTaskType.SPECIAL_CENSUS:
                startActivity(SpecialCensusActivity.class);
                break;
            case IndexTaskType.MAP_MANAGER:
                T.show("地图管理");
                break;
            case IndexTaskType.CASE_MANAGER:
                startActivity(CaseManageSpinnerActivity.class);
//                startActivity(WebActivity.class, WebUrl.CASE_MANAGER,"案件管理");
                break;
            case IndexTaskType.CASE_STATISTIC:
                startActivity(WebActivity.class, WebUrl.CASE_STATISTIC,"案件统计");
                break;
            case IndexTaskType.LEADER_MAP_MANAGER:
                startActivity(WebActivity.class, WebUrl.MAP_MANAGE,"地图管理");
                break;
            case IndexTaskType.ASSESSMENT_EVALUATION:
                T.show("考核评价");
                break;
            case IndexTaskType.CITY_QUES:
                startActivity(WebActivity.class, WebUrl.CITY_QUES,"城市问题");
                break;
        }
    }

    private void startActivity(Class<?> clazz) {
        itemView.getContext().startActivity(new Intent(itemView.getContext(), clazz));
    }

    private void startActivity(Class<?> clazz,String weburl,String name) {
        itemView.getContext().startActivity(new Intent(itemView.getContext(), clazz).putExtra(IKey.URL,weburl).putExtra(IKey.TITLE,name));
    }
}
