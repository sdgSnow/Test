package com.dimeno.wum.widget.toolbar

/**
 * toolbar callback
 * Created by wangzhen on 2020/9/19.
 */
abstract class OnToolbarCallback {
    open fun onClose() {}

    abstract fun onMenuClick()
}