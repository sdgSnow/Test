package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.wum.entity.CommonSpinnerEntity
import com.dimeno.wum.ui.adapter.holder.CaseSheetViewHolder

/**
 * CaseSheetAdapter
 * Created by wangzhen on 2020/9/18.
 */
class CaseSheetAdapter(list: MutableList<CommonSpinnerEntity>) : RecyclerAdapter<CommonSpinnerEntity>(list) {
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CaseSheetViewHolder(parent)
    }
}