package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class MyMessageEntity implements Serializable {


    /**
     * code : 200
     * data : [{"msg":"您提交的案件编号：深城管2020字第1039号已受理，感谢您的工作支持。","caseReportId":"1310529818731593730","caseMsgType":7,"msgType":1,"createTime":"2020-09-28 18:40:44","updateUser":"1","createUser":"1","updateTime":"2020-09-28 18:40:44","id":"1310529870308950017","title":"案件受理","userId":"1308613965165461505","url":""}]
     * message : 请求成功
     * success : true
     */

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;

    public static class DataBean implements Serializable{
        /**
         * msg : 您提交的案件编号：深城管2020字第1039号已受理，感谢您的工作支持。
         * caseReportId : 1310529818731593730
         * caseMsgType : 7
         * msgType : 1
         * createTime : 2020-09-28 18:40:44
         * updateUser : 1
         * createUser : 1
         * updateTime : 2020-09-28 18:40:44
         * id : 1310529870308950017
         * title : 案件受理
         * userId : 1308613965165461505
         * url :
         */

        public String msg;
        public String caseReportId;
        public int caseMsgType;
        public int msgType;
        public String createTime;
        public String updateUser;
        public String createUser;
        public String updateTime;
        public String id;
        public String title;
        public String userId;
        public String url;

    }
}
