package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;

/**
 * LoginTask
 * Created by sdg on 2020/9/15.
 */
public class CaseFlowTask extends PostFormTask {
    public <EntityType> CaseFlowTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getCaseProcess";
    }
}
