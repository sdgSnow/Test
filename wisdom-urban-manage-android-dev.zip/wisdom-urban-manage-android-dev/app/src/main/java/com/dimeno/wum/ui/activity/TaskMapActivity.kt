package com.dimeno.wum.ui.activity

import android.os.Bundle
import androidx.core.content.ContextCompat
import com.baidu.mapapi.map.*
import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.utils.SpatialRelationUtil
import com.dimeno.commons.json.JsonUtils
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.commons.utils.T
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.entity.CoordinateEntity
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import kotlinx.android.synthetic.main.activity_map_manage.*

/**
 * 任务地图
 * Created by wangzhen on 2020/9/19.
 */
class TaskMapActivity : BaseActivity() {
    private var coordinates = mutableListOf<LatLng>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_manage)
        fitDarkStatusBar(true)
        config()
        bindData()
    }

    private fun bindData() {
        val list = JsonUtils.parseArray(intent.getStringExtra("data"), CoordinateEntity::class.java)
        list?.let {
            coordinates = it.map { entity ->
                LatLng(entity.latitude.toDouble(), entity.longitude.toDouble())
            }.toMutableList()
        }
        if (this.coordinates.size >= 3) {
            map_view.map.apply {
                addOverlay(PolygonOptions().points(coordinates).fillColor(ContextCompat.getColor(this@TaskMapActivity, R.color.colorAccent)).stroke(Stroke(5, ContextCompat.getColor(this@TaskMapActivity, R.color.colorPrimary))))
                // 取第一个坐标点作为中心点
                coordinates[0].apply {
                    animateMapStatus(
                            MapStatusUpdateFactory.newLatLngZoom(LatLng(latitude, longitude), 15f)
                    )
                }
            }
        }
    }

    private fun config() {
        map_view.apply {
            showZoomControls(false)
            map.isMyLocationEnabled = true
            map.setOnMapClickListener(object : BaiduMap.OnMapClickListener {
                override fun onMapClick(latLng: LatLng) {
                    checkRegion(latLng)
                }

                override fun onMapPoiClick(poi: MapPoi) {
                    checkRegion(poi.position)
                }
            })
        }

    }

    private fun checkRegion(latLng: LatLng) {
        if (SpatialRelationUtil.isPolygonContainsPoint(coordinates, latLng)) {
            T.show("点击区域")
        }
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, "任务地图")
    }
}