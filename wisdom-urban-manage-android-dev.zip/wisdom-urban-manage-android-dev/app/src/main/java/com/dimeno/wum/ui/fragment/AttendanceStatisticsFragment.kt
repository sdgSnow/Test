package com.dimeno.wum.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.entity.CommonSpinnerEntity
import com.dimeno.wum.entity.db.AttendanceHistory
import com.dimeno.wum.entity.db.AttendanceHistory_
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.DateUtils
import com.dimeno.wum.widget.abs.AbsItemSelectedListener
import com.haibin.calendarview.Calendar
import com.haibin.calendarview.CalendarView
import io.objectbox.Box
import kotlinx.android.synthetic.main.fragment_attendance_statistics_layout.*

/**
 * 统计
 * Created by wangzhen on 2020/9/19.
 */
class AttendanceStatisticsFragment : Fragment() {
    private var curYear: Int = 0
    private var curMonth: Int = 0
    private var curDay: Int = 0

    private var requireGoWork: Long = 0 // 08:30
    private var clockInGoWork: Long = 0
    private var addressGoWork: String? = null

    private var requireOffWork: Long = 0 // 17:30
    private var clockInOffWork: Long = 0
    private var addressOffWork: String? = null

    private val box: Box<AttendanceHistory> = DBLoader.load(AttendanceHistory::class.java)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_attendance_statistics_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        bindSpinner()
        query()
    }

    private fun bindSpinner() {
        spinner_year.adapter = CommonSpinnerAdapter(context, mutableListOf<CommonSpinnerEntity>().apply {
            val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
            for (i in year downTo 2018) {
                add(CommonSpinnerEntity().apply {
                    code = i.toString()
                    name = i.toString()
                })
            }
        })
        spinner_month.adapter = CommonSpinnerAdapter(context, mutableListOf<CommonSpinnerEntity>().apply {
            for (i in 1..12) {
                add(CommonSpinnerEntity().apply {
                    code = i.toString()
                    name = i.toString()
                })
            }
        })
        spinner_month.setSelection(java.util.Calendar.getInstance().get(java.util.Calendar.MONTH))
    }

    private fun query() {
        // 查询打卡记录
        box.query().apply {
            equal(AttendanceHistory_.userId, UserBiz.get().userId)
            equal(AttendanceHistory_.dateString, String.format("%04d-%02d-%02d", curYear, curMonth, curDay))
        }.build().findFirst()?.let { record ->
            if (record.requireGoWork > 0)
                requireGoWork = record.requireGoWork
            clockInGoWork = record.clockInGoWork
            addressGoWork = record.addressGoWork

            if (record.requireOffWork > 0)
                requireOffWork = record.requireOffWork
            clockInOffWork = record.clockInOffWork
            addressOffWork = record.addressOffWork
        } ?: let {
            clockInGoWork = 0
            addressGoWork = null
            clockInOffWork = 0
            addressOffWork = null
        }
        val timeGoWork = DateUtils.format(requireGoWork, "HH:mm")
        val timeOffWork = DateUtils.format(requireOffWork, "HH:mm")
        val clockInCount = (if (clockInGoWork > 0) 1 else 0) + (if (clockInOffWork > 0) 1 else 0)
        val workHours = if (clockInGoWork > 0 && clockInOffWork > 0 && clockInOffWork > clockInGoWork) {
            "共计${(clockInOffWork - clockInGoWork) / 1000 / 60 / 60}小时"
        } else "无法统计"

        val summary = "班次:${timeGoWork}到${timeOffWork}，今日打卡${clockInCount}次，工时${workHours}"
        tv_summary.text = summary

        // 上班时间
        tv_require_go_work.text = String.format("上班时间%s", timeGoWork)
        when {
            clockInGoWork == 0L -> {
                tv_go_work_status.text = "缺卡"
                tv_go_work_status.setBackgroundResource(R.drawable.attendance_clock_in_abnormal)
            }
            clockInGoWork > requireGoWork -> {
                tv_go_work_status.text = "迟到"
                tv_go_work_status.setBackgroundResource(R.drawable.attendance_clock_in_abnormal)
            }
            else -> {
                tv_go_work_status.text = "正常"
                tv_go_work_status.setBackgroundResource(R.drawable.attendance_clock_in_normal)
            }
        }
        tv_clock_in_go_work.text = if (clockInGoWork == 0L) "未打卡" else String.format("打卡时间%s", DateUtils.format(clockInGoWork, "HH:mm"))
        tv_address_go_work.visibility = if (clockInGoWork == 0L) View.GONE else View.VISIBLE
        tv_address_go_work.text = addressGoWork

        // 下班时间
        tv_require_off_work.text = String.format("下班时间%s", timeOffWork)
        when {
            clockInOffWork == 0L -> {
                tv_off_work_status.text = "缺卡"
                tv_off_work_status.setBackgroundResource(R.drawable.attendance_clock_in_abnormal)
            }
            clockInOffWork < requireOffWork -> {
                tv_off_work_status.text = "早退"
                tv_off_work_status.setBackgroundResource(R.drawable.attendance_clock_in_abnormal)
            }
            else -> {
                tv_off_work_status.text = "正常"
                tv_off_work_status.setBackgroundResource(R.drawable.attendance_clock_in_normal)
            }
        }
        tv_clock_in_off_work.text = if (clockInOffWork == 0L) "未打卡" else String.format("打卡时间%s", DateUtils.format(clockInOffWork, "HH:mm"))
        tv_address_off_work.visibility = if (clockInOffWork == 0L) View.GONE else View.VISIBLE
        tv_address_off_work.text = addressOffWork
    }

    private fun initViews() {
        requireGoWork = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 8)
            set(java.util.Calendar.MINUTE, 30)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        requireOffWork = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 17)
            set(java.util.Calendar.MINUTE, 30)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis

        curYear = calendar_view.curYear
        curMonth = calendar_view.curMonth
        curDay = calendar_view.curDay
        calendar_view.setOnCalendarSelectListener(object : CalendarView.OnCalendarSelectListener {
            override fun onCalendarOutOfRange(calendar: Calendar) {

            }

            override fun onCalendarSelect(calendar: Calendar, isClick: Boolean) {
                curYear = calendar.year
                curMonth = calendar.month
                curDay = calendar.day
                query()
            }
        })

        spinner_year.onItemSelectedListener = object : AbsItemSelectedListener() {
            override fun onItemSelected(adapterView: AdapterView<*>, view: View, position: Int, id: Long) {
                if (adapterView.adapter is CommonSpinnerAdapter) {
                    (adapterView.adapter as CommonSpinnerAdapter).run {
                        getItem(position).code?.let { year ->
                            curYear = year.toInt()
                            calendar_view.scrollToCalendar(curYear, curMonth, curDay)
                        }
                    }
                }
            }
        }
        spinner_month.onItemSelectedListener = object : AbsItemSelectedListener() {
            override fun onItemSelected(adapterView: AdapterView<*>, view: View, position: Int, id: Long) {
                if (adapterView.adapter is CommonSpinnerAdapter) {
                    (adapterView.adapter as CommonSpinnerAdapter).run {
                        getItem(position).code?.let { month ->
                            curMonth = month.toInt()
                            calendar_view.scrollToCalendar(curYear, curMonth, curDay)
                        }
                    }
                }
            }
        }
    }
}