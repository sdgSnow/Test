package com.dimeno.wum.entity;

import com.dimeno.wum.entity.db.CaseDictEntity;
import com.dimeno.wum.entity.db.CaseTypeEntity;

import java.io.Serializable;
import java.util.List;

/**
 * 案件分类
 * Created by wangzhen on 2020/9/15.
 */
public class CaseTypeResponse implements Serializable {
    public int code;
    public Data data;
    public String message;
    public boolean success;

    public static class Data implements Serializable {
        public List<CaseTypeEntity> caseTypeList;
        public List<CaseDictEntity> dictList;
    }
}
