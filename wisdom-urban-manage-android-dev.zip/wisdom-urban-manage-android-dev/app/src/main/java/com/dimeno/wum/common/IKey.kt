package com.dimeno.wum.common

/**
 * intent keys
 * Created by wangzhen on 2020/9/23.
 */
class IKey {
    companion object {
        const val LATITUDE = "latitude"
        const val LONGITUDE = "longitude"
        const val ADDRESS = "address"
        const val TASK_ID = "task_id"
        const val DATA = "data"
        const val POSITION = "position"
        const val PREVIEW_URL = "preview_url"
        const val TITLE = "title"
        const val URL = "url"
        const val TASK_TYPE = "task_type"

        const val GENERAL_SURVEY_ID = "general_survey_id"
        const val PRESET = "preset" // 是否为预置类型
        const val CASE_TYPE_NAME = "case_type_name"
        const val CASE_TYPE_CODE = "case_type_code"
        const val CASE_BIG_CLASS_NAME = "case_big_class_name"
        const val CASE_BIG_CLASS_CODE = "case_big_class_code"
        const val CASE_SMALL_CLASS_NAME = "case_small_class_name"
        const val CASE_SMALL_CLASS_CODE = "case_small_class_code"
    }
}