package com.dimeno.wum.ui.bean;

public class CaseReCheckHeaderBean {

    public String imageUrl;
}
