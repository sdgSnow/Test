package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseCheckInfoViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseTypeViewHolder;
import com.dimeno.wum.ui.bean.CaseCheckInfoBean;
import com.dimeno.wum.ui.bean.SpinnerQueryCaseTypeBean;

import java.util.List;

public class CaseTypeAdapter extends RecyclerAdapter<SpinnerQueryCaseTypeBean> {
    public CaseTypeAdapter(List<SpinnerQueryCaseTypeBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseTypeViewHolder(parent);
    }
}
