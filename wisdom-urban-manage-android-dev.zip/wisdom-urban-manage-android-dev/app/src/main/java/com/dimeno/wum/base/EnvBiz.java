package com.dimeno.wum.base;

import android.content.Context;
import android.content.SharedPreferences;

import com.dimeno.commons.utils.AppUtils;
import com.dimeno.wum.BuildConfig;

/**
 * api environment biz
 * Created by wangzhen on 2020/9/14.
 */
public class EnvBiz {
    private static final String URL_TEST = "http://zhcg.dimenosys.com/";
    private static final String URL_FORMAL = "http://zhcg.dimenosys.com/";

    public static boolean isDebug() {
        return BuildConfig.APP_DEBUG;
    }

    public static String getUrl() {
        if (isDebug()) {
            SharedPreferences preferences = AppUtils.getContext().getSharedPreferences("developer", Context.MODE_PRIVATE);
            return preferences.getBoolean("env", true) ? URL_TEST : URL_FORMAL;
        }
        return URL_FORMAL;
    }
}
