package com.dimeno.wum.entity

/**
 * message data entity
 * Created by wangzhen on 2020/9/27.
 */
class MessageDataEntity : MessageEntity {
    var caseId: String? = null
    var status: String? = null
    var content: String? = null
    override fun type(): Int = MessageEntity.TYPE_DATA
}