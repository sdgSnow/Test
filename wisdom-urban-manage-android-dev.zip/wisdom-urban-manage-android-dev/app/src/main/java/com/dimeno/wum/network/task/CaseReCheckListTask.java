package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;

public class CaseReCheckListTask extends PostFormTask {
    public <EntityType> CaseReCheckListTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getCaseCheckList";
    }
}
