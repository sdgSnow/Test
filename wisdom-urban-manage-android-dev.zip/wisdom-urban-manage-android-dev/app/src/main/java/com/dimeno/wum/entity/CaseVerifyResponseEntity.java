package com.dimeno.wum.entity;

import java.io.Serializable;

public class CaseVerifyResponseEntity implements Serializable {

}
