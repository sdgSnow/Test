package com.dimeno.wum.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * index view model
 * Created by wangzhen on 2020/9/23.
 */
class IndexViewModel : ViewModel() {
    private val refreshLiveData = MutableLiveData<Any>()

    fun getRefreshLiveData(): MutableLiveData<Any> = refreshLiveData
    fun refreshIndex() {
        refreshLiveData.value = null
    }

}