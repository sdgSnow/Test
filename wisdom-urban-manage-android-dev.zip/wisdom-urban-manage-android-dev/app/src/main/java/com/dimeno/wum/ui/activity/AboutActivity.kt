package com.dimeno.wum.ui.activity

import android.os.Bundle
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.base.EnvBiz
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import com.wangzhen.router.Router
import kotlinx.android.synthetic.main.activity_about.*

/**
 * about activity
 * Created by wangzhen on 2020/9/26.
 */
class AboutActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        fitDarkStatusBar(true)
        app_version.text = String.format("V%s", AppUtils.getVersionName())

        if (EnvBiz.isDebug()) {
            logo.setOnLongClickListener {
                Router.with(this).toPath("/developer")
                false
            }
        }

        app_service_protocol.apply {
            paint.isUnderlineText = true
//            setOnClickListener {
//                startActivity(Intent(context, WebActivity::class.java).apply {
//                    putExtra(IKey.TITLE, getString(R.string.app_service_protocol))
//                    putExtra(IKey.URL, WebUrl.SERVICE_PROTOCOL)
//                })
//            }
        }
        app_privacy_guidelines.apply {
            paint.isUnderlineText = true
//            setOnClickListener {
//                startActivity(Intent(context, WebActivity::class.java).apply {
//                    putExtra(IKey.TITLE, getString(R.string.app_privacy_guidelines))
//                    putExtra(IKey.URL, WebUrl.PRIVACY_GUIDELINE)
//                })
//            }
        }
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, "关于")
    }
}