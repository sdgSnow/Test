package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.GetTask;
import com.dimeno.network.task.PostFormTask;

public class BasicStatisticsTask extends GetTask {
    public <EntityType> BasicStatisticsTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getBasicStatistics";
    }
}
