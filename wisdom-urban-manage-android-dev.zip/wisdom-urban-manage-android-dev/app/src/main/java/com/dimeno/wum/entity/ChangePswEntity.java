package com.dimeno.wum.entity;

import java.io.Serializable;

public class ChangePswEntity implements Serializable {


    /**
     * code : 200
     * data : null
     * message : 操作成功！
     * success : true
     */

    public int code;
    public Object data;
    public String message;
    public boolean success;

}
