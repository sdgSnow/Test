package com.dimeno.wum.ui.bean;

import java.io.Serializable;

public class IndexBean implements Serializable {
    public int type;
    public int icon;
    public String name;

    public IndexBean(int type, int icon, String name) {
        this.type = type;
        this.icon = icon;
        this.name = name;
    }
}
