package com.dimeno.wum.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.structure.IList;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.MyTaskEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.entity.db.TaskArea;
import com.dimeno.wum.network.task.MyTaskTask;
import com.dimeno.wum.ui.activity.TaskDetailsActivity;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.adapter.MyTaskAdapter;
import com.dimeno.wum.ui.bean.MapRouteEntity;
import com.dimeno.wum.ui.bean.MyTaskBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.viewmodel.MapRouteViewModel;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * 我的任务列表
 * Created by wangzhen on 2020/10/31.
 */
public class MyTaskListFragment extends Fragment implements OnRefreshCallback {
    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private Spinner spinner_small_class;
    private String mTaskAreaCode = null;
    private String mCaseTypeCode = null;
    private String mBigClassCode = null;
    private List<CommonSpinnerEntity> taskAreaList;
    private List<CommonSpinnerEntity> typeList;
    private List<CommonSpinnerEntity> bigClassList;
    private RecyclerView rv_my_task;
    private List<MyTaskBean> myTaskBeans;
    private EditText et_search;
    private RefreshLayout refresh_layout;
    private MyTaskAdapter mAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_task_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rv_my_task = view.findViewById(R.id.rv_my_task);
        spinner_type = view.findViewById(R.id.spinner_type);
        spinner_big_class = view.findViewById(R.id.spinner_big_class);
        spinner_small_class = view.findViewById(R.id.spinner_small_class);
        et_search = view.findViewById(R.id.et_search);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        refresh_layout.startRefresh();

        getMyTask();

        initSpinner1();
        initSpinner2();
        initSpinner3();
        initSelectListener();

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                getMyTask();
            }
        });

        initObserver();

    }

    private void initObserver() {
        if (getContext() instanceof ViewModelStoreOwner) {
            MapRouteViewModel viewModel = new ViewModelProvider((ViewModelStoreOwner) getContext()).get(MapRouteViewModel.class);
            viewModel.getSyncLiveData().observe(getViewLifecycleOwner(), o -> {
                if (mAdapter != null && IList.isNotEmpty(mAdapter.getDatas())) {
                    List<MapRouteEntity> list = new ArrayList<>();
                    MapRouteEntity entity;
                    for (MyTaskBean item : mAdapter.getDatas()) {
                        entity = new MapRouteEntity();
                        entity.id = item.id;
                        entity.caseType = item.caseType;
                        entity.caseTypeName = item.caseTypeName;
                        entity.smallClass = item.smallClass;
                        entity.smallClassName = item.smallClassName;
                        entity.bigClass = item.bigClass;
                        entity.bigClassName = item.bigClassName;
                        entity.latitude = item.latitude;
                        entity.longitude = item.longitude;
                        entity.address = item.address;
                        entity.createTime = item.createTime;
                        entity.uploadTimeEnd = item.createTime;
                        list.add(entity);
                    }
                    viewModel.setMapDataSource(list);
                }
            });
        }
    }

    private void getMyTask() {
        new MyTaskTask(new LoadingCallback<MyTaskEntity>() {
            @Override
            public void onSuccess(MyTaskEntity data) {
                initTaskList(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("taskArea", mTaskAreaCode)
                .put("caseType", mCaseTypeCode)
                .put("bigClass", mBigClassCode)
                .put("keyword", et_search.getText().toString().trim())
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    private void initSpinner1() {
        //初始化任务区域数据
        taskAreaList = createTaskAreaList();
        List<TaskArea> taskAreas = DBLoader.load(TaskArea.class).getAll();
        if (taskAreas != null) {
            for (TaskArea allType : taskAreas) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                taskAreaList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter1 = new CommonSpinnerAdapter(getContext(), taskAreaList);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化案件类型数据
        typeList = createTypeList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                typeList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter2 = new CommonSpinnerAdapter(getContext(), typeList);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSpinner3() {
        //初始化大类数据
        bigClassList = createBigClassList();
        if (mCaseTypeCode != null) {
            List<CaseBigClassEntity> caseBigClassEntities = DBLoader.load(CaseBigClassEntity.class).query().equal(CaseBigClassEntity_.topcode, mCaseTypeCode).build().find();
            if (caseBigClassEntities != null) {
                for (CaseBigClassEntity caseBigClassEntity : caseBigClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseBigClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseBigClassEntity.getName());
                    bigClassList.add(caseSpinnerEntity);
                }

            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter3 = new CommonSpinnerAdapter(getContext(), bigClassList);
        spinner_small_class.setAdapter(caseSpinnerAdapter3);
    }

    private void initSelectListener() {
        //spineer的点击事件
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mTaskAreaCode = taskAreaList.get(i).getCode();
                if (i == 0) {
                    getMyTask();
                }
                if (mTaskAreaCode != null) {
                    getMyTask();
                }
            }
        });

        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = bigClassList.get(i).getCode();
                mBigClassCode = null;
                initSpinner3();
                if (i == 0) {
                    getMyTask();
                }
                if (mCaseTypeCode != null) {
                    getMyTask();
                }
            }
        });

        spinner_small_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mBigClassCode = bigClassList.get(i).getCode();
                if (i == 0) {
                    getMyTask();
                }
                if (mBigClassCode != null) {
                    getMyTask();
                }
            }
        });
    }

    private List<CommonSpinnerEntity> createTaskAreaList() {
        List<CommonSpinnerEntity> taskAreaList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity3 = new CommonSpinnerEntity();
        caseSpinnerEntity3.setName("案件区域");
        taskAreaList.add(caseSpinnerEntity3);
        return taskAreaList;
    }

    private List<CommonSpinnerEntity> createTypeList() {
        List<CommonSpinnerEntity> caseTypeList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity1 = new CommonSpinnerEntity();
        caseSpinnerEntity1.setName("全部案件");
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<CommonSpinnerEntity> createBigClassList() {
        List<CommonSpinnerEntity> bigClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity2 = new CommonSpinnerEntity();
        caseSpinnerEntity2.setName("案件大类");
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private void initTaskList(MyTaskEntity taskEntity) {
        myTaskBeans = new ArrayList<>();
        List<MyTaskEntity.DataBean> tasks = taskEntity.data;
        if (tasks != null) {
            for (MyTaskEntity.DataBean task : tasks) {
                MyTaskBean myTaskBean = new MyTaskBean();
                myTaskBean.reportNum = task.reportNum;
                myTaskBean.address = task.address;
                myTaskBean.alreadyNum = task.alreadyNum;
                myTaskBean.assignUserId = task.assignUserId;
                myTaskBean.description = task.description;
                myTaskBean.updateUser = task.updateUser;
                myTaskBean.updateTime = task.updateTime;
                myTaskBean.caseType = task.caseType;
                myTaskBean.timeLimit = task.timeLimit;
                myTaskBean.smallClassName = task.smallClassName;
                myTaskBean.smallClass = task.smallClass;
                myTaskBean.caseTypeName = task.caseTypeName;
                myTaskBean.bigClassName = task.bigClassName;
                myTaskBean.createTime = task.createTime;
                myTaskBean.taskArea = task.taskArea;
                myTaskBean.taskName = task.taskName;
                myTaskBean.createUser = task.createUser;
                myTaskBean.id = task.id;
                myTaskBean.bigClass = task.bigClass;
                myTaskBean.status = task.status;
                myTaskBean.latitude = task.latitude;
                myTaskBean.longitude = task.longitude;
                myTaskBeans.add(myTaskBean);
            }
        }

        showTaskList();

    }

    private void showTaskList() {
        rv_my_task.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));
        mAdapter = new MyTaskAdapter(myTaskBeans, rv_my_task);
        mAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_my_task));
        rv_my_task.setAdapter(mAdapter);
        mAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                Intent intent = new Intent(getContext(), TaskDetailsActivity.class);
                intent.putExtra("id", myTaskBeans.get(position).id);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRefresh() {
        getMyTask();
    }
}
