package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseDetailsBean;
import com.dimeno.wum.ui.bean.SpinnerQueryDealResultBean;

public class CaseDealResultViewHolder extends RecyclerViewHolder<SpinnerQueryDealResultBean> {

    private final TextView deal_result_name;

    public CaseDealResultViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.spinner_item_deal_result);
        deal_result_name = findViewById(R.id.deal_result_name);
    }

    @Override
    public void bind() {
        deal_result_name.setText(mData.dealResultName);
    }
}
