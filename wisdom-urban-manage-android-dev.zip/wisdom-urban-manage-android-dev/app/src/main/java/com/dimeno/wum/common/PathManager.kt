package com.dimeno.wum.common

import android.content.Context
import java.io.File

class PathManager {
    companion object {
        fun getCaptureFile(ctx: Context): File {
            return File(ctx.getExternalFilesDir("camera"), "${System.currentTimeMillis()}.png")
        }
    }
}