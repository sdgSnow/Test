package com.dimeno.wum.widget.dialog

import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.TextView
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R

/**
 * common confirm dialog
 * Created by wangzhen on 2020/9/17.
 */
class ConfirmDialog : BaseDialogFragment() {
    private var callback: Callback? = null
    private var title: String? = null
    private var message: String? = null
    private var messageGravity: Int = Gravity.CENTER
    private var leftText: String? = null
    private var rightText: String? = null

    override fun layoutId(): Int = R.layout.dialog_confirm_layout

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<TextView>(R.id.title).apply {
            visibility = if (TextUtils.isEmpty(title)) View.GONE else View.VISIBLE
            text = title
        }

        view.findViewById<TextView>(R.id.message).apply {
            text = message
            gravity = messageGravity
        }

        view.findViewById<TextView>(R.id.btn_cancel).apply {
            leftText?.let { text = it }
            setOnClickListener {
                dismiss()
                callback?.onCancel()
            }
        }

        view.findViewById<TextView>(R.id.btn_confirm).apply {
            rightText?.let { text = it }
            setOnClickListener {
                dismiss()
                callback?.onConfirm()
            }
        }
    }

    fun setTitle(title: String): ConfirmDialog {
        this.title = title
        return this
    }

    fun setMessage(message: String): ConfirmDialog {
        this.message = message
        return this
    }

    fun setMessageGravity(gravity: Int): ConfirmDialog {
        this.messageGravity = gravity
        return this
    }

    fun setLeftText(text: String): ConfirmDialog {
        this.leftText = text
        return this
    }

    fun setRightText(text: String): ConfirmDialog {
        this.rightText = text
        return this
    }

    fun setCallback(callback: Callback): ConfirmDialog {
        this.callback = callback
        return this
    }

    override fun windowWidth(): Int = AppUtils.getScreenWidthPixels() * 5 / 6

    interface Callback {
        fun onCancel()
        fun onConfirm()
    }
}