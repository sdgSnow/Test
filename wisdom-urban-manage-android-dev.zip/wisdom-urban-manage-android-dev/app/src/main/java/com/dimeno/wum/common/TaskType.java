package com.dimeno.wum.common;

public class TaskType {

    public static final int REMAIN_DEAL = 1;//待办任务
    public static final int COMPLETED = 2;//已办任务

    public static final int STATUS_REMAIN_DEAL = 0;//待办任务
    public static final int STATUS_DEALING = 1;//处理中
    public static final int STATUS_COMPLETED = 2;//已办任务
}
