package com.dimeno.wum.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.LinearLayout
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.common.IKey
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import com.just.agentweb.AgentWeb
import com.just.agentweb.WebViewClient
import com.wangzhen.router.Router
import kotlinx.android.synthetic.main.activity_web.*

/**
 * WebActivity
 * Created by wangzhen on 2020/9/24.
 */
class WebActivity : BaseActivity() {
    private var web: AgentWeb? = null
    private var toolbar: AppCommonToolbar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)
        fitDarkStatusBar(true)
        config()

        intent.getStringExtra(IKey.TITLE)?.let { name ->
            toolbar?.setTitle(name)
        }
        intent.getStringExtra(IKey.URL)?.let { url ->
            loadUrl(url)
        }
    }

    private fun config() {
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, "").apply {
            toolbar = this
        }
    }

    private fun loadUrl(url: String) {
        web = AgentWeb.with(this)
                .setAgentWebParent(ll_web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
                .useDefaultIndicator()
                .setWebViewClient(object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        intercept(view, request.url.toString())
                        return true
                    }

                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                        intercept(view, url)
                        return true
                    }

                    fun intercept(view: WebView, url: String) {
                        if (!Router.with(view.context).to(url)) {
                            view.loadUrl(url)
                        }
                    }
                })
                .createAgentWeb()
                .ready().go(url)
        web?.let {
            it.agentWebSettings.webSettings.apply {
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                layoutAlgorithm = WebSettings.LayoutAlgorithm.NARROW_COLUMNS
                useWideViewPort = true
                loadWithOverviewMode = true
            }
        }
    }

    override fun onBackPressed() {
        web?.let {
            if (!it.back()) {
                super.onBackPressed()
            }
        } ?: super.onBackPressed()
    }

    override fun onPause() {
        web?.webLifeCycle?.onPause()
        super.onPause()
    }

    override fun onResume() {
        web?.webLifeCycle?.onResume()
        super.onResume()
    }

    override fun onDestroy() {
        web?.let {
            it.webLifeCycle?.onDestroy()
            it.clearWebCache()
        }
        super.onDestroy()
    }

    companion object {
        fun start(context: Context, url: String?) {
            start(context, url, null)
        }

        fun start(context: Context, url: String?, title: String?) {
            context.startActivity(Intent(context, WebActivity::class.java).apply {
                putExtra(IKey.URL, url)
                putExtra(IKey.TITLE, title)
            })
        }
    }
}