package com.dimeno.wum

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.ui.activity.ReportActivity
import com.dimeno.wum.ui.fragment.IndexFragment
import com.dimeno.wum.ui.fragment.MineFragment
import com.dimeno.wum.widget.toolbar.AppIndexToolbar
import kotlinx.android.synthetic.main.activity_main.*


/**
 * MainActivity
 * Created by wangzhen on 2020/9/14.
 */
class MainActivity : BaseActivity(), View.OnClickListener {
    private var mCurFragment: Fragment? = null
    private var mCurIndex: Int = 0
    private var mToolbar: AppIndexToolbar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.let {
            mCurIndex = it.getInt("index", 0)
        }
        setContentView(R.layout.activity_main)
        fitDarkStatusBar(true)
        initViews()
        initFragment(mCurIndex)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("index", mCurIndex)
        super.onSaveInstanceState(outState)
    }

    override fun createToolbar(): Toolbar? {
        return AppIndexToolbar(this).apply {
            mToolbar = this
        }
    }

    private fun initViews() {
        btn_index.setOnClickListener(this)
        btn_camera.setOnClickListener(this)
        btn_mine.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_index -> initFragment(0)
            R.id.btn_mine -> initFragment(1)
            R.id.btn_camera -> {
                startActivity(Intent(this, ReportActivity::class.java))
            }
        }
    }

    private fun initFragment(index: Int) {
        mCurIndex = index
        mToolbar?.setTitle(if (mCurIndex == 0) getString(R.string.app_name) else getString(R.string.bottom_bar_main_mine))
        btn_index.isSelected = index == 0
        btn_mine.isSelected = index == 1
        
        val tag = index.toString()
        val manager = supportFragmentManager
        var fragment = manager.findFragmentByTag(tag)
        val transaction = manager.beginTransaction()
        if (fragment == null) {
            fragment = newTab(index)
            transaction.add(R.id.container, fragment, tag)
        } else {
            transaction.show(fragment)
        }
        if (mCurFragment != null && mCurFragment !== fragment) {
            transaction.hide(mCurFragment!!)
        }
        transaction.commitAllowingStateLoss()
        mCurFragment = fragment
    }

    private fun newTab(type: Int): Fragment {
        return when (type) {
            0 -> IndexFragment()
            else -> MineFragment()
        }
    }
}