package com.dimeno.wum.entity.db;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;

/**
 * sample used to generate MyObjectBox, don`t delete
 * Created by wangzhen on 2020/9/15.
 */
@Entity
public class DbSample {
    @Id
    public long id;
}
