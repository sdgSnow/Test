package com.dimeno.wum.network.task

import com.dimeno.network.callback.RequestCallback
import com.dimeno.network.task.PostFormTask

/**
 * 获取案件分类
 * Created by wangzhen on 2020/9/15.
 */
class CaseTypeListTask(callback: RequestCallback<*>?) : PostFormTask(callback) {
    override fun getApi(): String {
        return "/wisdomurbanmanagecore/api/getCaseTypeList"
    }
}