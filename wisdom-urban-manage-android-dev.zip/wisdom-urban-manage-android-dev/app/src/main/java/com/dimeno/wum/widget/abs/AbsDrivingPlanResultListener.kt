package com.dimeno.wum.widget.abs

import com.baidu.mapapi.search.route.*

/**
 * abs driving plan result listener
 * Created by wangzhen on 2020/10/28.
 */
abstract class AbsDrivingPlanResultListener : OnGetRoutePlanResultListener {
    override fun onGetWalkingRouteResult(result: WalkingRouteResult) {
    }

    override fun onGetTransitRouteResult(result: TransitRouteResult) {
    }

    override fun onGetMassTransitRouteResult(result: MassTransitRouteResult) {
    }

    override fun onGetIndoorRouteResult(result: IndoorRouteResult) {
    }

    override fun onGetBikingRouteResult(result: BikingRouteResult) {
    }
}