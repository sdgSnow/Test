package com.dimeno.wum.widget.dialog

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.*
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager

/**
 * base dialog fragment
 * Created by wangzhen on 2020/9/17.
 */
abstract class BaseDialogFragment : DialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(layoutId(), container, false)
    }

    fun show(fragmentManager: FragmentManager) {
        show(fragmentManager, tag)
    }

    abstract fun layoutId(): Int

    open fun isBottom() = false

    open fun windowWidth(): Int = WindowManager.LayoutParams.WRAP_CONTENT

    open fun windowHeight(): Int = WindowManager.LayoutParams.WRAP_CONTENT

    open fun dimAmount(): Float = -1f

    open fun dimBehind(): Boolean = true

    override fun onStart() {
        super.onStart()
        dialog?.let { dialog ->
            dialog.setCancelable(false)
            dialog.setCanceledOnTouchOutside(false)
            dialog.window?.let { window ->
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val attr = window.attributes
                attr.width = windowWidth()
                attr.height = windowHeight()
                if (dimAmount() >= 0) {
                    attr.dimAmount = dimAmount()
                }
                if (!dimBehind()) {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                }
                attr.gravity = if (isBottom()) Gravity.BOTTOM else Gravity.CENTER_HORIZONTAL
                window.attributes = attr
            }
        }
    }
}