package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class TaskAreaEntity implements Serializable{


    /**
     * code : 200
     * data : [{"code":"210202001002","createTime":"2020-09-14 00:00:00","createUser":"1","name":"春海社区居委会","pcode":"210202001000","remark":"大连市中山区学士街与春生街交叉路口往西约50米(春德小区)","top":"210000000000","updateTime":"2020-09-19 08:50:44","updateUser":"1"}]
     * message : 请求成功
     * success : true
     */

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;

    public static class DataBean implements Serializable {
        /**
         * code : 210202001002
         * createTime : 2020-09-14 00:00:00
         * createUser : 1
         * name : 春海社区居委会
         * pcode : 210202001000
         * remark : 大连市中山区学士街与春生街交叉路口往西约50米(春德小区)
         * top : 210000000000
         * updateTime : 2020-09-19 08:50:44
         * updateUser : 1
         */

        public String code;
        public String createTime;
        public String createUser;
        public String name;
        public String pcode;
        public String remark;
        public String top;
        public String updateTime;
        public String updateUser;

    }
}
