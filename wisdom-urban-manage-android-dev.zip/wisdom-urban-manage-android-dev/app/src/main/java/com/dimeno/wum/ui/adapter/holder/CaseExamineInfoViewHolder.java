package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseDetailsBean;
import com.dimeno.wum.ui.bean.CaseExamineInfoBean;

public class CaseExamineInfoViewHolder extends RecyclerViewHolder<CaseExamineInfoBean> {

    private final TextView tv_case_details_name;
    private final TextView case_details_desc;

    public CaseExamineInfoViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_case_examine_info);
        tv_case_details_name = findViewById(R.id.tv_case_details_name);
        case_details_desc = findViewById(R.id.case_details_desc);
    }

    @Override
    public void bind() {
        tv_case_details_name.setText(mData.name);
        case_details_desc.setText(mData.desc);
    }
}
