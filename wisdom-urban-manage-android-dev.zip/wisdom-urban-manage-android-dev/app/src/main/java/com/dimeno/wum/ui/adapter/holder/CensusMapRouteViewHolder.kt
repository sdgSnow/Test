package com.dimeno.wum.ui.adapter.holder

import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.wum.R
import com.dimeno.wum.entity.CensusMapRouteEntity
import com.dimeno.wum.utils.AppFormat
import java.util.*

/**
 * census map route view holder
 * Created by wangzhen on 2020/10/28.
 */
class CensusMapRouteViewHolder(parent: ViewGroup) : RecyclerViewHolder<CensusMapRouteEntity>(parent, R.layout.item_census_route_plan_layout) {
    override fun bind() {
        itemView.isSelected = mData.isSelected
        findViewById<TextView>(R.id.tv_plan_name).text = String.format(Locale.CHINESE, "方案%s", AppFormat.getChineseChar(layoutPosition + 1))
        mData.data?.let { data ->
            findViewById<TextView>(R.id.tv_cost).text = AppFormat.formatTimeCost(data.duration)
            findViewById<TextView>(R.id.tv_distance).text = AppFormat.formatDistance(data.distance)
        }
    }
}