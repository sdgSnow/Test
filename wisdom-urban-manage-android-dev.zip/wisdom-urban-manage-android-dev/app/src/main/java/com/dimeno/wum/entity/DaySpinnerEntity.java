package com.dimeno.wum.entity;

import java.io.Serializable;

public class DaySpinnerEntity implements Serializable {

    public int day;
    public String name;
}
