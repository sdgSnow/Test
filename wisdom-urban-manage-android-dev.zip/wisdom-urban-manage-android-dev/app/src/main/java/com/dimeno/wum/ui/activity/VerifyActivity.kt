package com.dimeno.wum.ui.activity

import android.os.Bundle
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.ui.fragment.CaseReportFragment
import com.dimeno.wum.widget.toolbar.AppCommonToolbar


/**
 * VerifyActivity
 * Created by sdg on 2020/9/22.
 * 案例属实验证
 */
class VerifyActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify)
        fitDarkStatusBar(true)

        supportFragmentManager.findFragmentById(R.id.fragment).let {
            (it as CaseReportFragment).apply {
                hideStash()
                setCaseId(intent.getStringExtra("caseReportId"))
            }
        }

    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this,"案例属实验证")
    }
}