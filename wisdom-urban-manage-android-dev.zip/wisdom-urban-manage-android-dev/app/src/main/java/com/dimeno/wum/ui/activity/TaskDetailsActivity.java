package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.dimeno.commons.json.JsonUtils;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.entity.TaskDetailsEntity;
import com.dimeno.wum.network.task.TaskDetailsTask;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

import org.jetbrains.annotations.Nullable;

public class TaskDetailsActivity extends BaseActivity implements View.OnClickListener {

    private String id;
    private TextView tv_task_name;
    private TextView tv_case_type_name;
    private TextView tv_case_big_class_name;
    private TextView tv_case_small_class_name;
    private TextView tv_address_details;
    private ImageView iv_map_manage;
    private TextView tv_grid_require;
    private TextView tv_at_least_report;
    private TextView tv_task_time_limit;
    private TextView tv_start_inspection;
    private String coordinateListJson;
    private TaskDetailsEntity.DataBean mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_details);
        fitDarkStatusBar(true);

        tv_task_name = findViewById(R.id.tv_task_name);
        tv_case_type_name = findViewById(R.id.tv_case_type_name);
        tv_case_big_class_name = findViewById(R.id.tv_case_big_class_name);
        tv_case_small_class_name = findViewById(R.id.tv_case_small_class_name);
        tv_address_details = findViewById(R.id.tv_address_details);
        iv_map_manage = findViewById(R.id.iv_map_manage);
        tv_grid_require = findViewById(R.id.tv_task_require);
        tv_at_least_report = findViewById(R.id.tv_at_least_report);
        tv_task_time_limit = findViewById(R.id.tv_task_time_limit);
        tv_start_inspection = findViewById(R.id.tv_start_inspection);

        iv_map_manage.setOnClickListener(this);
        tv_start_inspection.setOnClickListener(this);

        id = getIntent().getStringExtra("id");

        getTaskDetail();
    }

    /**
     * 获取任务详情
     */
    private void getTaskDetail() {
        new TaskDetailsTask(new LoadingCallback<TaskDetailsEntity>() {
            @Override
            public void onSuccess(TaskDetailsEntity data) {
                if (data.data == null)
                    return;
                mData = data.data;
                coordinateListJson = JsonUtils.toJsonString(data.data.coordinateList);

                tv_task_name.setText(mData.taskName);
                tv_case_type_name.setText(mData.caseTypeName);
                tv_case_big_class_name.setText(mData.bigClassName);
                tv_case_small_class_name.setText(mData.smallClassName);
                tv_address_details.setText(mData.address);
                tv_grid_require.setText(mData.description);
                tv_at_least_report.setText(String.valueOf(mData.reportNum));
                tv_task_time_limit.setText(String.valueOf(mData.timeLimit));
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("id", id)
                .exe();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "任务详情");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_start_inspection:
                if (mData == null) {
                    return;
                }
                startActivity(new Intent(TaskDetailsActivity.this, ReportActivity.class)
                        .putExtra(IKey.TASK_ID, id)
                        .putExtra(IKey.PRESET, true)
                        .putExtra(IKey.CASE_TYPE_NAME, mData.caseTypeName)
                        .putExtra(IKey.CASE_TYPE_CODE, String.valueOf(mData.caseType))
                        .putExtra(IKey.CASE_BIG_CLASS_NAME, mData.bigClassName)
                        .putExtra(IKey.CASE_BIG_CLASS_CODE, mData.bigClass)
                        .putExtra(IKey.CASE_SMALL_CLASS_NAME, mData.smallClassName)
                        .putExtra(IKey.CASE_SMALL_CLASS_CODE, mData.smallClass)
                );
                break;
            case R.id.iv_map_manage:
                startActivity(new Intent(TaskDetailsActivity.this, TaskMapActivity.class)
                        .putExtra("data", coordinateListJson)
                );
                break;
        }
    }
}