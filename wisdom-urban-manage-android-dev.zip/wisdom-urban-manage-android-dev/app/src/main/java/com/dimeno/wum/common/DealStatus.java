package com.dimeno.wum.common;

public class DealStatus {

    public static final int DEAL_AGO = 0;
    public static final int DEAL_AFTER = 1;
}
