package com.dimeno.wum.entity

import java.io.Serializable

/**
 * OssTokenEntity
 * Created by wangzhen on 2020/9/16.
 */
class OssTokenEntity : Serializable {
    var SecurityToken: String? = null
    var endpoint: String? = null
    var BucketName: String? = null
    var code: Int = 0
    var AccessKeyId: String? = null
    var success: Boolean = false
    var AccessKeySecret: String? = null
    var Expiration: String? = null
    var Host: String? = null
    var Directory: String? = null
}