package com.dimeno.wum.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.entity.CaseDetailsEntity;
import com.dimeno.wum.entity.CaseFlowEntity;
import com.dimeno.wum.network.task.CaseDetailsTask;
import com.dimeno.wum.network.task.CaseFlowTask;
import com.dimeno.wum.ui.adapter.CaseFlowAdapter;
import com.dimeno.wum.ui.bean.CaseDetailsBannerBean;
import com.dimeno.wum.ui.bean.CaseFlowBean;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;
import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.listener.OnPageChangeListener;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseDetailsActivity
 * Created by sdg on 2020/9/16.
 */
public class CaseDetailsActivity extends BaseActivity implements View.OnClickListener {

    private Banner banner;
    private List<CaseDetailsBannerBean> caseDetailsBannerBeans;
    private TextView tv_select_picture;
    private String id;
    private TextView case_type_name;
    private TextView case_case_address;
    private TextView case_case_time;
    private TextView case_case_desc;
    private TextView case_case_status;
    private TextView case_case_opinion;
    private TextView case_time_total;
    private TextView tv_look;
    private boolean isShowFlow = false;
    private RecyclerView rv_flow;
    private ImageView iv_look;
    private List<CaseFlowBean> caseFlowBeans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_details);
        fitDarkStatusBar(true);

        banner = findViewById(R.id.banner_picture);
        tv_select_picture = findViewById(R.id.tv_select_picture);
        case_type_name = findViewById(R.id.case_type_name);
        case_case_address = findViewById(R.id.case_case_address);
        case_case_time = findViewById(R.id.case_case_time);
        case_case_desc = findViewById(R.id.case_case_desc);
        case_case_status = findViewById(R.id.case_case_status);
        case_case_opinion = findViewById(R.id.case_case_opinion);
        case_time_total = findViewById(R.id.case_time_total);
        tv_look = findViewById(R.id.tv_look);
        iv_look = findViewById(R.id.iv_look);
        tv_look.setOnClickListener(this::onClick);
        rv_flow = findViewById(R.id.rv_flow);

        id = getIntent().getStringExtra("id");
        getCaseDetail();
        getCaseProcess();
    }

    /**
     * 获取案例详情
     */
    private void getCaseDetail() {
        new CaseDetailsTask(new LoadingCallback<CaseDetailsEntity>() {
            @Override
            public void onSuccess(CaseDetailsEntity data) {
                if (data.success) {
                    case_type_name.setText(data.data.caseTypeName);
                    case_case_address.setText(data.data.address);
                    case_case_time.setText(data.data.createTime);
                    case_case_desc.setText(data.data.description);
                    case_case_status.setText(data.data.statusName);
                    case_case_opinion.setText(data.data.caseOperation.operationDescription);
                    initBanner(data);
                } else {
                    T.show(data.message);
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("id", id)
                .exe();
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案例详情");
    }

    private void initBanner(CaseDetailsEntity data) {
        caseDetailsBannerBeans = new ArrayList<>();
        if (data.data.caseFilesList != null) {
            for (CaseDetailsEntity.DataBean.CaseFilesListBean caseFilesListBean : data.data.caseFilesList) {
                CaseDetailsBannerBean caseDetailsBannerBean = new CaseDetailsBannerBean();
                caseDetailsBannerBean.caseReportId = caseFilesListBean.caseReportId;
                caseDetailsBannerBean.createTime = caseFilesListBean.createTime;
                caseDetailsBannerBean.createUser = caseFilesListBean.createUser;
                caseDetailsBannerBean.fileShowUrl = caseFilesListBean.fileShowUrl;
                caseDetailsBannerBean.fileSource = caseFilesListBean.fileSource;
                caseDetailsBannerBean.fileUrl = caseFilesListBean.fileUrl;
                caseDetailsBannerBean.id = caseFilesListBean.id;
                caseDetailsBannerBean.updateTime = caseFilesListBean.updateTime;
                caseDetailsBannerBean.updateUser = caseFilesListBean.updateUser;
                caseDetailsBannerBeans.add(caseDetailsBannerBean);
            }
        }
        String format = String.format("%s/%s", 1, caseDetailsBannerBeans.size());
        tv_select_picture.setText(format);
        banner.isAutoLoop(false);//禁止自动滑动
        banner.setAdapter(new BannerImageAdapter<CaseDetailsBannerBean>(caseDetailsBannerBeans) {
            @Override
            public void onBindView(BannerImageHolder holder, CaseDetailsBannerBean data, int position, int size) {
                //图片加载自己实现
                Glide.with(holder.itemView)
                        .load(data.fileShowUrl)
                        .into(holder.imageView);
            }
        }).setIndicator(new CircleIndicator(CaseDetailsActivity.this));
        banner.setOnBannerListener((OnBannerListener<CaseDetailsBannerBean>) (_data, position) -> {
            if (caseDetailsBannerBeans == null)
                return;
            ArrayList<String> urls = new ArrayList<>();
            for (CaseDetailsBannerBean bean : caseDetailsBannerBeans)
                urls.add(bean.fileShowUrl);
            startActivity(new Intent(CaseDetailsActivity.this, PicturePreviewActivity.class)
                    .putStringArrayListExtra(IKey.DATA, urls).putExtra(IKey.POSITION, position));
        });
        banner.addOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                String format = String.format("%s/%s", position + 1, caseDetailsBannerBeans.size());
                tv_select_picture.setText(format);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_look:
                showFlow();
                break;
        }
    }

    private void getCaseProcess() {
        new CaseFlowTask(new LoadingCallback<CaseFlowEntity>() {
            @Override
            public void onSuccess(CaseFlowEntity data) {
                initCaseFlow(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("id", id)
                .exe();
    }

    //控制显示案件流程详情
    private void showFlow() {
        if (isShowFlow) {
            iv_look.setImageResource(R.mipmap.down);
            rv_flow.setVisibility(View.GONE);
            isShowFlow = !isShowFlow;
        } else {
            iv_look.setImageResource(R.mipmap.up);
            rv_flow.setVisibility(View.VISIBLE);
            isShowFlow = !isShowFlow;
        }
    }

    private void initCaseFlow(CaseFlowEntity data) {
        caseFlowBeans = new ArrayList<>();
        if (data.data != null) {
            for (CaseFlowEntity.DataBean datum : data.data) {
                CaseFlowBean caseFlowBean = new CaseFlowBean();
                caseFlowBean.caseReportId = datum.caseReportId;
                caseFlowBean.operationDescription = datum.operationDescription;
                caseFlowBean.manager = datum.manager;
                caseFlowBean.totalTime = datum.totalTime;
                caseFlowBean.linkTime = datum.linkTime;
                caseFlowBean.remark = datum.remark;
                caseFlowBean.linkName = datum.linkName;
                caseFlowBean.timeOut = datum.timeOut;
                caseFlowBean.timeLimit = datum.timeLimit;
                caseFlowBean.startTime = datum.startTime;
                caseFlowBean.operationType = datum.operationType;
                caseFlowBean.endTime = datum.endTime;
                caseFlowBean.id = datum.id;
                caseFlowBeans.add(caseFlowBean);
            }
        }
        showCaseFlow();
    }

    private void showCaseFlow() {
        rv_flow.setLayoutManager(new GridLayoutManager(CaseDetailsActivity.this, 1, GridLayoutManager.VERTICAL, false));
        CaseFlowAdapter caseFlowAdapter = new CaseFlowAdapter(caseFlowBeans);
        rv_flow.setAdapter(caseFlowAdapter);
    }

}