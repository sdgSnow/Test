package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;
import com.dimeno.network.task.PostJsonTask;

public class CaseVerifyTask extends PostJsonTask {
    public <EntityType> CaseVerifyTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/caseVerify";
    }
}
