package com.dimeno.wum.ui.activity

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.dimeno.adapter.base.RecyclerItem
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.commons.utils.T
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.network.loading.DefaultLoadingPage
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.common.NewsType
import com.dimeno.wum.entity.NewsEntity
import com.dimeno.wum.network.task.NewsTask
import com.dimeno.wum.ui.adapter.NoticeAdapter
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import com.wangzhen.refresh.callback.OnRefreshCallback
import kotlinx.android.synthetic.main.activity_notice.*

/**
 * notice activity
 * Created by wangzhen on 2020/9/27.
 */
class NoticeActivity : BaseActivity(), OnRefreshCallback {
    private var adapter: NoticeAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notice)
        fitDarkStatusBar(true)
        initViews()
        request(true)
    }

    private fun request(auto: Boolean) {
        NewsTask(object : LoadingCallback<NewsEntity>() {
            override fun onSuccess(data: NewsEntity) {
                adapter?.setData(data.data)
            }

            override fun onError(code: Int, message: String) {
                T.show(message)
            }

            override fun onComplete() {
                refresh_layout.refreshComplete()
            }
        }).setTag(this)
                .setLoadingPage(if (auto) DefaultLoadingPage(refresh_layout) else null)
                .put("newsType", NewsType.NOTICE).exe()
    }

    private fun initViews() {
        refresh_layout.setOnRefreshCallback(this)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = NoticeAdapter(null, recycler).apply {
            adapter = this
            setEmpty(object : RecyclerItem() {
                override fun layout(): Int = R.layout.global_empty_layout

                override fun onViewCreated(itemView: View) {

                }
            }.onCreateView(recycler))
        }
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, getString(R.string.mine_notice))
    }

    override fun onRefresh() {
        request(false)
    }
}