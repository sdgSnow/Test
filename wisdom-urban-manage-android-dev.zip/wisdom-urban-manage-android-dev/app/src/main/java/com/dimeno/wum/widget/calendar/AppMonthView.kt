package com.dimeno.wum.widget.calendar

import android.content.Context
import android.graphics.Canvas
import com.dimeno.commons.utils.AppUtils
import com.haibin.calendarview.Calendar
import com.haibin.calendarview.MonthView

/**
 * custom month view
 * Created by wangzhen on 2020/9/22.
 */
class AppMonthView(context: Context) : MonthView(context) {
    private var radius: Float = 0f

    init {
        radius = AppUtils.dip2px(18f).toFloat()
    }

    override fun onDrawSelected(canvas: Canvas, calendar: Calendar, x: Int, y: Int, hasScheme: Boolean): Boolean {
        canvas.drawCircle(x + mItemWidth / 2f, y + mItemHeight / 2f, radius, if (calendar.isCurrentDay) mCurDayTextPaint else mSelectedPaint)
        return true
    }

    override fun onDrawScheme(canvas: Canvas?, calendar: Calendar?, x: Int, y: Int) {

    }

    override fun onDrawText(canvas: Canvas, calendar: Calendar, x: Int, y: Int, hasScheme: Boolean, isSelected: Boolean) {
        val day = calendar.day.toString()
        val cx = x + mItemWidth / 2f
        val cy = y + mItemHeight / 2f + getTextHeight() / 4f

        if (isSelected) {
            canvas.drawText(day, cx, cy, mSelectTextPaint)
        } else {
            canvas.drawText(day, cx, cy,
                    when {
                        calendar.isCurrentDay -> mCurDayTextPaint
                        calendar.isCurrentMonth -> mCurMonthTextPaint
                        else -> mOtherMonthTextPaint
                    })
        }
    }

    private fun getTextHeight(): Float {
        val fontMetrics = mSelectTextPaint.fontMetrics
        return fontMetrics.descent - fontMetrics.ascent
    }
}