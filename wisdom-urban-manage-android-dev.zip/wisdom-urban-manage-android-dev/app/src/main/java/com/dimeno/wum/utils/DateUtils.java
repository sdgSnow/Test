package com.dimeno.wum.utils;

import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * DateUtils
 * Created by wangzhen on 2020/9/18.
 */
public class DateUtils {
    public static String format(long timestamp, String format) {
        if (TextUtils.isEmpty(format)) {
            return String.valueOf(timestamp);
        }
        SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.CHINESE);
        return formatter.format(new Date(timestamp));
    }
}
