package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class LoginEntity implements Serializable {


    /**
     * code : 200
     * data : {"account":"jdy","avatar":null,"birthday":null,"createTime":"2020-09-14 19:47:21","createUser":"1","deptId":null,"divDeptRole":"①210200000000▉②1▉③supervisor","divisionId":null,"email":"","name":"监督员1","password":"cd282eb2046ad22d38e685122beb3444","phone":"18659842690","roleId":null,"salt":"lpw8d","sex":null,"smsFrequency":0,"source":0,"status":1,"updateTime":"2020-09-14 19:47:21","updateUser":"1","userId":"1305473202950389761","userRefList":null,"version":null}
     * message : 登录成功！
     * success : true
     */

    public int code;
    public DataBean data;
    public String message;
    public boolean success;

    public static class DataBean implements Serializable {
        /**
         * account : jdy
         * avatar : null
         * birthday : null
         * createTime : 2020-09-14 19:47:21
         * createUser : 1
         * deptId : null
         * divDeptRole : ①210200000000▉②1▉③supervisor
         * divisionId : null
         * email :
         * name : 监督员1
         * password : cd282eb2046ad22d38e685122beb3444
         * phone : 18659842690
         * roleId : null
         * salt : lpw8d
         * sex : null
         * smsFrequency : 0
         * source : 0
         * status : 1
         * updateTime : 2020-09-14 19:47:21
         * updateUser : 1
         * userId : 1305473202950389761
         * userRefList : null
         * version : null
         */

        public String account;
        public Object avatar;
        public Object birthday;
        public String createTime;
        public String createUser;
        public Object deptId;
        public String divDeptRole;
        public Object divisionId;
        public String email;
        public String name;
        public String password;
        public String phone;
        public Object roleId;
        public String salt;
        public Object sex;
        public int smsFrequency;
        public int source;
        public int status;
        public String updateTime;
        public String updateUser;
        public String userId;
        public int userType;//对应到UserType类
        public Object userRefList;
        public Object version;
        public List<LatLngEntity> coordinateList;
    }
}
