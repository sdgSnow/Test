package com.dimeno.wum.ui.adapter.holder

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.bumptech.glide.Glide
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.adapter.callback.OnHolderClickCallback
import com.dimeno.wum.R
import com.dimeno.wum.common.MineType
import com.dimeno.wum.common.WebUrl
import com.dimeno.wum.ui.activity.*
import com.dimeno.wum.ui.bean.MineBean

/**
 * CasePictureViewHolder
 * Created by wangzhen on 2020/9/16.
 */
class MineViewHolder(parent: ViewGroup) : RecyclerViewHolder<MineBean>(parent, R.layout.item_mine), OnHolderClickCallback {

    override fun bind() {
        Glide.with(itemView.context).load(mData.icon).into(findViewById(R.id.icon))
        findViewById<TextView>(R.id.name).text = mData.name
    }

    override fun onItemClick(itemView: View, position: Int) {
        when (mData.type) {
            MineType.MANAGEMENT_SYSTEM -> {
                WebActivity.start(itemView.context, WebUrl.INSTITUTION, itemView.context.getString(R.string.mine_management_system))
            }
            MineType.MESSAGE -> {
                startActivity(Intent(itemView.context, MyMessageActivity::class.java))
            }
            MineType.NOTICE -> {
                startActivity(Intent(itemView.context, NoticeActivity::class.java))
            }
            MineType.HELP -> {
                WebActivity.start(itemView.context, WebUrl.HELP_CENTER, itemView.context.getString(R.string.mine_help))
            }
            MineType.ABOUT -> {
                startActivity(Intent(itemView.context, AboutActivity::class.java))
            }
            MineType.CHANGE_PSW -> {
                startActivity(Intent(itemView.context, ChangePswActivity::class.java))
            }
        }
    }

    private fun startActivity(intent: Intent) {
        itemView.context.startActivity(intent)
    }
}