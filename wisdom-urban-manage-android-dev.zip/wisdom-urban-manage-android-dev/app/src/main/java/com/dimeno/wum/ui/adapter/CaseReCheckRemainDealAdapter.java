package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseReCheckEntity;
import com.dimeno.wum.entity.CaseRemainDealEntity;
import com.dimeno.wum.network.task.CaseReCheckListTask;
import com.dimeno.wum.network.task.CaseVerifyListTask;
import com.dimeno.wum.ui.adapter.holder.CaseReCheckRemainDealHolder;
import com.dimeno.wum.ui.adapter.holder.CaseRemainDealHolder;
import com.dimeno.wum.ui.bean.CaseReCheckRemainDealBean;
import com.dimeno.wum.ui.bean.CaseRemainDealBean;

import java.util.ArrayList;
import java.util.List;

public class CaseReCheckRemainDealAdapter extends LoadRecyclerAdapter<CaseReCheckRemainDealBean> {
    private int page = 1;

    public CaseReCheckRemainDealAdapter(List<CaseReCheckRemainDealBean> list,RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseReCheckRemainDealHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new CaseReCheckListTask(new LoadingCallback<CaseReCheckEntity>() {
            @Override
            public void onSuccess(CaseReCheckEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<CaseReCheckRemainDealBean> addList = new ArrayList<>();
                    for (CaseReCheckEntity.DataBean datum : data.data) {
                        CaseReCheckRemainDealBean caseReCheckRemainDealBean = new CaseReCheckRemainDealBean();
                        caseReCheckRemainDealBean.address = datum.address;
                        caseReCheckRemainDealBean.latitude = datum.latitude;
                        caseReCheckRemainDealBean.assignType = datum.assignType;
                        caseReCheckRemainDealBean.description = datum.description;
                        caseReCheckRemainDealBean.updateUser = datum.updateUser;
                        caseReCheckRemainDealBean.updateTime = datum.updateTime;
                        caseReCheckRemainDealBean.caseCoding = datum.caseCoding;
                        caseReCheckRemainDealBean.source = datum.source;
                        caseReCheckRemainDealBean.caseNo = datum.caseNo;
                        caseReCheckRemainDealBean.caseType = datum.caseType;
                        caseReCheckRemainDealBean.assignTypeName = datum.assignTypeName;
                        caseReCheckRemainDealBean.smallClassName = datum.smallClassName;
                        caseReCheckRemainDealBean.smallClass = datum.smallClass;
                        caseReCheckRemainDealBean.caseTypeName = datum.caseTypeName;
                        caseReCheckRemainDealBean.bigClassName = datum.bigClassName;
                        caseReCheckRemainDealBean.createTime = datum.createTime;
                        caseReCheckRemainDealBean.statusName = datum.statusName;
                        caseReCheckRemainDealBean.createUser = datum.createUser;
                        caseReCheckRemainDealBean.id = datum.id;
                        caseReCheckRemainDealBean.taskId = datum.taskId;
                        caseReCheckRemainDealBean.bigClass = datum.bigClass;
                        caseReCheckRemainDealBean.longitude = datum.longitude;
                        caseReCheckRemainDealBean.status = datum.status;
                        addList.add(caseReCheckRemainDealBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
//                .put("assignType", AssignType.CASE_EXAMINE)
                .put("status", CasePro.CASE_REMAIN_DEAL)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
