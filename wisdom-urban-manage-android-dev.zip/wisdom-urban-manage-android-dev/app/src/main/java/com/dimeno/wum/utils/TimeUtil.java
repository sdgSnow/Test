package com.dimeno.wum.utils;

/**
 * TimeUtil
 * Created by sdg on 2020/9/22.
 */
public class TimeUtil {

    /**
     * 获取当前时间并格式化为 yyyy-MM-dd HH:mm:ss
     */
    public static String getCurrentTime() {
        return DateUtils.format(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss");
    }
}
