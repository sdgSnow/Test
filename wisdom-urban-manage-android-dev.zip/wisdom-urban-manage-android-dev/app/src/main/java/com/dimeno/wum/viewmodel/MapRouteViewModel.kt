package com.dimeno.wum.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dimeno.wum.ui.bean.MapRouteEntity

/**
 * map route view model
 * Created by wangzhen on 2020/10/27.
 */
class MapRouteViewModel : ViewModel() {
    private val syncLiveData = MutableLiveData<Any>()
    private val mapLiveData = MutableLiveData<MutableList<MapRouteEntity>>()

    fun getSyncLiveData(): MutableLiveData<Any> {
        return syncLiveData
    }

    fun sync() {
        syncLiveData.value = null
    }

    fun getMapLiveData(): MutableLiveData<MutableList<MapRouteEntity>> {
        return mapLiveData
    }

    fun setMapDataSource(list: MutableList<MapRouteEntity>) {
        mapLiveData.value = list
    }
}