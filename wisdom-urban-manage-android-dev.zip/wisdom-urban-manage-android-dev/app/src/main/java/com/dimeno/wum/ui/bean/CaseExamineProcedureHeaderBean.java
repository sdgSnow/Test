package com.dimeno.wum.ui.bean;

public class CaseExamineProcedureHeaderBean {

    public String imageUrl;
}
