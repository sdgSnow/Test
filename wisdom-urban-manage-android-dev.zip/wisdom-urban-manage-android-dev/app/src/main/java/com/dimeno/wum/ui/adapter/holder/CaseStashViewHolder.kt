package com.dimeno.wum.ui.adapter.holder

import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.adapter.callback.OnHolderClickCallback
import com.dimeno.wum.R
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.utils.DateUtils
import com.dimeno.wum.viewmodel.CaseStashViewModel
import kotlinx.android.synthetic.main.item_case_stash_holder_layout.view.*

/**
 * CaseStashViewHolder
 * Created by wangzhen on 2020/9/18.
 */
class CaseStashViewHolder(parent: ViewGroup) : RecyclerViewHolder<CaseStashEntity>(parent, R.layout.item_case_stash_holder_layout), OnHolderClickCallback {
    override fun bind() {
        itemView.checkbox.visibility = if (mData.isCheckMode) View.VISIBLE else View.GONE
        itemView.checkbox.isChecked = mData.isChecked
        itemView.checkbox.setOnCheckedChangeListener { _, b -> onCheckStatusChange(b) }
        itemView.tv_type.text = String.format("%s/%s/%s", mData.typeName, mData.bigClassName, mData.smallClassName)
        itemView.tv_case_address.text = if (TextUtils.isEmpty(mData.address)) "无地址" else mData.address
        itemView.tv_case_date.text = DateUtils.format(mData.createTime, "yyyy-MM-dd HH:mm:ss")
    }

    override fun onItemClick(itemView: View, position: Int) {
        if (mData.isCheckMode) {
            itemView.checkbox.isChecked = !itemView.checkbox.isChecked
            onCheckStatusChange(itemView.checkbox.isChecked)
        } else {
            if (itemView.context is ViewModelStoreOwner)
                ViewModelProvider(itemView.context as ViewModelStoreOwner).get(CaseStashViewModel::class.java).edit(mData)
        }
    }

    private fun onCheckStatusChange(check: Boolean) {
        mData.isChecked = check
        if (itemView.context is ViewModelStoreOwner)
            ViewModelProvider(itemView.context as ViewModelStoreOwner).get(CaseStashViewModel::class.java).onMultiCheckChange()
    }
}