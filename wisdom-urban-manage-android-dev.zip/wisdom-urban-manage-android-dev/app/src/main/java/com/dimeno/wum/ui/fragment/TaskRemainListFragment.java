package com.dimeno.wum.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.structure.IList;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.common.TaskType;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.SpecialCensusEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.network.task.SpecialCensusTask;
import com.dimeno.wum.ui.activity.CensusDetailsActivity;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.adapter.SpecialCensusAdapter;
import com.dimeno.wum.ui.bean.MapRouteEntity;
import com.dimeno.wum.ui.bean.SpecialCensusBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.viewmodel.MapRouteViewModel;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * 专项普查-待办任务列表
 * Created by wangzhen on 2020/10/27.
 */
public class TaskRemainListFragment extends Fragment implements OnRefreshCallback {
    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private String mCaseTypeCode = null;
    private String mBigClassCode = null;
    private List<CommonSpinnerEntity> typeList;
    private List<CommonSpinnerEntity> bigClassList;
    private RecyclerView rv_task_remain_deal;
    private List<SpecialCensusBean> specialCensusBeans;
    private SpecialCensusAdapter adapter;
    private RefreshLayout refresh_layout;
    private View container;

    public static TaskRemainDealFragment newInstance() {
        TaskRemainDealFragment fragment = new TaskRemainDealFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_task_remain_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        container = view.findViewById(R.id.container);
        rv_task_remain_deal = view.findViewById(R.id.rv_task_remain_deal);
        spinner_type = view.findViewById(R.id.spinner_type);
        spinner_big_class = view.findViewById(R.id.spinner_big_class);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        initSpinner1();
        initSpinner2();
        initSelectListener();
        initObserver();
        request(true);
    }

    private void initObserver() {
        if (getContext() instanceof ViewModelStoreOwner) {
            MapRouteViewModel viewModel = new ViewModelProvider((ViewModelStoreOwner) getContext()).get(MapRouteViewModel.class);
            viewModel.getSyncLiveData().observe(getViewLifecycleOwner(), o -> {
                if (adapter != null && IList.isNotEmpty(adapter.getDatas())) {
                    List<MapRouteEntity> list = new ArrayList<>();
                    MapRouteEntity entity;
                    for (SpecialCensusBean item : adapter.getDatas()) {
                        entity = new MapRouteEntity();
                        entity.id = item.id;
                        entity.caseType = item.caseType;
                        entity.caseTypeName = item.caseTypeName;
                        entity.smallClass = item.smallClass;
                        entity.smallClassName = item.smallClassName;
                        entity.bigClass = item.bigClass;
                        entity.bigClassName = item.bigClassName;
                        entity.latitude = item.latitude;
                        entity.longitude = item.longitude;
                        entity.address = item.address;
                        entity.createTime = item.createTime;
                        entity.uploadTimeEnd = item.uploadTimeEnd;
                        list.add(entity);
                    }
                    viewModel.setMapDataSource(list);
                }
            });
        }
    }

    private void initSpinner1() {
        //初始化案件类型数据
        typeList = createTypeList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                typeList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter1 = new CommonSpinnerAdapter(getActivity(), typeList);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化大类数据
        bigClassList = createBigClassList();
        if (mCaseTypeCode != null) {
            List<CaseBigClassEntity> caseBigClassEntities = DBLoader.load(CaseBigClassEntity.class).query().equal(CaseBigClassEntity_.topcode, mCaseTypeCode).build().find();
            if (caseBigClassEntities != null) {
                for (CaseBigClassEntity caseBigClassEntity : caseBigClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseBigClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseBigClassEntity.getName());
                    bigClassList.add(caseSpinnerEntity);
                }

            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter2 = new CommonSpinnerAdapter(getActivity(), bigClassList);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSelectListener() {
        spinner_type.setSelection(0, true);
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = typeList.get(i).getCode();
                mBigClassCode = null;
                initSpinner2();
                if (i == 0) {
                    request();
                }
                if (mCaseTypeCode != null) {
                    request();
                }
            }
        });

        spinner_big_class.setSelection(0, true);
        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mBigClassCode = bigClassList.get(i).getCode();
                if (i == 0) {
                    request();
                }
                if (mBigClassCode != null) {
                    request();
                }
            }
        });
    }

    private List<CommonSpinnerEntity> createTypeList() {
        List<CommonSpinnerEntity> caseTypeList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity1 = new CommonSpinnerEntity();
        caseSpinnerEntity1.setName("案件类型");
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<CommonSpinnerEntity> createBigClassList() {
        List<CommonSpinnerEntity> bigClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity2 = new CommonSpinnerEntity();
        caseSpinnerEntity2.setName("案件大类");
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private void request() {
        request(false);
    }

    private void request(boolean showLoading) {
        new SpecialCensusTask(new LoadingCallback<SpecialCensusEntity>() {
            @Override
            public void onSuccess(SpecialCensusEntity data) {
                initTaskRemainDeal(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
//                .setLoadingPage(showLoading ? new DefaultLoadingPage(container) : null)
                .put("caseType", mCaseTypeCode)
                .put("bigClass", mBigClassCode)
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("status", TaskType.STATUS_REMAIN_DEAL)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    private void initTaskRemainDeal(SpecialCensusEntity data) {
        specialCensusBeans = new ArrayList<>();
        if (data.data != null) {
            for (SpecialCensusEntity.DataBean task : data.data) {
                SpecialCensusBean specialCensusBean = new SpecialCensusBean();
                specialCensusBean.address = task.address;
                specialCensusBean.alreadyNum = task.alreadyNum;
                specialCensusBean.alreadyNum = task.alreadyNum;
                specialCensusBean.surveyTimeStart = task.surveyTimeStart;
                specialCensusBean.surveyContext = task.surveyContext;
                specialCensusBean.updateUser = task.updateUser;
                specialCensusBean.updateTime = task.updateTime;
                specialCensusBean.surveyUserid = task.surveyUserid;
                specialCensusBean.caseType = task.caseType;
                specialCensusBean.smallClassName = task.smallClassName;
                specialCensusBean.smallClass = task.smallClass;
                specialCensusBean.caseTypeName = task.caseTypeName;
                specialCensusBean.bigClassName = task.bigClassName;
                specialCensusBean.uploadTimeEnd = task.uploadTimeEnd;
                specialCensusBean.photographRequire = task.photographRequire;
                specialCensusBean.createTime = task.createTime;
                specialCensusBean.createUser = task.createUser;
                specialCensusBean.taskArea = task.taskArea;
                specialCensusBean.noteMatter = task.noteMatter;
                specialCensusBean.id = task.id;
                specialCensusBean.descriptionFormat = task.descriptionFormat;
                specialCensusBean.bigClass = task.bigClass;
                specialCensusBean.status = task.status;
                specialCensusBean.latitude = task.latitude;
                specialCensusBean.longitude = task.longitude;
                specialCensusBeans.add(specialCensusBean);
            }
        }
        showTaskRemainDealList();
    }

    private void showTaskRemainDealList() {
        rv_task_remain_deal.setLayoutManager(new GridLayoutManager(getActivity(), 1, GridLayoutManager.VERTICAL, false));
        adapter = new SpecialCensusAdapter(specialCensusBeans, rv_task_remain_deal);
        adapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_task_remain_deal));
        rv_task_remain_deal.setAdapter(adapter);
        adapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                Intent intent = new Intent(getActivity(), CensusDetailsActivity.class);
                intent.putExtra("id", specialCensusBeans.get(position).id);
                intent.putExtra(IKey.TASK_TYPE, TaskType.REMAIN_DEAL);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRefresh() {
        request();
    }
}
