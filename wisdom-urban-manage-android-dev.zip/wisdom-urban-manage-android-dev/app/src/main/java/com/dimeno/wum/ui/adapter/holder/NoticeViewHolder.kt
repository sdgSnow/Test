package com.dimeno.wum.ui.adapter.holder

import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.wum.R
import com.dimeno.wum.entity.NewsEntity
import com.dimeno.wum.ui.activity.WebActivity

/**
 * notice view holder
 * Created by wangzhen on 2020/9/27.
 */
class NoticeViewHolder(parent: ViewGroup) : RecyclerViewHolder<NewsEntity.DataBean>(parent, R.layout.notice_item_layout) {
    override fun bind() {
        findViewById<TextView>(R.id.tv_title).text = mData.introduction
        findViewById<TextView>(R.id.tv_content).text = mData.content
        findViewById<View>(R.id.btn_see).setOnClickListener {
            if (!TextUtils.isEmpty(mData.linkUrl)) {
                WebActivity.start(it.context, mData.linkUrl, mData.introduction)
            }
        }
    }
}