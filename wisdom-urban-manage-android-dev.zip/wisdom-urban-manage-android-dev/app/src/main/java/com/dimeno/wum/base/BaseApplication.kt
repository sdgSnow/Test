package com.dimeno.wum.base

import android.app.Application
import cn.jpush.android.api.JPushInterface
import com.bumptech.glide.Glide
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader
import com.bumptech.glide.load.model.GlideUrl
import com.dimeno.commons.utils.AppUtils
import com.dimeno.network.ClientLoader
import com.dimeno.network.Network
import com.dimeno.network.config.NetConfig
import com.dimeno.wum.network.interceptor.RequestInterceptor
import com.tencent.bugly.crashreport.CrashReport
import java.io.InputStream

/**
 * BaseApplication
 * Created by wangzhen on 2020/9/14.
 */
class BaseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppUtils.install(this, EnvBiz.isDebug())
        initNetwork()
        initBugly()
        initGlide()
        AppInitializer.prepare()
        initPush()
    }

    fun initNetwork() {
        Network.init(this, NetConfig.Builder()
                .baseUrl(EnvBiz.getUrl())
                .interceptor(RequestInterceptor())
                .build())
    }

    private fun initPush() {
        JPushInterface.setDebugMode(EnvBiz.isDebug())
        JPushInterface.init(this)
    }

    private fun initGlide() {
        Glide.get(this).registry.replace(GlideUrl::class.java, InputStream::class.java, OkHttpUrlLoader.Factory(ClientLoader.getClient()))
    }

    private fun initBugly() {
        CrashReport.initCrashReport(applicationContext, "0387a95770", EnvBiz.isDebug())
    }
}