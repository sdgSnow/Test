package com.dimeno.wum.widget.dialog

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.TextView
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R

/**
 * common tips dialog
 * Created by wangzhen on 2020/9/17.
 */
class TipDialog : BaseDialogFragment() {
    private var callback: Callback? = null
    private var title: String? = null
    private var message: String? = null
    private var confirmText: String? = null

    override fun layoutId(): Int = R.layout.dialog_tips_layout

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<TextView>(R.id.title).apply {
            visibility = if (TextUtils.isEmpty(title)) View.GONE else View.VISIBLE
            text = title
        }

        view.findViewById<TextView>(R.id.message).apply {
            text = message
        }

        view.findViewById<TextView>(R.id.btn_confirm).apply {
            confirmText?.let { text = it }
            setOnClickListener {
                dismiss()
                callback?.onConfirm()
            }
        }
    }

    fun setTitle(title: String): TipDialog {
        this.title = title
        return this
    }

    fun setMessage(message: String): TipDialog {
        this.message = message
        return this
    }

    fun setConfirmText(text: String): TipDialog {
        this.confirmText = text
        return this
    }

    fun setCallback(callback: Callback): TipDialog {
        this.callback = callback
        return this
    }

    override fun windowWidth(): Int = AppUtils.getScreenWidthPixels() * 5 / 6

    interface Callback {
        fun onConfirm()
    }
}