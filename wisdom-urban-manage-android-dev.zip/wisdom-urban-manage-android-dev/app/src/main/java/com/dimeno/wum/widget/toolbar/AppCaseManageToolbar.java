package com.dimeno.wum.widget.toolbar;

import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import com.dimeno.commons.toolbar.ToolbarActivity;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.wum.R;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.DaySpinnerEntity;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.adapter.DaySpinnerAdapter;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class AppCaseManageToolbar extends Toolbar {

    private String mTitle;
    private Activity mActivity;
    private Spinner spinner;
    private String days[] = new String[]{"当天","近一周","近两周"};
    private int nums[] = new int[]{2,7,14};
    private SpinnerListener spinnerListener;

    public AppCaseManageToolbar(@NotNull Activity activity,String title) {
        super(activity);
        this.mActivity = activity;
        this.mTitle = title;
    }

    @Override
    public int layoutRes() {
        return R.layout.toolbar_app_case_manage;
    }

    @Override
    public void onViewCreated(@NotNull View view) {
        TextView back = view.findViewById(R.id.back);
        TextView title = view.findViewById(R.id.title);
        spinner = view.findViewById(R.id.spinner_day);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.finish();
            }
        });
        title.setText(mTitle);
        initSpinner();
    }

    public void initSpinner(){
        List<DaySpinnerEntity> daysList = new ArrayList<>();
        for (int i = 0; i < days.length; i++) {
            DaySpinnerEntity daySpinnerEntity = new DaySpinnerEntity();
            daySpinnerEntity.day = nums[i];
            daySpinnerEntity.name = days[i];
            daysList.add(daySpinnerEntity);
        }
        DaySpinnerAdapter daySpinnerAdapter = new DaySpinnerAdapter(getActivity(), daysList);
        spinner.setAdapter(daySpinnerAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spinnerListener.onItemSelected(daysList.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

   public interface SpinnerListener{
        void onItemSelected(DaySpinnerEntity entity);
   }

   public void setOnItemSelected(SpinnerListener spinnerListener){
        this.spinnerListener = spinnerListener;
   }
}
