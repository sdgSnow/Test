package com.dimeno.wum.utils;

import com.dimeno.commons.utils.AppUtils;
import com.dimeno.wum.entity.db.MyObjectBox;

import io.objectbox.Box;
import io.objectbox.BoxStore;

/**
 * database loader
 * Created by wangzhen on 2020/9/15.
 */
public class DBLoader {
    private static BoxStore mBoxStore;

    public static <T> Box<T> load(Class<T> clz) {
        return getBoxStore().boxFor(clz);
    }

    private static BoxStore getBoxStore() {
        if (mBoxStore == null) {
            mBoxStore = MyObjectBox.builder().androidContext(AppUtils.getContext()).build();
        }
        return mBoxStore;
    }
}
