package com.dimeno.wum.push.entity

/**
 * notification message type
 * Created by wangzhen on 2020/9/24.
 */
class MsgType {
    companion object {
        const val CASE = 1
        const val NEWS = 2
    }
}