package com.dimeno.wum.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.ui.fragment.CaseCheckRemainDealFragment;
import com.dimeno.wum.ui.fragment.CaseCompletedFragment;
import com.dimeno.wum.widget.CustomViewPager;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

/**
 * CaseExamineActivity
 * Created by sdg on 2020/9/17.
 * 案件核实
 */
public class CaseCheckActivity extends BaseActivity implements View.OnClickListener {

    private CustomViewPager viewPager;
    private TextView tv_case_remain_deal;
    private TextView tv_completed;
    private View indicator_remain_deal;
    private View indicator_completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_check);
        fitDarkStatusBar(true);
        initView();
        initViewPager();
    }

    private void initView() {
        tv_case_remain_deal = findViewById(R.id.tv_case_remain_deal);
        tv_completed = findViewById(R.id.tv_completed);
        indicator_remain_deal = findViewById(R.id.indicator_remain_deal);
        indicator_completed = findViewById(R.id.indicator_completed);
        viewPager = findViewById(R.id.viewPager);

        tv_case_remain_deal.setOnClickListener(this);
        tv_completed.setOnClickListener(this);
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案件核实");
    }

    private void initViewPager() {
        viewPager.setScanScroll(false);
        viewPager.setOffscreenPageLimit(1);
        viewPager.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_case_remain_deal:
                viewPager.setCurrentItem(0);
                indicator_remain_deal.setVisibility(View.VISIBLE);
                indicator_completed.setVisibility(View.GONE);
                break;
            case R.id.tv_completed:
                viewPager.setCurrentItem(1);
                indicator_remain_deal.setVisibility(View.GONE);
                indicator_completed.setVisibility(View.VISIBLE);
                break;
        }
    }

    public class MyPagerAdapter extends FragmentPagerAdapter {

        private final String[] fragments = {"CaseRemainDealFragment", "CaseCompletedFragment"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return fragments.length;
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return CaseCheckRemainDealFragment.newInstance();
                case 1:
                    return CaseCompletedFragment.newInstance();
                default:
                    return null;
            }
        }
    }
}