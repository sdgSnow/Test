package com.dimeno.wum.utils.location;

import android.text.TextUtils;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.dimeno.commons.utils.AppUtils;
import com.dimeno.wum.utils.location.callback.OnLocationCallback;
import com.dimeno.wum.utils.location.entity.LocationEntity;

/**
 * location manager
 * Created by wangzhen on 2020/9/16.
 */
public final class LocationManager {
    private static LocationManager sInstance;
    private LocationClient mLocationClient;
    private OnLocationCallback mCallback;

    private LocationClient getClient() {
        if (mLocationClient == null) {
            LocationClientOption option = new LocationClientOption();
            option.setCoorType("bd09ll");
            option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);
            option.setOnceLocation(true);
            option.setIsNeedAddress(true);
            option.setNeedDeviceDirect(true);
            option.setIsNeedLocationPoiList(true);
            mLocationClient = new LocationClient(AppUtils.getContext());
            mLocationClient.setLocOption(option);
            return mLocationClient;
        }
        return mLocationClient;
    }

    public static LocationManager get() {
        if (sInstance == null) {
            sInstance = new LocationManager();
        }
        return sInstance;
    }

    public LocationManager callback(OnLocationCallback callback) {
        this.mCallback = callback;
        return this;
    }

    public void locate() {
        LocationClient client = getClient();
        client.registerLocationListener(listener);
        client.start();
    }

    private BDAbstractLocationListener listener = new BDAbstractLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation bdLocation) {
            if (mCallback != null) {
                LocationEntity entity = new LocationEntity();
                entity.latitude = bdLocation.getLatitude();
                entity.longitude = bdLocation.getLongitude();
                if (TextUtils.isEmpty(bdLocation.getAddrStr())) {
                    entity.address = "未获取到地址，请打开定位服务开关";
                } else {
                    entity.address = bdLocation.getAddrStr();
                }
                mCallback.onLocation(entity);
            }
        }
    };

    public void destroy() {
        getClient().unRegisterLocationListener(listener);
    }
}
