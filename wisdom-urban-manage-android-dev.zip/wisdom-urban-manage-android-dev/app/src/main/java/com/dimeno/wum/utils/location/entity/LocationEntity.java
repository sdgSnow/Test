package com.dimeno.wum.utils.location.entity;

/**
 * location info entity
 */
public class LocationEntity {
    public double latitude;
    public double longitude;
    public String address;
}
