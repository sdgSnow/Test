package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;
import com.dimeno.network.task.PostJsonTask;

public class CaseVerifyListTask extends PostFormTask {
    public <EntityType> CaseVerifyListTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getCaseVerifyList";
    }
}
