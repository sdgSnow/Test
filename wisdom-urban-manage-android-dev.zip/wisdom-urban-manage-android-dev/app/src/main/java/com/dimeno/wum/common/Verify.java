package com.dimeno.wum.common;

public class Verify {

    public static final int PASS = 1;//通过
    public static final int NO_PASS = 2;//不通过

    public static final int VERIFY = 1;//属实
    public static final int UN_VERIFY = 2;//不属实

    //定义类型，代表核实和核查进入到详情提交页
    public static final int TYPE_RECHECK = 1;//核查/复核
    public static final int TYPE_CHECK = 2;//核实
}
