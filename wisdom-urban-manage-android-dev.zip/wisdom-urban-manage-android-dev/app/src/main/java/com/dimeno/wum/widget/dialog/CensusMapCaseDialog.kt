package com.dimeno.wum.widget.dialog

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.utils.DistanceUtil
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.common.IKey
import com.dimeno.wum.ui.activity.ReportActivity
import com.dimeno.wum.ui.bean.MapRouteEntity
import kotlinx.android.synthetic.main.dialog_census_map_case_info.*
import java.util.*

/**
 * census map case dialog
 * Created by wangzhen on 2020/10/27.
 */
class CensusMapCaseDialog : BaseDialogFragment() {
    private var entity: MapRouteEntity? = null
    private var location: LatLng? = null

    override fun layoutId(): Int = R.layout.dialog_census_map_case_info

    override fun isBottom(): Boolean = true

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_case_start.setOnClickListener {
            startCensus()
        }

        entity?.run {
            tv_road_name.text = "西环路"
            val distance = DistanceUtil.getDistance(location, LatLng(latitude, longitude)).toInt()
            tv_distance.text = if (distance < 1000) {
                "距您${distance}m"
            } else {
                "距您${distance * 1f / 1000}km"
            }
            tv_case_type.text = String.format(Locale.CHINESE, "【%s/%s/%s】", caseTypeName, bigClassName, smallClassName)
            tv_case_address.text = address
            tv_case_time.text = uploadTimeEnd
        }
    }

    private fun startCensus() {
        entity?.let {
            startActivity(Intent(context, ReportActivity::class.java).apply {
                putExtra(IKey.GENERAL_SURVEY_ID, it.id)
                putExtra(IKey.PRESET, true)
                putExtra(IKey.CASE_TYPE_NAME, it.caseTypeName)
                putExtra(IKey.CASE_TYPE_CODE, it.caseType.toString())
                putExtra(IKey.CASE_BIG_CLASS_NAME, it.bigClassName)
                putExtra(IKey.CASE_BIG_CLASS_CODE, it.bigClass)
                putExtra(IKey.CASE_SMALL_CLASS_NAME, it.smallClassName)
                putExtra(IKey.CASE_SMALL_CLASS_CODE, it.smallClass)
            })
        }
    }

    fun setLocation(location: LatLng): CensusMapCaseDialog {
        this.location = location
        return this
    }

    fun setEntity(entity: MapRouteEntity): CensusMapCaseDialog {
        this.entity = entity
        return this
    }

    override fun windowWidth(): Int {
        return AppUtils.getScreenWidthPixels()
    }

    override fun dimAmount(): Float = 0.2f

    override fun onStart() {
        super.onStart()
        dialog?.let {
            it.setCancelable(true)
            it.setCanceledOnTouchOutside(true)
        }
    }
}