package com.dimeno.wum.widget.dialog

import android.os.Bundle
import android.view.View
import com.dimeno.wum.R
import kotlinx.android.synthetic.main.dialog_case_picture_selector.*

/**
 * CasePictureSelector
 * Created by wangzhen on 2020/9/21.
 */
class CasePictureSelector : BaseDialogFragment() {
    private var callback: Callback? = null

    override fun layoutId(): Int = R.layout.dialog_case_picture_selector

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        container_gallery.setOnClickListener {
            dismiss()
            callback?.onGallery()
        }
        container_camera.setOnClickListener {
            dismiss()
            callback?.onCamera()
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.let {
            it.setCancelable(true)
            it.setCanceledOnTouchOutside(true)
        }
    }

    fun setCallback(callback: Callback): CasePictureSelector {
        this.callback = callback
        return this
    }

    interface Callback {
        fun onGallery()
        fun onCamera()
    }
}