package com.dimeno.wum.ui.activity

import android.Manifest
import android.content.Intent
import android.os.Bundle
import com.dimeno.commons.storage.SPHelper
import com.dimeno.permission.PermissionManager
import com.dimeno.permission.callback.AbsPermissionCallback
import com.dimeno.wum.MainActivity
import com.dimeno.wum.R
import com.dimeno.wum.base.AppInitializer
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.SpConstant
import com.dimeno.wum.widget.dialog.ConfirmDialog


/**
 * splash activity
 * Created by wangzhen on 2020/9/25.
 */
class SplashActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        requestPermission()
    }

    private fun requestPermission() {
        PermissionManager.request(this, object : AbsPermissionCallback() {
            override fun onGrant(permissions: Array<out String>?) {
                AppInitializer.initBaiduMap()
                next()
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                ConfirmDialog().setTitle("提示").setMessage("为了正常使用，请授予权限").setCallback(object : ConfirmDialog.Callback {
                    override fun onCancel() {
                        finish()
                    }

                    override fun onConfirm() {
                        startActivityForResult(PermissionManager.getSettingIntent(this@SplashActivity), Code.CODE_SETTING)
                    }

                }).show(supportFragmentManager)
            }
        }, Manifest.permission.READ_PHONE_STATE)
    }

    private fun next() {
        if (SPHelper.get().get(SpConstant.SP_IS_FIRST_RUNNING, true)) {
            startActivity(Intent(this@SplashActivity, GuideActivity::class.java))
        } else {
            startActivity(Intent(this@SplashActivity, if (UserBiz.get().isLogin) MainActivity::class.java else LoginActivity::class.java))
        }
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Code.CODE_SETTING) {
            requestPermission()
        }
    }
}