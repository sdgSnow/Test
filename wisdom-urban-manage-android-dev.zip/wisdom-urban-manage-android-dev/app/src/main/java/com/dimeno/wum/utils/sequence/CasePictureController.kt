package com.dimeno.wum.utils.sequence

import com.dimeno.commons.utils.T
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.entity.OssTokenEntity
import com.dimeno.wum.network.task.GetOssTokenTask
import com.dimeno.wum.ui.adapter.CasePictureAdapter
import com.dimeno.wum.utils.OSSManager
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceTask

/**
 * 上传案件图片
 * Created by wangzhen on 2020/9/17.
 */
class CasePictureController(val adapter: CasePictureAdapter?) : SequenceTask() {
    private var total = 0
    private var size = 0
    override fun run() {
        if (adapter != null && adapter.datas != null && adapter.datas.isNotEmpty()) {
            val list = adapter.datas;
            total = list.size
            for (i in 0 until total) {
                GetOssTokenTask(object : LoadingCallback<OssTokenEntity>() {
                    override fun onSuccess(data: OssTokenEntity) {
                        OSSManager.get()
                                .accessKeyId(data.AccessKeyId)
                                .accessKeySecret(data.AccessKeySecret)
                                .securityToken(data.SecurityToken)
                                .endPoint(data.endpoint)
                                .bucket(data.BucketName)
                                .directory(data.Directory)
                                .file(list[i].url)
                                .callback(object : OSSManager.Callback {
                                    override fun onSuccess() {
                                        size++
                                        if (size >= total) {
                                            controller().proceed()
                                        }
                                    }

                                    override fun onFailure(message: String) {
                                        onFail(message)
                                    }

                                }).upload()
                    }

                    override fun onError(code: Int, message: String) {
                        onFail(message)
                    }
                }).setTag(activity()).exe()
            }
        }
    }

    private fun onFail(msg: String) {
        T.show(msg)
        DialogManager.get().stopLoading()
    }
}