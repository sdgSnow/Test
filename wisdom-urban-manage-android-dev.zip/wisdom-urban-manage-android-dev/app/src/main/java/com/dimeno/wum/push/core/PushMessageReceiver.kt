package com.dimeno.wum.push.core

import cn.jpush.android.service.JPushMessageReceiver

/**
 * push message receiver
 * Created by wangzhen on 2020/9/25.
 */
class PushMessageReceiver : JPushMessageReceiver()