package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseFlowBean;
import com.dimeno.wum.ui.bean.CaseQueryBean;

/**
 * CaseFlowHolder
 * Created by sdg on 2020/10/9.
 */
public class CaseFlowHolder extends RecyclerViewHolder<CaseFlowBean> {


    private final TextView tv_case_status_name;
    private final TextView tv_case_unit;
    private final TextView tv_case_opition;
    private final TextView tv_status_deal_time;

    public CaseFlowHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_case_flow);
        tv_case_status_name = findViewById(R.id.tv_case_status_name);
        tv_case_unit = findViewById(R.id.tv_case_unit);
        tv_case_opition = findViewById(R.id.tv_case_opition);
        tv_status_deal_time = findViewById(R.id.tv_status_deal_time);

    }

    @Override
    public void bind() {
        tv_case_status_name.setText(mData.linkName);
        tv_case_unit.setText(mData.manager);
        tv_case_opition.setText(mData.remark);
        tv_status_deal_time.setText(mData.linkTime);
    }
}
