package com.dimeno.wum.ui.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.ui.adapter.holder.CaseStashViewHolder

/**
 * CaseStashAdapter
 * Created by wangzhen on 2020/9/18.
 */
class CaseStashAdapter(list: MutableList<CaseStashEntity>) : RecyclerAdapter<CaseStashEntity>(list) {
    override fun onAbsCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CaseStashViewHolder(parent)
    }

    fun checkMode(mode: Boolean) {
        mDatas?.let {
            for (i in it.indices)
                it[i].isCheckMode = mode
            notifyDataSetChanged()
        }
    }

    fun getCheckedList(): MutableList<CaseStashEntity>? {
        mDatas?.let {
            val list = mutableListOf<CaseStashEntity>()
            for (i in it.indices) {
                if (it[i].isChecked)
                    list.add(it[i])
            }
            return list
        }
        return null
    }
}