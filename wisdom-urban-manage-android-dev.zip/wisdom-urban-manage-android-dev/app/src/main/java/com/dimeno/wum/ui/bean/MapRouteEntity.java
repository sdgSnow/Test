package com.dimeno.wum.ui.bean;

import java.io.Serializable;

/**
 * MapRouteEntity
 * Created by wangzhen on 2020/10/31.
 */
public class MapRouteEntity implements Serializable {
    public String address;
    public int alreadyNum;
    public String surveyTimeEnd;
    public String surveyTimeStart;
    public String surveyContext;
    public String updateUser;
    public String updateTime;
    public String surveyUserid;
    public int caseType;
    public String smallClassName;
    public String smallClass;
    public String caseTypeName;
    public String bigClassName;
    public String uploadTimeEnd;
    public String photographRequire;
    public String createTime;
    public String taskArea;
    public String noteMatter;
    public String createUser;
    public String id;
    public String descriptionFormat;
    public String bigClass;
    public int status;
    public double latitude;
    public double longitude;
}
