package com.dimeno.wum.base

import com.baidu.mapapi.CoordType
import com.baidu.mapapi.SDKInitializer
import com.dimeno.commons.utils.AppUtils
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.entity.CaseTypeResponse
import com.dimeno.wum.entity.TaskAreaEntity
import com.dimeno.wum.entity.db.CaseBigClassEntity
import com.dimeno.wum.entity.db.CaseSmallClassEntity
import com.dimeno.wum.entity.db.CaseTypeEntity
import com.dimeno.wum.entity.db.TaskArea
import com.dimeno.wum.network.task.CaseTypeListTask
import com.dimeno.wum.network.task.TaskAreaTask
import com.dimeno.wum.utils.DBLoader
import java.util.concurrent.Executors

/**
 * app initializer, prepare essential data in advance
 * Created by wangzhen on 2020/9/18.
 */
class AppInitializer {
    companion object {
        fun prepare() {
            prepareCaseType()
        }

        private fun prepareCaseType() {
            CaseTypeListTask(object : LoadingCallback<CaseTypeResponse>() {
                override fun onSuccess(data: CaseTypeResponse) {
                    Executors.newCachedThreadPool().submit {
                        data.data?.apply {
                            caseTypeList?.let { types ->
                                DBLoader.load(CaseTypeEntity::class.java).apply {
                                    removeAll()
                                    put(types)
                                }
                                dictList?.let { dict ->
                                    val bigList = mutableListOf<CaseBigClassEntity>()
                                    for (i in types.indices) {
                                        for (j in dict.indices) {
                                            if (types[i].code == dict[j].topCode && dict[j].pcode == "0") {
                                                bigList.add(CaseBigClassEntity().apply {
                                                    code = dict[j].code
                                                    name = dict[j].name
                                                    topcode = types[i].code.toString()
                                                })
                                            }
                                        }
                                    }
                                    DBLoader.load(CaseBigClassEntity::class.java).apply {
                                        removeAll()
                                        put(bigList)
                                    }

                                    val smallList = mutableListOf<CaseSmallClassEntity>()
                                    for (i in bigList.indices) {
                                        for (j in dict.indices) {
                                            if (dict[j].topCode.toString() == bigList[i].topcode && dict[j].pcode == bigList[i].code) {
                                                smallList.add(CaseSmallClassEntity().apply {
                                                    code = dict[j].code
                                                    name = dict[j].name
                                                    pcode = bigList[i].code
                                                    topcode = bigList[i].topcode
                                                })
                                            }
                                        }
                                    }
                                    DBLoader.load(CaseSmallClassEntity::class.java).apply {
                                        removeAll()
                                        put(smallList)
                                    }
                                }
                            }
                        }
                    }
                }
            }).exe()
        }

        fun prepareTaskArea() {
            TaskAreaTask(object : LoadingCallback<TaskAreaEntity>() {
                override fun onSuccess(data: TaskAreaEntity) {
                    Executors.newCachedThreadPool().submit {
                        data.data?.apply {
                            val taskAreaList = mutableListOf<TaskArea>()
                            for (datum in data.data) {
                                taskAreaList.add(TaskArea().apply {
                                    code = datum.code;
                                    createTime = datum.createTime;
                                    createUser = datum.createUser;
                                    name = datum.name;
                                    pcode = datum.pcode;
                                    remark = datum.remark;
                                    top = datum.top;
                                    updateTime = datum.updateTime;
                                    updateUser = datum.updateUser;
                                })
                            }
                            DBLoader.load(TaskArea::class.java).apply {
                                removeAll()
                                put(taskAreaList)
                            }
                        }
                    }
                }
            }).put("userId", UserBiz.get().userId).exe()
        }

        fun initBaiduMap() {
            SDKInitializer.initialize(AppUtils.getContext())
            SDKInitializer.setCoordType(CoordType.BD09LL)
        }
    }
}