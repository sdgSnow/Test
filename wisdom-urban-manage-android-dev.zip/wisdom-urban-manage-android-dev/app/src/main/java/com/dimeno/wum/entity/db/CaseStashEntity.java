package com.dimeno.wum.entity.db;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;
import io.objectbox.annotation.Transient;

/**
 * case stash entity
 * Created by wangzhen on 2020/9/17.
 */
@Entity
public class CaseStashEntity {
    @Id
    public long id;
    public String typeCode; // 案件类型
    public String typeName; // 案件类型名称
    public String bigClassCode; // 案件大类
    public String bigClassName; // 案件大类名称
    public String smallClassCode; // 案件小类
    public String smallClassName; // 案件小类名称
    public String address; // 地址
    public double latitude; // 纬度
    public double longitude; //经度
    public String description; // 问题描述
    public String pictures;// json
    public String userId; // 用户id
    public String taskId;// 任务id
    public String caseId;// 案件id
    public String generalSurveyId;// 普查案件id
    public long createTime; // 创建时间
    public long updateTime; // 更新时间
    @Transient
    public boolean isCheckMode;// 是否为选择模式
    @Transient
    public boolean isChecked; // 是否选中
}
