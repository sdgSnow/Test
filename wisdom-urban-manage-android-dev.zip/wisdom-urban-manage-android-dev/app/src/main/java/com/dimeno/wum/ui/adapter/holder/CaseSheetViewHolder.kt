package com.dimeno.wum.ui.adapter.holder

import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.wum.R
import com.dimeno.wum.entity.CommonSpinnerEntity

/**
 * CaseSheetViewHolder
 * Created by wangzhen on 2020/9/18.
 */
class CaseSheetViewHolder(parent: ViewGroup) : RecyclerViewHolder<CommonSpinnerEntity>(parent, R.layout.case_sheet_item_layout) {
    override fun bind() {
        findViewById<TextView>(R.id.tv).text = mData.name
    }
}