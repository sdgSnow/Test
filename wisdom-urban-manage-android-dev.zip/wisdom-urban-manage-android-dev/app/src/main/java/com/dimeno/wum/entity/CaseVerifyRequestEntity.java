package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class CaseVerifyRequestEntity implements Serializable {


    /**
     * address : string
     * caseFilesList : [{"caseReportId":"string","createTime":"2020-09-21T06:08:51.440Z","createUser":"string","fileShowUrl":"string","fileSource":"REPORT","fileUrl":"string","id":"string","updateTime":"2020-09-21T06:08:51.440Z","updateUser":"string"}]
     * caseReportId : string
     * createTime : 2020-09-21T06:08:51.440Z
     * createUser : string
     * id : string
     * latitude : string
     * longitude : string
     * operationDescription : string
     * operationType : CASESTATUS0
     * passFailed : 0
     * updateTime : 2020-09-21T06:08:51.440Z
     * updateUser : string
     */

    public String address;
    public String caseReportId;
    public String createTime;
    public String createUser;
    public String id;
    public String latitude;
    public String longitude;
    public String operationDescription;
    public String operationType;
    public int passFailed;
    public String updateTime;
    public String updateUser;
    public List<CaseFilesListBean> caseFilesList;

    public static class CaseFilesListBean implements Serializable{
        /**
         * caseReportId : string
         * createTime : 2020-09-21T06:08:51.440Z
         * createUser : string
         * fileShowUrl : string
         * fileSource : REPORT
         * fileUrl : string
         * id : string
         * updateTime : 2020-09-21T06:08:51.440Z
         * updateUser : string
         */

        public String caseReportId;
        public String createTime;
        public String createUser;
        public String fileShowUrl;
        public int fileSource;
        public String fileUrl;
        public String id;
        public String updateTime;
        public String updateUser;
    }
}
