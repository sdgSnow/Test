package com.dimeno.wum.push;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.dimeno.wum.R;
import com.dimeno.wum.push.callback.Notifications;
import com.dimeno.wum.push.entity.NotificationEntity;

/**
 * notification helper
 * Created by wangzhen on 2020/9/24.
 */
public class NotificationHelper implements Notifications {
    private static Notifications mInstance;
    private static int notify_id = 0;
    public static final String CHANNEL_ID = "channel_wisdom_urban";
    public static final String CHANNEL_NAME = "wisdom_urban";
    private static final long NO_DISTURBING = 1500; // 免打扰间隔时间
    private static long mLastNotifyTime;
    private static NotificationManager notificationManager;
    private Context context;

    public static Notifications get(Context ctx) {
        if (mInstance == null) {
            synchronized (NotificationHelper.class) {
                if (mInstance == null) {
                    mInstance = new NotificationHelper(ctx);
                }
            }
        }
        return mInstance;
    }

    private NotificationHelper(Context ctx) {
        this.context = ctx.getApplicationContext();
    }

    @Override
    public void send(NotificationEntity data) {
        if (data != null) {
            createNotificationChannel();
            Notification notification = createNotification(data);
            if (notification != null) {
                mLastNotifyTime = SystemClock.uptimeMillis();
                getNotificationManager().notify(notify_id++, notification);
            }
        }
    }

    /**
     * create notification
     *
     * @param data data
     * @return notification
     */
    private Notification createNotification(NotificationEntity data) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID);
        builder.setContentIntent(getBroadcastIntent(data))
                .setWhen(System.currentTimeMillis())
                .setPriority(Notification.PRIORITY_DEFAULT)
                .setOngoing(false)
                .setSmallIcon(R.mipmap.logo)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.logo))
                .setAutoCancel(true)
                .setContentTitle(data.title)
                .setContentText(data.content);
        if (data.bigTextStyle) {
            builder.setStyle(new NotificationCompat.BigTextStyle());
        }
        if (SystemClock.uptimeMillis() - mLastNotifyTime < NO_DISTURBING) {
            builder.setDefaults(Notification.DEFAULT_LIGHTS);
        } else {
            builder.setDefaults(Notification.DEFAULT_ALL);
        }
        return builder.build();
    }

    @Override
    public void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.enableLights(true);
            channel.setShowBadge(true);
            channel.enableVibration(true);
            channel.setLightColor(Color.YELLOW);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            getNotificationManager().createNotificationChannel(channel);
        }
    }

    private PendingIntent getBroadcastIntent(NotificationEntity data) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction(NotificationReceiver.ACTION);
        intent.putExtra("push_data", data);
        return PendingIntent.getBroadcast(context, notify_id, intent, PendingIntent.FLAG_CANCEL_CURRENT);
    }

    @NonNull
    @Override
    public NotificationManager getNotificationManager() {
        if (notificationManager == null) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return notificationManager;
    }
}
