package com.dimeno.wum.utils.sequence

import android.content.Intent
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.dimeno.commons.storage.DataHelper
import com.dimeno.commons.utils.T
import com.dimeno.network.base.Task
import com.dimeno.network.callback.LoadingCallback
import com.dimeno.wum.MainActivity
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.FileSource
import com.dimeno.wum.common.IKey
import com.dimeno.wum.entity.CaseCheckRepeatEntity
import com.dimeno.wum.entity.CasePictureEntity
import com.dimeno.wum.entity.CaseReportFileEntity
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.network.task.CaseCheckRepeatTask
import com.dimeno.wum.network.task.CaseReportTask
import com.dimeno.wum.ui.activity.CaseRepeatConfirmActivity
import com.dimeno.wum.utils.ActivityManager
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.OSSManager
import com.dimeno.wum.viewmodel.CaseStashViewModel
import com.dimeno.wum.viewmodel.IndexViewModel
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceTask
import java.io.File

/**
 * 上传案件请求
 * Created by wangzhen on 2020/9/17.
 */
class CaseReportController(val stash: CaseStashEntity?) : SequenceTask() {
    var address: String? = null // 定位地址
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var caseType: String? = null // 案件属性
    var bigClass: String? = null // 案件大类
    var smallClass: String? = null // 案件小类
    var smallClassOtherName: String? = null // 案件自定义小类名称
    var description: String? = null // 问题描述
    var taskId: String? = null // 任务id
    var caseId: String? = null // 案件id
    var generalSurveyId: String? = null // 普查案件id
    var pictures: List<CasePictureEntity>? = null // 文件列表

    private val fileList: MutableList<CaseReportFileEntity> = mutableListOf() // 文件列表

    private fun createFileList(): MutableList<CaseReportFileEntity> {
        pictures?.let {
            fileList.clear()
            for (i in it.indices) {
                fileList.add(CaseReportFileEntity().apply {
                    fileUrl = "${OSSManager.get().directory}${File.separator}android${File.separator}${File(it[i].url).name}"
                    createUser = UserBiz.get().userId
                    createTime = System.currentTimeMillis().toString()
                    updateUser = createUser
                    updateTime = createTime
                    fileSource = FileSource.REPORT
                })
            }
        }
        return fileList
    }

    override fun run() {
        CaseCheckRepeatTask(object : LoadingCallback<CaseCheckRepeatEntity>() {
            override fun onSuccess(data: CaseCheckRepeatEntity) {
                if (data.success) {
                    data.data?.let {
                        if (it.isRepeat && it.caseList != null && it.caseList!!.isNotEmpty()) {
                            DialogManager.get().stopLoading()
                            DataHelper.get().put("case_controller", this@CaseReportController)
                            if (activity() is FragmentActivity) {
                                activity().startActivityForResult(Intent(activity(), CaseRepeatConfirmActivity::class.java).apply {
                                    putExtra(IKey.DATA, it.caseList)
                                }, Code.CODE_REPEAT)
                            }
                        } else {
                            report()
                        }
                    }
                } else {
                    T.show(data.message)
                }
            }

            override fun onError(code: Int, message: String) {
                DialogManager.get().stopLoading()
                T.show(message)
            }
        }).setTag(activity()).apply {
            buildParams(this)
        }.exe()
    }

    private fun report() {
        CaseReportTask(object : LoadingCallback<String>() {
            override fun onSuccess(data: String) {
                T.show("上报成功")
                stash?.let {
                    // 如果是暂存案件提交成功，删除本地数据
                    DBLoader.load(CaseStashEntity::class.java).remove(stash)
                    // 同步刷新暂存列表
                    ViewModelProvider(activity() as ViewModelStoreOwner).get(CaseStashViewModel::class.java).refreshStash()
                }
                // 同步刷新首页数据
                ActivityManager.get(MainActivity::class.java)?.let {
                    ViewModelProvider(it as ViewModelStoreOwner).get(IndexViewModel::class.java).refreshIndex()
                }
                // 通知案件核实上报成功
                activity().setResult(Code.CODE_REPORT_SUCCESS)
                activity().finish()
            }

            override fun onError(code: Int, message: String) {
                T.show(message)
            }

            override fun onComplete() {
                DialogManager.get().stopLoading()
            }
        }).setTag(activity()).apply {
            buildParams(this)
        }.exe()
    }

    fun buildParams(task: Task): Task {
        return task.put("caseType", caseType)
                .put("bigClass", bigClass)
                .put("smallClass", smallClass)
                .put("smallClassOtherName", smallClassOtherName)
                .put("address", address)
                .put("latitude", latitude)
                .put("longitude", longitude)
                .put("description", description)
                .put("caseFilesList", createFileList())
                .put("createUser", UserBiz.get().userId)
                .put("createTime", System.currentTimeMillis())
                .put("updateUser", UserBiz.get().userId)
                .put("updateTime", System.currentTimeMillis())
                .put("taskId", taskId)
                .put("id", caseId)
                .put("generalSurveyId", generalSurveyId)
    }
}