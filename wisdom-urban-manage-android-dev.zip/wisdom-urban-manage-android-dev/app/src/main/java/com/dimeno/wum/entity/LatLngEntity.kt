package com.dimeno.wum.entity

import java.io.Serializable

/**
 * 用户区划列表实体
 * Created by wangzhen on 2020/9/23.
 */
class LatLngEntity : Serializable {
    var latitude: Double = 0.0
    var longitude: Double = 0.0
}