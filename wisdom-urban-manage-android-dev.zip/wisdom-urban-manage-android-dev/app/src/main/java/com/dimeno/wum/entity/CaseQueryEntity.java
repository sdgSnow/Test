package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class CaseQueryEntity implements Serializable {

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;


    public static class DataBean implements Serializable {
        /**
         * address : 中国广东省深圳市罗湖区桂园街道宝安南路3097号11层
         * latitude : 22.561172
         * assignType : 1
         * description : 下雨了
         * updateUser : 1305473202950389761
         * updateTime : 2020-09-18 20:51:13
         * caseCoding : 深城管2020字第1030号
         * source : 1
         * caseNo : 1030
         * caseType : 1
         * assignTypeName : 案件上报
         * smallClassName : 交通标志牌
         * smallClass : B2
         * caseTypeName : 部件
         * bigClassName : 交通设施
         * createTime : 2020-09-18 20:51:13
         * statusName : 办理登记
         * createUser : 1305473202950389761
         * id : 1306939525365059585
         * taskId : null
         * bigClass : 02
         * longitude : 114.115144
         * status : 0
         */

        public String address;
        public String latitude;
        public int assignType;
        public String description;
        public String updateUser;
        public String updateTime;
        public String caseCoding;
        public int source;
        public int caseNo;
        public int caseType;
        public String assignTypeName;
        public String smallClassName;
        public String smallClass;
        public String caseTypeName;
        public String bigClassName;
        public String createTime;
        public String statusName;
        public String createUser;
        public String id;
        public Object taskId;
        public String bigClass;
        public String longitude;
        public int status;
    }
}
