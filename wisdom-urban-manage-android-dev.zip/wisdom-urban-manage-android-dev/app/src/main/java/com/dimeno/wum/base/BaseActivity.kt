package com.dimeno.wum.base

import android.os.Bundle
import com.dimeno.commons.toolbar.ToolbarActivity
import com.dimeno.wum.utils.ActivityManager
import com.wangzhen.statusbar.DarkStatusBar

/**
 * BaseActivity
 * Created by wangzhen on 2020/9/14.
 */
open class BaseActivity : ToolbarActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityManager.add(this)
    }

    /**
     * set dark status bar mode
     *
     * @param dark true: dark / false: light
     */
    fun fitDarkStatusBar(dark: Boolean) {
        val statusBar = DarkStatusBar.get()
        if (dark) statusBar.fitDark(this) else statusBar.fitLight(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        ActivityManager.remove(this)
    }
}