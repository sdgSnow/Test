package com.dimeno.wum.ui.activity

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.viewpager.widget.ViewPager
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.ui.adapter.GuidePagerAdapter
import kotlinx.android.synthetic.main.activity_guide.*

/**
 * guide activity
 * Created by wangzhen on 2020/9/25.
 */
class GuideActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guide)
        indicator.setImageResource(R.mipmap.ic_guide_indicator_one)
        view_pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                indicator.apply {
                    setImageResource(when (position) {
                        0 -> R.mipmap.ic_guide_indicator_one
                        else -> R.mipmap.ic_guide_indicator_two
                    })
                    visibility = if (position == 0 || position == 1) View.VISIBLE else View.GONE
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        view_pager.adapter = GuidePagerAdapter(supportFragmentManager)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        return keyCode == KeyEvent.KEYCODE_BACK
    }
}