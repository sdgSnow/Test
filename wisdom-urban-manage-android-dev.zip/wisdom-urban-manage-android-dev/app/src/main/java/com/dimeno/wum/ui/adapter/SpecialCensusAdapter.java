package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.SpecialCensusEntity;
import com.dimeno.wum.network.task.MyTaskTask;
import com.dimeno.wum.ui.adapter.holder.SpecialCensusHolder;
import com.dimeno.wum.ui.bean.SpecialCensusBean;

import java.util.ArrayList;
import java.util.List;

public class SpecialCensusAdapter extends LoadRecyclerAdapter<SpecialCensusBean> {

    private int page = 1;

    public SpecialCensusAdapter(List<SpecialCensusBean> list, RecyclerView parent) {
        super(list, parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new SpecialCensusHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new MyTaskTask(new LoadingCallback<SpecialCensusEntity>() {
            @Override
            public void onSuccess(SpecialCensusEntity data) {
                if (IList.isNotEmpty(data.data)) {
                    List<SpecialCensusBean> addList = new ArrayList<>();
                    for (SpecialCensusEntity.DataBean task : data.data) {
                        SpecialCensusBean specialCensusBean = new SpecialCensusBean();
                        specialCensusBean.address = task.address;
                        specialCensusBean.alreadyNum = task.alreadyNum;
                        specialCensusBean.alreadyNum = task.alreadyNum;
                        specialCensusBean.surveyTimeStart = task.surveyTimeStart;
                        specialCensusBean.surveyContext = task.surveyContext;
                        specialCensusBean.updateUser = task.updateUser;
                        specialCensusBean.updateTime = task.updateTime;
                        specialCensusBean.surveyUserid = task.surveyUserid;
                        specialCensusBean.caseType = task.caseType;
                        specialCensusBean.smallClassName = task.smallClassName;
                        specialCensusBean.smallClass = task.smallClass;
                        specialCensusBean.caseTypeName = task.caseTypeName;
                        specialCensusBean.bigClassName = task.bigClassName;
                        specialCensusBean.uploadTimeEnd = task.uploadTimeEnd;
                        specialCensusBean.photographRequire = task.photographRequire;
                        specialCensusBean.createTime = task.createTime;
                        specialCensusBean.createUser = task.createUser;
                        specialCensusBean.taskArea = task.taskArea;
                        specialCensusBean.noteMatter = task.noteMatter;
                        specialCensusBean.id = task.id;
                        specialCensusBean.descriptionFormat = task.descriptionFormat;
                        specialCensusBean.bigClass = task.bigClass;
                        specialCensusBean.status = task.status;
                        addList.add(specialCensusBean);
                    }
                    addData(addList);
                } else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                setState(LoadMoreState.ERROR);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
