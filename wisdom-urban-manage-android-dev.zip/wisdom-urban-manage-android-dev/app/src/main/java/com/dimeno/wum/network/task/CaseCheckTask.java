package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostJsonTask;

/**
 * CaseCheckTask
 * Created by sdg on 2020/9/23.
 * 核查接口
 */
public class CaseCheckTask extends PostJsonTask {
    public <EntityType> CaseCheckTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/caseCheck";
    }
}
