package com.dimeno.wum.ui.bean;

public class CaseDetailsBean {

    public String name;//案例详情页的标题
    public String desc;//案例详情页的对应描述信息
}
