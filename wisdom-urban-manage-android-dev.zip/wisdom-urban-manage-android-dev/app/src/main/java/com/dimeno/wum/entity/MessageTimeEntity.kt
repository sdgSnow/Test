package com.dimeno.wum.entity

/**
 * message time entity
 * Created by wangzhen on 2020/9/27.
 */
class MessageTimeEntity : MessageEntity {
    var time: Long = 0
    override fun type(): Int = MessageEntity.TYPE_TIME
}