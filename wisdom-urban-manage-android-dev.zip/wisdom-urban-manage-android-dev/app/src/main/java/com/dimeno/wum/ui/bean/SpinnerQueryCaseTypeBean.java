package com.dimeno.wum.ui.bean;

public class SpinnerQueryCaseTypeBean {

    public String caseTypeName;//案例类型名称
}
