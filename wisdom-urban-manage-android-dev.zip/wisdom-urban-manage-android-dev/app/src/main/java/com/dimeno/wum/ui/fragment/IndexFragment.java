package com.dimeno.wum.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.IndexTaskType;
import com.dimeno.wum.common.NewsType;
import com.dimeno.wum.common.UserType;
import com.dimeno.wum.entity.BasicStatisticsEntity;
import com.dimeno.wum.entity.NewsEntity;
import com.dimeno.wum.network.task.BasicStatisticsTask;
import com.dimeno.wum.network.task.NewsTask;
import com.dimeno.wum.ui.adapter.IndexAdapter;
import com.dimeno.wum.ui.bean.IndexBean;
import com.dimeno.wum.ui.bean.IndexHeaderBean;
import com.dimeno.wum.ui.footer.IndexFooter;
import com.dimeno.wum.ui.header.IndexHeader;
import com.dimeno.wum.viewmodel.IndexViewModel;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * IndexFragment
 * Created by sdg on 2020/9/16.
 */
public class IndexFragment extends Fragment implements OnRefreshCallback {
    private static final int SUPERCISOR_SPAN_COUNT = 4;//监督员首页列数
    private static final int LEADER_SPAN_COUNT = 3;//领导层首页列数
    private RecyclerView rv_index;
    private List<IndexBean> list;
    private List<IndexHeaderBean> header_list;
    private IndexAdapter indexAdapter;
    private IndexFooter indexFooter;
    private IndexHeader indexHeader;
    private RefreshLayout refresh_layout;
    private int userType;

    public static IndexFragment newInstance() {
        IndexFragment fragment = new IndexFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_index, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv_index = view.findViewById(R.id.rv_index);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);

        userType = UserBiz.get().getUserType();
        if (userType == UserType.LEADER) {
            rv_index.setLayoutManager(new GridLayoutManager(getActivity(), LEADER_SPAN_COUNT, GridLayoutManager.VERTICAL, false));
            initLeaderData();
        } else {
            rv_index.setLayoutManager(new GridLayoutManager(getActivity(), SUPERCISOR_SPAN_COUNT, GridLayoutManager.VERTICAL, false));
            initSupercisorData();
        }
        refresh_layout.startRefresh();
        getBasicStatistics();
        getNewsList();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getActivity() != null)
            new ViewModelProvider(getActivity()).get(IndexViewModel.class).getRefreshLiveData().observe(getViewLifecycleOwner(), new Observer<Object>() {
                @Override
                public void onChanged(Object o) {
                    getBasicStatistics();
                }
            });
    }

    //获取新闻列表
    private void getNewsList() {
        new NewsTask(new LoadingCallback<NewsEntity>() {
            @Override
            public void onSuccess(NewsEntity data) {
                if (data.data != null) {
                    indexHeader.setData(data);
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("newsType", NewsType.NEWS)
                .exe();
    }

    //获取基本统计数据
    private void getBasicStatistics() {
        if(userType == UserType.LEADER){
            new BasicStatisticsTask(new LoadingCallback<BasicStatisticsEntity>() {
                @Override
                public void onSuccess(BasicStatisticsEntity data) {
                    indexFooter.setData(data.data);
                }

                @Override
                public void onError(int code, String message) {
                    T.show(message);
                }

                @Override
                public void onComplete() {
                    refresh_layout.refreshComplete();
                }
            }).setTag(this)
                    .exe();
        }else {
            new BasicStatisticsTask(new LoadingCallback<BasicStatisticsEntity>() {
                @Override
                public void onSuccess(BasicStatisticsEntity data) {
                    indexFooter.setData(data.data);
                }

                @Override
                public void onError(int code, String message) {
                    T.show(message);
                }

                @Override
                public void onComplete() {
                    refresh_layout.refreshComplete();
                }
            }).setTag(this)
                    .put("userId", UserBiz.get().getUserId())
                    .exe();
        }
    }

    //监督员数据
    private void initSupercisorData() {
        list = new ArrayList<>();
        list.add(new IndexBean(IndexTaskType.ATTENDANCE, R.mipmap.menu_kaoqindaka, "考勤打卡"));
        list.add(new IndexBean(IndexTaskType.CASE_QUERY, R.mipmap.menu_anjianchaxun, "案件查询"));
        list.add(new IndexBean(IndexTaskType.CASE_CHECK, R.mipmap.menu_anjianheshi, "案件核实"));
        list.add(new IndexBean(IndexTaskType.CASE_RE_CHECK, R.mipmap.menu_anjianfuhe, "案件复核"));
        list.add(new IndexBean(IndexTaskType.MY_TASK, R.mipmap.menu_woderenwu, "我的任务"));
        list.add(new IndexBean(IndexTaskType.SPECIAL_CENSUS , R.mipmap.menu_zhuanxiangpucha, "专项普查"));
//        list.add(new IndexBean(IndexTaskType.MAP_MANAGER, R.mipmap.menu_dituguanli, "地图管理"));
        // 空白条目补位
        int mod = list.size() % SUPERCISOR_SPAN_COUNT;
        for (int i = 0; i < SUPERCISOR_SPAN_COUNT - mod; i++) {
            list.add(null);
        }
        init();
    }

    //领导端数据
    private void initLeaderData() {
        list = new ArrayList<>();
        list.add(new IndexBean(IndexTaskType.CASE_MANAGER, R.mipmap.menu_anjianguanli, "案件管理"));
        list.add(new IndexBean(IndexTaskType.CASE_STATISTIC, R.mipmap.menu_anjiantongji, "案件统计"));
        list.add(new IndexBean(IndexTaskType.LEADER_MAP_MANAGER, R.mipmap.menu_dituguanli, "地图管理"));
        list.add(new IndexBean(IndexTaskType.ASSESSMENT_EVALUATION, R.mipmap.menu_kaohepingjia, "考核评价"));
        list.add(new IndexBean(IndexTaskType.CITY_QUES, R.mipmap.menu_chengshiwenti, "城市问题"));
        // 空白条目补位
        int mod = list.size() % LEADER_SPAN_COUNT;
        for (int i = 0; i < LEADER_SPAN_COUNT - mod; i++) {
            list.add(null);
        }
        init();
    }

    private void init() {
        indexAdapter = new IndexAdapter(list);
        indexHeader = new IndexHeader(getActivity());
        indexFooter = new IndexFooter();
        indexAdapter.addHeader(indexHeader.onCreateView(rv_index));
        indexAdapter.addFooter(indexFooter.onCreateView(rv_index));
        rv_index.setAdapter(indexAdapter);
    }

    @Override
    public void onRefresh() {
        getBasicStatistics();
        getNewsList();
    }

    @Override
    public void onPause() {
        super.onPause();
        indexHeader.stopBanner();
    }

    @Override
    public void onResume() {
        super.onResume();
        indexHeader.startBanner();
    }
}