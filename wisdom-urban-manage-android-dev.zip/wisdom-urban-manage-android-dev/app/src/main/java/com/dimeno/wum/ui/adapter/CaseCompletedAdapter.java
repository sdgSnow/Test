package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.commons.structure.IList;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseCompletedEntity;
import com.dimeno.wum.entity.CaseRemainDealEntity;
import com.dimeno.wum.network.task.CaseVerifyListTask;
import com.dimeno.wum.network.task.CaseVerifyTask;
import com.dimeno.wum.ui.adapter.holder.CaseCompleteHolder;
import com.dimeno.wum.ui.adapter.holder.CaseRemainDealHolder;
import com.dimeno.wum.ui.bean.CaseCompletedBean;
import com.dimeno.wum.ui.bean.CaseRemainDealBean;

import java.util.ArrayList;
import java.util.List;

public class CaseCompletedAdapter extends LoadRecyclerAdapter<CaseCompletedBean> {
    private int page = 1;

    public CaseCompletedAdapter(List<CaseCompletedBean> list,RecyclerView parent) {
        super(list,parent);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseCompleteHolder(parent);
    }

    @Override
    public void onLoadMore() {
        new CaseVerifyListTask(new LoadingCallback<CaseCompletedEntity>() {
            @Override
            public void onSuccess(CaseCompletedEntity data) {
                if(IList.isNotEmpty(data.data)){
                    List<CaseCompletedBean> addList = new ArrayList<>();
                    for (CaseCompletedEntity.DataBean datum : data.data) {
                        CaseCompletedBean caseCompletedBean = new CaseCompletedBean();
                        caseCompletedBean.address = datum.address;
                        caseCompletedBean.latitude = datum.latitude;
                        caseCompletedBean.assignType = datum.assignType;
                        caseCompletedBean.description = datum.description;
                        caseCompletedBean.updateUser = datum.updateUser;
                        caseCompletedBean.updateTime = datum.updateTime;
                        caseCompletedBean.caseCoding = datum.caseCoding;
                        caseCompletedBean.source = datum.source;
                        caseCompletedBean.caseNo = datum.caseNo;
                        caseCompletedBean.caseType = datum.caseType;
                        caseCompletedBean.assignTypeName = datum.assignTypeName;
                        caseCompletedBean.smallClassName = datum.smallClassName;
                        caseCompletedBean.smallClass = datum.smallClass;
                        caseCompletedBean.caseTypeName = datum.caseTypeName;
                        caseCompletedBean.bigClassName = datum.bigClassName;
                        caseCompletedBean.createTime = datum.createTime;
                        caseCompletedBean.statusName = datum.statusName;
                        caseCompletedBean.createUser = datum.createUser;
                        caseCompletedBean.id = datum.id;
                        caseCompletedBean.taskId = datum.taskId;
                        caseCompletedBean.bigClass = datum.bigClass;
                        caseCompletedBean.longitude = datum.longitude;
                        caseCompletedBean.status = datum.status;
                        addList.add(caseCompletedBean);
                    }
                    addData(addList);
                }else {
                    setState(LoadMoreState.NO_MORE);
                }
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }
        }).setTag(this)
                .put("pageIndex", ++page)
                .put("pageSize", Load.PAGE_SUM)
//                .put("assignType", AssignType.CASE_EXAMINE)
                .put("status", CasePro.CASE_COMPLETE)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }
}
