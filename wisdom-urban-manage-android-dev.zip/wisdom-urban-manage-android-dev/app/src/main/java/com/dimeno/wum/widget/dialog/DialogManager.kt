package com.dimeno.wum.widget.dialog

import androidx.fragment.app.FragmentActivity
import com.dimeno.wum.utils.ActivityManager

/**
 * DialogManager
 * Created by wangzhen on 2020/9/17.
 */
class DialogManager {
    private var mLoadingDialog: LoadingDialog? = null

    companion object {
        private var sInstance: DialogManager? = null
        fun get(): DialogManager {
            if (sInstance == null) {
                synchronized(DialogManager::class.java) {
                    if (sInstance == null) {
                        sInstance = DialogManager()
                    }
                }
            }
            return sInstance!!
        }
    }

    /**
     * show loading dialog
     */
    fun showLoading() {
        mLoadingDialog?.let {
            mLoadingDialog!!.dismiss()
        } ?: let {
            mLoadingDialog = LoadingDialog()
        }
        ActivityManager.current()?.let { activity ->
            if (activity is FragmentActivity) {
                mLoadingDialog!!.show(activity.supportFragmentManager)
            }
        }
    }

    /**
     * dismiss loading dialog
     */
    fun stopLoading() {
        mLoadingDialog?.dismiss()
    }
}