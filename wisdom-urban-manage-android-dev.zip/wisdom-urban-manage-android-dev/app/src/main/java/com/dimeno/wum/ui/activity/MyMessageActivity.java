package com.dimeno.wum.ui.activity;

import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.network.loading.DefaultLoadingPage;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.MyMessageEntity;
import com.dimeno.wum.network.task.MyMessageTask;
import com.dimeno.wum.ui.adapter.MyMessageAdapter;
import com.dimeno.wum.ui.bean.MyMessageBean;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class MyMessageActivity extends BaseActivity implements OnRefreshCallback {

    private RefreshLayout refresh_layout;
    private RecyclerView rv_my_message;
    private List<MyMessageBean> messageBeans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_message);
        fitDarkStatusBar(true);
        rv_my_message = findViewById(R.id.rv_my_message);
        refresh_layout = findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        getMsg(true);
    }

    private void getMsg(boolean first) {
        new MyMessageTask(new LoadingCallback<MyMessageEntity>() {
            @Override
            public void onSuccess(MyMessageEntity data) {
                initMessage(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .setLoadingPage(first ? new DefaultLoadingPage(refresh_layout) : null)
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    public void initMessage(MyMessageEntity data) {
        messageBeans = new ArrayList<>();
        if (data != null && data.data != null) {
            for (MyMessageEntity.DataBean datum : data.data) {
                MyMessageBean myMessageBean = new MyMessageBean();
                myMessageBean.msg = datum.msg;
                myMessageBean.caseReportId = datum.caseReportId;
                myMessageBean.caseMsgType = datum.caseMsgType;
                myMessageBean.msgType = datum.msgType;
                myMessageBean.createTime = datum.createTime;
                myMessageBean.updateUser = datum.updateUser;
                myMessageBean.createUser = datum.createUser;
                myMessageBean.updateTime = datum.updateTime;
                myMessageBean.id = datum.id;
                myMessageBean.title = datum.title;
                myMessageBean.userId = datum.userId;
                myMessageBean.url = datum.url;
                messageBeans.add(myMessageBean);
            }
        }
        showMessage();
    }

    private void showMessage() {
        rv_my_message.setLayoutManager(new GridLayoutManager(MyMessageActivity.this, 1, GridLayoutManager.VERTICAL, false));
        MyMessageAdapter myMessageAdapter = new MyMessageAdapter(messageBeans, rv_my_message);
        myMessageAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_my_message));
        rv_my_message.setAdapter(myMessageAdapter);
        myMessageAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                T.show(messageBeans.get(position).msg);
            }
        });
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "我的消息");
    }

    @Override
    public void onRefresh() {
        getMsg(false);
    }
}