package com.dimeno.wum.entity

import java.io.Serializable

/**
 * CasePictureEntity
 * Created by wangzhen on 2020/9/16.
 */
data class CasePictureEntity(val url: String) : Serializable