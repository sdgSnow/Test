package com.dimeno.wum.widget.abs;

import android.view.View;
import android.widget.AdapterView;

/**
 * AbsItemSelectedListener
 * Created by wangzhen on 2020/9/15.
 */
public class AbsItemSelectedListener implements AdapterView.OnItemSelectedListener {
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
