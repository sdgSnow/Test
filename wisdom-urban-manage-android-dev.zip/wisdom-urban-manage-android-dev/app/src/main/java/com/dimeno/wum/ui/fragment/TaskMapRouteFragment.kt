package com.dimeno.wum.ui.fragment

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.baidu.location.BDAbstractLocationListener
import com.baidu.location.BDLocation
import com.baidu.location.LocationClient
import com.baidu.location.LocationClientOption
import com.baidu.mapapi.map.*
import com.baidu.mapapi.model.LatLng
import com.baidu.mapapi.overlayutil.DrivingRouteOverlay
import com.baidu.mapapi.overlayutil.OverlayManager
import com.baidu.mapapi.search.route.*
import com.baidu.mapapi.utils.DistanceUtil
import com.dimeno.commons.utils.T
import com.dimeno.wum.R
import com.dimeno.wum.common.IKey
import com.dimeno.wum.ui.bean.MapRouteEntity
import com.dimeno.wum.ui.bean.SpecialCensusBean
import com.dimeno.wum.viewmodel.MapRouteViewModel
import com.dimeno.wum.widget.abs.AbsDrivingPlanResultListener
import com.dimeno.wum.widget.dialog.CensusMapCaseDialog
import com.dimeno.wum.widget.dialog.CensusRoutePlanDialog
import com.dimeno.wum.widget.dialog.DialogManager
import kotlinx.android.synthetic.main.fragment_task_remain_map.*
import java.util.*
import kotlin.collections.ArrayList

/**
 * 任务地图 路径规划
 * Created by wangzhen on 2020/10/27.
 */
class TaskMapRouteFragment : Fragment() {
    private val distanceArr = intArrayOf(20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 25000, 50000, 100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000)
    private val levelArr = intArrayOf(21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3)

    private var locationClient: LocationClient? = null
    private var baiduMap: BaiduMap? = null
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var list: MutableList<MapRouteEntity>? = null
    private var routeSearch: RoutePlanSearch? = null
    private var overlay: OverlayManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_task_remain_map, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        initMap()
        initObserver()
    }

    private fun initObserver() {
        if (context is ViewModelStoreOwner) {
            ViewModelProvider(context as ViewModelStoreOwner).get(MapRouteViewModel::class.java).getMapLiveData().observe(viewLifecycleOwner, Observer<MutableList<MapRouteEntity>> {
                list = it
                addMarker()
            })
        }
    }

    private fun addMarker() {
        baiduMap?.let { map ->
            map.clear()
            list?.let {
                it.forEach { item ->
                    val option = MarkerOptions()
                            .position(LatLng(item.latitude, item.longitude))
                            .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_census_map_marker))
                            .extraInfo(Bundle().apply {
                                putString(IKey.DATA, item.id)
                            })
                    map.addOverlay(option)
                }
            }
        }
    }

    private fun initMap() {
        map_view.apply {
            showZoomControls(false)
            baiduMap = map.apply {
                isMyLocationEnabled = true
                uiSettings.isCompassEnabled = false
                setOnMarkerClickListener { marker ->
                    marker.extraInfo?.let {
                        showCaseInfo(it.getString(IKey.DATA, ""))
                    }
                    false
                }
            }
        }
        // 定位当前位置
        getClient().apply {
            registerLocationListener(object : BDAbstractLocationListener() {
                override fun onReceiveLocation(location: BDLocation) {
                    latitude = location.latitude
                    longitude = location.longitude

//                    latitude = 38.911344
//                    longitude = 121.601577

                    baiduMap?.apply {
                        setMyLocationData(MyLocationData.Builder().latitude(latitude).longitude(longitude).build())
                        addOverlay(CircleOptions().center(LatLng(latitude, longitude)).radius(1000).fillColor(Color.parseColor("#4d1271F0")))
//                        setMyLocationConfiguration(MyLocationConfiguration(MyLocationConfiguration.LocationMode.NORMAL, true, BitmapDescriptorFactory.fromResourceWithDpi(R.mipmap.ic_census_current_position,720)))
                    }
                    centerAndZoom()
                }
            })
            start()
        }
    }

    /**
     * show case info
     */
    private fun showCaseInfo(id: String) {
        activity?.supportFragmentManager?.let { fragmentManager ->
            getCaseEntity(id)?.let {
                CensusMapCaseDialog()
                        .setLocation(LatLng(latitude, longitude))
                        .setEntity(it).show(fragmentManager)
            }
        }
    }

    /**
     * get case entity
     */
    private fun getCaseEntity(id: String): MapRouteEntity? {
        list?.forEach {
            if (id == it.id) {
                return it
            }
        }
        return null
    }

    private fun centerAndZoom() {
        list?.let {
            if (it.size > 0 && latitude > 0 && longitude > 0) {
                val start = LatLng(latitude, longitude)
                val end = LatLng(it[0].latitude, it[0].longitude)
                val distance = DistanceUtil.getDistance(start, end).toInt()
                val level = getLevel(distance)
                if (level > 0) {
                    baiduMap?.animateMapStatus(
                            MapStatusUpdateFactory.newMapStatus(MapStatus.Builder()
                                    .target(start)
                                    .zoom(levelArr[level].toFloat())
                                    .build()))
                }
            }
        }
    }

    private fun getLevel(distance: Int): Int {
        var level = -1
        var min = 10000000
        for (i in distanceArr.indices) {
            if (distanceArr[i] - distance in 1 until min) {
                min = distanceArr[i] - distance
                level = i
            }
        }
        return level
    }

    private fun initViews() {
        btn_path_plan.setOnClickListener { execRoutePlan() }
    }

    private fun execRoutePlan() {
        list?.let {
            if (it.isEmpty())
                return
            val points = ArrayList(it)

            val location = LatLng(latitude, longitude)
            // sort asc
            points.sortWith(Comparator { first, second ->
                (DistanceUtil.getDistance(location, LatLng(first.latitude, first.longitude)) - DistanceUtil.getDistance(location, LatLng(second.latitude, second.longitude))).toInt()
            })
            // find the most far distance as destination
            val destination = points[points.size - 1]
            // remove the most far item
            points.remove(destination)

            DialogManager.get().showLoading()
            val option = DrivingRoutePlanOption().from(PlanNode.withLocation(location))
                    .to(PlanNode.withLocation(LatLng(destination.latitude, destination.longitude)))
                    .apply {
                        val list = mutableListOf<PlanNode>()
                        for (i in 0 until points.size) {
                            list.add(PlanNode.withLocation(LatLng(points[i].latitude, points[i].longitude)))
                        }
                        passBy(list)
                    }

            RoutePlanSearch.newInstance().apply {
                routeSearch = this
                setOnGetRoutePlanResultListener(object : AbsDrivingPlanResultListener() {
                    override fun onGetDrivingRouteResult(result: DrivingRouteResult) {
                        DialogManager.get().stopLoading()
                        result.routeLines?.let { routes ->
                            if (routes.isNotEmpty()) {
                                drawRouteLine(routes[0])
                                showRouteDialog(routes)
                            }
                        } ?: let {
                            T.show("暂无推荐路径")
                        }
                    }
                })
                drivingSearch(option)
            }
        }
    }

    private fun showRouteDialog(routes: MutableList<DrivingRouteLine>) {
        activity?.supportFragmentManager?.let { fragmentManager ->
            CensusRoutePlanDialog().setRoutes(routes).setCallback(object : CensusRoutePlanDialog.Callback {
                override fun onRouteSelect(line: DrivingRouteLine) {
                    drawRouteLine(line)
                }

                override fun onNavigation(line: DrivingRouteLine) {
                    T.show("开始导航")
                }
            }).show(fragmentManager)
        }
    }

    private fun drawRouteLine(line: DrivingRouteLine) {
        overlay?.removeFromMap()
        overlay = DrivingRouteOverlay(baiduMap).apply {
            setData(line)
            addToMap()
            zoomToSpan()
        }
    }

    private fun getClient(): LocationClient {
        if (locationClient == null) {
            locationClient = LocationClient(context).apply {
                locOption = LocationClientOption().apply {
                    isOpenGps = true
                    coorType = "bd09ll"
                    locationMode = LocationClientOption.LocationMode.Hight_Accuracy
                    isOnceLocation = true
                    setIsNeedAddress(true)
                    setNeedDeviceDirect(false)
                }
            }
        }
        return locationClient!!
    }

    override fun onResume() {
        map_view.onResume()
        super.onResume()
    }

    override fun onPause() {
        map_view.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        getClient().stop()
        baiduMap?.isMyLocationEnabled = false
        map_view?.onDestroy()
        super.onDestroy()
        routeSearch?.destroy()
    }
}