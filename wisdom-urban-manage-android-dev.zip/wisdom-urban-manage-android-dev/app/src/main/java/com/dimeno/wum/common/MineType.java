package com.dimeno.wum.common;

public class MineType {
    public static final int MANAGEMENT_SYSTEM = 10;
    public static final int MESSAGE = 20;
    public static final int NOTICE = 30;
    public static final int HELP = 40;
    public static final int ABOUT = 50;
    public static final int CHANGE_PSW = 60;
}
