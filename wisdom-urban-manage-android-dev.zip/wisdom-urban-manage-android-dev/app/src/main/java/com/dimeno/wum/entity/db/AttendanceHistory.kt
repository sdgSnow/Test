package com.dimeno.wum.entity.db

import io.objectbox.annotation.Entity
import io.objectbox.annotation.Id

/**
 * 考勤记录
 * Created by wangzhen on 2020/9/22.
 */
@Entity
class AttendanceHistory {
    @Id
    var id: Long = 0
    var userId: String? = null

    var requireGoWork: Long = 0
    var clockInGoWork: Long = 0
    var addressGoWork: String? = null

    var requireOffWork: Long = 0
    var clockInOffWork: Long = 0
    var addressOffWork: String? = null

    var dateString: String? = null
    var createTime: Long = 0
    var updateTime: Long = 0
}