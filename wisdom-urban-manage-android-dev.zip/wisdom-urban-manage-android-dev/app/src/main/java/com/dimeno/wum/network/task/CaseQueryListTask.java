package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;
import com.dimeno.network.task.PostJsonTask;

public class CaseQueryListTask extends PostFormTask {
    public <EntityType> CaseQueryListTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getCaseQueryList";
    }
}
