package com.dimeno.wum.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dimeno.wum.R

/**
 * guide one fragment
 * Created by wangzhen on 2020/9/25.
 */
class GuideOneFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_guide_one, container, false)
    }
}