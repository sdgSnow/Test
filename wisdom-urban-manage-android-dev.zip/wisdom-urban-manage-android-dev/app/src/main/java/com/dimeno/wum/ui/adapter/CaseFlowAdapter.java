package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseFlowHolder;
import com.dimeno.wum.ui.bean.CaseFlowBean;

import java.util.List;

/**
 * CaseFlowAdapter
 * Created by sdg on 2020/10/9.
 */
public class CaseFlowAdapter extends RecyclerAdapter<CaseFlowBean> {
    public CaseFlowAdapter(List<CaseFlowBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseFlowHolder(parent);
    }
}
