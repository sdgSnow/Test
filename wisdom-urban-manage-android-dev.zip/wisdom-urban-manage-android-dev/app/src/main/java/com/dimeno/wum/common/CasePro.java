package com.dimeno.wum.common;

public class CasePro {
    public static final int CASE_REMAIN_DEAL = 1;//待办案件
    public static final int CASE_COMPLETE = 2;//已办案件
}
