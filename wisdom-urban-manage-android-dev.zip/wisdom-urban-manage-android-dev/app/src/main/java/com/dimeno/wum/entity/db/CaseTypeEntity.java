package com.dimeno.wum.entity.db;

import java.io.Serializable;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;

/**
 * case type entity
 * Created by wangzhen on 2020/9/17.
 */
@Entity
public class CaseTypeEntity implements Serializable {
    @Id
    public long id;
    public int code;
    public String name;

}
