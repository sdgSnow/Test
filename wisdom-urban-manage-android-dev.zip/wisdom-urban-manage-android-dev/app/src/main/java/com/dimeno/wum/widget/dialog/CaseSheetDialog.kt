package com.dimeno.wum.widget.dialog

import android.os.Bundle
import android.text.Editable
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R
import com.dimeno.wum.entity.CommonSpinnerEntity
import com.dimeno.wum.ui.adapter.CaseSheetAdapter
import com.dimeno.wum.widget.abs.AbsTextWatcher
import kotlinx.android.synthetic.main.dialog_case_sheet_layout.*

/**
 * 案件菜单选择
 * Created by wangzhen on 2020/9/18.
 */
class CaseSheetDialog : BaseDialogFragment() {
    private var list: MutableList<CommonSpinnerEntity>? = null
    private var callback: Callback? = null
    private var showCustom: Boolean = false

    override fun layoutId(): Int = R.layout.dialog_case_sheet_layout

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler.apply {
            layoutManager = LinearLayoutManager(context)
            list?.let {
                adapter = CaseSheetAdapter(it).apply {
                    setOnClickCallback { _, position ->
                        callback?.onItemClick(datas[position])
                        dismiss()
                    }
                }
            }
        }

        container_other.visibility = if (showCustom) View.VISIBLE else View.GONE
        input_custom_case.addTextChangedListener(object : AbsTextWatcher() {
            override fun afterTextChanged(editable: Editable) {
                btn_custom_save.isEnabled = editable.isNotEmpty()
            }
        })
        btn_custom_save.setOnClickListener {
            callback?.onCustomCase(input_custom_case.text.toString().trim())
            dismiss()
        }
        btn_custom_save.isEnabled = false
    }

    private fun initView(view: View) {

    }

    fun showCustom(custom: Boolean): CaseSheetDialog {
        this.showCustom = custom
        return this
    }

    fun setData(list: MutableList<CommonSpinnerEntity>): CaseSheetDialog {
        this.list = list
        return this
    }

    fun callback(callback: Callback): CaseSheetDialog {
        this.callback = callback
        return this
    }

    override fun windowWidth(): Int = AppUtils.getScreenWidthPixels() * 5 / 6

    override fun onStart() {
        super.onStart()
        dialog?.run {
            setCancelable(true)
            setCanceledOnTouchOutside(true)
        }
    }

    interface Callback {
        fun onItemClick(data: CommonSpinnerEntity)
        fun onCustomCase(value: String)
    }
}