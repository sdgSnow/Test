package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class TaskDetailsEntity implements Serializable {


    /**
     * code : 200
     * data : {"reportNum":3,"address":"大连市中山区学士街与春生街交叉路口往西约50米(春德小区)","alreadyNum":0,"assignUserId":"1305473202950389761","description":"说明11","updateUser":"1","updateTime":"2020-09-18 19:12:15","coordinateList":[{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827970","latitude":"38.92416066460569","longitude":"121.66388511657713","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827971","latitude":"38.92108897519732","longitude":"121.6567611694336","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827972","latitude":"38.9140102281006","longitude":"121.65804862976074","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022273","latitude":"38.91234060936887","longitude":"121.66817665100098","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022274","latitude":"38.91835105298569","longitude":"121.67263984680176","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022275","latitude":"38.92342614228006","longitude":"121.67083740234375","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022276","latitude":"38.92416066460569","longitude":"121.66388511657713","updateTime":"2020-09-19 08:53:57","updateUser":"1"}],"caseType":1,"timeLimit":2,"smallClassName":"文物古迹","smallClass":"E5","createTime":"2020-09-18 18:45:26","caseTypeName":"部件","bigClassName":"其他部件","taskArea":"210202001002","taskName":"任务1","createUser":"1","id":"1306907175293050882","bigClass":"05","status":0}
     * message : 请求成功
     * success : true
     */

    public int code;
    public DataBean data;
    public String message;
    public boolean success;

    public static class DataBean implements Serializable {
        /**
         * reportNum : 3
         * address : 大连市中山区学士街与春生街交叉路口往西约50米(春德小区)
         * alreadyNum : 0
         * assignUserId : 1305473202950389761
         * description : 说明11
         * updateUser : 1
         * updateTime : 2020-09-18 19:12:15
         * coordinateList : [{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827970","latitude":"38.92416066460569","longitude":"121.66388511657713","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827971","latitude":"38.92108897519732","longitude":"121.6567611694336","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708287827972","latitude":"38.9140102281006","longitude":"121.65804862976074","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022273","latitude":"38.91234060936887","longitude":"121.66817665100098","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022274","latitude":"38.91835105298569","longitude":"121.67263984680176","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022275","latitude":"38.92342614228006","longitude":"121.67083740234375","updateTime":"2020-09-19 08:53:57","updateUser":"1"},{"areaCode":"210202001002","createTime":"2020-09-19 08:53:57","createUser":"1","id":"1307120708292022276","latitude":"38.92416066460569","longitude":"121.66388511657713","updateTime":"2020-09-19 08:53:57","updateUser":"1"}]
         * caseType : 1
         * timeLimit : 2
         * smallClassName : 文物古迹
         * smallClass : E5
         * createTime : 2020-09-18 18:45:26
         * caseTypeName : 部件
         * bigClassName : 其他部件
         * taskArea : 210202001002
         * taskName : 任务1
         * createUser : 1
         * id : 1306907175293050882
         * bigClass : 05
         * status : 0
         */

        public int reportNum;
        public String address;
        public int alreadyNum;
        public String assignUserId;
        public String description;
        public String updateUser;
        public String updateTime;
        public int caseType;
        public int timeLimit;
        public String smallClassName;
        public String smallClass;
        public String createTime;
        public String caseTypeName;
        public String bigClassName;
        public String taskArea;
        public String taskName;
        public String createUser;
        public String id;
        public String bigClass;
        public int status;
        public List<CoordinateEntity> coordinateList;
    }
}
