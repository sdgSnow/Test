package com.dimeno.wum.ui.fragment;

import android.Manifest;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;

import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.AbsPermissionCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.viewmodel.MapRouteViewModel;
import com.dimeno.wum.widget.dialog.ConfirmDialog;

/**
 * CaseInfoFragment
 * Created by sdg on 2020/9/16.
 * 待办任务
 */
public class TaskRemainDealFragment extends Fragment {
    private int mCurIndex;
    private Fragment mCurFragment;
    private View mBtnSwitch;

    public static TaskRemainDealFragment newInstance() {
        TaskRemainDealFragment fragment = new TaskRemainDealFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_task_remain_deal, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (savedInstanceState != null) {
            mCurIndex = savedInstanceState.getInt("index");
        }
        mBtnSwitch = view.findViewById(R.id.btn_switch);
        mBtnSwitch.setOnClickListener((v) -> {
            if (mCurIndex > 0) {
                --mCurIndex;
                mBtnSwitch.setSelected(false);
                initFragment(mCurIndex);
            } else {
                PermissionManager.request(getContext(), new AbsPermissionCallback() {
                    @Override
                    public void onGrant(String[] permissions) {
                        ++mCurIndex;
                        mBtnSwitch.setSelected(true);
                        initFragment(mCurIndex);
                        if (getContext() instanceof ViewModelStoreOwner) {
                            new ViewModelProvider((ViewModelStoreOwner) getContext()).get(MapRouteViewModel.class).sync();
                        }
                    }

                    @Override
                    public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                        if (getActivity() != null) {
                            new ConfirmDialog().setTitle("权限提示").setMessage("请授予定位权限").setRightText("授予权限").setCallback(new ConfirmDialog.Callback() {
                                @Override
                                public void onCancel() {

                                }

                                @Override
                                public void onConfirm() {
                                    startActivity(PermissionManager.getSettingIntent(getActivity()));
                                }
                            }).show(getActivity().getSupportFragmentManager());
                        }
                    }
                }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
            }
        });
        initFragment(0);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt("index", mCurIndex);
        super.onSaveInstanceState(outState);
    }

    private void initFragment(int index) {
        mCurIndex = index;
        String tag = String.valueOf(index);
        FragmentManager manager = getChildFragmentManager();
        Fragment fragment = manager.findFragmentByTag(tag);
        FragmentTransaction transaction = manager.beginTransaction();
        if (fragment == null) {
            fragment = newTab(index);
            transaction.add(R.id.container, fragment);
        } else {
            transaction.show(fragment);
        }
        if (mCurFragment != null && mCurFragment != fragment) {
            transaction.hide(mCurFragment);
        }
        transaction.commitAllowingStateLoss();
        mCurFragment = fragment;
    }

    private Fragment newTab(int index) {
        Fragment fragment;
        if (index == 0) {
            fragment = new TaskRemainListFragment();
        } else {
            fragment = new TaskMapRouteFragment();
        }
        return fragment;
    }
}