package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseCheckProcedureViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseDetailsViewHolder;
import com.dimeno.wum.ui.bean.CaseCheckProcedureBean;
import com.dimeno.wum.ui.bean.CaseDetailsBean;

import java.util.List;

public class CaseCheckProcedureAdapter extends RecyclerAdapter<CaseCheckProcedureBean> {
    public CaseCheckProcedureAdapter(List<CaseCheckProcedureBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseCheckProcedureViewHolder(parent);
    }
}
