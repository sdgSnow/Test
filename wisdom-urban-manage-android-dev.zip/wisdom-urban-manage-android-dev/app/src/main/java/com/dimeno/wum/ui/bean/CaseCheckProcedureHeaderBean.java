package com.dimeno.wum.ui.bean;

public class CaseCheckProcedureHeaderBean {

    public String imageUrl;
}
