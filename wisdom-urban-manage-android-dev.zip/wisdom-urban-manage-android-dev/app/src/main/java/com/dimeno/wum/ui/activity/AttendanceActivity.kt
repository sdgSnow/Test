package com.dimeno.wum.ui.activity

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.ui.fragment.AttendanceClockInFragment
import com.dimeno.wum.ui.fragment.AttendanceStatisticsFragment
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import kotlinx.android.synthetic.main.activity_attendance.*

/**
 * 考勤打卡
 * Created by wangzhen on 2020/9/19.
 */
class AttendanceActivity : BaseActivity(), View.OnClickListener {
    private var mCurFragment: Fragment? = null
    private var mCurIndex: Int = 0
    private var mToolbar: AppCommonToolbar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.let {
            mCurIndex = it.getInt("index", 0)
        }
        setContentView(R.layout.activity_attendance)
        fitDarkStatusBar(true)
        initViews()
        selectTab(mCurIndex)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("index", mCurIndex)
        super.onSaveInstanceState(outState)
    }

    private fun initViews() {
        btn_clock_in.setOnClickListener(this)
        btn_statistics.setOnClickListener(this)
    }

    override fun createToolbar(): Toolbar? {
        mToolbar = AppCommonToolbar(this, "打卡")
        return mToolbar
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_clock_in -> selectTab(0)
            R.id.btn_statistics -> selectTab(1)
        }
    }

    private fun selectTab(index: Int) {
        mCurIndex = index
        btn_clock_in.isSelected = index == 0
        btn_statistics.isSelected = index == 1
        mToolbar?.setTitle(if (index == 0) getString(R.string.attendance_clock_in) else getString(R.string.attendance_statistics))

        val tag = index.toString()
        val manager = supportFragmentManager
        var fragment = manager.findFragmentByTag(tag)
        val transaction = manager.beginTransaction()
        if (fragment == null) {
            fragment = when (index) {
                0 -> AttendanceClockInFragment()
                else -> AttendanceStatisticsFragment()
            }
            transaction.add(R.id.container, fragment, tag)
        } else {
            transaction.show(fragment)
        }
        if (mCurFragment != null && mCurFragment !== fragment) {
            transaction.hide(mCurFragment!!)
        }
        transaction.commitAllowingStateLoss()
        mCurFragment = fragment
    }
}