package com.dimeno.wum.ui.adapter.holder;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.adapter.UnVerifyPictureAdapter;
import com.dimeno.wum.ui.bean.UnVerifyPictureBean;
import com.dimeno.wum.widget.dialog.ConfirmDialog;

public class UnVerifyPictureHolder extends RecyclerViewHolder<UnVerifyPictureBean> {

    private final ImageView iv;
    private final ImageView btn_delete;

    public UnVerifyPictureHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_un_verify_picture);
        iv = findViewById(R.id.iv);
        btn_delete = findViewById(R.id.btn_delete);
    }

    @Override
    public void bind() {
        Glide.with(itemView.getContext()).load(mData.fileLocalUrl).into(iv);
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getContext() instanceof FragmentActivity) {
                    new ConfirmDialog().setTitle("删除").setMessage("确定删除当前图片？").setCallback(new ConfirmDialog.Callback() {
                        @Override
                        public void onCancel() {

                        }

                        @Override
                        public void onConfirm() {
                            RecyclerView recyclerView = (RecyclerView) itemView.getParent();
                            UnVerifyPictureAdapter adapter = (UnVerifyPictureAdapter) recyclerView.getAdapter();
                            if (adapter != null) {
                                adapter.getDatas().remove(mData);
                                adapter.notifyItemRemoved(getAdapterPosition());
                            }
                        }
                    }).show(((FragmentActivity) view.getContext()).getSupportFragmentManager());
                }
            }
        });
    }
}
