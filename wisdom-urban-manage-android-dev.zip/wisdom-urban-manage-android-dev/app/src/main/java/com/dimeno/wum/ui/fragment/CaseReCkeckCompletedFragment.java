package com.dimeno.wum.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.AssignType;
import com.dimeno.wum.common.CasePro;
import com.dimeno.wum.common.Load;
import com.dimeno.wum.entity.CaseCompletedEntity;
import com.dimeno.wum.entity.CaseReCheckEntity;
import com.dimeno.wum.entity.CommonSpinnerEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity;
import com.dimeno.wum.entity.db.CaseBigClassEntity_;
import com.dimeno.wum.entity.db.CaseSmallClassEntity;
import com.dimeno.wum.entity.db.CaseSmallClassEntity_;
import com.dimeno.wum.entity.db.CaseTypeEntity;
import com.dimeno.wum.network.task.CaseQueryListTask;
import com.dimeno.wum.network.task.CaseReCheckListTask;
import com.dimeno.wum.ui.activity.CaseReCheckDetailsActivity;
import com.dimeno.wum.ui.adapter.CaseCompletedAdapter;
import com.dimeno.wum.ui.adapter.CaseReCheckCompletedAdapter;
import com.dimeno.wum.ui.adapter.CommonSpinnerAdapter;
import com.dimeno.wum.ui.bean.CaseCompletedBean;
import com.dimeno.wum.ui.bean.CaseReCheckCompletedBean;
import com.dimeno.wum.utils.DBLoader;
import com.dimeno.wum.widget.abs.AbsItemSelectedListener;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import java.util.ArrayList;
import java.util.List;

/**
 * CaseInfoFragment
 * Created by sdg on 2020/9/16.
 * 复核的已办案件
 */
public class CaseReCkeckCompletedFragment extends Fragment implements OnRefreshCallback {

    private Spinner spinner_type;
    private Spinner spinner_big_class;
    private Spinner spinner_small_class;
    private String mCaseTypeCode = null;
    private String mBigClassCode = null;
    private String mSmallClassCode = null;
    private List<CommonSpinnerEntity> typeList;
    private List<CommonSpinnerEntity> bigClassList;
    private List<CommonSpinnerEntity> smallClassList;
    private RecyclerView rv_case_recheck_completed;
    private List<CaseReCheckCompletedBean> caseReCheckCompletedBeans;
    private CaseReCheckCompletedAdapter caseReCheckCompletedAdapter;
    private EditText et_search;
    private RefreshLayout refresh_layout;

    public static CaseReCkeckCompletedFragment newInstance() {
        CaseReCkeckCompletedFragment fragment = new CaseReCkeckCompletedFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_case_recheck_completed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv_case_recheck_completed = view.findViewById(R.id.rv_case_recheck_completed);
        spinner_type = view.findViewById(R.id.spinner_type);
        spinner_big_class = view.findViewById(R.id.spinner_big_class);
        spinner_small_class = view.findViewById(R.id.spinner_small_class);
        et_search = view.findViewById(R.id.et_search);
        refresh_layout = view.findViewById(R.id.refresh_layout);
        refresh_layout.setOnRefreshCallback(this);
        refresh_layout.startRefresh();

        initSpinner1();
        initSpinner2();
        initSpinner3();
        initSelectListener();

        getCaseCheckList();

        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                getCaseCheckList();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        getCaseCheckList();
    }

    private void initSpinner1() {
        //初始化案件类型数据
        typeList = createTypeList();
        List<CaseTypeEntity> allTypes = DBLoader.load(CaseTypeEntity.class).getAll();
        if (allTypes != null) {
            for (CaseTypeEntity allType : allTypes) {
                CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                caseSpinnerEntity.setCode(String.valueOf(allType.code));
                caseSpinnerEntity.setName(allType.name);
                typeList.add(caseSpinnerEntity);
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter1 = new CommonSpinnerAdapter(getActivity(), typeList);
        spinner_type.setAdapter(caseSpinnerAdapter1);
    }

    private void initSpinner2() {
        //初始化大类数据
        bigClassList = createBigClassList();
        if (mCaseTypeCode != null) {
            List<CaseBigClassEntity> caseBigClassEntities = DBLoader.load(CaseBigClassEntity.class).query().equal(CaseBigClassEntity_.topcode, mCaseTypeCode).build().find();
            if (caseBigClassEntities != null) {
                for (CaseBigClassEntity caseBigClassEntity : caseBigClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseBigClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseBigClassEntity.getName());
                    bigClassList.add(caseSpinnerEntity);
                }

            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter2 = new CommonSpinnerAdapter(getActivity(), bigClassList);
        spinner_big_class.setAdapter(caseSpinnerAdapter2);
    }

    private void initSpinner3() {
        //初始化小类数据
        smallClassList = createSmallClassList();
        if (mCaseTypeCode != null && mBigClassCode != null) {
            List<CaseSmallClassEntity> caseSmallClassEntities = DBLoader.load(CaseSmallClassEntity.class).query().equal(CaseSmallClassEntity_.topcode, mCaseTypeCode).equal(CaseSmallClassEntity_.pcode, mBigClassCode).build().find();
            if (caseSmallClassEntities != null) {
                for (CaseSmallClassEntity caseSmallClassEntity : caseSmallClassEntities) {
                    CommonSpinnerEntity caseSpinnerEntity = new CommonSpinnerEntity();
                    caseSpinnerEntity.setCode(String.valueOf(caseSmallClassEntity.getCode()));
                    caseSpinnerEntity.setName(caseSmallClassEntity.getName());
                    smallClassList.add(caseSpinnerEntity);
                }
            }
        }
        CommonSpinnerAdapter caseSpinnerAdapter3 = new CommonSpinnerAdapter(getActivity(), smallClassList);
        spinner_small_class.setAdapter(caseSpinnerAdapter3);
    }

    private void initSelectListener() {
        //spineer的点击事件
        spinner_type.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mCaseTypeCode = typeList.get(i).getCode();
                mBigClassCode = null;
                mSmallClassCode = null;
                initSpinner2();
                initSpinner3();
                if(i == 0){
                    getCaseCheckList();
                }
                if(mCaseTypeCode != null) {
                    getCaseCheckList();
                }
            }
        });

        spinner_big_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mBigClassCode = bigClassList.get(i).getCode();
                mSmallClassCode = null;
                initSpinner3();
                if(i == 0){
                    getCaseCheckList();
                }
                if(mBigClassCode != null) {
                    getCaseCheckList();
                }
            }
        });

        spinner_small_class.setOnItemSelectedListener(new AbsItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                mSmallClassCode = smallClassList.get(i).getCode();
                if(i == 0){
                    getCaseCheckList();
                }
                if(mSmallClassCode != null) {
                    getCaseCheckList();
                }
            }
        });
    }

    private List<CommonSpinnerEntity> createTypeList() {
        List<CommonSpinnerEntity> caseTypeList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity1 = new CommonSpinnerEntity();
        caseSpinnerEntity1.setName("案件类型");
        caseTypeList.add(caseSpinnerEntity1);
        return caseTypeList;
    }

    private List<CommonSpinnerEntity> createBigClassList() {
        List<CommonSpinnerEntity> bigClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity2 = new CommonSpinnerEntity();
        caseSpinnerEntity2.setName("案件大类");
        bigClassList.add(caseSpinnerEntity2);
        return bigClassList;
    }

    private List<CommonSpinnerEntity> createSmallClassList() {
        List<CommonSpinnerEntity> smallClassList = new ArrayList<>();
        CommonSpinnerEntity caseSpinnerEntity3 = new CommonSpinnerEntity();
        caseSpinnerEntity3.setName("案件小类");
        smallClassList.add(caseSpinnerEntity3);
        return smallClassList;
    }

    private void getCaseCheckList() {
        new CaseReCheckListTask(new LoadingCallback<CaseReCheckEntity>() {
            @Override
            public void onSuccess(CaseReCheckEntity data) {
                initCaseReCheckCompleted(data);
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
            }

            @Override
            public void onComplete() {
                refresh_layout.refreshComplete();
            }
        }).setTag(this)
                .put("caseType", mCaseTypeCode)
                .put("bigClass", mBigClassCode)
                .put("smallClass", mSmallClassCode)
                .put("pageIndex", 1)
                .put("pageSize", Load.PAGE_SUM)
                .put("keyword", et_search.getText().toString().trim())
                .put("status", CasePro.CASE_COMPLETE)
//                .put("taskArea", pwd)
                .put("userId", UserBiz.get().getUserId())
                .exe();
    }

    private void initCaseReCheckCompleted(CaseReCheckEntity caseReCheckEntity) {
        caseReCheckCompletedBeans = new ArrayList<>();
        if(caseReCheckEntity.data != null){
            for (CaseReCheckEntity.DataBean datum : caseReCheckEntity.data) {
                CaseReCheckCompletedBean caseReCheckCompletedBean = new CaseReCheckCompletedBean();
                caseReCheckCompletedBean.address = datum.address;
                caseReCheckCompletedBean.latitude = datum.latitude;
                caseReCheckCompletedBean.assignType = datum.assignType;
                caseReCheckCompletedBean.description = datum.description;
                caseReCheckCompletedBean.updateUser = datum.updateUser;
                caseReCheckCompletedBean.updateTime = datum.updateTime;
                caseReCheckCompletedBean.caseCoding = datum.caseCoding;
                caseReCheckCompletedBean.source = datum.source;
                caseReCheckCompletedBean.caseNo = datum.caseNo;
                caseReCheckCompletedBean.caseType = datum.caseType;
                caseReCheckCompletedBean.assignTypeName = datum.assignTypeName;
                caseReCheckCompletedBean.smallClassName = datum.smallClassName;
                caseReCheckCompletedBean.smallClass = datum.smallClass;
                caseReCheckCompletedBean.caseTypeName = datum.caseTypeName;
                caseReCheckCompletedBean.bigClassName = datum.bigClassName;
                caseReCheckCompletedBean.createTime = datum.createTime;
                caseReCheckCompletedBean.statusName = datum.statusName;
                caseReCheckCompletedBean.createUser = datum.createUser;
                caseReCheckCompletedBean.id = datum.id;
                caseReCheckCompletedBean.taskId = datum.taskId;
                caseReCheckCompletedBean.bigClass = datum.bigClass;
                caseReCheckCompletedBean.longitude = datum.longitude;
                caseReCheckCompletedBean.status = datum.status;
                caseReCheckCompletedBeans.add(caseReCheckCompletedBean);
            }
        }
        showCaseRemainDealList();
    }

    private void showCaseRemainDealList() {
        rv_case_recheck_completed.setLayoutManager(new GridLayoutManager(getActivity(),1,GridLayoutManager.VERTICAL,false));
        caseReCheckCompletedAdapter = new CaseReCheckCompletedAdapter(caseReCheckCompletedBeans,rv_case_recheck_completed);
        caseReCheckCompletedAdapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.global_empty_layout;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rv_case_recheck_completed));
        rv_case_recheck_completed.setAdapter(caseReCheckCompletedAdapter);
//        caseReCheckCompletedAdapter.setOnClickCallback(new OnItemClickCallback() {
//            @Override
//            public void onItemClick(View itemView, int position) {
//                Intent intent = new Intent(getActivity(), CaseReCheckDetailsActivity.class);
//                intent.putExtra("id",caseReCheckCompletedBeans.get(position).id);
//                startActivity(intent);
//            }
//        });
    }

    @Override
    public void onRefresh() {
        getCaseCheckList();
    }
}