package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class CaseFlowEntity implements Serializable {


    /**
     * code : 200
     * data : [{"caseReportId":"1311195656170106881","operationDescription":"公众端测试","manager":"　　　　　　　　","totalTime":"","linkTime":"","remark":"公众端测试","linkName":"案件办理","timeOut":0,"timeLimit":"","startTime":"2020-09-30 14:46:20","operationType":0,"endTime":"2020-09-30 14:46:20","id":"1311195656195272705"},{"caseReportId":"1311195656170106881","operationDescription":"","manager":"超级管理员","totalTime":"13分38秒","linkTime":"13分38秒","remark":"","linkName":"案件受理","timeOut":0,"timeLimit":"15分","startTime":"2020-09-30 14:46:20","operationType":10,"endTime":"2020-09-30 14:59:58","id":"1311199089069518849"},{"caseReportId":"1311195656170106881","operationDescription":"请核查","manager":"超级管理员","totalTime":"13分57秒","linkTime":"19秒","remark":"请核查","linkName":"核实指派","timeOut":0,"timeLimit":"20分","startTime":"2020-09-30 14:59:58","operationType":20,"endTime":"2020-09-30 15:00:17","id":"1311199166303432706"},{"caseReportId":"1311195656170106881","operationDescription":"不属实","manager":"岚","totalTime":"17分17秒","linkTime":"3分20秒","remark":"不属实","linkName":"案件核实","timeOut":0,"timeLimit":"1时","startTime":"2020-09-30 15:00:17","operationType":30,"endTime":"2020-09-30 15:03:37","id":"1311200009949933569"},{"caseReportId":"1311195656170106881","operationDescription":"不属实","manager":"岚","totalTime":"17分35秒","linkTime":"18秒","remark":"不属实","linkName":"案件核实","timeOut":0,"timeLimit":"1时","startTime":"2020-09-30 15:03:37","operationType":30,"endTime":"2020-09-30 15:03:55","id":"1311200085082501122"},{"caseReportId":"1311195656170106881","operationDescription":"通过","manager":"超级管理员","totalTime":"18分12秒","linkTime":"37秒","remark":"通过","linkName":"案件立案","timeOut":0,"timeLimit":"10分","startTime":"2020-09-30 15:03:55","operationType":40,"endTime":"2020-09-30 15:04:32","id":"1311200237943910402"},{"caseReportId":"1311195656170106881","operationDescription":" 123","manager":"超级管理员","totalTime":"18分29秒","linkTime":"17秒","remark":" 123","linkName":"整改派遣","timeOut":0,"timeLimit":"30分","startTime":"2020-09-30 15:04:32","operationType":50,"endTime":"2020-09-30 15:04:49","id":"1311200308706013186"},{"caseReportId":"1311195656170106881","operationDescription":"退回按键测试","manager":"超级管理员","totalTime":"8天19时4分19秒","linkTime":"8天18时45分50秒","remark":"退回按键测试","linkName":"案件退件","timeOut":1,"timeLimit":"20分","startTime":"2020-09-30 15:04:49","operationType":70,"endTime":"2020-10-09 09:50:39","id":"1314382738266865666"},{"caseReportId":"1311195656170106881","operationDescription":"  123","manager":"超级管理员","totalTime":"8天19时28分35秒","linkTime":"24分16秒","remark":"  123","linkName":"整改派遣","timeOut":0,"timeLimit":"30分","startTime":"2020-10-09 09:50:39","operationType":50,"endTime":"2020-10-09 10:14:55","id":"1314388843663540225"}]
     * message : 请求成功
     * success : true
     */

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;

    public static class DataBean implements Serializable{
        /**
         * caseReportId : 1311195656170106881
         * operationDescription : 公众端测试
         * manager : 　　　　　　　　
         * totalTime :
         * linkTime :
         * remark : 公众端测试
         * linkName : 案件办理
         * timeOut : 0
         * timeLimit :
         * startTime : 2020-09-30 14:46:20
         * operationType : 0
         * endTime : 2020-09-30 14:46:20
         * id : 1311195656195272705
         */

        public String caseReportId;
        public String operationDescription;
        public String manager;
        public String totalTime;
        public String linkTime;
        public String remark;
        public String linkName;
        public int timeOut;
        public String timeLimit;
        public String startTime;
        public int operationType;
        public String endTime;
        public String id;

    }
}
