package com.dimeno.wum.network.interceptor;

import com.dimeno.commons.utils.L;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class InterceptorManage {

    public static InterceptorManage interceptorManage;

    public static InterceptorManage getInstance() {
        if (interceptorManage == null) {
            return new InterceptorManage();
        }
        return interceptorManage;
    }

    public final Interceptor mLoggingInterceptor = new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            L.e(String.format("发送请求: %s%n%s", request.url(), chain.connection(), request.headers()));
            Response response = chain.proceed(request);
            //这里不能直接使用response.body().string()的方式输出日志
            //因为response.body().string()之后，response中的流会被关闭，程序会报错，我们需要创建出一个新的response给应用层处理
            ResponseBody responseBody = response.peekBody(1024 * 1024);
            return response;
        }
    };
}
