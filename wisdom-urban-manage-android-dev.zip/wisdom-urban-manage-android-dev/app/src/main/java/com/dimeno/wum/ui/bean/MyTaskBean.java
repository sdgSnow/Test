package com.dimeno.wum.ui.bean;

public class MyTaskBean {

    public int reportNum;
    public String address;
    public int alreadyNum;
    public String assignUserId;
    public String description;
    public String updateUser;
    public String updateTime;
    public int caseType;
    public int timeLimit;
    public String smallClassName;
    public String smallClass;
    public String caseTypeName;
    public String bigClassName;
    public String createTime;
    public String taskArea;
    public String taskName;
    public String createUser;
    public String id;
    public String bigClass;
    public int status;
    public double latitude;
    public double longitude;
}
