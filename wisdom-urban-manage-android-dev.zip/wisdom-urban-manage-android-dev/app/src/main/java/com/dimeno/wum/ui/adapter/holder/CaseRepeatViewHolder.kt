package com.dimeno.wum.ui.adapter.holder

import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.adapter.callback.OnHolderClickCallback
import com.dimeno.wum.R
import com.dimeno.wum.entity.CaseRepeatEntity
import com.dimeno.wum.ui.activity.CaseDetailsActivity

/**
 * case repeat view holder
 * Created by wangzhen on 2020/10/26.
 */
class CaseRepeatViewHolder(parent: ViewGroup) : RecyclerViewHolder<CaseRepeatEntity>(parent, R.layout.case_repeat_confirm_item_layout), OnHolderClickCallback {
    override fun bind() {
        findViewById<TextView>(R.id.tv_case_serial).text = adapterPosition.toString()
        findViewById<TextView>(R.id.tv_case_number).text = mData.caseCoding
        findViewById<TextView>(R.id.tv_case_time).text = mData.createTime
    }

    override fun onItemClick(itemView: View, position: Int) {
        itemView.context.apply {
            startActivity(Intent(this, CaseDetailsActivity::class.java).apply {
                putExtra("id", mData.id)
            })
        }
    }
}