package com.dimeno.wum.ui.activity;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.ui.fragment.CaseReCkeckCompletedFragment;
import com.dimeno.wum.ui.fragment.CaseReCkeckRemainDealFragment;
import com.dimeno.wum.widget.CustomViewPager;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

/**
 * CaseReCheckActivity
 * Created by sdg on 2020/9/17.
 * 案件复核
 */
public class CaseReCheckActivity extends BaseActivity implements View.OnClickListener {

    private CustomViewPager viewPager;
    private TextView tv_case_remain_deal;
    private TextView tv_completed;
    private View indicator_remain_deal;
    private View indicator_completed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_re_check);

        fitDarkStatusBar(true);
        initView();
        initViewPager();
    }
    private void initView() {
        tv_case_remain_deal = findViewById(R.id.tv_case_remain_deal);
        tv_completed = findViewById(R.id.tv_completed);
        indicator_remain_deal = findViewById(R.id.indicator_remain_deal);
        indicator_completed = findViewById(R.id.indicator_completed);
        viewPager = findViewById(R.id.viewPager);
        tv_case_remain_deal.setOnClickListener(this::onClick);
        tv_completed.setOnClickListener(this::onClick);
    }
    @Nullable
    @Override
    public Toolbar createToolbar() {
        AppCommonToolbar commonToolbar = new AppCommonToolbar(this, "案件复核");
        return commonToolbar;
    }
    private void initViewPager() {
        viewPager.setScanScroll(false);
        viewPager.setOffscreenPageLimit(1);
        viewPager.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_case_remain_deal:
                viewPager.setCurrentItem(0);
                indicator_remain_deal.setVisibility(View.VISIBLE);
                indicator_completed.setVisibility(View.GONE);
                break;
            case R.id.tv_completed:
                viewPager.setCurrentItem(1);
                indicator_remain_deal.setVisibility(View.GONE);
                indicator_completed.setVisibility(View.VISIBLE);
                break;
        }
    }
    public class MyPagerAdapter extends FragmentPagerAdapter {

        private final String[] fragments = {"CaseRemainDealFragment", "CaseCompletedFragment"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getCount() {
            return fragments.length;
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return CaseReCkeckRemainDealFragment.newInstance();
                case 1:
                    return CaseReCkeckCompletedFragment.newInstance();
                default:
                    return null;
            }
        }
    }

}