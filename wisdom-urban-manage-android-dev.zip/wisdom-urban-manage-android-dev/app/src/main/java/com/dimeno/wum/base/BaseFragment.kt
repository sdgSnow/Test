package com.dimeno.wum.base

import androidx.fragment.app.Fragment

/**
 * base fragment
 * Created by wangzhen on 2020/9/17.
 */
open class BaseFragment : Fragment() {
}