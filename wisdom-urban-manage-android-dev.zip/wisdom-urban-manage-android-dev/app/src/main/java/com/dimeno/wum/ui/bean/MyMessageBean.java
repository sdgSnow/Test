package com.dimeno.wum.ui.bean;

public class MyMessageBean {

    public String msg;
    public String caseReportId;
    public int caseMsgType;
    public int msgType;
    public String createTime;
    public String updateUser;
    public String createUser;
    public String updateTime;
    public String id;
    public String title;
    public String userId;
    public String url;
}
