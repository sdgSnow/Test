package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.ui.bean.SpinnerQueryCaseTypeBean;

public class CaseQueryHolder extends RecyclerViewHolder<CaseQueryBean> {

    private final TextView tv_case_type_name;
    private final TextView tv_case_big_class_name;
    private final TextView tv_case_small_class_name;
    private final TextView tv_case_coding_name;
    private final TextView tv_case_address;
    private final TextView tv_create_time;
    private final TextView tv_assign_type_name;
    private final TextView tv_status_name;

    public CaseQueryHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_case_query);
        tv_case_type_name = findViewById(R.id.tv_case_type_name);
        tv_case_big_class_name = findViewById(R.id.tv_case_big_class_name);
        tv_case_small_class_name = findViewById(R.id.tv_case_small_class_name);
        tv_case_coding_name = findViewById(R.id.tv_case_coding_name);
        tv_case_address = findViewById(R.id.tv_case_address);
        tv_create_time = findViewById(R.id.tv_create_time);
        tv_assign_type_name = findViewById(R.id.tv_assign_type_name);
        tv_status_name = findViewById(R.id.tv_status_name);
    }

    @Override
    public void bind() {
        tv_case_type_name.setText(mData.caseTypeName);
        tv_case_big_class_name.setText(mData.bigClassName);
        tv_case_small_class_name.setText(mData.smallClassName);
        tv_case_coding_name.setText(mData.caseCoding);
        tv_case_address.setText(mData.address);
        tv_create_time.setText(mData.createTime);
        tv_assign_type_name.setText(mData.assignTypeName);
        tv_status_name.setText(mData.statusName);
    }
}
