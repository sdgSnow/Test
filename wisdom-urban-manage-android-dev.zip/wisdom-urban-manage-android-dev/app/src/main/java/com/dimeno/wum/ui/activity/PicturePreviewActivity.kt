package com.dimeno.wum.ui.activity

import android.os.Bundle
import android.view.View
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.common.IKey
import com.dimeno.wum.ui.adapter.PicturePreviewAdapter
import com.dimeno.wum.widget.abs.AbsPageChangeListener
import kotlinx.android.synthetic.main.activity_picture_preview.*

/**
 * picture preview activity
 * Created by wangzhen on 2020/9/25.
 */
class PicturePreviewActivity : BaseActivity() {
    private var list: MutableList<String>? = null
    private var position: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_picture_preview)
        list = intent.getStringArrayListExtra(IKey.DATA)
        position = intent.getIntExtra(IKey.POSITION, 0)
        list?.let {
            tv_indicator.visibility = if (it.size > 1) View.VISIBLE else View.GONE
            tv_indicator.text = String.format("1 / %d", it.size)

            view_pager.addOnPageChangeListener(object : AbsPageChangeListener() {
                override fun onPageSelected(position: Int) {
                    tv_indicator.text = String.format("%d / %d", position + 1, it.size)
                }
            })
            view_pager.adapter = PicturePreviewAdapter(it, supportFragmentManager)
            view_pager.currentItem = position
        } ?: let {
            tv_indicator.visibility = View.GONE
        }
    }
}