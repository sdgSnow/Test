package com.dimeno.wum.common

/**
 * Code
 * Created by wangzhen on 2020/9/16.
 */
class Code {
    companion object {
        const val CODE_BROWSE_FILE = 0
        const val CODE_SETTING = 1
        const val CODE_IMAGE_CAPTURE = 2
        const val CODE_REPORT_SUCCESS = 3
        const val CODE_REPORT = 4
        const val CODE_UNPASS_REPORT = 7
        const val CODE_CHANGE_LOCATION = 5
        const val CODE_CHANGE_LOCATION_SUCCESS = 6
        const val CODE_REPEAT = 7
    }
}