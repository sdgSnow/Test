package com.dimeno.wum.widget.abs

import android.text.TextWatcher

/**
 * abs text watcher
 * Created by wangzhen on 2020/9/25.
 */
abstract class AbsTextWatcher : TextWatcher {
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

    }
}