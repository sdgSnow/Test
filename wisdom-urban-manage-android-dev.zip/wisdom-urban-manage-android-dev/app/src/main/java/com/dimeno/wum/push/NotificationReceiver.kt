package com.dimeno.wum.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dimeno.wum.MainActivity
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.push.entity.MsgCaseType
import com.dimeno.wum.push.entity.MsgType
import com.dimeno.wum.push.entity.NotificationEntity
import com.dimeno.wum.ui.activity.*
import com.dimeno.wum.utils.ActivityManager

/**
 * notification receiver
 * Created by wangzhen on 2020/9/24.
 */
class NotificationReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION: String = "com.dimeno.wum.push.open"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val data = intent.getSerializableExtra("push_data")
        if (data is NotificationEntity) {
            if (!UserBiz.get().isLogin) {
                ActivityManager.closeAllActivities()
                context.startActivity(Intent(context, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                return
            }
            if (ActivityManager.count() == 0) {
                context.startActivity(Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
            }
            if (data.msgType == MsgType.CASE) {
                handleCase(context, data)
            }
        }
    }

    private fun handleCase(context: Context, data: NotificationEntity) {
        var intent: Intent? = null
        when (data.caseMsgType) {
            MsgCaseType.VERIFY -> {
                intent = Intent(context,CaseCheckDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
            MsgCaseType.CHECK -> {
                intent = Intent(context,CaseReCheckDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
            MsgCaseType.INSPECTION -> {
                intent = Intent(context,CaseDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
            MsgCaseType.REGISTER -> {
                intent = Intent(context,CaseDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
            MsgCaseType.CLOSED -> {
                intent = Intent(context,CaseDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
            MsgCaseType.VOID -> {
                intent = Intent(context,CaseDetailsActivity::class.java)
                intent.putExtra("id",data.id)
            }
        }
        intent?.let {
            context.startActivity(it.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }
    }
}