package com.dimeno.wum.ui.bean;

public class CaseExamineInfoHeaderBean {

    public String imageUrl;
}
