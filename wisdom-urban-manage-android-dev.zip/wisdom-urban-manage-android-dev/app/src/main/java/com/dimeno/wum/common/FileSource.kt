package com.dimeno.wum.common

/**
 * FileSource
 * Created by wangzhen on 2020/9/17.
 */
class FileSource {
    companion object {
        const val REPORT = 1 //上报
        const val VERIFY = 2 //案件核实
        const val CHECK = 3 //案件核查
        const val INSPECTION = 4 //案件巡查
    }
}