package com.dimeno.wum.network.task;

import com.dimeno.network.callback.RequestCallback;
import com.dimeno.network.task.PostFormTask;

/**
 * LoginTask
 * Created by sdg on 2020/9/15.
 */
public class TaskDetailsTask extends PostFormTask {
    public <EntityType> TaskDetailsTask(RequestCallback<EntityType> callback) {
        super(callback);
    }

    @Override
    public String getApi() {
        return "/wisdomurbanmanagecore/api/getTaskDetail";
    }
}
