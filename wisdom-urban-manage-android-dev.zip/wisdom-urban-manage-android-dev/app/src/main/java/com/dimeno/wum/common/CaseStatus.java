package com.dimeno.wum.common;

public class CaseStatus {

    public static final int REGISTRATION = 0;//办理登记/未办结
    public static final int ACCEPTANCE_REGISTRATION = 10;//受理登记
    public static final int CHECK = 20;//核实中
    public static final int CHECK_COMPLETE = 30;//已核实
    public static final int FILING_CASE = 40;//已立案
    public static final int RECTIFICATION = 50;//整改中
    public static final int RECTIFICATION_COMPLETE = 60;//整改完成
    public static final int RETURN_REQUEST = 70;//推荐申请
    public static final int BACK_OFF = 80;//回退
    public static final int RECHECKING = 90;//复核中
    public static final int RECHECKED = 100;//已复核
    public static final int CLOSED = 110;//已结案
    public static final int VOIDED = 120;//已作废
}
