package com.dimeno.wum.entity

import java.io.Serializable

/**
 * CaseCheckRepeatEntity
 * Created by wangzhen on 2020/10/12.
 */
class CaseCheckRepeatEntity : Serializable {
    var code = 0
    var message: String? = null
    var success = false
    var data: DataEntity? = null

    class DataEntity : Serializable {
        var isRepeat = false
        var caseList: ArrayList<CaseRepeatEntity>? = null
    }
}