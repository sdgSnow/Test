package com.dimeno.wum.common;

/**
 * Load
 * Created by sdg on 2020/9/24.
 * 每页加载的数量
 */
public class Load {

    public static final int PAGE_SUM = 10;
}
