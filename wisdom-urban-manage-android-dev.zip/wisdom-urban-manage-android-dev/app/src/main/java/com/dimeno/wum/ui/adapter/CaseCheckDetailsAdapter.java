package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.CaseCheckDetailsViewHolder;
import com.dimeno.wum.ui.adapter.holder.CaseCheckInfoViewHolder;
import com.dimeno.wum.ui.bean.CaseCheckDetailsBean;
import com.dimeno.wum.ui.bean.CaseCheckInfoBean;

import java.util.List;

public class CaseCheckDetailsAdapter extends RecyclerAdapter<CaseCheckDetailsBean> {
    public CaseCheckDetailsAdapter(List<CaseCheckDetailsBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new CaseCheckDetailsViewHolder(parent);
    }
}
