package com.dimeno.wum.entity;

import java.io.Serializable;
import java.util.List;

public class NewsEntity implements Serializable {


    /**
     * code : 200
     * data : [{"content":"<img src=\"https://publicoss.dimenosys.com/wisdom-urban-manage/temp/caseNewsImage/20200922111344_886.png\" alt=\"\" />","coverUrl":"wisdom-urban-manage/temp/caseNewsImage/20200922111333_851.png","createTime":"2020-09-22 11:13:58","createUser":"1","id":"1308243111831240705","introduction":"防守打法","newsType":2,"showUrl":null,"status":1,"updateTime":"2020-09-22 11:13:58","updateUser":"1"},{"content":"芙蓉蛋糕","coverUrl":"wisdom-urban-manage/temp/caseNewsImage/20200922111506_469.jpg","createTime":"2020-09-19 15:30:00","createUser":"1","id":"1307220380775890946","introduction":"个的发生","newsType":2,"showUrl":null,"status":1,"updateTime":"2020-09-22 11:15:07","updateUser":"1"},{"content":"<p>地方飞得更高<\/p>\r\n<p>刚发的<\/p>\r\n<p>规范的红包<\/p>","coverUrl":"wisdom-urban-manage/temp/caseNewsImage/20200922111436_275.jpg","createTime":"2020-09-19 15:29:46","createUser":"1","id":"1307220319882985474","introduction":"河钢股份","newsType":2,"showUrl":null,"status":1,"updateTime":"2020-09-22 11:14:39","updateUser":"1"}]
     * message : 请求成功
     * success : true
     */

    public int code;
    public String message;
    public boolean success;
    public List<DataBean> data;

    public static class DataBean implements Serializable {
        /**
         * content : <img src="https://publicoss.dimenosys.com/wisdom-urban-manage/temp/caseNewsImage/20200922111344_886.png" alt="" />
         * coverUrl : wisdom-urban-manage/temp/caseNewsImage/20200922111333_851.png
         * createTime : 2020-09-22 11:13:58
         * createUser : 1
         * id : 1308243111831240705
         * introduction : 防守打法
         * newsType : 2
         * showUrl : null
         * status : 1
         * updateTime : 2020-09-22 11:13:58
         * updateUser : 1
         */

        public String content;
        public String coverUrl;
        public String createTime;
        public String createUser;
        public String id;
        public String introduction;
        public int newsType;
        public String showUrl;
        public String linkUrl;
        public int status;
        public String updateTime;
        public String updateUser;
    }
}
