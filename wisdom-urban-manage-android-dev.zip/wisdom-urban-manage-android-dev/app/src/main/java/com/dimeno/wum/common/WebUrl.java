package com.dimeno.wum.common;

public class WebUrl {
    public static final String CASE_MANAGER = "http://zhcg.dimenosys.com/custom/#/caseManage?days=2";
    public static final String CASE_STATISTIC = "http://zhcg.dimenosys.com/custom/#/caseStatistics";
    public static final String MAP_MANAGE = "http://zhcg.dimenosys.com/custom/#/caseMapManage";
    public static final String SERVICE_PROTOCOL = "";
    public static final String PRIVACY_GUIDELINE = "";
    public static final String HELP_CENTER = "http://zhcg.dimenosys.com/custom/#/helpCenter";
    public static final String INSTITUTION = "http://zhcg.dimenosys.com/custom/#/institution";
    public static final String CITY_QUES = "http://zhcg.dimenosys.com/custom/#/problemList";
}
