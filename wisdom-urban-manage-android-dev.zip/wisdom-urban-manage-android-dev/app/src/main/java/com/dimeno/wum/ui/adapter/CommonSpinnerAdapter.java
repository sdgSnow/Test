package com.dimeno.wum.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.dimeno.wum.R;
import com.dimeno.wum.entity.CommonSpinnerEntity;

import java.util.List;

/**
 * common spinner adapter
 * Created by wangzhen on 2020/9/15.
 */
public class CommonSpinnerAdapter extends BaseAdapter implements SpinnerAdapter {
    private Context context;
    private List<CommonSpinnerEntity> list;

    public CommonSpinnerAdapter(Context context, List<CommonSpinnerEntity> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    public CommonSpinnerEntity getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public void setData(List<CommonSpinnerEntity> list) {
        this.list = list;
    }

    public List<CommonSpinnerEntity> getData() {
        return list;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if (view == null) {
            holder = new ViewHolder(view = LayoutInflater.from(context).inflate(R.layout.common_spinner_item_layout, null));
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.textView.setTextColor(ContextCompat.getColor(view.getContext(), R.color.color_3b424c));
        holder.textView.setText(getItem(position).getName());
        return view;
    }

    @Override
    public View getDropDownView(int position, View view, ViewGroup parent) {
        DropdownViewHolder holder;
        if (view == null) {
            holder = new DropdownViewHolder(view = LayoutInflater.from(context).inflate(R.layout.common_spinner_dropdown_item_layout, null));
            view.setTag(holder);
        } else {
            holder = (DropdownViewHolder) view.getTag();
        }
        holder.textView.setTextColor(ContextCompat.getColor(view.getContext(), R.color.color_3b424c));
        holder.textView.setText(getItem(position).getName());
        return view;
    }

    static class ViewHolder {
        TextView textView;

        public ViewHolder(View view) {
            textView = view.findViewById(R.id.tv);
        }
    }

    static class DropdownViewHolder {
        TextView textView;

        public DropdownViewHolder(View view) {
            textView = view.findViewById(R.id.tv);
        }
    }
}
