package com.dimeno.wum.entity

import java.io.Serializable

/**
 * CaseReportFileEntity
 * Created by wangzhen on 2020/9/17.
 */
class CaseReportFileEntity : Serializable {
    var fileUrl: String? = null
    var createTime: String? = null
    var createUser: String? = null

    /**
     * @see FileSource}
     */
    var fileSource: Int = 0
    var updateTime: String? = null
    var updateUser: String? = null
}