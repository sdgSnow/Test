package com.dimeno.wum.ui.adapter.holder

import android.view.ViewGroup
import android.widget.TextView
import com.dimeno.adapter.base.RecyclerViewHolder
import com.dimeno.wum.R
import com.dimeno.wum.entity.MessageTimeEntity
import com.dimeno.wum.utils.DateUtils

/**
 * message time view holder
 * Created by wangzhen on 2020/9/27.
 */
class MessageTimeViewHolder(parent: ViewGroup) : RecyclerViewHolder<MessageTimeEntity>(parent, R.layout.message_time_layout) {
    override fun bind() {
        findViewById<TextView>(R.id.tv_time).text = DateUtils.format(System.currentTimeMillis(), "yyyy年MM月dd日")
    }
}