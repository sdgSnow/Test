package com.dimeno.wum.network.task

import com.dimeno.network.callback.RequestCallback
import com.dimeno.network.task.GetTask

/**
 * GetOssTokenTask
 * Created by wangzhen on 2020/9/16.
 */
class GetOssTokenTask(callback: RequestCallback<*>?) : GetTask(callback) {
    override fun getApi(): String {
        return "/wisdomurbanmanagecore/api/getAppSignature"
    }
}