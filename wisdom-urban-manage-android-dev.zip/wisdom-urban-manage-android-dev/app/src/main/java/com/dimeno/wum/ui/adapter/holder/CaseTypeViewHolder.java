package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseDetailsBean;
import com.dimeno.wum.ui.bean.SpinnerQueryCaseTypeBean;

public class CaseTypeViewHolder extends RecyclerViewHolder<SpinnerQueryCaseTypeBean> {

    private final TextView case_type_name;

    public CaseTypeViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.spinner_item_case_type);
        case_type_name = findViewById(R.id.case_type_name);
    }

    @Override
    public void bind() {
        case_type_name.setText(mData.caseTypeName);
    }
}
