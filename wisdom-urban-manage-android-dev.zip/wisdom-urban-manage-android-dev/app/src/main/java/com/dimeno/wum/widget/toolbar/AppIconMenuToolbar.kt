package com.dimeno.wum.widget.toolbar

import android.app.Activity
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R

/**
 * app icon menu toolbar
 * Created by wangzhen on 2020/9/19.
 */
class AppIconMenuToolbar(activity: Activity, private val title: String, private val menu: Int) : Toolbar(activity) {
    private var callback: OnToolbarCallback? = null
    override fun layoutRes(): Int = R.layout.toolbar_app_icon_menu_layout
    override fun onViewCreated(view: View) {
        view.findViewById<View>(R.id.back).apply {
            setOnClickListener {
                callback?.onClose()
                activity.finish()
            }
        }
        view.findViewById<TextView>(R.id.title).apply {
            text = title
        }
        view.findViewById<ImageView>(R.id.menu).apply {
            setImageResource(menu)
            setOnClickListener {
                callback?.onMenuClick()
            }
        }
    }

    fun setCallback(callback: OnToolbarCallback?) {
        this.callback = callback
    }
}