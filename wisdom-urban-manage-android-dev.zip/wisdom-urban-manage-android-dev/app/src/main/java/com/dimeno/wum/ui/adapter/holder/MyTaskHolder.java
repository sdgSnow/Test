package com.dimeno.wum.ui.adapter.holder;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.bean.CaseQueryBean;
import com.dimeno.wum.ui.bean.MyTaskBean;

public class MyTaskHolder extends RecyclerViewHolder<MyTaskBean> {

    private final TextView tv_case_query_name;
    private final TextView tv_case_big_class_name;
    private final TextView tv_case_small_class_name;
    private final TextView tv_case_location;
    private final TextView tv_create_time;
    private final TextView tv_task_area_name;
    private final TextView tv_completed;
    private final TextView tv_un_complete;

    public MyTaskHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_my_task);
        tv_task_area_name = findViewById(R.id.tv_task_area_name);
        tv_completed = findViewById(R.id.tv_completed);
        tv_un_complete = findViewById(R.id.tv_un_complete);
        tv_case_query_name = findViewById(R.id.tv_case_query_name);
        tv_case_big_class_name = findViewById(R.id.tv_case_big_class_name);
        tv_case_small_class_name = findViewById(R.id.tv_case_small_class_name);
        tv_case_location = findViewById(R.id.tv_case_location);
        tv_create_time = findViewById(R.id.tv_create_time);
    }

    @Override
    public void bind() {
        tv_task_area_name.setText(mData.taskArea);
        tv_completed.setText(mData.alreadyNum + "");
        tv_un_complete.setText(mData.reportNum + "");
        tv_case_query_name.setText(mData.caseTypeName);
        tv_case_big_class_name.setText(mData.bigClassName);
        tv_case_small_class_name.setText(mData.smallClassName);
        tv_case_location.setText(mData.address);
        tv_create_time.setText(mData.createTime);
    }
}
