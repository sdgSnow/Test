package com.dimeno.wum.common;

/**
 * AssignType
 * Created by sdg on 2020/9/21.
 * 案件类型
 */
public class AssignType {

    public static final int CASE_REPORT = 1;//案件上报
    public static final int CASE_EXAMINE = 2;//案件核实
    public static final int CASE_RECHECK = 3;//案件复核
    public static final int CASE_INSPECTION = 4;//案件巡查
}
