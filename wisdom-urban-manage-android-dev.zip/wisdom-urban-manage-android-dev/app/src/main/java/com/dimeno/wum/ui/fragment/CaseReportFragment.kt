package com.dimeno.wum.ui.fragment

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.baidu.mapapi.model.LatLng
import com.dimeno.commons.json.JsonUtils
import com.dimeno.commons.structure.IList
import com.dimeno.commons.utils.AppUtils
import com.dimeno.commons.utils.FileUtils
import com.dimeno.commons.utils.T
import com.dimeno.permission.PermissionManager
import com.dimeno.permission.callback.AbsPermissionCallback
import com.dimeno.wum.R
import com.dimeno.wum.base.UserBiz
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.IKey
import com.dimeno.wum.common.PathManager
import com.dimeno.wum.entity.CasePictureEntity
import com.dimeno.wum.entity.CommonSpinnerEntity
import com.dimeno.wum.entity.db.*
import com.dimeno.wum.ui.activity.CaseReportMapActivity
import com.dimeno.wum.ui.adapter.CasePictureAdapter
import com.dimeno.wum.utils.CaseValidator
import com.dimeno.wum.utils.DBLoader
import com.dimeno.wum.utils.location.LocationManager
import com.dimeno.wum.utils.sequence.CasePictureController
import com.dimeno.wum.utils.sequence.CaseReportController
import com.dimeno.wum.viewmodel.CaseStashViewModel
import com.dimeno.wum.widget.dialog.CasePictureSelector
import com.dimeno.wum.widget.dialog.CaseSheetDialog
import com.dimeno.wum.widget.dialog.ConfirmDialog
import com.dimeno.wum.widget.dialog.DialogManager
import com.wangzhen.sequence.SequenceController
import com.wangzhen.sequence.SequenceControllerImpl
import kotlinx.android.synthetic.main.fragment_case_report.*
import java.io.File

/**
 * 案件上报
 * Created by wangzhen on 2020/9/16.
 */
class CaseReportFragment : Fragment(), View.OnClickListener {
    private var mTypeCode: String? = null
    private var mBigClassCode: String? = null
    private var mSmallClassCode: String? = null
    private var mLatitude: Double = 0.0
    private var mLongitude: Double = 0.0
    private var mAddress: String? = null

    private var mPictureAdapter: CasePictureAdapter? = null
    private var mCaseStashEntity: CaseStashEntity? = null

    private var mCameraFile: File? = null

    private var mTaskId: String? = null
    private var mCaseId: String? = null
    private var mGeneralSurveyId: String? = null

    private var isPreset = false // 是否预置类型

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_case_report, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        location()
        initObserver()
    }

    private fun location() {
        PermissionManager.request(this, object : AbsPermissionCallback() {
            override fun onGrant(permissions: Array<out String>?) {
                DialogManager.get().showLoading()
                LocationManager.get().callback {
                    DialogManager.get().stopLoading()
                    mLatitude = it.latitude
                    mLongitude = it.longitude
                    mAddress = it.address
                    tv_location.setText(it.address)
                }.locate()
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                activity?.supportFragmentManager?.let {
                    ConfirmDialog().setTitle("权限提示").setMessage("为了正常上报，请授予定位权限").setRightText("授予权限")
                            .setCallback(object : ConfirmDialog.Callback {
                                override fun onCancel() {
                                    activity!!.finish()
                                }

                                override fun onConfirm() {
                                    startActivityForResult(PermissionManager.getSettingIntent(context), Code.CODE_SETTING)
                                }
                            })
                            .show(it)
                }
            }
        }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    /**
     * 编辑案件、设置数据
     */
    private fun initObserver() {
        ViewModelProvider(context as ViewModelStoreOwner).get(CaseStashViewModel::class.java).getEditLiveData().observe(viewLifecycleOwner, Observer<CaseStashEntity> { data ->
            mCaseStashEntity = data

            mTypeCode = data.typeCode
            spinner_property.text = data.typeName

            mBigClassCode = data.bigClassCode
            spinner_big_class.text = data.bigClassName

            mSmallClassCode = data.smallClassCode
            spinner_small_class.text = data.smallClassName

            mTaskId = data.taskId
            mCaseId = data.caseId
            mGeneralSurveyId = data.generalSurveyId
            mAddress = data.address
            mLatitude = data.latitude
            mLongitude = data.longitude

            tv_location.setText(mAddress)
            data.description?.let {
                input_issue.setText(it)
            }
            mPictureAdapter?.setData(mutableListOf<CasePictureEntity>().apply {
                val pictures = JsonUtils.parseArray(data.pictures, String::class.java)
                for (i in 0 until pictures.size)
                    add(CasePictureEntity(pictures[i]))
            })
        })
    }

    private fun initViews() {
        arguments?.let { bundle ->
            mTaskId = bundle.getString(IKey.TASK_ID)
            isPreset = bundle.getBoolean(IKey.PRESET, false)
            if (isPreset) {
                mGeneralSurveyId = bundle.getString(IKey.GENERAL_SURVEY_ID)
                mTypeCode = bundle.getString(IKey.CASE_TYPE_CODE)
                bundle.getString(IKey.CASE_TYPE_NAME)?.let {
                    spinner_property.text = it
                }
                mBigClassCode = bundle.getString(IKey.CASE_BIG_CLASS_CODE)
                bundle.getString(IKey.CASE_BIG_CLASS_NAME)?.let {
                    spinner_big_class.text = it
                }
                mSmallClassCode = bundle.getString(IKey.CASE_SMALL_CLASS_CODE)
                bundle.getString(IKey.CASE_SMALL_CLASS_NAME)?.let {
                    spinner_small_class.text = it
                }
            }
        }

        btn_change_location.setOnClickListener(this)
        btn_browse_picture.setOnClickListener(this)
        btn_stash.setOnClickListener(this)
        btn_report.setOnClickListener(this)

        spinner_property.setOnClickListener {
            if (!isPreset) {
                activity?.supportFragmentManager?.apply {
                    val list = mutableListOf<CommonSpinnerEntity>().apply {
                        DBLoader.load(CaseTypeEntity::class.java).all.forEach { item ->
                            add(CommonSpinnerEntity().apply {
                                code = item.code.toString()
                                name = item.name
                            })
                        }
                    }
                    if (IList.isNotEmpty(list)) {
                        CaseSheetDialog()
                                .setData(list)
                                .callback(object : CaseSheetDialog.Callback {
                                    override fun onItemClick(data: CommonSpinnerEntity) {
                                        spinner_property.text = data.name
                                        mTypeCode = data.code
                                        mBigClassCode = null
                                        mSmallClassCode = null

                                        spinner_big_class.text = "请选择"
                                        spinner_small_class.text = "请选择"
                                    }

                                    override fun onCustomCase(value: String) {

                                    }
                                })
                                .show(this)
                    }
                }
            }
        }
        spinner_big_class.setOnClickListener {
            if (!isPreset) {
                activity?.supportFragmentManager?.apply {
                    val list = mutableListOf<CommonSpinnerEntity>().apply {
                        mTypeCode?.let {
                            DBLoader.load(CaseBigClassEntity::class.java).query()
                                    .equal(CaseBigClassEntity_.topcode, it).build().find().forEach { item ->
                                        val entity = CommonSpinnerEntity()
                                        entity.code = item.code.toString()
                                        entity.name = item.name
                                        add(entity)
                                    }
                        }
                    }
                    if (IList.isNotEmpty(list)) {
                        CaseSheetDialog()
                                .setData(list)
                                .callback(object : CaseSheetDialog.Callback {
                                    override fun onItemClick(data: CommonSpinnerEntity) {
                                        spinner_big_class.text = data.name
                                        mBigClassCode = data.code
                                        mSmallClassCode = null

                                        spinner_small_class.text = "请选择"
                                    }

                                    override fun onCustomCase(value: String) {

                                    }
                                })
                                .show(this)
                    }
                }
            }
        }
        spinner_small_class.setOnClickListener {
            if (!isPreset) {
                activity?.supportFragmentManager?.apply {
                    val list = mutableListOf<CommonSpinnerEntity>().apply {
                        mTypeCode?.let { type ->
                            mBigClassCode?.let { big ->
                                DBLoader.load(CaseSmallClassEntity::class.java).query().apply {
                                    equal(CaseSmallClassEntity_.topcode, type)
                                    equal(CaseSmallClassEntity_.pcode, big)
                                }.build().find().forEach { item ->
                                    val entity = CommonSpinnerEntity()
                                    entity.code = item.code.toString()
                                    entity.name = item.name
                                    add(entity)
                                }
                            }
                        }
                    }
                    if (IList.isNotEmpty(list)) {
                        CaseSheetDialog()
                                .showCustom(true)
                                .setData(list)
                                .callback(object : CaseSheetDialog.Callback {
                                    override fun onItemClick(data: CommonSpinnerEntity) {
                                        spinner_small_class.text = data.name
                                        mSmallClassCode = data.code
                                    }

                                    override fun onCustomCase(value: String) {
                                        spinner_small_class.text = value
                                        mSmallClassCode = "other"
                                    }
                                })
                                .show(this)
                    }
                }
            }
        }

        recycler.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                outRect.left = if (parent.getChildAdapterPosition(view) == 0) 0 else AppUtils.dip2px(10f)
            }
        })
        mPictureAdapter = CasePictureAdapter(mutableListOf())
        recycler.adapter = mPictureAdapter
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_change_location -> {
                startActivityForResult(Intent(context, CaseReportMapActivity::class.java).apply {
                    putExtra(IKey.LATITUDE, mLatitude)
                    putExtra(IKey.LONGITUDE, mLongitude)
                }, Code.CODE_CHANGE_LOCATION)
            }
            R.id.btn_browse_picture -> {
                activity?.supportFragmentManager?.let {
                    CasePictureSelector().setCallback(object : CasePictureSelector.Callback {
                        override fun onGallery() {
                            openGallery()
                        }

                        override fun onCamera() {
                            openCamera()
                        }
                    }).show(it)
                }
            }
            R.id.btn_stash -> {
                doStash()
            }
            R.id.btn_report -> {
                if (!checkIntegrity()) return
                if (!CaseValidator.inRegion(UserBiz.get().coordinates?.map {
                            LatLng(it.latitude, it.longitude)
                        }?.toMutableList(), LatLng(mLatitude, mLongitude))) {
                    activity?.supportFragmentManager?.apply {
                        ConfirmDialog().setTitle(getString(R.string.case_dialog_title)).setMessage(getString(R.string.case_dialog_out_of_region_single_tip)).setRightText(getString(R.string.case_dialog_out_of_region_confirm))
                                .setCallback(object : ConfirmDialog.Callback {
                                    override fun onCancel() {

                                    }

                                    override fun onConfirm() {
                                        doReport()
                                    }
                                })
                                .show(this)
                    }
                } else {
                    doReport()
                }
            }
        }
    }

    private fun doStash() {
        val loader = DBLoader.load(CaseStashEntity::class.java)
        if (mCaseStashEntity == null) {
            // 直接暂存
            loader.put(CaseStashEntity().apply {
                typeCode = mTypeCode
                typeName = spinner_property.text.toString()
                bigClassCode = mBigClassCode
                bigClassName = spinner_big_class.text.toString()
                smallClassCode = mSmallClassCode
                smallClassName = spinner_small_class.text.toString()
                address = mAddress
                latitude = mLatitude
                longitude = mLongitude
                description = input_issue.text.toString().trim()
                val list = mutableListOf<String>()
                mPictureAdapter?.datas?.let {
                    for (i in 0 until it.size)
                        list.add(it[i].url)
                }
                pictures = JsonUtils.toJsonString(list)
                userId = UserBiz.get().userId
                taskId = mTaskId
                caseId = mCaseId
                generalSurveyId = mGeneralSurveyId
                createTime = System.currentTimeMillis()
                updateTime = createTime
            })
        } else {
            // 更新记录
            loader.put(mCaseStashEntity!!.apply {
                typeCode = mTypeCode
                typeName = spinner_property.text.toString()
                bigClassCode = mBigClassCode
                bigClassName = spinner_big_class.text.toString()
                smallClassCode = mSmallClassCode
                smallClassName = spinner_small_class.text.toString()
                address = mAddress
                latitude = mLatitude
                longitude = mLongitude
                description = input_issue.text.toString().trim()
                val list = mutableListOf<String>()
                mPictureAdapter?.datas?.let {
                    for (i in 0 until it.size)
                        list.add(it[i].url)
                }
                pictures = JsonUtils.toJsonString(list)
                updateTime = System.currentTimeMillis()
            })
        }
        T.show("暂存成功")
        activity?.finish()
    }

    private fun doReport() {
        DialogManager.get().showLoading()
        val controller: SequenceController = SequenceControllerImpl(activity)
        controller.enqueue(CasePictureController(mPictureAdapter))
        controller.enqueue(CaseReportController(mCaseStashEntity).apply {
            address = mAddress
            latitude = mLatitude
            longitude = mLongitude
            caseType = mTypeCode
            bigClass = mBigClassCode
            smallClass = mSmallClassCode
            smallClassOtherName = spinner_small_class.text.toString()
            description = input_issue.text.toString().trim()
            pictures = mPictureAdapter?.datas
            taskId = mTaskId
            caseId = mCaseId
            generalSurveyId = mGeneralSurveyId
        })
        controller.proceed()
    }

    private fun checkIntegrity(): Boolean {
        if (TextUtils.isEmpty(mTypeCode)) {
            T.show("请选择案件属性")
            return false
        }
        if (TextUtils.isEmpty(mBigClassCode)) {
            T.show("请选择案件大类")
            return false
        }
        if (TextUtils.isEmpty(mSmallClassCode)) {
            T.show("请选择案件小类")
            return false
        }
        if (TextUtils.isEmpty(mAddress)) {
            T.show("请先定位")
            return false
        }
        if (TextUtils.isEmpty(input_issue.text)) {
            T.show("请输入问题描述")
            return false
        }
        if (IList.isEmpty(mPictureAdapter?.datas)) {
            T.show("请选择图片")
            return false
        }
        return true
    }

    private fun openCamera() {
        PermissionManager.request(this, object : AbsPermissionCallback() {
            override fun onGrant(permissions: Array<out String>?) {
                context?.let { ctx ->
                    startActivityForResult(Intent().apply {
                        mCameraFile = PathManager.getCaptureFile(ctx)
                        action = MediaStore.ACTION_IMAGE_CAPTURE
                        putExtra(MediaStore.EXTRA_OUTPUT,
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileProvider", mCameraFile!!)
                                } else
                                    Uri.fromFile(mCameraFile)
                        )
                    }, Code.CODE_IMAGE_CAPTURE)
                }
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                showPermissionDialog("为了正常上报，请授予相机权限")
            }
        }, Manifest.permission.CAMERA)
    }

    private fun openGallery() {
        PermissionManager.request(this, object : AbsPermissionCallback() {
            override fun onGrant(permissions: Array<out String>?) {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, Code.CODE_BROWSE_FILE)
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                showPermissionDialog("为了正常上报，请授予存储权限")
            }
        }, Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == Code.CODE_BROWSE_FILE) {
            data?.let { _data ->
                _data.data?.let { single ->
                    val url = FileUtils.getFileFromUri(context, single)
                    if (!TextUtils.isEmpty(url)) {
                        mPictureAdapter?.addData(mutableListOf<CasePictureEntity>().apply {
                            add(CasePictureEntity(url))
                        })
                    }
                } ?: let {
                    _data.clipData?.let { clipData ->
                        val list = mutableListOf<CasePictureEntity>()
                        for (i in 0 until clipData.itemCount) {
                            val url = FileUtils.getFileFromUri(context, clipData.getItemAt(i).uri)
                            if (!TextUtils.isEmpty(url)) {
                                list.add(CasePictureEntity(url))
                            }
                        }
                        if (list.isNotEmpty())
                            mPictureAdapter?.addData(list)
                    }
                }
            }
        }
        if (resultCode == Activity.RESULT_OK && requestCode == Code.CODE_IMAGE_CAPTURE) {
            mCameraFile?.let {
                if (it.exists()) {
                    mPictureAdapter?.addData(mutableListOf<CasePictureEntity>().apply {
                        add(CasePictureEntity(it.absolutePath))
                    })
                }
            }
        }
        if (requestCode == Code.CODE_SETTING) {
            location()
        }
        if (requestCode == Code.CODE_CHANGE_LOCATION && resultCode == Code.CODE_CHANGE_LOCATION_SUCCESS) {
            data?.let {
                mAddress = it.getStringExtra(IKey.ADDRESS)
                mLatitude = it.getDoubleExtra(IKey.LATITUDE, 0.0)
                mLongitude = it.getDoubleExtra(IKey.LONGITUDE, 0.0)
                tv_location.setText(mAddress)
            }
        }
    }

    private fun showPermissionDialog(msg: String) {
        activity?.supportFragmentManager?.let {
            ConfirmDialog().setTitle("权限提示").setMessage(msg).setRightText("授予权限")
                    .setCallback(object : ConfirmDialog.Callback {
                        override fun onCancel() {

                        }

                        override fun onConfirm() {
                            startActivity(PermissionManager.getSettingIntent(context))
                        }
                    })
                    .show(it)
        }
    }

    fun hideStash() {
        btn_stash.visibility = View.GONE
    }

    fun setCaseId(caseId: String?) {
        mCaseId = caseId
    }

    override fun onDestroy() {
        super.onDestroy()
        LocationManager.get().destroy()
    }
}