package com.dimeno.wum.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.dimeno.commons.toolbar.impl.Toolbar
import com.dimeno.wum.R
import com.dimeno.wum.base.BaseActivity
import com.dimeno.wum.common.Code
import com.dimeno.wum.common.IKey
import com.dimeno.wum.entity.db.CaseStashEntity
import com.dimeno.wum.ui.fragment.CaseReportFragment
import com.dimeno.wum.ui.fragment.CaseStashFragment
import com.dimeno.wum.viewmodel.CaseStashViewModel
import com.dimeno.wum.widget.toolbar.AppCommonToolbar
import kotlinx.android.synthetic.main.activity_report.*

/**
 * 案件
 * Created by wangzhen on 2020/9/15.
 */
class ReportActivity : BaseActivity(), View.OnClickListener {
    private var mCurFragment: Fragment? = null
    private var mCurIndex: Int = 0
    private var mTaskId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.let {
            mCurIndex = it.getInt("index", 0)
        }
        setContentView(R.layout.activity_report)
        fitDarkStatusBar(true)
        initViews()
        selectTab(mCurIndex)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("index", mCurIndex)
        super.onSaveInstanceState(outState)
    }

    private fun initViews() {
        mTaskId = intent.getStringExtra(IKey.TASK_ID)

        tab_report.setOnClickListener(this)
        tab_stash.setOnClickListener(this)

        ViewModelProvider(this).get(CaseStashViewModel::class.java).getEditLiveData().observe(this, Observer<CaseStashEntity> { selectTab(0) })
    }

    override fun createToolbar(): Toolbar? {
        return AppCommonToolbar(this, "案件")
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.tab_report -> {
                selectTab(0)
            }
            R.id.tab_stash -> {
                selectTab(1)
            }
        }
    }

    private fun selectTab(index: Int) {
        mCurIndex = index
        tab_report.isSelected = index == 0
        tab_report.paint.isFakeBoldText = index == 0
        indicator_report.visibility = if (index == 0) View.VISIBLE else View.GONE

        tab_stash.isSelected = index == 1
        tab_stash.paint.isFakeBoldText = index == 1
        indicator_stash.visibility = if (index == 1) View.VISIBLE else View.GONE

        val tag = index.toString()
        val manager = supportFragmentManager
        var fragment = manager.findFragmentByTag(tag)
        val transaction = manager.beginTransaction()
        if (fragment == null) {
            fragment = when (index) {
                0 -> CaseReportFragment().apply {
                    arguments = Bundle().apply {
                        putString(IKey.TASK_ID, mTaskId)
                        putString(IKey.GENERAL_SURVEY_ID, intent.getStringExtra(IKey.GENERAL_SURVEY_ID))
                        putBoolean(IKey.PRESET, intent.getBooleanExtra(IKey.PRESET, false))
                        putString(IKey.CASE_TYPE_NAME, intent.getStringExtra(IKey.CASE_TYPE_NAME))
                        putString(IKey.CASE_TYPE_CODE, intent.getStringExtra(IKey.CASE_TYPE_CODE))
                        putString(IKey.CASE_BIG_CLASS_NAME, intent.getStringExtra(IKey.CASE_BIG_CLASS_NAME))
                        putString(IKey.CASE_BIG_CLASS_CODE, intent.getStringExtra(IKey.CASE_BIG_CLASS_CODE))
                        putString(IKey.CASE_SMALL_CLASS_NAME, intent.getStringExtra(IKey.CASE_SMALL_CLASS_NAME))
                        putString(IKey.CASE_SMALL_CLASS_CODE, intent.getStringExtra(IKey.CASE_SMALL_CLASS_CODE))
                    }
                }
                else -> CaseStashFragment()
            }
            transaction.add(R.id.container, fragment, tag)
        } else {
            transaction.show(fragment)
        }
        if (mCurFragment != null && mCurFragment !== fragment) {
            transaction.hide(mCurFragment!!)
        }
        transaction.commitAllowingStateLoss()
        mCurFragment = fragment
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Code.CODE_REPEAT && resultCode == Code.CODE_REPORT_SUCCESS) {
            finish()
        }
    }
}