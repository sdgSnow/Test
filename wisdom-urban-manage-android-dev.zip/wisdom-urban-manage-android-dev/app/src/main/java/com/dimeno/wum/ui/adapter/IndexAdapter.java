package com.dimeno.wum.ui.adapter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.wum.ui.adapter.holder.IndexEmptyViewHolder;
import com.dimeno.wum.ui.adapter.holder.IndexViewHolder;
import com.dimeno.wum.ui.bean.IndexBean;

import java.util.List;

public class IndexAdapter extends RecyclerAdapter<IndexBean> {
    public static final int TYPE_ITEM = 0;
    public static final int TYPE_PLACE_HOLDER = 1;

    public IndexAdapter(List<IndexBean> list) {
        super(list);
    }

    @Override
    protected int getAbsItemViewType(int position) {
        if (mDatas.get(position) == null)
            return TYPE_PLACE_HOLDER;
        return TYPE_ITEM;
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_PLACE_HOLDER)
            return new IndexEmptyViewHolder(parent);
        return new IndexViewHolder(parent);
    }
}
