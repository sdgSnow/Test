package com.dimeno.wum.ui.header;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.commons.utils.T;
import com.dimeno.wum.R;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.entity.NewsEntity;
import com.dimeno.wum.ui.activity.NewsActivity;
import com.dimeno.wum.ui.adapter.AppBannerAdapter;
import com.dimeno.wum.ui.bean.IndexHeaderBean;
import com.youth.banner.Banner;
import com.youth.banner.indicator.CircleIndicator;

import java.util.ArrayList;
import java.util.List;

public class IndexHeader extends RecyclerItem {

    private Context mContext;
    private Banner<IndexHeaderBean, AppBannerAdapter> banner;
    private AppBannerAdapter adapter;

    public IndexHeader(Context context) {
        this.mContext = context;
    }

    @Override
    public int layout() {
        return R.layout.item_index_header;
    }

    @Override
    public void onViewCreated(View itemView) {
        banner = itemView.findViewById(R.id.banner);
    }

    public void setData(NewsEntity newsEntity) {
        if (newsEntity != null && newsEntity.data != null) {
            List<IndexHeaderBean> list = new ArrayList<>();
            for (NewsEntity.DataBean datum : newsEntity.data) {
                IndexHeaderBean indexHeaderBean = new IndexHeaderBean();
                indexHeaderBean.imageUrl = datum.coverUrl;
                list.add(indexHeaderBean);
            }
            if (adapter == null) {
                banner.setAdapter(new AppBannerAdapter(list)).setIndicator(new CircleIndicator(mContext));
                banner.setOnBannerListener((data, position) -> {
                    Intent intent = new Intent(mContext, NewsActivity.class);
                    intent.putExtra(IKey.URL, newsEntity.data.get(position).linkUrl);
                    mContext.startActivity(intent);
                });
            } else {
                adapter.setDatas(list);
                adapter.notifyDataSetChanged();
            }
        }
    }

    public void stopBanner() {
        banner.stop();
    }

    public void startBanner() {
        banner.start();
    }
}
