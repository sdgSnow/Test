package com.dimeno.wum.ui.bean;

/**
 * CaseFlowBean
 * Created by sdg on 2020/10/9.
 * 案件流程
 */
public class CaseFlowBean {

    public String caseReportId;
    public String operationDescription;
    public String manager;
    public String totalTime;
    public String linkTime;
    public String remark;
    public String linkName;
    public int timeOut;
    public String timeLimit;
    public String startTime;
    public int operationType;
    public String endTime;
    public String id;
}
