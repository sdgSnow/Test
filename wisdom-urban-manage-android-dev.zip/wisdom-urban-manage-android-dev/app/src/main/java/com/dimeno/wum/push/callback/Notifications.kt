package com.dimeno.wum.push.callback

import android.app.NotificationManager
import com.dimeno.wum.push.entity.NotificationEntity

/**
 * Notifications
 * Created by wangzhen on 2020/9/24.
 */
interface Notifications {
    fun createNotificationChannel()
    fun getNotificationManager(): NotificationManager?
    fun send(data: NotificationEntity?)
}