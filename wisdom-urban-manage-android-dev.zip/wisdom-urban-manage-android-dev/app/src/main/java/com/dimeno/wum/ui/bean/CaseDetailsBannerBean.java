package com.dimeno.wum.ui.bean;

public class CaseDetailsBannerBean {

    /**
     * caseReportId : 1306939525365059585
     * createTime : 2020-09-18 20:53:59
     * createUser : 1305473202950389761
     * fileShowUrl : https://lwctest.oss-cn-shenzhen.aliyuncs.com/wisdom-urban-managewisdom.urban.manage//android/P00918-175357.jpg?Expires=1600589391&OSSAccessKeyId=LTAI4FwRosaByiTNJDUdefmD&Signature=F1XTCxM20kSSu9YnJMJhywj4b24%3D
     * fileSource : 1
     * fileUrl : wisdom-urban-managewisdom.urban.manage//android/P00918-175357.jpg
     * id : 1306939525377642498
     * updateTime : 2020-09-18 20:53:59
     * updateUser : 1305473202950389761
     */

    public String caseReportId;
    public String createTime;
    public String createUser;
    public String fileShowUrl;
    public int fileSource;
    public String fileUrl;
    public String id;
    public String updateTime;
    public String updateUser;
}
