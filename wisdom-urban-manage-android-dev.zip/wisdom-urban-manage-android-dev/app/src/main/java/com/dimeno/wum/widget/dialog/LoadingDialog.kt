package com.dimeno.wum.widget.dialog

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import com.dimeno.commons.utils.AppUtils
import com.dimeno.wum.R

/**
 * common loading dialog
 * Created by wangzhen on 2020/9/17.
 */
class LoadingDialog : BaseDialogFragment() {
    override fun layoutId(): Int = R.layout.dialog_loading_layout

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews(view)
    }

    private fun initViews(view: View) {
        val loading = view.findViewById<View>(R.id.loading)
        ObjectAnimator.ofFloat(loading, "rotation", 0f, 360f).apply {
            interpolator = LinearInterpolator()
            repeatCount = Animation.INFINITE
            duration = 1000
        }.start()
    }

    override fun windowWidth(): Int = AppUtils.dip2px(80f)

    override fun windowHeight(): Int = AppUtils.dip2px(80f)

    override fun dimAmount(): Float = 0f

    override fun dimBehind(): Boolean = false
}