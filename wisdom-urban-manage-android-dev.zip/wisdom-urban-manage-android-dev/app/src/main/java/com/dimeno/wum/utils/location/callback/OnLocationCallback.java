package com.dimeno.wum.utils.location.callback;

import com.dimeno.wum.utils.location.entity.LocationEntity;

/**
 * OnLocationCallback
 * Created by wangzhen on 2020/9/16.
 */
public interface OnLocationCallback {
    void onLocation(LocationEntity entity);
}
