package com.dimeno.wum.push.entity;

import androidx.core.app.NotificationCompat;

import java.io.Serializable;

/**
 * notification entity
 * Created by wangzhen on 2020/9/24.
 */
public class NotificationEntity implements Serializable {
    public String id;
    public int msgType;
    public int caseMsgType;
    public String url;
    public String title;
    public String content;
    /**
     * @see NotificationCompat.BigTextStyle
     */
    public boolean bigTextStyle;

    NotificationEntity(Builder builder) {
        this.id = builder.id;
        this.msgType = builder.msgType;
        this.caseMsgType = builder.caseMsgType;
        this.url = builder.url;
        this.title = builder.title;
        this.content = builder.content;
        this.bigTextStyle = builder.bigTextStyle;
    }

    public static class Builder {
        private String id;
        private int msgType;
        private int caseMsgType;
        private String url;
        private String title;
        private String content;
        private boolean bigTextStyle = false;

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setMsgType(int type) {
            this.msgType = type;
            return this;
        }

        public Builder setCaseMsgType(int type) {
            this.caseMsgType = type;
            return this;
        }

        public Builder setUrl(String url) {
            this.url = url;
            return this;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setContent(String content) {
            this.content = content;
            return this;
        }

        public Builder setBigTextStyle(boolean bigTextStyle) {
            this.bigTextStyle = bigTextStyle;
            return this;
        }

        public NotificationEntity build() {
            return new NotificationEntity(this);
        }
    }
}
