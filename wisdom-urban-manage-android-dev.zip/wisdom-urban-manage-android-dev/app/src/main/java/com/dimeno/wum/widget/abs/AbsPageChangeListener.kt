package com.dimeno.wum.widget.abs

import androidx.viewpager.widget.ViewPager
/**
 * abs page change listener
 * Created by wangzhen on 2020/9/25.
 */
abstract class AbsPageChangeListener: ViewPager.OnPageChangeListener {
    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

    }

    override fun onPageScrollStateChanged(state: Int) {

    }
}