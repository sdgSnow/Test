package com.dimeno.wum.ui.adapter.holder;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.wum.R;
import com.dimeno.wum.ui.activity.CaseDetailsActivity;
import com.dimeno.wum.ui.bean.MyMessageBean;
import com.dimeno.wum.ui.bean.MyTaskBean;

public class MyMessageHolder extends RecyclerViewHolder<MyMessageBean> {

    private final TextView tv_title;
    private final TextView tv_content;
    private final TextView btn_see;

    public MyMessageHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.message_item_layout);
        tv_title = findViewById(R.id.tv_title);
        tv_content = findViewById(R.id.tv_content);
        btn_see = findViewById(R.id.btn_see);
    }

    @Override
    public void bind() {
        tv_title.setText(mData.title);
        tv_content.setText(mData.msg);
        btn_see.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemView.getContext().startActivity(new Intent(itemView.getContext(), CaseDetailsActivity.class).putExtra("id",mData.caseReportId));
            }
        });
    }
}
