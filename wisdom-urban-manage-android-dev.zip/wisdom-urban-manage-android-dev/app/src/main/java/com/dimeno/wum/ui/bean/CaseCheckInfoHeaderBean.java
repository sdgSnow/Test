package com.dimeno.wum.ui.bean;

public class CaseCheckInfoHeaderBean {

    public String imageUrl;
}
