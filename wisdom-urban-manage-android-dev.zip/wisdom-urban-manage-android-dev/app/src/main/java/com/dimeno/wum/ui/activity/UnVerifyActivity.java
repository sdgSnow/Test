package com.dimeno.wum.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.FileUtils;
import com.dimeno.commons.utils.L;
import com.dimeno.commons.utils.T;
import com.dimeno.network.callback.LoadingCallback;
import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.AbsPermissionCallback;
import com.dimeno.permission.callback.PermissionCallback;
import com.dimeno.wum.R;
import com.dimeno.wum.base.BaseActivity;
import com.dimeno.wum.base.UserBiz;
import com.dimeno.wum.common.Code;
import com.dimeno.wum.common.FileSource;
import com.dimeno.wum.common.IKey;
import com.dimeno.wum.common.PathManager;
import com.dimeno.wum.common.Verify;
import com.dimeno.wum.entity.CaseVerifyRequestEntity;
import com.dimeno.wum.entity.OssTokenEntity;
import com.dimeno.wum.network.task.CaseCheckTask;
import com.dimeno.wum.network.task.CaseVerifyTask;
import com.dimeno.wum.network.task.GetOssTokenTask;
import com.dimeno.wum.ui.adapter.UnVerifyPictureAdapter;
import com.dimeno.wum.ui.bean.CaseCheckDetailsHeaderBean;
import com.dimeno.wum.ui.bean.UnVerifyPictureBean;
import com.dimeno.wum.utils.OSSManager;
import com.dimeno.wum.utils.TimeUtil;
import com.dimeno.wum.utils.location.LocationManager;
import com.dimeno.wum.widget.dialog.CasePictureSelector;
import com.dimeno.wum.widget.dialog.ConfirmDialog;
import com.dimeno.wum.widget.dialog.DialogManager;
import com.dimeno.wum.widget.toolbar.AppCommonToolbar;

import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * UnVerifyActivity
 * Created by sdg on 2020/9/21.
 * 案件不属实/不通过校验 类型请查看Verify类
 */
public class UnVerifyActivity extends BaseActivity implements View.OnClickListener {

    private TextView tv_location;
    private EditText input_issue;
    private RecyclerView recycler;
    private ImageView btn_browse_picture;
    private double latitude;
    private double longitude;
    private String address;
    private List<UnVerifyPictureBean> unVerifyPictureBeans;
    private UnVerifyPictureAdapter unVerifyPictureAdapter;
    private List<CaseCheckDetailsHeaderBean> caseFilesList;
    private String caseReportId;
    private int uploadTotal;
    private int type;
    private File captureFile;
    private int verifyType;
    private View mBtnChangeLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_un_verify);
        fitDarkStatusBar(true);
        initViews();
        initData();
        setAddress();
    }

    private void initData() {
        unVerifyPictureBeans = new ArrayList<>();
        caseReportId = getIntent().getStringExtra("caseReportId");
        type = getIntent().getIntExtra("type", 0);
        verifyType = getIntent().getIntExtra("verifyType", 0);
    }

    private void initViews() {
        tv_location = findViewById(R.id.tv_location);
        input_issue = findViewById(R.id.input_issue);
        recycler = findViewById(R.id.recycler);
        btn_browse_picture = findViewById(R.id.btn_browse_picture);

        btn_browse_picture.setOnClickListener(this);

        findViewById(R.id.tv_last_step).setOnClickListener(this);
        findViewById(R.id.tv_commit).setOnClickListener(this);

        mBtnChangeLocation = findViewById(R.id.btn_change_location);
        mBtnChangeLocation.setVisibility(View.GONE);
        mBtnChangeLocation.setOnClickListener(this);
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new AppCommonToolbar(this, "案件验证详情");
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_browse_picture:
                new CasePictureSelector().setCallback(new CasePictureSelector.Callback() {
                    @Override
                    public void onGallery() {
                        openPictureBrowser();
                    }

                    @Override
                    public void onCamera() {
                        openCamera();
                    }
                }).show(UnVerifyActivity.this.getSupportFragmentManager());
                break;
            case R.id.tv_last_step:
                finish();
                break;
            case R.id.tv_commit:
                //进行验证必填项：地址，问题描述，图片
                if (TextUtils.isEmpty(address)) {
                    T.show("请先获取地址信息");
                    return;
                }
                if (TextUtils.isEmpty(input_issue.getText().toString().trim())) {
                    T.show("请先输入描述信息");
                    return;
                }
                if (unVerifyPictureBeans == null || unVerifyPictureBeans.size() < 1) {
                    T.show("请先选择图片");
                    return;
                }
                uploadPicture();
//                caseVerify();
                break;
            case R.id.btn_change_location:
                Intent intent = new Intent(this, CaseReportMapActivity.class);
                intent.putExtra(IKey.LATITUDE, latitude);
                intent.putExtra(IKey.LONGITUDE, longitude);
                startActivityForResult(intent, Code.CODE_CHANGE_LOCATION);
                break;
        }
    }

    private void openCamera() {
        PermissionManager.request(UnVerifyActivity.this, new PermissionCallback() {
            @Override
            public void onGrant(String[] permissions) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                captureFile = PathManager.Companion.getCaptureFile(UnVerifyActivity.this);
                Uri uri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    uri = FileProvider.getUriForFile(UnVerifyActivity.this, getPackageName() + ".fileProvider", captureFile);
                } else {
                    uri = Uri.fromFile(captureFile);
                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                startActivityForResult(intent, Code.CODE_IMAGE_CAPTURE);

            }

            @Override
            public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                showPermissionDialog("为了正常上报，请授予相机权限");
            }

            @Override
            public void onNotDeclared(String[] permissions) {

            }
        }, Manifest.permission.CAMERA);
    }

    private void showPermissionDialog(String s) {
        new ConfirmDialog().setTitle("权限提示").setMessage(s).setRightText("授予权限").setCallback(new ConfirmDialog.Callback() {
            @Override
            public void onCancel() {

            }

            @Override
            public void onConfirm() {
                startActivity(PermissionManager.getSettingIntent(UnVerifyActivity.this));
            }
        }).show(UnVerifyActivity.this.getSupportFragmentManager());
    }

    public void setAddress() {
        PermissionManager.request(UnVerifyActivity.this, new PermissionCallback() {
            @Override
            public void onGrant(String[] permissions) {
                DialogManager.Companion.get().showLoading();
                LocationManager.get().callback(entity -> {
                    DialogManager.Companion.get().stopLoading();
                    mBtnChangeLocation.setVisibility(View.VISIBLE);
                    latitude = entity.latitude;
                    longitude = entity.longitude;
                    address = entity.address;
                    tv_location.setText(address);
                }).locate();
            }

            @Override
            public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                new ConfirmDialog().setTitle("权限提示").setMessage("为了正常上报，请授予定位权限").setRightText("授予权限")
                        .setCallback(new ConfirmDialog.Callback() {
                            @Override
                            public void onConfirm() {
                                startActivityForResult(PermissionManager.getSettingIntent(UnVerifyActivity.this), Code.CODE_SETTING);
                            }

                            @Override
                            public void onCancel() {
                                finish();
                            }
                        })
                        .show(getSupportFragmentManager());
            }

            @Override
            public void onNotDeclared(String[] permissions) {

            }
        }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
    }

    private void uploadPicture() {
        DialogManager.Companion.get().showLoading();
        if (unVerifyPictureBeans != null) {
            uploadTotal = 0;
            for (UnVerifyPictureBean unVerifyPictureBean : unVerifyPictureBeans) {
                new GetOssTokenTask(new LoadingCallback<OssTokenEntity>() {
                    @Override
                    public void onSuccess(OssTokenEntity data) {
                        OSSManager.get()
                                .accessKeyId(data.getAccessKeyId())
                                .accessKeySecret(data.getAccessKeySecret())
                                .securityToken(data.getSecurityToken())
                                .endPoint(data.getEndpoint())
                                .bucket(data.getBucketName())
                                .directory(data.getDirectory())
                                .file(unVerifyPictureBean.fileLocalUrl)
                                .callback(new OSSManager.Callback() {
                                    @Override
                                    public void onSuccess() {
                                        uploadTotal++;
                                        L.e("已上传" + uploadTotal);
                                        if (uploadTotal == unVerifyPictureBeans.size()) {
                                            if (type == Verify.TYPE_CHECK) {//核实
                                                caseVerify();
                                            }
                                            if (type == Verify.TYPE_RECHECK) {//复核
                                                caseCheck();
                                            }

                                        }
                                    }

                                    @Override
                                    public void onFailure(String message) {
                                        T.show(message);
                                        DialogManager.Companion.get().stopLoading();
                                    }
                                }).upload();
                    }

                    @Override
                    public void onError(int code, String message) {
                        T.show(message);
                    }
                }).setTag(this).exe();
            }
        }
    }

    //案件不属实校验提交
    private void caseVerify() {
        DialogManager.Companion.get().showLoading();
        List<CaseVerifyRequestEntity.CaseFilesListBean> caseFilesListBeanList = new ArrayList<>();
        if (unVerifyPictureBeans != null) {
            for (UnVerifyPictureBean unVerifyPictureBean : unVerifyPictureBeans) {
                CaseVerifyRequestEntity.CaseFilesListBean caseFilesListBean = new CaseVerifyRequestEntity.CaseFilesListBean();
                caseFilesListBean.caseReportId = unVerifyPictureBean.caseReportId;
                caseFilesListBean.createTime = unVerifyPictureBean.createTime;
                caseFilesListBean.createUser = unVerifyPictureBean.createUser;
                caseFilesListBean.fileShowUrl = unVerifyPictureBean.fileShowUrl;
                caseFilesListBean.fileSource = unVerifyPictureBean.fileSource;
                File file = new File(unVerifyPictureBean.fileLocalUrl);
                caseFilesListBean.fileUrl = OSSManager.get().getDirectory() + File.separator + "android" + File.separator + file.getName();
                caseFilesListBean.id = unVerifyPictureBean.id;
                caseFilesListBean.updateTime = unVerifyPictureBean.updateTime;
                caseFilesListBean.updateUser = unVerifyPictureBean.updateUser;
                caseFilesListBeanList.add(caseFilesListBean);
            }
        }
        new CaseVerifyTask(new LoadingCallback<String>() {
            @Override
            public void onSuccess(String data) {
                T.show("上传成功");
                DialogManager.Companion.get().stopLoading();
                L.e(data);
                startActivity(new Intent(UnVerifyActivity.this, CaseCheckActivity.class));
                //上传成功后返回到
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
                DialogManager.Companion.get().stopLoading();
            }
        }).setTag(this)
                .put("address", address)
                .put("caseFilesList", caseFilesListBeanList)
                .put("caseReportId", caseReportId)
                .put("createTime", System.currentTimeMillis())
                .put("createUser", UserBiz.get().getUserId())
                .put("id", "")
                .put("latitude", latitude)
                .put("longitude", longitude)
                .put("operationDescription", input_issue.getText().toString())
                .put("operationType", 1)//暂定随便填，后台会重新改值，不影响
                .put("passFailed", verifyType)
                .put("updateTime", System.currentTimeMillis())
                .put("updateUser", UserBiz.get().getUserId())
                .exe();
    }

    //案件不通过校验提交
    private void caseCheck() {
        DialogManager.Companion.get().showLoading();
        List<CaseVerifyRequestEntity.CaseFilesListBean> caseFilesListBeanList = new ArrayList<>();
        if (unVerifyPictureBeans != null) {
            for (UnVerifyPictureBean unVerifyPictureBean : unVerifyPictureBeans) {
                CaseVerifyRequestEntity.CaseFilesListBean caseFilesListBean = new CaseVerifyRequestEntity.CaseFilesListBean();
                caseFilesListBean.caseReportId = unVerifyPictureBean.caseReportId;
                caseFilesListBean.createTime = unVerifyPictureBean.createTime;
                caseFilesListBean.createUser = unVerifyPictureBean.createUser;
                caseFilesListBean.fileShowUrl = unVerifyPictureBean.fileShowUrl;
                caseFilesListBean.fileSource = unVerifyPictureBean.fileSource;
                File file = new File(unVerifyPictureBean.fileLocalUrl);
                caseFilesListBean.fileUrl = OSSManager.get().getDirectory() + File.separator + "android" + File.separator + file.getName();
                caseFilesListBean.id = unVerifyPictureBean.id;
                caseFilesListBean.updateTime = unVerifyPictureBean.updateTime;
                caseFilesListBean.updateUser = unVerifyPictureBean.updateUser;
                caseFilesListBeanList.add(caseFilesListBean);
            }
        }
        new CaseCheckTask(new LoadingCallback<String>() {
            @Override
            public void onSuccess(String data) {
                T.show("上传成功");
                DialogManager.Companion.get().stopLoading();
                L.e(data);
                startActivity(new Intent(UnVerifyActivity.this, CaseReCheckActivity.class));
                //上传成功后返回到
            }

            @Override
            public void onError(int code, String message) {
                T.show(message);
                DialogManager.Companion.get().stopLoading();
            }
        }).setTag(this)
                .put("address", address)
                .put("caseFilesList", caseFilesListBeanList)
                .put("caseReportId", caseReportId)
                .put("createTime", System.currentTimeMillis())
                .put("createUser", UserBiz.get().getUserId())
                .put("id", "")
                .put("latitude", latitude)
                .put("longitude", longitude)
                .put("operationDescription", input_issue.getText().toString())
                .put("operationType", 1)//暂定随便填，后台会重新改值，不影响
                .put("passFailed", verifyType)
                .put("updateTime", System.currentTimeMillis())
                .put("updateUser", UserBiz.get().getUserId())
                .exe();
    }

    private void openPictureBrowser() {
        PermissionManager.request(UnVerifyActivity.this, new AbsPermissionCallback() {
            @Override
            public void onGrant(String[] permissions) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, Code.CODE_BROWSE_FILE);
            }

            @Override
            public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                T.show("需要存储权限");
            }
        }, Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @androidx.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (requestCode == Code.CODE_BROWSE_FILE) {
                if (data.getData() == null) return;
                String url = FileUtils.getFileFromUri(UnVerifyActivity.this, data.getData());
                if (!TextUtils.isEmpty(url)) {
                    UnVerifyPictureBean unVerifyPictureBean = new UnVerifyPictureBean();
                    unVerifyPictureBean.caseReportId = caseReportId;
                    unVerifyPictureBean.createTime = TimeUtil.getCurrentTime();
                    unVerifyPictureBean.createUser = UserBiz.get().getUserId();
                    unVerifyPictureBean.fileShowUrl = "";
                    unVerifyPictureBean.fileSource = FileSource.REPORT;
                    unVerifyPictureBean.fileUrl = "";
                    unVerifyPictureBean.fileLocalUrl = url;
                    unVerifyPictureBean.id = "";
                    unVerifyPictureBean.updateTime = TimeUtil.getCurrentTime();
                    unVerifyPictureBean.updateUser = UserBiz.get().getUserId();
                    unVerifyPictureBeans.add(unVerifyPictureBean);
                    showPicture();
                }
            }
        }
        if (resultCode == Activity.RESULT_OK && requestCode == Code.CODE_IMAGE_CAPTURE) {
            if (captureFile != null && captureFile.exists()) {
                UnVerifyPictureBean unVerifyPictureBean = new UnVerifyPictureBean();
                unVerifyPictureBean.caseReportId = caseReportId;
                unVerifyPictureBean.createTime = TimeUtil.getCurrentTime();
                unVerifyPictureBean.createUser = UserBiz.get().getUserId();
                unVerifyPictureBean.fileShowUrl = "";
                unVerifyPictureBean.fileSource = FileSource.REPORT;
                unVerifyPictureBean.fileUrl = "";
                unVerifyPictureBean.fileLocalUrl = captureFile.getAbsolutePath();
                unVerifyPictureBean.id = "";
                unVerifyPictureBean.updateTime = TimeUtil.getCurrentTime();
                unVerifyPictureBean.updateUser = UserBiz.get().getUserId();
                unVerifyPictureBeans.add(unVerifyPictureBean);
                showPicture();
            }
        }
        if (requestCode == Code.CODE_SETTING) {
            setAddress();
        }
        if (requestCode == Code.CODE_CHANGE_LOCATION && resultCode == Code.CODE_CHANGE_LOCATION_SUCCESS) {
            if (data != null) {
                address = data.getStringExtra(IKey.ADDRESS);
                latitude = data.getDoubleExtra(IKey.LATITUDE, 0.0);
                longitude = data.getDoubleExtra(IKey.LONGITUDE, 0.0);
                tv_location.setText(address);
            }
        }
    }

    public void showPicture() {
        unVerifyPictureAdapter = new UnVerifyPictureAdapter(unVerifyPictureBeans);
        recycler.setLayoutManager(new GridLayoutManager(UnVerifyActivity.this, 1, GridLayoutManager.HORIZONTAL, false));
        recycler.setAdapter(unVerifyPictureAdapter);
        unVerifyPictureAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                if (unVerifyPictureBeans == null)
                    return;
                ArrayList<String> urls = new ArrayList<>();
                for (UnVerifyPictureBean bean : unVerifyPictureBeans)
                    urls.add(bean.fileLocalUrl);
                startActivity(new Intent(UnVerifyActivity.this, PicturePreviewActivity.class)
                        .putStringArrayListExtra(IKey.DATA, urls).putExtra(IKey.POSITION, position));
            }
        });
    }
}