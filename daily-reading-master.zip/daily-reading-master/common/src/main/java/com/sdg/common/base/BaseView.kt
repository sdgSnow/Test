package com.sdg.common

interface BaseView {
}