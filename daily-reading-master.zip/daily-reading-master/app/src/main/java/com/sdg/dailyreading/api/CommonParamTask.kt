package com.sdg.dailyreading.api

import com.dimeno.network.callback.LoadingCallback
import com.dimeno.network.callback.RequestCallback
import com.dimeno.network.task.GetTask

open class CommonParamTask(callback: RequestCallback<*>) : GetTask(callback) {
    override fun getApi(): String {
        return ""
    }

    override fun onSetupParams(vararg params: Any?) {
        put("app_id","zhpsbtt3wgagnjrp")
        put("app_secret","YVBtbGNLTkl2QWZFL0NvUmhnbGRhdz09")
    }
}