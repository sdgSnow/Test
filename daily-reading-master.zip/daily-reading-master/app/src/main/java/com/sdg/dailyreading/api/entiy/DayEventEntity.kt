package com.sdg.dailyreading.api.entiy

class DayEventEntity {

    var code: Int? = null
    var msg: String? = null
    var data: List<DataBean>? = null

    class DataBean {
        var picUrl: String? = null
        var title: String? = null
        var year: String? = null
        var month: Int? = null
        var day: Int? = null
        var details: String? = null
    }
}