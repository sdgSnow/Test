package com.sdg.dailyreading.common.activity

import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.widget.Toast
import com.dimeno.commons.toolbar.impl.Toolbar
import com.sdg.dailyreading.api.entiy.DayEventEntity
import com.sdg.dailyreading.common.p.PEventDetails
import com.sdg.dailyreading.common.v.VEventDetails
import com.sdg.dailyreading.databinding.ActivityEventDetailsBinding
import com.sdg.dailyreading.event.DetailsEvent
import com.sdg.ktques.base.BaseBindingActivity
import com.sdg.toolbar.TitleToolBar
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class EventDetailsActivity : BaseBindingActivity<ActivityEventDetailsBinding,VEventDetails,PEventDetails>(),VEventDetails {

    var list: List<DayEventEntity.DataBean>? = null
    var curPos:Int? = null

    override fun createPresenter(): PEventDetails? = PEventDetails()

    override fun initViews() {
        EventBus.getDefault().register(this)
        mBinding.tvDetails.movementMethod = ScrollingMovementMethod.getInstance()
    }

    override fun initData() {
        mBinding.tvLast.setOnClickListener {
            if(curPos == 0){
                Toast.makeText(mContext, "当前为第一篇", Toast.LENGTH_SHORT).show()
            }else{
                mBinding.tvTitle.text = list?.get(curPos!! - 1)?.title
                mBinding.tvDetails.text = changeDetails(list?.get(curPos!! - 1)?.details)
                curPos = curPos!! - 1
            }
        }

        mBinding.tvNext.setOnClickListener {
            Log.i("tag", "当前页为$curPos")
            if(curPos!! >= list?.size!! - 1){
                Toast.makeText(mContext, "当前为最后一篇", Toast.LENGTH_SHORT).show()
            }else{
                mBinding.tvTitle.text = list?.get(curPos!! + 1)?.title
                mBinding.tvDetails.text = changeDetails(list?.get(curPos!! + 1)?.details)
                curPos = curPos!! + 1
            }
        }
    }

    override fun createToolbar(): Toolbar? = TitleToolBar(this,"详情介绍")

    @Subscribe(threadMode = ThreadMode.MAIN,sticky = true)
    fun getDetails(event: DetailsEvent) {
        this.list = event.list
        this.curPos = event.curPos
        mBinding.tvTitle.text = event.list[event.curPos].title
        mBinding.tvDetails.text = changeDetails(event.list[event.curPos].details)
    }

    private fun changeDetails(eventDetails: String?) : String?{
        var details = eventDetails
        if(details?.contains("　　")!!){
            details = details.replace("　　", "\n　　")
        }
        return "　　$details"
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}