package com.sdg.dailyreading.widget

import android.view.View
import androidx.appcompat.widget.AppCompatTextView
import com.dimeno.adapter.base.RecyclerItem
import com.sdg.dailyreading.R

class JokeAndWordHeader() : RecyclerItem() {

    private var tvJokesContent: AppCompatTextView? = null
    private var tvWordContent: AppCompatTextView? = null

    override fun layout(): Int = R.layout.item_day_event_header

    override fun onViewCreated(itemView: View) {
        tvJokesContent = itemView.findViewById(R.id.tvJokesContent)
        tvWordContent = itemView.findViewById(R.id.tvWordContent)
    }

    fun setJokesContent(jokesContent:String?){
        tvJokesContent?.text = jokesContent
    }

    fun setWordContent(wordContent:String?){
        tvWordContent?.text = wordContent
    }

}