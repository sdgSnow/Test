package com.sdg.dailyreading.api.entiy

class DateEntity {

    var code: Int? = null
    var msg: String? = null
    var data: DataBean? = null

    class DataBean {
        var date: String? = null
        var weekDay: Int? = null
        var yearTips: String? = null
        var type: Int? = null
        var typeDes: String? = null
        var chineseZodiac: String? = null
        var solarTerms: String? = null
        var avoid: String? = null
        var lunarCalendar: String? = null
        var suit: String? = null
        var dayOfYear: Int? = null
        var weekOfYear: Int? = null
        var constellation: String? = null
        var indexWorkDayOfMonth: Int? = null
    }
}