package com.sdg.dailyreading.common.adapter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dimeno.adapter.RecyclerAdapter
import com.sdg.dailyreading.common.adapter.holder.HistoryTodayHolder
import com.sdg.dailyreading.api.entiy.DayEventEntity

class HistoryTodayAdapter(list: List<DayEventEntity.DataBean>) : RecyclerAdapter<DayEventEntity.DataBean>(list) {
    override fun onAbsCreateViewHolder(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return HistoryTodayHolder(parent)
    }
}