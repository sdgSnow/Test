package com.sdg.dailyreading.test;

import com.sdg.dailyreading.api.entiy.DayEventEntity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Json2Bean implements Serializable {


    private Integer code;
    private String msg;
    private DataBean data;
    public static class DataBean {
        private String address;
        private String cityCode;
        private String temp;
        private String weather;
        private String windDirection;
        private String windPower;
        private String humidity;
        private String reportTime;
    }

}
