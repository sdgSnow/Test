package com.sdg.dailyreading.api.task

import com.dimeno.network.callback.RequestCallback
import com.sdg.dailyreading.api.CommonParamTask

class RandomJokesTask(callback:RequestCallback<*>) : CommonParamTask(callback) {
    //https://www.mxnzp.com/api/
    override fun getApi(): String {
        return "/jokes/list/random"
    }
}