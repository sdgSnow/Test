package com.sdg.dailyreading.api.task

import com.dimeno.network.callback.RequestCallback
import com.sdg.dailyreading.api.CommonParamTask

class DateTask(callback:RequestCallback<*>) : CommonParamTask(callback) {

    var dateApi:String = ""

    override fun getApi(): String {
        return dateApi
    }

    fun setDate(date:String?): DateTask {
        this.dateApi = "/holiday/single/$date"
        return this
    }
}