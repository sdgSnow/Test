package com.sdg.dailyreading.widget

import android.view.View
import androidx.appcompat.widget.AppCompatTextView
import com.dimeno.adapter.base.RecyclerItem
import com.sdg.dailyreading.R

class TitleHeader() : RecyclerItem() {

    override fun layout(): Int = R.layout.item_day_event_title_header

    override fun onViewCreated(itemView: View) {
        itemView.findViewById<AppCompatTextView>(R.id.tvTitle).apply {
            text = "历史上的今日："
        }
    }

}