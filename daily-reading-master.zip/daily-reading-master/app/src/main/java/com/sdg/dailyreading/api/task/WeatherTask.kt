package com.sdg.dailyreading.api.task

import com.dimeno.network.callback.RequestCallback
import com.sdg.dailyreading.api.CommonParamTask

class WeatherTask(callback:RequestCallback<*>) : CommonParamTask(callback) {

    var weatherApi:String = ""

    override fun getApi(): String {
        return weatherApi
    }

    fun setCity(cityName:String?): WeatherTask {
        this.weatherApi = "/weather/current/$cityName"
        return this
    }
}