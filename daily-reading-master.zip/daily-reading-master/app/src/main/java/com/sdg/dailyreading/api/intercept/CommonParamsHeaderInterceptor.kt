package com.sdg.dailyreading.api.intercept

import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.HashMap

class CommonParamsHeaderInterceptor(params: HashMap<Any, Any>?) : Interceptor{

    private val TAG = "CommonParametersInterceptor"

    private var params: HashMap<Any, Any>? = null

    init {
        this.params = params
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val oldRequest: Request = chain.request()
        var response: Response? = null
        // 新的请求,添加参数
//        Request addParamRequest = addHeader(oldRequest);
        val addParamRequest = addParam(oldRequest)
        response = chain.proceed(addParamRequest)
        return response
    }

    /**
     * 添加公共参数
     *
     * @param oldRequest
     * @return
     */
    private fun addParam(oldRequest: Request): Request {
        val builder: HttpUrl.Builder = oldRequest.url.newBuilder()
        if (params != null) {
            for ((key, value) in params!!) {
                builder.setQueryParameter(key.toString(), value.toString())
            }
        }
        return oldRequest.newBuilder()
            .method(oldRequest.method, oldRequest.body)
            .url(builder.build())
            .build()
    }


    /**
     * 添加请求头
     *
     * @param oldRequest
     * @return
     */
    fun addHeader(oldRequest: Request): Request? {
        val builder: Request.Builder = oldRequest.newBuilder().addHeader("user-agent", "Android-APP").addHeader("Connection", "close")
        return builder.build()
    }
}