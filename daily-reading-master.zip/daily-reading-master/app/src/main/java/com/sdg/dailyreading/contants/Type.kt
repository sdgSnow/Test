package com.sdg.dailyreading.contants

interface Type {

    interface WeekDay{
        companion object {
            const val Monday : String = "周一"
            const val Tuesday : String = "周二"
            const val Wednesday : String = "周三"
            const val Thursday : String = "周四"
            const val Friday : String = "周五"
            const val Saturday : String = "周六"
            const val Sunday : String = "周日"
        }
    }

    interface Weather{
        companion object {
            const val unknown : Int = 0
            const val sunny : Int = 1
            const val wind : Int = 2
            const val haze : Int = 3
            const val rain : Int = 4
            const val snow : Int = 5
            const val sand : Int = 6
            const val fog : Int = 7
        }
    }

    interface SolarTermType{
        companion object {
            const val solarTerm1 : Int = 1
            const val solarTerm2 : Int = 2
            const val solarTerm3 : Int = 3
            const val solarTerm4 : Int = 4
            const val solarTerm5 : Int = 5
            const val solarTerm6 : Int = 6
            const val solarTerm7 : Int = 7
            const val solarTerm8 : Int = 8
            const val solarTerm9 : Int = 9
            const val solarTerm10 : Int = 10
            const val solarTerm11 : Int = 11
            const val solarTerm12 : Int = 12
            const val solarTerm13 : Int = 13
            const val solarTerm14 : Int = 14
            const val solarTerm15 : Int = 15
            const val solarTerm16 : Int = 16
            const val solarTerm17 : Int = 17
            const val solarTerm18 : Int = 18
            const val solarTerm19 : Int = 19
            const val solarTerm20 : Int = 20
            const val solarTerm21 : Int = 21
            const val solarTerm22 : Int = 22
            const val solarTerm23 : Int = 23
            const val solarTerm24 : Int = 24
        }
    }
}