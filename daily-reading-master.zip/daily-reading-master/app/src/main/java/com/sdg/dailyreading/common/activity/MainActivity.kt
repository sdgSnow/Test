package com.sdg.dailyreading.common.activity

import android.Manifest
import android.content.pm.PackageManager
import android.location.*
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.dimeno.commons.toolbar.impl.Toolbar
import com.sdg.dailyreading.common.adapter.HistoryTodayAdapter
import com.sdg.dailyreading.databinding.ActivityMainBinding
import com.sdg.dailyreading.api.entiy.DateEntity
import com.sdg.dailyreading.api.entiy.DayEventEntity
import com.sdg.dailyreading.api.entiy.DayWordEntity
import com.sdg.dailyreading.api.entiy.WeatherEntity
import com.sdg.dailyreading.api.entiy.PageJokesEntity
import com.sdg.dailyreading.api.entiy.RandomJokesEntity
import com.sdg.dailyreading.common.p.PMain
import com.sdg.dailyreading.common.v.VMain
import com.sdg.dailyreading.event.DetailsEvent
import com.sdg.dailyreading.utils.LocationUtils
import com.sdg.dailyreading.utils.MyUtils
import com.sdg.dailyreading.widget.JokeAndWordHeader
import com.sdg.dailyreading.widget.TitleHeader
import com.sdg.ktques.base.BaseBindingActivity
import com.sdg.toolbar.TitleToolBar
import org.greenrobot.eventbus.EventBus
import java.io.IOException

class MainActivity : BaseBindingActivity<ActivityMainBinding, VMain, PMain>(), VMain {

    private var mHistoryTodayAdapter:HistoryTodayAdapter? = null
    private lateinit var jokeAndWordHeader:JokeAndWordHeader
    private var historyList:List<DayEventEntity.DataBean> = mutableListOf()

    override fun initViews() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            mPresenter?.getWeather("深圳")
            mBinding.tvWeatherCity.text = "深圳"
        }else {
            LocationUtils.get().getLocationManage(this, locationListener)
        }
        mPresenter?.getRandomJokes()
        mPresenter?.getDayEvent()
        mPresenter?.getDayWord()
        mPresenter?.getDay()
    }

    override fun initData() {
        mBinding.rcyDayEvent.layoutManager = GridLayoutManager(mContext, 1, GridLayoutManager.VERTICAL, false)
        mHistoryTodayAdapter = HistoryTodayAdapter(historyList)
        mBinding.rcyDayEvent.adapter = mHistoryTodayAdapter
        jokeAndWordHeader = JokeAndWordHeader()
        mHistoryTodayAdapter!!.addHeader(jokeAndWordHeader.onCreateView(mBinding.rcyDayEvent))
        mHistoryTodayAdapter!!.addHeader(TitleHeader().onCreateView(mBinding.rcyDayEvent))
        mHistoryTodayAdapter!!.setOnClickCallback { _, position ->
            EventBus.getDefault().postSticky(DetailsEvent(historyList,position))
            gotoActivity(EventDetailsActivity::class.java)
        }
    }

    override fun createToolbar(): Toolbar? {
        return TitleToolBar(this,"趣闻")
    }

    override fun createPresenter(): PMain? = PMain()

    override fun onSuccess(randomJokesEntity: RandomJokesEntity?) {
        if(randomJokesEntity?.data?.isNotEmpty()!!){
            jokeAndWordHeader.setJokesContent(randomJokesEntity?.data?.get(0)?.content)
        }
    }

    override fun onSuccess(pageJokesEntity: PageJokesEntity?) {
        if(pageJokesEntity?.data?.list?.isNotEmpty()!!){

        }
    }

    override fun onSuccess(dayWordEntity: DayWordEntity?) {
        if(dayWordEntity?.data?.isNotEmpty()!!){
            jokeAndWordHeader.setWordContent(dayWordEntity.data?.get(0)?.content)
        }
    }

    override fun onSuccess(dateEntity: DateEntity?) {
        mBinding.lunarCalendar.text = dateEntity?.data?.lunarCalendar
        mBinding.date.text = dateEntity?.data?.date
        mBinding.weekDay.text = MyUtils.getWeekDay(dateEntity?.data?.weekDay)
        mBinding.solarTerms.text = dateEntity?.data?.solarTerms
        "宜：${dateEntity?.data?.suit}".also { mBinding.suit.text = it }
        "忌：${dateEntity?.data?.avoid}".also { mBinding.avoid.text = it }
        MyUtils.setSolarTerm(dateEntity?.data?.solarTerms,mBinding.ivSolarTerm)
    }

    override fun onSuccess(dayEventEntity: DayEventEntity?) {
        if(dayEventEntity?.data?.isNotEmpty()!!){
            historyList = dayEventEntity.data!!
            mHistoryTodayAdapter?.setData(historyList)
        }
    }

    override fun onSuccess(weatherEntity: WeatherEntity?) {
        MyUtils.setWeatherIcon(weatherEntity?.data?.weather,mBinding.ivWeather)
        mBinding.tvWeatherName.text = weatherEntity?.data?.weather
        mBinding.tvWeatherTemp.text = weatherEntity?.data?.temp
    }

    override fun onError(msg: String?) {
        Toast.makeText(mContext,msg,Toast.LENGTH_SHORT).show()
    }

    private var locationListener: LocationListener = object : LocationListener {
        override fun onStatusChanged(provider: String, status: Int, arg2: Bundle) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onLocationChanged(location: Location) {
            val latitude = location.latitude
            val longitude = location.longitude
            var addString: String? = null
            var addList: List<Address>? = null
            val ge = Geocoder(this@MainActivity)
            try {
                addList = ge.getFromLocation(latitude, longitude, 1)
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (addList != null && addList.isNotEmpty()) {
                for (i in addList.indices) {
                    val ad = addList[i]
                    addString = ad.locality //拿到城市
                    mBinding.tvWeatherCity.text = addString
                    mPresenter?.getWeather(addString)
                    LocationUtils.get().removeUpdates()
                }
            }
            val locationStr = ("纬度：" + location.latitude + "经度：" + location.longitude)
            Log.i("andly", "$locationStr----$addString")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LocationUtils.get().removeUpdates()
    }
}
