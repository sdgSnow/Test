package com.sdg.dailyreading.api.entiy

class WeatherEntity {

    var code: Int? = null
    var msg: String? = null
    var data: DataBean? = null

    class DataBean {
        var address: String? = null
        var cityCode: String? = null
        var temp: String? = null
        var weather: String? = null
        var windDirection: String? = null
        var windPower: String? = null
        var humidity: String? = null
        var reportTime: String? = null
    }
}