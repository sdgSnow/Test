package com.sdg.dailyreading.common.v

import com.sdg.common.BaseView
import com.sdg.dailyreading.api.entiy.DateEntity
import com.sdg.dailyreading.api.entiy.DayEventEntity
import com.sdg.dailyreading.api.entiy.DayWordEntity
import com.sdg.dailyreading.api.entiy.WeatherEntity
import com.sdg.dailyreading.api.entiy.PageJokesEntity
import com.sdg.dailyreading.api.entiy.RandomJokesEntity

interface VEventDetails : BaseView {

}