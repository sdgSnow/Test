package com.sdg.dailyreading.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationListener
import android.location.LocationManager
import androidx.core.app.ActivityCompat

class LocationUtils {

    companion object {
        private var sInstance: LocationUtils? = null
        fun get(): LocationUtils {
            if (sInstance == null) {
                synchronized(LocationUtils::class.java) {
                    if (sInstance == null) {
                        sInstance = LocationUtils()
                    }
                }
            }
            return sInstance!!
        }
    }

    private lateinit var locationManager : LocationManager
    private var locationListener: LocationListener? = null
    fun getLocationManage(context: Context, locationListener: LocationListener?) {
        this.locationListener = locationListener
            locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = locationManager.getProviders(true)
            val locationProvider: String
            locationProvider = if (providers.contains(LocationManager.GPS_PROVIDER)) {
                LocationManager.GPS_PROVIDER
            } else if (providers.contains(LocationManager.NETWORK_PROVIDER)) {
                LocationManager.NETWORK_PROVIDER
            } else {
                return
            }
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            locationManager.requestLocationUpdates(locationProvider, 3000, 1f, locationListener!!)
        }
        fun removeUpdates(){
            locationManager?.removeUpdates(locationListener!!);
        }

}