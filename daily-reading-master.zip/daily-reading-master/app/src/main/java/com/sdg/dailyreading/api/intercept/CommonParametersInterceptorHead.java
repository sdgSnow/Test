package com.sdg.dailyreading.api.intercept;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class CommonParametersInterceptorHead implements Interceptor {

    private String TAG = "CommonParametersInterceptor";

    private HashMap<Object,Object> params;

    public CommonParametersInterceptorHead(HashMap<Object,Object> params) {
        this.params = params;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request oldRequest = chain.request();
        Response response = null;
        // 新的请求,添加参数
//        Request addParamRequest = addHeader(oldRequest);
        Request addParamRequest = addParam(oldRequest);
        response = chain.proceed(addParamRequest);
        return response;
    }

    /**
     * 添加公共参数
     *
     * @param oldRequest
     * @return
     */
    private Request addParam(Request oldRequest) {
        HttpUrl.Builder builder = oldRequest.url().newBuilder();
        if(params != null) {
            for (Map.Entry<Object, Object> entry : params.entrySet()) {
                builder.setQueryParameter(String.valueOf(entry.getKey()), String.valueOf(entry.getValue()));
            }
        }
        Request newRequest = oldRequest.newBuilder()
                .method(oldRequest.method(), oldRequest.body())
                .url(builder.build())
                .build();
        return newRequest;
    }


    /**
     * 添加请求头
     *
     * @param oldRequest
     * @return
     */
    public Request addHeader(Request oldRequest) {
        Request.Builder builder = oldRequest.newBuilder().addHeader("user-agent", "Android-APP").addHeader("Connection","close");
        return builder.build();
    }
}
