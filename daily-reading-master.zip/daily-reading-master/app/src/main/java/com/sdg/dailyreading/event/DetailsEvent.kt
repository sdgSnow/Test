package com.sdg.dailyreading.event

import com.sdg.dailyreading.api.entiy.DayEventEntity

class DetailsEvent(var list: List<DayEventEntity.DataBean>, var curPos: Int)