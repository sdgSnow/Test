package com.sdg.dailyreading.common

import android.app.Application
import com.dimeno.network.Network
import com.dimeno.network.config.NetConfig
import com.sdg.dailyreading.api.intercept.CommonParamsHeaderInterceptor
import com.sdg.dailyreading.api.intercept.RequestInterceptor

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        var commomParams = HashMap<Any,Any>()
        commomParams["app_id"] = "zhpsbtt3wgagnjrp"
        commomParams["app_secret"] = "YVBtbGNLTkl2QWZFL0NvUmhnbGRhdz09"

        Network.init(this, NetConfig.Builder()
            .baseUrl("https://www.mxnzp.com/api/")
            .interceptor(RequestInterceptor())
            .interceptor(CommonParamsHeaderInterceptor(commomParams))
            .build())
    }
}