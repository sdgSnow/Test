package com.sdg.dailyreading.test;

public interface Test {


}
