package com.sdg.dailyreading.common.p

import com.dimeno.network.callback.LoadingCallback
import com.sdg.common.BaseRxPresenter
import com.sdg.dailyreading.api.entiy.*
import com.sdg.dailyreading.api.task.DateTask
import com.sdg.dailyreading.api.task.DayEventTask
import com.sdg.dailyreading.api.task.DayWordTask
import com.sdg.dailyreading.api.task.WeatherTask
import com.sdg.dailyreading.api.task.PageJokesTask
import com.sdg.dailyreading.api.task.RandomJokesTask
import com.sdg.dailyreading.common.v.VMain
import com.sdg.dailyreading.utils.MyUtils

class PMain : BaseRxPresenter<VMain>() {
    fun getPageJokes(){
        PageJokesTask(object : LoadingCallback<PageJokesEntity>(){
            override fun onSuccess(data: PageJokesEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setTag(this)
            .put("page",1)
            .exe()
    }

    fun getRandomJokes(){
        RandomJokesTask(object : LoadingCallback<RandomJokesEntity>(){
            override fun onSuccess(data: RandomJokesEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setTag(this)
            .exe()
    }

    fun getDayWord(){
        DayWordTask(object : LoadingCallback<DayWordEntity>(){
            override fun onSuccess(data: DayWordEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setTag(this)
            .put("count",1)//1-20之间
            .exe()
    }

    fun getDayEvent(){
        DayEventTask(object : LoadingCallback<DayEventEntity>(){
            override fun onSuccess(data: DayEventEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setTag(this)
            .put("type",1)//是否需要详情，0：不需要详情 1：需要详情 默认值 0 可不传
            .exe()
    }

    fun getDay(){
        DateTask(object : LoadingCallback<DateEntity>(){
            override fun onSuccess(data: DateEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setDate(MyUtils.getCurrentTime())
            .setTag(this)
            .put("ignoreHoliday",false)//是否忽略节假日，仅仅获取万年历，默认值false
            .exe()
    }

    fun getWeather(city:String){
        WeatherTask(object : LoadingCallback<WeatherEntity>(){
            override fun onSuccess(data: WeatherEntity?) {
                if(data?.code == 1){
                    mView?.onSuccess(data)
                }
            }

            override fun onError(code: Int, message: String?) {
                mView?.onError(message)
            }
        }).setCity(city)
            .setTag(this)
            .put("ignoreHoliday",false)//是否忽略节假日，仅仅获取万年历，默认值false
            .exe()
    }
}