package com.sdg.dailyreading.common.activity

import android.Manifest
import com.dimeno.permission.PermissionManager
import com.dimeno.permission.callback.PermissionCallback
import com.sdg.dailyreading.common.p.PSplash
import com.sdg.dailyreading.common.v.VSplash
import com.sdg.dailyreading.databinding.ActivitySplashBinding
import com.sdg.ktques.base.BaseBindingActivity

class SplashActivity : BaseBindingActivity<ActivitySplashBinding, VSplash, PSplash>(), VSplash {
    override fun createPresenter(): PSplash? = PSplash()

    override fun initViews() {
        PermissionManager.request(this, object : PermissionCallback {
            override fun onGrant(permissions: Array<out String>?) {
                gotoActivity(MainActivity::class.java,true)
            }

            override fun onDeny(deniedPermissions: Array<out String>?, neverAskPermissions: Array<out String>?) {
                gotoActivity(MainActivity::class.java,true)
            }

            override fun onNotDeclared(permissions: Array<out String>?) {
                gotoActivity(MainActivity::class.java,true)
            }
        }, Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION)
    }

    override fun initData() {

    }

}