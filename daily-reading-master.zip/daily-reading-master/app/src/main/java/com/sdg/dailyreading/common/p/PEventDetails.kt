package com.sdg.dailyreading.common.p

import com.sdg.common.BaseRxPresenter
import com.sdg.dailyreading.common.v.VEventDetails
import com.sdg.dailyreading.common.v.VSplash

class PEventDetails : BaseRxPresenter<VEventDetails>() {

}