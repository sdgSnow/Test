package com.sdg.dailyreading.api.entiy

class DayWordEntity {

    var code: Int? = null
    var msg: String? = null
    var data: List<DataBean>? = null

    class DataBean {
        var content: String? = null
        var author: String? = null
    }
}