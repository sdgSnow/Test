package com.sdg.dailyreading.api.task

import com.dimeno.network.callback.RequestCallback
import com.sdg.dailyreading.api.CommonParamTask

class DayWordTask(callback:RequestCallback<*>) : CommonParamTask(callback) {
    override fun getApi(): String {
        return "/daily_word/recommend"
    }
}