package com.sdg.dailyreading.utils

import androidx.appcompat.widget.AppCompatImageView
import com.sdg.dailyreading.R
import com.sdg.dailyreading.contants.Type
import java.text.SimpleDateFormat
import java.util.*

class MyUtils {

    companion object{
        /**
         * 获取当前时间并格式化为 yyyyMMdd
         */
        fun getCurrentTime(): String? {
            val df = SimpleDateFormat("yyyyMMdd")
            val l = System.currentTimeMillis()
            return df.format(Date(l))
        }

        /**
         * 转换周*
         * */
        fun getWeekDay(type:Int?):String{
            return when(type){
                1 -> Type.WeekDay.Monday
                2 -> Type.WeekDay.Tuesday
                3 -> Type.WeekDay.Wednesday
                4 -> Type.WeekDay.Thursday
                5 -> Type.WeekDay.Friday
                6 -> Type.WeekDay.Saturday
                7 -> Type.WeekDay.Sunday
                else -> "周*"
            }
        }

        /**
         * 天气描述转type
         晴 少云 晴间多云 多云 阴
        有风 平静 微风 和风 清风 强风/劲风 疾风 大风 烈风 风暴 狂爆风 飓风 热带风暴
        霾 中度霾 重度霾 严重霾
        阵雨 雷阵雨 雷阵雨并伴有冰雹 小雨 中雨 大雨 暴雨 大暴雨 特大暴雨 强阵雨 强雷阵雨 极端降雨 毛毛雨/细雨 雨 小雨-中雨 中雨-大雨 大雨-暴雨 暴雨-大暴雨 大暴雨-特大暴雨
        雨雪天气 雨夹雪 阵雨夹雪 冻雨 雪 阵雪 小雪 中雪 大雪 暴雪 小雪-中雪 中雪-大雪 大雪-暴雪
        浮尘 扬沙 沙尘暴 强沙尘暴 龙卷风
        雾 浓雾 强浓雾 轻雾 大雾 特强浓雾
        热 冷 未知
         * */
        private fun getWeatherType(weather: String?):Int{
            when(weather){
                "晴" -> return Type.Weather.sunny
                "少云" -> return Type.Weather.sunny
                "晴间多云" -> return Type.Weather.sunny
                "多云" -> return Type.Weather.sunny
                "阴" -> return Type.Weather.sunny
                "有风" -> return Type.Weather.wind
                "平静" -> return Type.Weather.wind
                "微风" -> return Type.Weather.wind
                "和风" -> return Type.Weather.wind
                "清风" -> return Type.Weather.wind
                "强风/劲风" -> return Type.Weather.wind
                "疾风" -> return Type.Weather.wind
                "大风" -> return Type.Weather.wind
                "烈风" -> return Type.Weather.wind
                "风暴" -> return Type.Weather.wind
                "狂爆风" -> return Type.Weather.wind
                "飓风" -> return Type.Weather.wind
                "热带风暴" -> return Type.Weather.wind
                "龙卷风" -> return Type.Weather.wind
                "霾" -> return Type.Weather.haze
                "中度霾" -> return Type.Weather.haze
                "重度霾" -> return Type.Weather.haze
                "严重霾" -> return Type.Weather.haze
                "阵雨" -> return Type.Weather.rain
                "雷阵雨" -> return Type.Weather.rain
                "雷阵雨并伴有冰雹" -> return Type.Weather.rain
                "小雨" -> return Type.Weather.rain
                "中雨" -> return Type.Weather.rain
                "大雨" -> return Type.Weather.rain
                "暴雨" -> return Type.Weather.rain
                "大暴雨" -> return Type.Weather.rain
                "特大暴雨" -> return Type.Weather.rain
                "强阵雨" -> return Type.Weather.rain
                "强雷阵雨" -> return Type.Weather.rain
                "极端降雨" -> return Type.Weather.rain
                "毛毛雨/细雨" -> return Type.Weather.rain
                "雨" -> return Type.Weather.rain
                "小雨-中雨" -> return Type.Weather.rain
                "中雨-大雨" -> return Type.Weather.rain
                "大雨-暴雨" -> return Type.Weather.rain
                "暴雨-大暴雨" -> return Type.Weather.rain
                "大暴雨-特大暴雨" -> return Type.Weather.rain
                "雨雪天气" -> return Type.Weather.snow
                "雨夹雪" -> return Type.Weather.snow
                "阵雨夹雪" -> return Type.Weather.snow
                "冻雨" -> return Type.Weather.snow
                "雪" -> return Type.Weather.snow
                "阵雪" -> return Type.Weather.snow
                "小雪" -> return Type.Weather.snow
                "中雪" -> return Type.Weather.snow
                "大雪" -> return Type.Weather.snow
                "暴雪" -> return Type.Weather.snow
                "小雪-中雪" -> return Type.Weather.snow
                "中雪-大雪" -> return Type.Weather.snow
                "大雪-暴雪" -> return Type.Weather.snow
                "浮尘" -> return Type.Weather.sand
                "扬沙" -> return Type.Weather.sand
                "沙尘暴" -> return Type.Weather.sand
                "强沙尘暴" -> return Type.Weather.sand
                "雾" -> return Type.Weather.fog
                "浓雾" -> return Type.Weather.fog
                "强浓雾" -> return Type.Weather.fog
                "轻雾" -> return Type.Weather.fog
                "大雾" -> return Type.Weather.fog
                "特强浓雾" -> return Type.Weather.fog
                else -> return Type.Weather.unknown
            }
        }

        fun setWeatherIcon(weather: String?,icon:AppCompatImageView){
            when(getWeatherType(weather)){
                Type.Weather.unknown -> icon.setBackgroundResource(R.mipmap.unknown)
                Type.Weather.sunny -> icon.setBackgroundResource(R.mipmap.sunny)
                Type.Weather.wind -> icon.setBackgroundResource(R.mipmap.wind)
                Type.Weather.haze -> icon.setBackgroundResource(R.mipmap.haze)
                Type.Weather.rain -> icon.setBackgroundResource(R.mipmap.rain)
                Type.Weather.snow -> icon.setBackgroundResource(R.mipmap.snow)
                Type.Weather.sand -> icon.setBackgroundResource(R.mipmap.sand)
                Type.Weather.fog -> icon.setBackgroundResource(R.mipmap.fog)
            }
        }

        private fun getSolarTermType(solarTerm:String):Int{
            if(solarTerm.contains("立春")) return Type.SolarTermType.solarTerm1
            if(solarTerm.contains("雨水")) return Type.SolarTermType.solarTerm2
            if(solarTerm.contains("惊蛰")) return Type.SolarTermType.solarTerm3
            if(solarTerm.contains("春分")) return Type.SolarTermType.solarTerm4
            if(solarTerm.contains("清明")) return Type.SolarTermType.solarTerm5
            if(solarTerm.contains("谷雨")) return Type.SolarTermType.solarTerm6
            if(solarTerm.contains("立夏")) return Type.SolarTermType.solarTerm7
            if(solarTerm.contains("小满")) return Type.SolarTermType.solarTerm8
            if(solarTerm.contains("芒种")) return Type.SolarTermType.solarTerm9
            if(solarTerm.contains("夏至")) return Type.SolarTermType.solarTerm10
            if(solarTerm.contains("小暑")) return Type.SolarTermType.solarTerm11
            if(solarTerm.contains("大暑")) return Type.SolarTermType.solarTerm12
            if(solarTerm.contains("立秋")) return Type.SolarTermType.solarTerm13
            if(solarTerm.contains("处暑")) return Type.SolarTermType.solarTerm14
            if(solarTerm.contains("白露")) return Type.SolarTermType.solarTerm15
            if(solarTerm.contains("秋分")) return Type.SolarTermType.solarTerm16
            if(solarTerm.contains("寒露")) return Type.SolarTermType.solarTerm17
            if(solarTerm.contains("霜降")) return Type.SolarTermType.solarTerm18
            if(solarTerm.contains("立冬")) return Type.SolarTermType.solarTerm19
            if(solarTerm.contains("小雪")) return Type.SolarTermType.solarTerm20
            if(solarTerm.contains("大雪")) return Type.SolarTermType.solarTerm21
            if(solarTerm.contains("冬至")) return Type.SolarTermType.solarTerm22
            if(solarTerm.contains("小寒")) return Type.SolarTermType.solarTerm23
            if(solarTerm.contains("大寒")) return Type.SolarTermType.solarTerm24

            return Type.SolarTermType.solarTerm1
        }

        fun setSolarTerm(solarTerm: String?,ivSolarTerm:AppCompatImageView){
            when(getSolarTermType(solarTerm!!)){
                Type.SolarTermType.solarTerm1 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm1)
                Type.SolarTermType.solarTerm2 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm2)
                Type.SolarTermType.solarTerm3 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm3)
                Type.SolarTermType.solarTerm4 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm4)
                Type.SolarTermType.solarTerm5 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm5)
                Type.SolarTermType.solarTerm6 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm6)
                Type.SolarTermType.solarTerm7 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm7)
                Type.SolarTermType.solarTerm8 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm8)
                Type.SolarTermType.solarTerm9 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm9)
                Type.SolarTermType.solarTerm10 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm10)
                Type.SolarTermType.solarTerm11 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm11)
                Type.SolarTermType.solarTerm12 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm12)
                Type.SolarTermType.solarTerm13 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm13)
                Type.SolarTermType.solarTerm14 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm14)
                Type.SolarTermType.solarTerm15 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm15)
                Type.SolarTermType.solarTerm16 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm16)
                Type.SolarTermType.solarTerm17 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm17)
                Type.SolarTermType.solarTerm18 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm18)
                Type.SolarTermType.solarTerm19 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm19)
                Type.SolarTermType.solarTerm20 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm20)
                Type.SolarTermType.solarTerm21 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm21)
                Type.SolarTermType.solarTerm22 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm22)
                Type.SolarTermType.solarTerm23 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm23)
                Type.SolarTermType.solarTerm24 -> ivSolarTerm.setBackgroundResource(R.mipmap.solarterm24)
            }
        }
    }
}