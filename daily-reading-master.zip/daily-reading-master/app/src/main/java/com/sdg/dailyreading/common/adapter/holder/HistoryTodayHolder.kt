package com.sdg.dailyreading.common.adapter.holder

import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import com.bumptech.glide.Glide
import com.dimeno.adapter.base.RecyclerViewHolder
import com.sdg.dailyreading.R
import com.sdg.dailyreading.api.entiy.DayEventEntity

class HistoryTodayHolder(parent: ViewGroup?) : RecyclerViewHolder<DayEventEntity.DataBean>(parent!!, R.layout.item_day_event) {
    override fun bind() {
        val ivHistoryTodayBack = findViewById<AppCompatImageView>(R.id.ivHistoryTodayBack)
        Glide.with(itemView.context).load(R.mipmap.event_back_one).into(ivHistoryTodayBack)
//        setIvBack(adapterPosition % 4,ivHistoryTodayBack)
        findViewById<AppCompatTextView>(R.id.tvTime).apply {
            text = mData.year+mData.month+mData.day
        }
        findViewById<AppCompatTextView>(R.id.tvTitle).apply {
            text = mData.title
        }
    }

    private fun setIvBack(type:Int, ivHistoryTodayBack:AppCompatImageView){
        when(type){
            0 -> Glide.with(itemView.context).load(R.mipmap.event_back_one).into(ivHistoryTodayBack)
            1 -> Glide.with(itemView.context).load(R.mipmap.event_back_two).into(ivHistoryTodayBack)
            2 -> Glide.with(itemView.context).load(R.mipmap.event_back_three).into(ivHistoryTodayBack)
            3 -> Glide.with(itemView.context).load(R.mipmap.event_back_four).into(ivHistoryTodayBack)
            else -> Glide.with(itemView.context).load(R.mipmap.event_back_four).into(ivHistoryTodayBack)
        }
    }

}