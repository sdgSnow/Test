package com.czt.mp3recorder;

/**
 * Created by hss01248 on 2016/3/3.
 */
public class AudioNoPermissionEvent {
}
