package com.dimeno.threadlib;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :优先级
 * 不要改变排列顺序
 */
public enum Priority {
    /**
     * Lowest priority level. Used for prefetches of data.
     */
    LOW,

    /**
     * Medium priority level. Used for warming of data that might soon get visible.
     */
    MEDIUM,

    /**
     * Highest priority level. Used for data that are currently visible on screen.
     */
    HIGH,

    /**
     * Highest priority level. Used for data that are required instantly(mainly for emergency).
     */
    IMMEDIATE;
}
