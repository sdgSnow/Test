package com.dimeno.threadlib;

import java.util.concurrent.ThreadFactory;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :通过线程工厂中线程优先级
 *
 * 线程优先级有以下几种：
 * int THREAD_PRIORITY_AUDIO //标准音乐播放使用的线程优先级
 * int THREAD_PRIORITY_BACKGROUND //标准后台程序
 * int THREAD_PRIORITY_DEFAULT // 默认应用的优先级
 * int THREAD_PRIORITY_DISPLAY //标准显示系统优先级，主要是改善UI的刷新
 * int THREAD_PRIORITY_FOREGROUND //标准前台线程优先级
 * int THREAD_PRIORITY_LESS_FAVORABLE //低于favorable
 * int THREAD_PRIORITY_LOWEST //有效的线程最低的优先级
 * int THREAD_PRIORITY_MORE_FAVORABLE //高于favorable
 * int THREAD_PRIORITY_URGENT_AUDIO //标准较重要音频播放优先级
 * int THREAD_PRIORITY_URGENT_DISPLAY //标准较重要显示优先级，对于输入事件同样适用。
 *
 * Created by Tim on 2018/9/3.
 */
public class PriorityThreadFactory implements ThreadFactory {

    private final int mThreadPriority;

    public PriorityThreadFactory(int threadPriority) {
        mThreadPriority = threadPriority;
    }

    @Override
    public Thread newThread(final Runnable runnable) {
        Runnable wrapperRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    //设置线程优先级为后台，这样当多个线程并发后很多无关紧要的线程分配的CPU时间将会减少，有利于主线程的处理
                    android.os.Process.setThreadPriority(mThreadPriority);
                } catch (Throwable t) {

                }
                runnable.run();
            }
        };
        return new Thread(wrapperRunnable);
    }

}