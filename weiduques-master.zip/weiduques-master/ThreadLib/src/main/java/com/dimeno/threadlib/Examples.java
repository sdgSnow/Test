package com.dimeno.threadlib;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :线程池使用实例
 */
public class Examples {
    /*
     * Using it for Background Tasks
     * 将其用于后台任务
     * 例如Bitmap生成等耗时任务
     */
    public void doSomeBackgroundWork() {
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        // do some background work here.
                    }
                });
    }

    /*
     * Using it for Light-Weight Background Tasks
     * 将其用于轻量级背景任务
     * 例如数据库查询
     */
    public void doSomeLightWeightBackgroundWork() {
        ExecutorHandler.getInstance().forLightWeightBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        // do some light-weight background work here.
                    }
                });
    }

    /*
     * Using it for MainThread Tasks
     * 将其用于MainThread任务
     */
    public void doSomeMainThreadWork() {
        ExecutorHandler.getInstance().forMainThreadTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        // do some Main Thread work here.
                    }
                });
    }

    /*
     * do some task at high priority
     * 高优先级地完成一些任务
     */
    public void doSomeTaskAtHighPriority() {
        ExecutorHandler.getInstance().forBackgroundTasks()
                .submit(new PriorityRunnable(Priority.HIGH) {
                    @Override
                    public void run() {
                        // do some background work here at high priority.
                    }
                });
    }
}
