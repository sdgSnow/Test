package com.dimeno.threadlib;

import android.util.Log;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :线程池助手
 * 注：暂无ScheduledThreadPoolExecutor 定时任务的功能
 * <p>
 * 线程池饱和策略:
 * 在使用线程池并且使用有界队列的时候，如果队列满了，任务添加到线程池的时候就会有问题，针对这些问题java线程池提供了以下几种策略：
 * AbortPolicy该策略是线程池的默认策略。使用该策略时，如果线程池队列满了丢掉这个任务并且抛出RejectedExecutionException异常。
 * DiscardPolicy 这个策略和AbortPolicy的slient版本，如果线程池队列满了，会直接丢掉这个任务并且不会有任何异常。
 * DiscardOldestPolicy 这个策略从字面上也很好理解，丢弃最老的。也就是说如果队列满了，会将最早进入队列的任务删掉腾出空间，再尝试加入队列。因为队列是队尾进，队头出，所以队头元素是最老的，因此每次都是移除对头元素后再尝试入队。
 * CallerRunsPolicy 使用此策略，如果添加到线程池失败，那么主线程会自己去执行该任务，不会等待线程池中的线程去执行。就像是个急脾气的人，我等不到别人来做这件事就干脆自己干。哈哈哈。。。
 * RejectedExecutionHandler 如果以上策略都不符合业务场景，那么可以自己定义一个拒绝策略，只要实现RejectedExecutionHandler接口,并且实现rejectedExecution方法就可以了。具体的逻辑就在rejectedExecution方法里去定义就OK了。
 * Created by Tim on 2018/9/3.
 */
public class ExecutorHandler implements RejectedExecutionHandler {
    //核心线程数
    public static final int NUMBER_OF_CORES = Runtime.getRuntime().availableProcessors();

    private final ThreadPoolExecutor mForBackgroundTasks;
    private final ThreadPoolExecutor mForLightWeightBackgroundTasks;
    private final Executor mMainThreadExecutor;
    private static ExecutorHandler sInstance;

    public static ExecutorHandler getInstance() {
        if (sInstance == null) {
            synchronized (ExecutorHandler.class) {
                sInstance = new ExecutorHandler();
            }
        }
        return sInstance;

    }

    private ExecutorHandler() {

        //标准后台程序
        ThreadFactory backgroundPriorityThreadFactory = new
                PriorityThreadFactory(android.os.Process.THREAD_PRIORITY_BACKGROUND);

        // setting the thread pool executor for mForBackgroundTasks;
        mForBackgroundTasks = new ThreadPoolExecutor(
                NUMBER_OF_CORES * 8,
                NUMBER_OF_CORES * 16,
                30,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(),
                backgroundPriorityThreadFactory,
                this
        );

        // setting the thread pool executor for mForLightWeightBackgroundTasks;
        mForLightWeightBackgroundTasks = new ThreadPoolExecutor(
                NUMBER_OF_CORES * 16,
                NUMBER_OF_CORES * 32,
                20,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(),
                backgroundPriorityThreadFactory,
                this
        );

        // setting the thread pool executor for mMainThreadExecutor;
        mMainThreadExecutor = new MainThreadExecutor();
    }

    /**
     * 执行重量级任务
     * returns the thread pool executor for background task
     */
    public ThreadPoolExecutor forBackgroundTasks() {
        return mForBackgroundTasks;
    }

    /**
     * 执行轻量级任务
     * returns the thread pool executor for light weight background task
     */
    public ThreadPoolExecutor forLightWeightBackgroundTasks() {
        return mForLightWeightBackgroundTasks;
    }

    /**
     * 在主线程执行任务
     * returns the thread pool executor for main thread task
     */
    public Executor forMainThreadTasks() {
        return mMainThreadExecutor;
    }

    /*public void clear() {
        try {
            mForLightWeightBackgroundTasks.shutdownNow();
            mForBackgroundTasks.shutdownNow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
        //达到拒绝策略的条件时，仅仅只是打印一个LOG 什么都不做
        Log.e("Tim", "rejectedExecution: ");
    }
}