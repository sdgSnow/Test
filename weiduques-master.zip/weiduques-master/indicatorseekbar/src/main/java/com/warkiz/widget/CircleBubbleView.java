package com.warkiz.widget;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Created by ZhuangGuangquan on 2017/12/13.
 */

class CircleBubbleView extends View {
    private int mIndicatorTextColor;
    private int mIndicatorColor;
    private int mIndicatorTextSize;
    private Context mContext;
    private Path mPath;
    private Paint mPaint;
    private float mIndicatorWidth;
    private float mIndicatorHeight;
    private float mTextHeight;
    private String mProgress;

    /**
     * CircleBubbleView
     * @param context
     */
    CircleBubbleView(Context context) {
        this(context, null);
    }

    /**
     * CircleBubbleView
     * @param context
     * @param attrs
     */
    CircleBubbleView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * CircleBubbleView
     * @param context
     * @param attrs
     * @param defStyleAttr
     */
    CircleBubbleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init("100");
    }

    /**
     * CircleBubbleView
     * @param p
     * @param maxLengthText
     */
    CircleBubbleView(BuilderParams p, String maxLengthText) {
        super(p.mContext, null, 0);
        this.mContext = p.mContext;
        this.mIndicatorTextSize = p.mIndicatorTextSize;
        this.mIndicatorTextColor = p.mIndicatorTextColor;
        this.mIndicatorColor = p.mIndicatorColor;
        init(maxLengthText);
    }

    /**
     * init
     * @param maxLengthText
     */
    private void init(String maxLengthText) {
        //初始化画笔
        mPaint = new Paint();
        //去锯齿
        mPaint.setAntiAlias(true);
        //设置宽度
        mPaint.setStrokeWidth(1);
        //字体方向
        mPaint.setTextAlign(Paint.Align.CENTER);
        //字体大小
        mPaint.setTextSize(mIndicatorTextSize);
        //初始化rect
        Rect mRect = new Rect();
        mPaint.getTextBounds(maxLengthText, 0, maxLengthText.length(), mRect);
        mIndicatorWidth = mRect.width() + IndicatorUtils.dp2px(mContext, 4);
        int minWidth = IndicatorUtils.dp2px(mContext, 36);
        if (mIndicatorWidth < minWidth) {
            mIndicatorWidth = minWidth;
        }
        mTextHeight = mRect.height();
        mIndicatorHeight = mIndicatorWidth * 1.2f;
        initPath();
    }

    /**
     * initPath
     */
    private void initPath() {
        mPath = new Path();
        RectF rectF = new RectF(0, 0, mIndicatorWidth, mIndicatorWidth);
        mPath.arcTo(rectF, 135, 270);
        mPath.lineTo(mIndicatorWidth / 2, mIndicatorHeight);
        mPath.close();
    }

    /**
     * 测量
     * @param widthMeasureSpec
     * @param heightMeasureSpec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension((int) mIndicatorWidth, (int) mIndicatorHeight);
    }

    /**
     * 绘制
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        mPaint.setColor(mIndicatorColor);
        canvas.drawPath(mPath, mPaint);
        mPaint.setColor(mIndicatorTextColor);
        canvas.drawText(mProgress, mIndicatorWidth / 2f, mIndicatorHeight / 2 + mTextHeight / 4, mPaint);
    }

    /**
     * 设置进度
     * @param progress
     */
    void setProgress(String progress) {
        this.mProgress = progress;
        invalidate();
    }

}
