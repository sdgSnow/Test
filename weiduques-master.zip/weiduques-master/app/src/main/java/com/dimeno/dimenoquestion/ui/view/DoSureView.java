package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.QueBean;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface DoSureView extends BaseView {
    /**
     * 失败回调
     * @param sucess
     * @param message
     */
    void loadFailure(boolean sucess,String message);

    /**
     * 成功回调
     * @param queBean
     */
    void initQueEntity(QueBean queBean);
}
