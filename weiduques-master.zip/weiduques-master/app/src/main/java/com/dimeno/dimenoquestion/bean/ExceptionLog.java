package com.dimeno.dimenoquestion.bean;

/**
 * Create by   :PNJ
 * Date        :2021/8/25
 * Description :日志
 */
public class ExceptionLog {
    private String id;
    /**
     * 调查员id
     */
    private String userId;
    /**
     * 问卷id
     */
    private String queId;
    /**
     * 答卷编码
     */
    private String enterAnswerId;
    /**
     * 文件类型 1问卷。2答卷
     */
    private String fileType;
    /**
     * 备注
     */
    private String remark;
    /**
     * 文件状态
     */
    private Integer fileStatus;
    /**
     * 状态\r\n-1：删除\r\n0：等待导出\r\n1：执行导出\r\n2：导出完成
     */
    private Integer status;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private String updateTime;
    /**
     * 下载地址
     */
    private String fileUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getQueId() {
        return queId;
    }

    public void setQueId(String queId) {
        this.queId = queId;
    }

    public String getEnterAnswerId() {
        return enterAnswerId;
    }

    public void setEnterAnswerId(String enterAnswerId) {
        this.enterAnswerId = enterAnswerId;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(Integer fileStatus) {
        this.fileStatus = fileStatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }
}
