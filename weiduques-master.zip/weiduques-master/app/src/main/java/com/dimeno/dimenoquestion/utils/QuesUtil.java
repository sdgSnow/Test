package com.dimeno.dimenoquestion.utils;


import com.blankj.utilcode.util.SPUtils;
import com.dimeno.dimenoquestion.bean.NewQuesBean;

import java.util.ArrayList;

/**
 * 用户信息sp工具类
 */
public class QuesUtil {
    private static final SPUtils spUtils = SPUtils.getInstance(SPkeyConstantUtil.SSP_KEY);

    public static void setAnswerCode(String aboutUs) {
        spUtils.put("answerCode", aboutUs);
    }

    public static String getAnswerCode() {
        return spUtils.getString("answerCode");
    }



    public static void clear() {
        spUtils.clear();
    }

}

