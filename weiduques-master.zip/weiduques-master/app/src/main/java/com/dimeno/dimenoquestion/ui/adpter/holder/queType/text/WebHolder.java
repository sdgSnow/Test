package com.dimeno.dimenoquestion.ui.adpter.holder.queType.text;

import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.blankj.utilcode.util.RegexUtils;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.MultiBlankAdapter;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :网站
 */
public class WebHolder extends RecyclerViewHolder<AttrBean> {

    private ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks;
    private TextView mLeftText;
    private TextView mRightText;
    private EditText editText;
    private SpannableStringBuilder title;
    private MultiBlankAdapter.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param multiFillBlanks
     * @param onChildClickLisener
     * @param type
     */
    public WebHolder(@NonNull ViewGroup parent, ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks, MultiBlankAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_multi_blank);
        this.multiFillBlanks = multiFillBlanks;
        mLeftText =findViewById(R.id.tv_title);
        mRightText =findViewById(R.id.tv_right_text);
        editText =findViewById(R.id.et_fill_multi_blank);
        editText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});

        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
    }
    @Override
    public void bind() {
        if(type.equals("look")){
            editText.setClickable(false);
            editText.setEnabled(false);
        }
        title= StringUtils.getTitle(mData.getLeftText(),mData.isMust());
        mLeftText.setText(title);
        mRightText.setText(mData.getRightText());
        editText.setHint("请输入网站");
        //editText软键盘的EditorAction监控
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        editText.addTextChangedListener(new AbsTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
                    multiFillBlanks.get(getAdapterPosition()).fillText = s.toString();
                }
                if(mData.isMust()) {
                    //只有满足条件，才去核验去框
                    if(!StringUtils.isEmpty(s.toString()) && StringUtils.checkValue(CharFormatPattern.WEBSITE, s.toString()) && onChildClickLisener!=null){
                        onChildClickLisener.onChildClick();
                    }
                }else {
                    if (onChildClickLisener != null) {
                        onChildClickLisener.onChildClick();
                    }
                }
            }
        });
        if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
            multiFillBlanks.get(getAdapterPosition()).format = CharFormat.WEBSITE;
            editText.setText(multiFillBlanks.get(getAdapterPosition()).fillText);
        }
    }


}
