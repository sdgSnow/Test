package com.dimeno.dimenoquestion.ui.actvity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.blankj.utilcode.util.AppUtils;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.dialog.NormalDialog;
import com.dimeno.common.utils.GsonUtils;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AppInfoEntity;
import com.dimeno.dimenoquestion.constant.Constant;
import com.dimeno.dimenoquestion.utils.AppUpdateBean;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.HProgressDialogUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UpdateAppHttpUtil;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.PermissionCallback;
import com.socks.library.KLog;
import com.vector.update_app.UpdateAppBean;
import com.vector.update_app.UpdateAppManager;
import com.vector.update_app.UpdateCallback;
import com.vector.update_app.service.DownloadService;
import com.vector.update_app.utils.AppUpdateUtils;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableObserver;

import static com.dimeno.dimenoquestion.constant.Constant.mUpdateUrl;

/**
 * Create by   :PNJ
 * Date        :2021/3/15
 * Description :
 */
public class SplashActivity extends BaseActivity {
    ConstraintLayout splash_bg;
    ImageView iv_spalsh_logo;
    TextView tv_sys_name;

    private boolean isShowDownloadProgress = true;
    private AlertView tipAlert;
    private Runnable runnable;
    private boolean flag = false;

    @Override
    protected void initThings(Bundle savedInstanceState) {
        splash_bg=findViewById(R.id.splash_bg);
        iv_spalsh_logo=findViewById(R.id.iv_spalsh_logo);
        tv_sys_name=findViewById(R.id.tv_sys_name);

        SpUtil.get().setQueLst("");

        fitDarkStatusBar(true);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_splash;
    }

    @Override
    protected void initViews() {
        getPermission();
    }

    @Override
    protected BasePresenter createPresenter() {
        return null;
    }

    @Override
    public void initListeners() {

    }

    private void getPermission() {
        PermissionManager.request(this, new PermissionCallback() {
                    @Override
                    public void onGrant(String[] permissions) {
//                FileUtils.createDirectoryIfNotExist(getExternalCacheDir()+"/weiduques/audio/");
                        FileUtils.createDirectoryIfNotExist(Constant.AUDIO_BASE_PATH);
                        FileUtils.createDirectoryIfNotExist(Constant.SIGN_PIC_BASE_PATH);
                        FileUtils.createDirectoryIfNotExist(LogUtils.MYLOG_PATH);
                        FileUtils.createDirectoryIfNotExist(Constant.COPY_PATH);
                        FileUtils.createDirectoryIfNotExist(Constant.ZIP_PATH);
                        FileUtils.createDirectoryIfNotExist(Constant.QUE_DETAIL);//问卷详情
                        //清除过期日记
                        LogUtils.delFile();
                        initCheckVersion();

                    }

                    @Override
                    public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                        showTipDialog();
                    }

                    @Override
                    public void onNotDeclared(String[] permissions) {
                    }
                }, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION
                ,Manifest.permission.RECORD_AUDIO, Manifest.permission.WAKE_LOCK);
    }
    public void next(){
        Observable.timer(1, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableObserver<Long>() {
                    @Override
                    public void onNext(@NonNull Long aLong) {
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                    }

                    @Override
                    public void onComplete() {
                        if(UserUtil.getIsLogin()){
                            gotoActivity(MainActivity.class,true);
                        }else {
                            gotoActivity(LoginActivity.class,true);
                        }
                    }
                });
    }

    public void initCheckVersion() {
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android" +
                "/data/" + AppUtils.getAppPackageName() + "/files/apk/";
        Map<String, String> params = new HashMap<>();
        params.put("appKey", "ab55ce55Ac4bcP408cPb8c1Aaeac179c5f6f");

        new UpdateAppManager
                .Builder()
                //必须设置，当前Activity
                .setActivity(SplashActivity.this)
                //必须设置，实现httpManager接口的对象
                .setHttpManager(new UpdateAppHttpUtil())
                //必须设置，更新地址
                .setUpdateUrl(mUpdateUrl)

                //以下设置，都是可选
                //设置请求方式，默认get
                .setPost(false)
                //添加自定义参数，默认version=1.0.0（app的versionName）；apkKey=唯一表示（在AndroidManifest.xml配置）
                .setParams(params)
                //设置apk下砸路径，默认是在下载到sd卡下/Download/1.0.0/test.apk
                .setTargetPath(path)
                //设置appKey，默认从AndroidManifest.xml获取，如果，使用自定义参数，则此项无效
                .setAppKey("ab55ce55Ac4bcP408cPb8c1Aaeac179c5f6f")
                .build()
                //检测是否有新版本
                .checkNewApp(new UpdateCallback() {
                    /**
                     * 解析json,自定义协议
                     *
                     * @param json 服务器返回的json
                     * @return UpdateAppBean
                     */
                    @Override
                    protected UpdateAppBean parseJson(String json) {
                        AppInfoEntity appInfoEntity = GsonUtils.getInstance().fromJson(json, AppInfoEntity.class);
                        UpdateAppBean updateAppBean = new UpdateAppBean();
                        if (appInfoEntity.getFlag() == 0) {
                            AppInfoEntity.ResultObjBean resultObj = appInfoEntity.getResultObj();
                            if(resultObj!=null) {
                                if (AppUpdateUtils.getVersionCode(SplashActivity.this) < resultObj.getVersionCode()) {
                                    updateAppBean.setUpdate("Yes");
                                    updateAppBean.setConstraint(resultObj.getLastForce() == 1);
                                    updateAppBean
                                            .setNewVersion(resultObj.getVersionName())
                                            .setUpdateLog(resultObj.getUpdateLog())
                                            .setApkFileUrl(resultObj.getUpdateurl())
                                            .setTag(resultObj.getYl_03());
                                } else {
                                    updateAppBean.setUpdate("No");
                                }
                                return updateAppBean;
                            }
                        }
                        return null;
                    }

                    /**
                     * 有新版本
                     *
                     * @param updateApp        新版本信息
                     * @param updateAppManager app更新管理器
                     */
                    @Override
                    public void hasNewApp(UpdateAppBean updateApp,
                                          UpdateAppManager updateAppManager) {
                        if (!isFinishing()) {
                            //强制更新，
                            if (updateApp != null && updateAppManager != null) {
                                if (updateApp.isConstraint()) {

                                } else {

                                }
                                //自定义对话框
                                showDiyDialog(updateApp, updateAppManager);
                            }
                        }
                    }

                    /**
                     * 网路请求之后
                     */
                    @Override
                    public void onAfter() {
                    }

                    /**
                     * 没有新版本
                     */
                    @Override
                    protected void noNewApp() {
                        super.noNewApp();
                        next();
                    }

                    /**
                     * 网络请求之前
                     */
                    @Override
                    public void onBefore() {
                    }
                });
    }

    /**
     * 自定义对话框
     *
     * @param updateApp
     * @param updateAppManager
     */
    private void showDiyDialog(UpdateAppBean updateApp, UpdateAppManager updateAppManager) {
        String targetSize = updateApp.getTargetSize();
        String updateLog = updateApp.getUpdateLog();
        if (updateLog != null) {
            updateLog = updateLog.replace("\\n", "\n");//换行
        }
        String msg = "";

        if (!TextUtils.isEmpty(targetSize)) {
            msg = "新版本大小：" + targetSize + "\n\n";
        }

        if (!TextUtils.isEmpty(updateLog)) {
            msg += updateLog;
        }
        if (updateApp.isConstraint()) {
            new AlertDialog.Builder(mContext)
                    .setTitle(String.format("请升级到%s版本", updateApp.getNewVersion()))
                    .setMessage(msg)
                    .setPositiveButton("升级", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (updateApp.getTag().equals("520")) {
                                Uri uri = Uri.parse(updateApp.getApkFileUrl());
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                startActivity(intent);
                            } else {
                                //升级后需要再次登录
                                UserUtil.setIsLogin(false);
                                loadApp(updateAppManager, dialog);
                            }
                        }
                    })
                    .setCancelable(false)
                    .create()
                    .show();
        } else {
            new AlertDialog.Builder(SplashActivity.this)
                    .setTitle(String.format("是否升级到%s版本？", updateApp.getNewVersion()))
                    .setMessage(msg)
                    .setPositiveButton("升级", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (updateApp.getTag().equals("520")) {
                                KLog.e("备选升级 url=" + updateApp.getTag());
                                Uri uri = Uri.parse(updateApp.getApkFileUrl());
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                startActivity(intent);
                            } else {
                                //升级后需要再次登录
                                UserUtil.setIsLogin(false);
                                loadApp(updateAppManager, dialog);
                            }
                        }
                    })
                    .setNegativeButton("暂不升级", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            next();
                        }
                    })
                    .setCancelable(false)
                    .create()
                    .show();
        }
    }

    private void loadApp(UpdateAppManager updateAppManager, DialogInterface dialog) {
        //显示下载进度
        if (isShowDownloadProgress) {
            updateAppManager.download(new DownloadService.DownloadCallback() {
                @Override
                public void onStart() {
                    HProgressDialogUtils.showHorizontalProgressDialog(SplashActivity.this, "下载进度"
                            , false);
                }

                /**
                 * 进度
                 *
                 * @param progress  进度 0.00 -1.00 ，总大小
                 * @param totalSize 总大小 单位B
                 */
                @Override
                public void onProgress(float progress, long totalSize) {
                    HProgressDialogUtils.setProgress(Math.round(progress * 100));
                }

                /**
                 *
                 * @param total 总大小 单位B
                 */
                @Override
                public void setMax(long total) {

                }

                @Override
                public boolean onFinish(File file) {
                    HProgressDialogUtils.cancel();
                    finish();
                    return true;
                }

                @Override
                public void onError(String msg1) {
                    //ToastUtils.showShort(msg1);
                    HProgressDialogUtils.cancel();
                    showTipAlert(msg1, SplashActivity.this);
                }
            });
        } else {
            //不显示下载进度
            updateAppManager.download();
        }
        dialog.dismiss();
    }

    public void showTipAlert(String tip, Activity activity) {
        if (tipAlert == null) {
            tipAlert = new AlertView("", tip, null, new String[]{"确定"}, null, activity, AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {
                    tipAlert.dismiss();
                }
            });
        }
        tipAlert.setCancelable(true);
        tipAlert.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(Object o) {
                tipAlert = null;
            }
        });
        tipAlert.show();
    }

    public void initRunnable() {
        new Handler().postDelayed(runnable = this::goHome, 800);
    }

    private synchronized void goHome() {
        if (!flag) {
            flag = true;
            Intent intent = new Intent();
            if (UserUtil.getIsLogin()) {
                intent.setClass(SplashActivity.this, MainActivity.class);
            } else {
                intent.setClass(SplashActivity.this, LoginActivity.class);
            }
            startActivity(intent);
            finish();
        }
    }

    private AlertView alertQuitView;
    private void showTipDialog() {
        if (alertQuitView == null) {
            alertQuitView = new AlertView("提示", "为了正常使用，请授予权限", "取消", new String[]{"确定"}, null,
                    mContext, AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {

                }
            });
        }
        alertQuitView.show();
    }

}
