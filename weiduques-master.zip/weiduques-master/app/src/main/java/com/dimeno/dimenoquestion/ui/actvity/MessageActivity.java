package com.dimeno.dimenoquestion.ui.actvity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.adapter.base.RecyclerItem;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.dialog.TipDoalog;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.event.LoadMessageEvent;
import com.dimeno.dimenoquestion.ui.adpter.MessageAdapter;
import com.dimeno.dimenoquestion.ui.presenter.MessagePresenter;
import com.dimeno.dimenoquestion.ui.view.MessageView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.widget.BackLeftToolbar;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.dimeno.dimenoquestion.widget.TitleToolbar;
import com.wangzhen.refresh.RefreshLayout;
import com.wangzhen.refresh.callback.OnRefreshCallback;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class MessageActivity extends BaseActivity<MessagePresenter> implements MessageView, OnRefreshCallback {

    private RecyclerView rcyMessage;
    private MessageAdapter adapter;
    private List<MessageEntity.RecordsBean> messageList;
    private RefreshLayout refreshLayout;
    private ConstraintLayout message;
    private int page = 1;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_message;
    }

    @Override
    protected void initThings(Bundle savedInstanceState) {

    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this, "消息通知");
    }

    @Override
    protected void initViews() {
        EventBus.getDefault().register(this);
        message = findViewById(R.id.message);
        rcyMessage = findViewById(R.id.rcyMessage);
        refreshLayout = findViewById(R.id.refreshLayout);
        refreshLayout.setOnRefreshCallback(this);
        refreshLayout.startRefresh();
        rcyMessage.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));

        messageList = new ArrayList<>();
        showMessageList();
        presenter.getAppMessages(mContext,1);
    }

    public void getAppMessages(int page){
        presenter.getAppMessages(mContext,page);
    }

    public void showMessageList() {
        adapter = new MessageAdapter(mContext, messageList,rcyMessage);
        adapter.setEmpty(new RecyclerItem() {
            @Override
            public int layout() {
                return R.layout.empty_message;
            }

            @Override
            public void onViewCreated(View itemView) {

            }
        }.onCreateView(rcyMessage));
        rcyMessage.setAdapter(adapter);
        adapter.setOnClickCallback((itemView, position) -> {
            showTipAlert(adapter.getDatas().get(position).getMsgContent(),mActivity);
        });
    }

    @Override
    protected MessagePresenter createPresenter() {
        return new MessagePresenter();
    }

    @Override
    public void initListeners() {

    }

    @Override
    public void onSucess(List<MessageEntity.RecordsBean> recordsBeans) {
        refreshLayout.refreshComplete();
        if(recordsBeans.size() > 0){
            if(page == 1){
                adapter.setData(recordsBeans);
            }else {
                adapter.addData(recordsBeans);
            }
            page++;
        }else {
            adapter.setState(LoadMoreState.NO_MORE);
        }
    }

    @Override
    public void onFail(String msg) {
        refreshLayout.refreshComplete();
        MyToast.showShortToast(msg);
        if(adapter != null){
            adapter.setState(LoadMoreState.NO_MORE);
//            adapter.setState(LoadMoreState.ERROR);
        }
    }

    @Override
    public void onRefresh() {
        page = 1;
        presenter.getAppMessages(mContext,1);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void chooseAttrEvent(LoadMessageEvent event) {
        presenter.getAppMessages(mContext,page);
    }

    private AlertView tipAlert;
    public void showTipAlert(String tip, Activity activity) {
        tipAlert = new AlertView("", tip, null, new String[]{"确定"}, null, activity, AlertView.Style.Alert, (o, position) ->{
            tipAlert.dismiss();
        });
        if(tipAlert != null && tipAlert.isShowing()){
            tipAlert.dismiss();
        }
        tipAlert.setCancelable(true);
        tipAlert.setOnDismissListener(o -> {

        });
        tipAlert.show();
    }
}