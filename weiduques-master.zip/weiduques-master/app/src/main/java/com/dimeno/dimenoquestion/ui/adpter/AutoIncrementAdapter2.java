package com.dimeno.dimenoquestion.ui.adpter;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.listener.OnChildClickLisener;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.ChinaTextIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.DataIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.DropDownIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.EmailIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.EnglishIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.FillTextIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.IdCardIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.NoLimitTextIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.NumberIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.PhoneIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.QQIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.TelephoneIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment.WebIncreHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.ChinaTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.DataHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EmailHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EnglishHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.IdCardHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.NoLimitTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.NumberHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.PhoneHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.QQHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.TelephoneHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.WebHolder;
import com.dimeno.dimenoquestion.utils.MyLog;

import java.util.ArrayList;
import java.util.List;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :填空题适配
 */
public class AutoIncrementAdapter2 extends RecyclerAdapter<AttrBean> {

    private SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer;
    private List<AttrBean> data=new ArrayList<>();
    //add新添加，edit编辑，look查看
    private String type;
    private int index;

    /**
     * 构造器
     * @param data
     * @param index
     * @param mAutoIncrementAnswer
     * @param type
     */
    public AutoIncrementAdapter2(@Nullable List<AttrBean> data,int index,SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer, String type) {
        super(data);
        this.data=data;
        this.mAutoIncrementAnswer = mAutoIncrementAnswer;
        this.type=type;
        this.index=index;
    }

    /**
     * 设置数据
     * @param data
     * @param mAutoIncrementAnswer
     */
    public void setData(List<AttrBean> data,SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer){
        this.data=data;
        this.mAutoIncrementAnswer = mAutoIncrementAnswer;
        notifyDataSetChanged();
    }

    @Override
    protected int getAbsItemViewType(int position) {
        MyLog.d("getAbsItemViewType","AutoIncrementAdapter2   data.size="+data.size()+"    position="+position);
        if(position>=data.size()){
            return 0;
        }
        if(data.size()==0){
            return 0;
        }
        return data.get(position).getCharFormat();
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case CharFormat.EMAIL:
                //1 邮箱
                return new EmailIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.TEXT:
                //2 中文
                return new ChinaTextIncreHolder(parent,index, mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.ENGLISH:
                //3 英文
                return new EnglishIncreHolder(parent,index, mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.WEBSITE:
                //4 网址
                return new WebIncreHolder(parent,index, mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.ID:
                //5 身份证号码
                return new IdCardIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.QQ:
                //6 QQ号
                return new QQIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.MOBILE_PHONE:
                //7 电话号码
                return new PhoneIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.TELEPHONE:
                //8 固定电话
                return new TelephoneIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.NUMBER:
                //9 数值
                return new NumberIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.DATE:
                //10 日期
                return new DataIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.DROP_DOWN:
                //11 下拉
                return new DropDownIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            case CharFormat.MULTI_TEXT:
                //12 多行文本
                return new FillTextIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
            default:
                //默认
                return new NoLimitTextIncreHolder(parent, index,mAutoIncrementAnswer,onChildClickLisener,type);
        }
    }

    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
    }
    //设置监听器
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }


}
