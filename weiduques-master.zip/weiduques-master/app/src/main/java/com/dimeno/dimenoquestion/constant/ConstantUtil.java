package com.dimeno.dimenoquestion.constant;

/**
 * Create by   :PNJ
 * Date        :2021/3/19
 * Description :
 */
public class ConstantUtil {
    //可见,必须为0，不能该为其它
    public static final int VISIBLE =0;
    //不可见
    public static final int GONE =1;
    //隐藏 2
    public static final int INVISIBLE =2;
    //跳转到修改密码界面的来源
    public static final String SOURCE = "source";
    //MainActivity跳转到修改密码界面
    public static final int MAINACTIVITY = 10;
    //activity回调,刷新数据
    public static final int ACTIVITY_FLUSH =1;
    //下拉题默认选项的值
    public static final String DROPDOWN_DEFAULT_VALUE = "";
}
