package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.blankj.utilcode.util.Utils;
import com.dimeno.dimenoquestion.R;

/**
 * DropDownSpinnerAdapter
 * Created by wangzhen on 2020/5/9.
 */
public class DropDownSpinnerAdapter extends BaseAdapter {
    private Context mContext;
    private String[] mDatas;
    private boolean mRootPosition;

    /**
     * DropDownSpinnerAdapter
     * @param context
     * @param array
     */
    public DropDownSpinnerAdapter(Context context, String[] array) {
        this(context, array, false);
    }

    /**
     * DropDownSpinnerAdapter
     * @param context
     * @param array
     * @param root
     */
    public DropDownSpinnerAdapter(Context context, String[] array, boolean root) {
        this.mContext = context;
        this.mDatas = array;
        this.mRootPosition = root;
    }

    @Override
    public int getCount() {
        return mDatas == null ? 0 : mDatas.length;
    }

    @Override
    public Object getItem(int position) {
        return mDatas[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * getView
     * @param position
     * @param convertView
     * @param parent
     * @return
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_spinner_layout, parent, false);
            convertView.setTag(holder = new Holder(convertView));
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.textView.setText(mDatas[position]);
        //修改第一级下拉选择第一项文本颜色
        holder.textView.setTextColor(
                (mRootPosition && position == 0) ?
                        Utils.getApp().getResources().getColor(R.color.color_8d8d8d)
                        :
                        Utils.getApp().getResources().getColor(R.color.blue));
        return convertView;
    }

    public void setRootPosition(boolean root) {
        this.mRootPosition = root;
    }

    private static class Holder {

        TextView textView;

        Holder(View view) {
            textView = view.findViewById(R.id.tvTitle);
        }
    }
}
