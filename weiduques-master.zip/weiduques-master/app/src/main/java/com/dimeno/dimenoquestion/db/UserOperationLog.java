package com.dimeno.dimenoquestion.db;

import org.litepal.crud.LitePalSupport;

/**
 * 用户操作日志记录表
 * */
public class UserOperationLog extends LitePalSupport {

    public Long id;
    //日志id
    public String logId;
    //用户id
    public String userId;
    //用户名
    public String userName;
    //用户账号
    public String userAccount;
    //创建时间
    public String createTime;
    //APP版本号
    public int appVersionCode;
    //APP版本号
    public String appVersionName;
    //系统设备版本号
    public String versionName;
    //系统设备版本码
    public int versionCode;
    //设备厂商
    public String manufacturer;
    //设备型号
    public String model;
    //当前api
    public String api;
    //操作类型
    public int operationType;
    //操作描述
    public String operationDesc;
    //记录的日志数据
    public String data;
    //是否已上传 0
    public int isUpload;
    //问卷id
    public String queId;
    //答卷编码
    public Long answerStartTime;
    //类型，1 接口返回，2 本地数据上传，
    public int type;
    //上传结果返回
    public String result;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getAppVersionCode() {
        return appVersionCode;
    }

    public void setAppVersionCode(int appVersionCode) {
        this.appVersionCode = appVersionCode;
    }

    public String getAppVersionName() {
        return appVersionName;
    }

    public void setAppVersionName(String appVersionName) {
        this.appVersionName = appVersionName;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getApi() {
        return api;
    }

    public void setApi(String api) {
        this.api = api;
    }

    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }

    public String getOperationDesc() {
        return operationDesc;
    }

    public void setOperationDesc(String operationDesc) {
        this.operationDesc = operationDesc;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getIsUpload() {
        return isUpload;
    }

    public void setIsUpload(int isUpload) {
        this.isUpload = isUpload;
    }

    public String getQueId() {
        return queId;
    }

    public void setQueId(String queId) {
        this.queId = queId;
    }

    public Long getAnswerStartTime() {
        return answerStartTime;
    }

    public void setAnswerStartTime(Long answerStartTime) {
        this.answerStartTime = answerStartTime;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
