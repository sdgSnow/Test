package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.blankj.utilcode.util.Utils;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;

import java.util.List;

public class SpinnerAdapter extends BaseAdapter {
    private List<QueOptionBean> mList;
    private Context mContext;

    /**
     * 构造器
     * @param pContext
     * @param pList
     */
    public SpinnerAdapter(Context pContext, List<QueOptionBean> pList) {
        this.mContext = pContext;
        this.mList = pList;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * 下面是重要代码
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(R.layout.item_spinner_layout, null);
        //AutoUtils.autoSize(convertView);
        if (convertView != null) {
            TextView tv = convertView.findViewById(R.id.tvTitle);
            tv.setText(mList.get(position).getOpText());
            tv.setTextColor(position == 0 ?
                    Utils.getApp().getResources().getColor(R.color.color_8d8d8d)
                    :
                    Utils.getApp().getResources().getColor(R.color.blue));
        }
        return convertView;
    }

}