package com.dimeno.dimenoquestion.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.blankj.utilcode.util.ScreenUtils;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.common.widget.UploadCircleProgressBar;
import com.dimeno.dimenoquestion.R;

/**
 * CircleProgressDialog
 * Created by wangzhen on 2020/6/24.
 */
public class CircleProgressDialog extends Dialog {

    private final UploadCircleProgressBar mProgressBar;
    private final View mContentView;

    public CircleProgressDialog(@NonNull Context context) {
        super(context, R.style.ConfirmDialog);
        mContentView = LayoutInflater.from(context).inflate(R.layout.layout_circle_progress_dialog, null);
        mProgressBar = mContentView.findViewById(R.id.progress);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(mContentView);
    }

    public void setProgress(int progress) {
        if (mProgressBar != null) {
            mProgressBar.setProgress(progress);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = Gravity.CENTER;
            attributes.width = UIUtils.dip2px(getContext(), 60);
            attributes.height = UIUtils.dip2px(getContext(), 60);
            window.setAttributes(attributes);
        }
    }
}
