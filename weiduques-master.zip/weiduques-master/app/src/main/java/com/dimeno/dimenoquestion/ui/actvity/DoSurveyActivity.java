package com.dimeno.dimenoquestion.ui.actvity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.blankj.utilcode.util.NetworkUtils;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.event.Event;
import com.dimeno.common.event.EventBusUtils;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.common.widget.bar.CustomViewPager;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.constant.AnnexFileType;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueBean;
import com.dimeno.dimenoquestion.db.Que;
import com.dimeno.dimenoquestion.map.LocationOnceUtils;
import com.dimeno.dimenoquestion.ui.fragment.DoSurveyFragment;
import com.dimeno.dimenoquestion.ui.presenter.DoSurePresenter;
import com.dimeno.dimenoquestion.ui.view.DoSureView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.BackLeftToolbar;
import com.dimeno.threadlib.ExecutorHandler;
import com.socks.library.KLog;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.dimeno.dimenoquestion.constant.EventConstant.ACCEPT_ANNEX;
import static com.dimeno.dimenoquestion.constant.EventConstant.ADD_ANNEX;
import static com.dimeno.dimenoquestion.constant.EventConstant.SURVEY_STOP;
import static com.dimeno.dimenoquestion.constant.OperationType.ERROR;
import static com.dimeno.dimenoquestion.constant.OperationType.OPERATION;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class DoSurveyActivity extends BaseActivity<DoSurePresenter> implements DoSureView{
    @BindView(R.id.viewPager)
    CustomViewPager viewPager;
    @BindView(R.id.tv_up)
    TextView tv_up;
    @BindView(R.id.tv_next)
    TextView tv_next;

    //Toolbar
    private BackLeftToolbar backToolbar;
    //分页adapter
    private CustomViewPager.MyPagerAdapter adapter;
    //保存Fragment的list
    private List<Fragment> fragList=new ArrayList<>();
    //titles
    private String[] titles;
    //当前fragement
    private int position=0;
    //问卷实体
    private NewQuesBean newQuesBean;
    //类型
    private String type;
    //是否核验成功
    private boolean checkSucess=true;
    //isSavedInstanceState
    private boolean isSavedInstanceState=false;
    //Bundle
    private Bundle savedInstanceState;
    //当前选中的附件类型
    private int curfileType;

    /**
     * 设置布局文件
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_dosurvey;
    }

    /**
     * Toolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        backToolbar=new BackLeftToolbar(this,"立即调查");
        return backToolbar;
    }

    /**
     * 初始化一些参数
     * @param savedInstanceState 缓存数据
     *                           <p>
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
        this.savedInstanceState=savedInstanceState;
        //通过intent获取带过来的参数
        newQuesBean = (NewQuesBean) getIntent().getSerializableExtra("newQuesBean");
        //类型
        type=getIntent().getStringExtra("type");
        //Toolbar显示右标题
        backToolbar.setRightVisible(true);
        //Toolbar设置右标题
        backToolbar.setRightTitle("完成调查");
        //根据savedInstanceState是否等于null判断activity是新建还是销毁重建
        if(savedInstanceState==null){
            //activity第一次创建的时候，savedInstanceState=null，标志isSavedInstanceState=false
            isSavedInstanceState=false;
        }else {
            //因某些操作，acitivity需要销毁，重建再次进来的时候，savedInstanceState是不为空的，携带的参数可以恢复activity
            isSavedInstanceState=true;
        }
        //参数判空
        if(newQuesBean!=null) {
            //初始化答题实体类
            presenter.initAnswer(newQuesBean,type);
            //获取定位
            presenter.location();
            //上一页隐藏
            tv_up.setVisibility(View.GONE);
            //下一页隐藏
            tv_next.setVisibility(View.GONE);
            //设置标题
            backToolbar.setViewTitle(newQuesBean.getQueTitle());
            //设置其能滑动不能换页
            viewPager.setScanScroll(false);
            //根据问卷id，查询数据库
            List<Que> ques =null;
            if(newQuesBean.getID()!=null){
                ques = LitePal.where("queId = ?", newQuesBean.getID()).find(Que.class);
            }
            //是否是本地获取
            boolean isLocal=false;
            QueBean queBean=null;
            //判断本地是否有离线问卷题目
            if (ques != null && ques.size() > 0) {
                //有保存的数据，获取第一个数据
                Que que = ques.get(0);
                if (que != null) {
                    //获取问卷详情
                    ///判空问卷id
                    if(!StringUtils.isEmpty(que.getQueId())){
                        //String queDetail = que.getQueDetail();
                        //根据问卷id获取本地问卷详情
                        String queDetail = FileUtils.readFile(FileUtils.getQuePath(que.getQueId()));
                        //判空
                        if (!TextUtils.isEmpty(queDetail)) {
                            //转换问卷详情实体类
                            queBean = JsonUtil.toObj(queDetail, QueBean.class);
                            //判空
                            if(queBean!=null){
                                //数据内容不为空，如果问卷的更新时间不一致，则重新网络获取
                                if(!StringUtils.isEmpty(queBean.getModifyDate()) && !StringUtils.isEmpty(newQuesBean.getModifyDate()) && queBean.getModifyDate().equals(newQuesBean.getModifyDate())){
                                    //本地获取数据
                                    isLocal=true;
                                    //开始加载题目
                                    loadQueSub(queBean);
                                }
                            }
                        }
                    }
                }
            }

            //如果不是本地获取数据，则网络获取数据
            if(!isLocal){
                //没有保存的数据
                if(!NetworkUtils.isConnected()) {
                    //获取线上的数据，但是在没有网络的情况下，还是要获取本地数据
                    if(queBean!=null){
                        //开始加载题目
                        loadQueSub(queBean);
                    }else {
                        //土司
                        MyToast.showLongToast("当前网络不可用");
                    }
                }else {
                    //根据接口，获取问卷详情
                    presenter.loadQuesList(this, newQuesBean.getID());
                }
            }

        }
    }

    @Override
    protected void initViews() {
        //上一页隐藏
        tv_up.setVisibility(View.GONE);
        //参数判空
        if(newQuesBean!=null){
            //开启录音
            presenter.initRecorder(newQuesBean);
        }
    }


    /**
     * 保存状态
     * @param outState
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        KLog.d("MainActivity","dosurvey onSaveInstanceState");
        try {
            //activiyt销毁的时候，通过fragList循环保存fragment
            //判空
            if(fragList!=null && fragList.size()!=0){
                //循环
                for (int i = 0; i < fragList.size(); i++) {
                    if(fragList.get(i).isAdded()){
                        //保存frament
                        getSupportFragmentManager().putFragment(outState, "fragment"+i, fragList.get(i));
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    protected void onDestroy() {
        //关闭定位
        presenter.stopLocation();
        //暂停录音,不保存
        presenter.stopRecord(false);
        super.onDestroy();
    }

    @OnClick({R.id.tv_up,R.id.tv_next})
    public void myOnclick(View view){
        //点击事件
        switch (view.getId()){
            //上一页
            case R.id.tv_up:
                //当前页码大于0
                if(position>0){
                    //当前页码减一
                    position--;
                    //分页切换
                    viewPager.setCurrentItem(position);
                    //如果当前页码等于0
                    if(position==0){
                        //则没有上一页了，上一页隐藏
                        tv_up.setVisibility(View.GONE);
                        //如果页数大于1，说明是有两页也是的，所以下一页要显示
                        if(fragList.size()>1){
                            //因为返回了上一页，所以下一页显示
                            tv_next.setVisibility(View.VISIBLE);
                        }
                    }else {
                        //当前页码不等于第一页，则表明页码总数大于0
                        //因为返回了上一页，所以下一页显示
                        tv_next.setVisibility(View.VISIBLE);
                    }
                }
                //去掉冒泡
                hideOptionBubble();
                break;
            case R.id.tv_next:
                //下一页
                //如果当前页码小于总页码数
                if(position<fragList.size()-1){
                    //当前页码加一
                    position++;
                    //切换页面
                    viewPager.setCurrentItem(position);
                    //如果当前页码等于总页码数
                    if(position==fragList.size()-1){
                        //下一页隐藏
                        tv_next.setVisibility(View.GONE);
                    }
                    //上一页显示
                    tv_up.setVisibility(View.VISIBLE);
                }
                //去掉冒泡
                hideOptionBubble();
                break;
        }
    }

    /**
     * 去掉冒泡
     */
    public void hideOptionBubble(){
        //集合判空
        if(fragList!=null && fragList.size()!=0){
            //循环fragment
            for (int currentPage = 0; currentPage < fragList.size(); currentPage++) {
                //去掉冒泡
                ((DoSurveyFragment)fragList.get(currentPage)).hideOptionBubble();
            }
        }
    }

    @Override
    protected DoSurePresenter createPresenter() {
        return new DoSurePresenter();
    }

    @Override
    public void initListeners() {
        //toolbar点击事件
        backToolbar.setMyOnClickListener(new BackLeftToolbar.MyOnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.back:
                        //返回，退出
                        showQuitDialog();
                        break;
                    case R.id.rightTitle:
                        //立即调查
                        //去掉冒泡
                        hideOptionBubble();
                        //检查答案
                        checkAnswer();
                        break;
                }
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //监听物理返回键
        if(keyCode==KeyEvent.KEYCODE_BACK){
            //返回退出
            showQuitDialog();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     *  点击提交问卷,核验答案
     */
    public void checkAnswer(){
        //判断Activity销毁
        if(presenter.getMvpView()!=null) {
            ProgressHelper.getInstance().show(DoSurveyActivity.this, "请稍等...", false);
        }
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        //集合判空
                        if(fragList.size()>0) {
                            //循环所有的页面
                            for (int currentPage = 0; currentPage < fragList.size(); currentPage++) {
                                int finalI = currentPage;
                                //初始化检查成功状态为true
                                checkSucess = true;
                                //获取当前页的题目列表
                                ((DoSurveyFragment) fragList.get(currentPage)).getQuesBeanList(new DoSurveyFragment.FramentCallBack() {
                                    @Override
                                    public void getDataList(ArrayList<PageSubjectBean> list) {
                                        //题目列表判空
                                        if (list != null && list.size() != 0) {
                                            //不为空，根据答案页配置答题
                                            presenter.addAnswerPage(finalI, list);
                                            //开始校验各个题型的格式
                                            checkSucess = presenter.check(finalI, list, -1);
                                        } else {
                                            //为空，设置检查失败
                                            checkSucess = false;
                                            MyLog.d("DoSurveyFragment", "getDataList.size=0");
                                        }
                                    }
                                });
                                //校验失败
                                if (!checkSucess) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            //取消loading
                                            ProgressHelper.getInstance().cancel();
                                            //判断当前页码在总页码内
                                            if (finalI <= fragList.size() - 1 && finalI != position) {
                                                //跳转fragment
                                                viewPager.setCurrentItem(finalI);
                                                position = finalI;
                                                if (finalI == fragList.size() - 1) {
                                                    //当前页码等于总页码数
                                                    //下一页隐藏
                                                    tv_next.setVisibility(View.GONE);
                                                } else {
                                                    //当前页码小于总页码数，下一页显示
                                                    tv_next.setVisibility(View.VISIBLE);
                                                }
                                                if (finalI == 0) {
                                                    //当前页码=0，上一页隐藏
                                                    tv_up.setVisibility(View.GONE);
                                                } else {
                                                    //当前页码大于零，上一页显示
                                                    tv_up.setVisibility(View.VISIBLE);
                                                }
                                            }
                                        }
                                    });
                                    //结束循环
                                    return;
                                }
                            }
                            //检查题目通过，保存数据库
                            if (checkSucess) {
                                //保存数据 未上传
                                boolean flag= presenter.saveDb(mActivity, AnswerState.COMPLETE);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //结束录音
                                        if(flag){
                                            presenter.stopRecord(true);
                                            //添加日志
                                            LogUtils.addLog("",OPERATION,newQuesBean.getID(),presenter.getAnswer().getAnswerStartTime(),"完成调查且校验通过", JsonUtil.toJson(presenter.getAnswer()));
                                            //土司
                                            MyToast.showLongToast("完成调查成功");
                                            //结束当前页面
                                            finish();
                                        }else {
                                            //添加日志
                                            LogUtils.addLog("",ERROR,newQuesBean.getID(),presenter.getAnswer().getAnswerStartTime(),"完成调查且校验通过,保存数据失败", JsonUtil.toJson(presenter.getAnswer()));
                                            //土司
                                            MyToast.showLongToast("数据保存失败，请重试");
                                        }

                                    }
                                });
                            }
                        }else {
                            //集合为空
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //取消loading
                                    ProgressHelper.getInstance().cancel();
                                    //土司
                                    MyToast.showLongToast("暂无数据");
                                }
                            });
                        }
                    }
                });
    }
    /**
     *  点击返回,保存答案
     */
    public void saveAnswer(AlertDialog dialog){
        //判断Activity销毁
        if(presenter.getMvpView()!=null) {
            //展示loading
            ProgressHelper.getInstance().show(DoSurveyActivity.this, "数据保存中...", false);
        }
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        //集合判空
                        if(fragList.size()>0){
                            //分页循环
                            for (int currentPage=0;currentPage< fragList.size();currentPage++) {
                                int finalI = currentPage;
                                //获取当前分页的题目列表
                                ((DoSurveyFragment)fragList.get(currentPage)).getQuesBeanList(new DoSurveyFragment.FramentCallBack() {
                                    @Override
                                    public void getDataList(ArrayList<PageSubjectBean> list) {
                                        //题目列表判空
                                        if(list!=null) {
                                            //不为空，根据答案页配置答题
                                            presenter.addAnswerPage(finalI, list);
                                        }
                                    }
                                });
                            }
                            //保存数据，继续编辑
                            boolean flag= presenter.saveDb(mActivity, AnswerState.EDIT);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //结束当前页面
                                    if(flag){
                                        finish();
                                    }else {
                                        //添加日志
                                        LogUtils.addLog("",ERROR,newQuesBean.getID(),presenter.getAnswer().getAnswerStartTime(),"点击返回,保存答案失败", JsonUtil.toJson(presenter.getAnswer()));
                                        //土司
                                        MyToast.showLongToast("数据保存失败，请重试");
                                    }
                                }
                            });
                        }else {
                            //集合为空
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //隐藏loading
                                    ProgressHelper.getInstance().cancel();
                                    //土司
                                    MyToast.showLongToast("暂无数据");
                                }
                            });
                        }
                    }
                });
    }
    /**
     *  点击end结束
     *  页数page
     *  该页的第pos道题
     */
    public void saveAnswer2(int page,int pos){
        //判断Activity销毁
        if(presenter.getMvpView()!=null) {
            //展示loading
            ProgressHelper.getInstance().show(this, "请稍等...", false);
        }
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        //集合判空
                        if(fragList.size()>0) {
                            //end所在的当前页码在总页码数之内
                            if (page < fragList.size()) {
                                //循环，从零开始，到end所在页码的分页
                                for (int currentPage = 0; currentPage <= page; currentPage++) {
                                    int finalI = currentPage;
                                    //初始化核验成功状态
                                    checkSucess = true;
                                    //获取分页的题目列表
                                    ((DoSurveyFragment) fragList.get(currentPage)).getQuesBeanList(new DoSurveyFragment.FramentCallBack() {
                                        @Override
                                        public void getDataList(ArrayList<PageSubjectBean> list) {
                                            //列表判空
                                            if (list != null) {
                                                //根据答案页配置答题
                                                //2022-02-23 新需求，选择结束页之后，清空当前结束题后面所有题目答案
                                                //因此需要将list重新构造一遍，剔除当前结束题后面题目
                                                //定义新的答案newList,
                                                //因前面已经做了page的判断，故这里只需要将list剔除掉当前结束题的结束页比当前结束题大的题目即可
                                                List<PageSubjectBean> newList = newList = (List<PageSubjectBean>) list.clone();
                                                if(finalI == page) {
                                                    //获取当前结束题的sort
                                                    int sort = list.get(pos).getSort();
                                                    for (PageSubjectBean pageSubjectBean : list) {
                                                        //对比sort大小，比当前结束题sort大的则取消答案上传
                                                        if (pageSubjectBean.getSort() > sort) {
                                                            newList.remove(pageSubjectBean);
                                                        }
                                                    }
                                                }
                                                presenter.addAnswerPage(finalI, newList);
//                                                presenter.addAnswerPage(finalI, list);
                                                //判断当前页是否等于end所在的页码
                                                if (finalI == page) {
                                                    //是end所在的页，该页，只检测到pos位置
                                                    checkSucess = presenter.check(finalI, list, pos);
                                                } else {
                                                    //不是end所在的页，检测全部
                                                    checkSucess = presenter.check(finalI, list, -1);
                                                }
                                                //检查不通过
                                                if (!checkSucess) {
                                                    //检测不通过的时候，如果去掉该end选项的选项值，让用户重新选择
                                                    //单多选，排序
                                                    if (list.get(pos).getSurveyAnswer().choiceList != null) {
                                                        list.get(pos).getSurveyAnswer().choiceList.clear();
                                                    }
                                                    //下拉
                                                    if (list.get(pos).getSurveyAnswer().OptionList != null) {
                                                        list.get(pos).getSurveyAnswer().OptionList.clear();
                                                    }
                                                }
                                            }
                                        }
                                    });
                                    //检查不通过
                                    if (!checkSucess) {
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                //判断当前页码在总页码内
                                                if (finalI <= fragList.size() - 1 && finalI != position) {
                                                    //跳转fragment
                                                    viewPager.setCurrentItem(finalI);
                                                    position = finalI;

                                                    if (finalI == fragList.size() - 1) {
                                                        //当前分页等于总分页数
                                                        //下一页隐藏
                                                        tv_next.setVisibility(View.GONE);
                                                    } else {
                                                        //上一页显示
                                                        tv_next.setVisibility(View.VISIBLE);
                                                    }
                                                    if (finalI == 0) {
                                                        //当前页等于第一页，上一页隐藏
                                                        tv_up.setVisibility(View.GONE);
                                                    } else {
                                                        //否则，上一页显示
                                                        tv_up.setVisibility(View.VISIBLE);
                                                    }
                                                }
                                                //取消loading
                                                ProgressHelper.getInstance().cancel();
                                            }
                                        });
                                        //结束循环
                                        return;
                                    }
                                }
                                //检查题目通过，保存数据库
                                if (checkSucess) {
                                    //保存数据库，未上传
                                    boolean flag= presenter.saveDb(mActivity, AnswerState.COMPLETE);
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            //结束当前页面
                                            if(flag){
                                                //添加日志
                                                LogUtils.addLog("",OPERATION,newQuesBean.getID(),presenter.getAnswer().getAnswerStartTime(),"完成调查且校验通过", JsonUtil.toJson(presenter.getAnswer()));
                                                //土司
                                                MyToast.showLongToast("完成调查成功");
                                                //activity回调
                                                Intent intent = new Intent();
                                                // 设置resultCode，onActivityResult()中能获取到，用于刷新列表
                                                setResult(ConstantUtil.ACTIVITY_FLUSH, intent);
                                                //结束当前activity
                                                finish();
                                            }else {
                                                //添加日志
                                                LogUtils.addLog("",ERROR,newQuesBean.getID(),presenter.getAnswer().getAnswerStartTime(),"完成调查且校验通过,保存数据失败", JsonUtil.toJson(presenter.getAnswer()));
                                                //土司
                                                MyToast.showLongToast("数据保存失败，请重试");
                                            }
                                        }
                                    });
                                }
                            }
                        }else {
                            //集合为空
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //取消loading
                                    ProgressHelper.getInstance().cancel();
                                    //土司
                                    MyToast.showLongToast("暂无数据");
                                }
                            });
                        }
                    }
                });
    }

    /**
     * 退出弹框
     */
    private void showQuitDialog() {
        //创建Builder,配置style
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.dialog);
        LayoutInflater inflater = LayoutInflater.from(this);
        //添加布局
        View vw = inflater.inflate(R.layout.alert_tip_quit, null);
        //创建dialog
        final AlertDialog dialog = builder.setView(vw).create();
        //确定按钮
        TextView btnYes = vw.findViewById(R.id.btn_del_yes);
        //内容
        TextView tvTip = vw.findViewById(R.id.tvTip);
        //取消按钮
        TextView btnNo = vw.findViewById(R.id.btn_del_no);
        //图片关闭按钮
        ImageView ivCloseQuit = vw.findViewById(R.id.iv_close_quit);
        //适配系统更改字号
//        if(StringUtils.getFontSize()>=1.3){
//            btnYes.setTextSize(16);
//            btnNo.setTextSize(16);
//        }
        //设置确定的内容
        btnYes.setText("保存");
        //设置取消的内容
        btnNo.setText("放弃");
        //设置提示的内容
        tvTip.setText("即将离开页面\n" +
                "您需要保存本份问卷吗？");
        //确定点击事件
        btnYes.setOnClickListener(v -> {
            //保存答案
            saveAnswer(dialog);
            //关闭dialog
            dialog.dismiss();
        });
        //取消点击事件
        btnNo.setOnClickListener(v -> {
            //判断activity销毁
            if(presenter.getMvpView()!=null) {
                //显示loading
                ProgressHelper.getInstance().show(this, "请稍等...", false);
            }
            //关闭dialog
            dialog.dismiss();
            ExecutorHandler.getInstance().forBackgroundTasks()
                    .execute(new Runnable() {
                        @Override
                        public void run() {
                            //暂停录音,不保存
                            presenter.stopRecord(false);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //销毁activity
                                    finish();
                                }
                            });
                        }
                    });
        });
        //关闭点击事件
        ivCloseQuit.setOnClickListener(v -> {
            //关闭dialog
            dialog.dismiss();
        });
        //展示dialog
        dialog.show();
    }

    /**
     * 根据接口返回的类型，选择不同类型的文件
     * @param fileType
     * @return
     */
    private String createFileType(int fileType) {
        switch (fileType) {
            case AnnexFileType.IMAGE:
                return "image/*";
            case AnnexFileType.AUDIO:
                return "audio/*";
            case AnnexFileType.VIDEO:
                return "video/*";
            case AnnexFileType.FILE:
            case AnnexFileType.ALL:
            default:
                return "*/*";
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == FileType.CODE_BROWSE_FILE) {
                //判空
                if (data != null && data.getData() != null) {
                    try {
                        //获取路径
                        String path = FileUtils.getFileFromUri(DoSurveyActivity.this, data.getData());
                        //路径判空
                        if (!TextUtils.isEmpty(path)) {
                            //获取当前选中的附件是否符合附件格式
                            boolean chooseType = FileUtils.isChooseType(curfileType, path);
                            if(chooseType){
                                //ADD_ANNEX带过来的参数中，设置标号0的参数
                                list[0]=path;
                                //eventBus
                                EventBusUtils.getInstance().postEvent(new Event(ACCEPT_ANNEX, list));
                            }else {
                                MyToast.showShortToast("当前附件格式不符合附件题类型");
                            }
                        }else {
                            MyToast.showShortToast("当前附件文件不可选");
                        }
                    }catch (Exception e){
                        MyToast.showShortToast("选择文件异常：" + e.getMessage());
                    }
                }
            }
        }
    }

    private  String[] list;
    @Override
    public boolean onEventListener(Event event) {
        if (super.onEventListener(event)) {
            return true;
        }
        //判断activity销毁
        if (!isFinishing()) {
            switch (event.getTag()) {
                case ADD_ANNEX:
                    //添加附件
                    //获取参数
                    list= (String[]) event.data;
                    //获取fileType
                    int fileType= Integer.parseInt(list[0]);
                    curfileType = fileType;
                    //intent
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    //intent设置类型
                    intent.setType(createFileType(fileType));
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    //跳转intent选择文件
                    startActivityForResult(intent, FileType.CODE_BROWSE_FILE);
                    break;
                case SURVEY_STOP:
                    //结束调查
                    //获取参数
                    Integer[] data= (Integer[]) event.data;
                    //参数长度大于等于2
                    if(data.length>=2){
                        //获取页码
                        int page=data[0];
                        //获取题目位置
                        int position=data[1];
                        //结束调查pop
                        showTipAlert(page,position);
                    }
                    break;
            }
        }
        return false;
    }

    @Override
    public void loadFailure(boolean sucess, String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //取消loading
                ProgressHelper.getInstance().cancel();
            }
        });
    }

    @Override
    public void initQueEntity(QueBean queBean) {
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        //问卷详情获取成功，判空
                        if(queBean!=null){
                            //保存题目
                            presenter.initQue(queBean,newQuesBean.getModifyDate());//保存题目
                            //加载题目
                            loadQueSub(queBean);
                        }
                    }
                });

    }

    /**
     * 开始加载题目
     * */
    public void loadQueSub(QueBean queBean){
        //寻找隐藏题目逻辑
        presenter.findLogic(queBean);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //判空
                if(queBean.getQuePage()!=null && queBean.getQuePage().size()>0){
                    //分页集合清空
                    fragList.clear();
                    //循环分页
                    for(int currentPage=0;currentPage<queBean.getQuePage().size();currentPage++){
                        //如果是新创建，直接新建DoSurveyFragment
                        if(!isSavedInstanceState) {
                            //创建doSurveyFragment
                            DoSurveyFragment doSurveyFragment=DoSurveyFragment.newInstance(currentPage, type, newQuesBean.getID(), queBean.QueTitle, queBean.getRmk(), queBean.getQuePage().get(currentPage));
                            //设置当前页的题目，因为题目数据过大，这样设置，以防intent传参数据过大奔溃
                            doSurveyFragment.setQuePageBean(queBean.getQuePage().get(currentPage));
                            //集合添加fragement
                            fragList.add(doSurveyFragment);
                        }else {
                            //如果有保存状态，直接获取保存的DoSurveyFragment
                            DoSurveyFragment myFragment = (DoSurveyFragment) getSupportFragmentManager().getFragment(
                                    savedInstanceState, "fragment"+currentPage);
                            //判空
                            if(myFragment!=null){
                                //集合添加fragement
                                fragList.add(myFragment);
                            }
                        }
                    }
                    titles=new String[queBean.getQuePage().size()];
                    //ViewPager的adapter
                    adapter=new CustomViewPager.MyPagerAdapter(getSupportFragmentManager(),fragList,titles);
                    //设置adapter
                    viewPager.setAdapter(adapter);
                    viewPager.setOffscreenPageLimit(queBean.getQuePage().size());
                    if(queBean.getQuePage().size()<=1){
                        //总页码等于0
                        //上一页隐藏
                        tv_up.setVisibility(View.GONE);
                        //下一页隐藏
                        tv_next.setVisibility(View.GONE);
                    }else {
                        //总页码大于0
                        //上一页隐藏
                        tv_up.setVisibility(View.GONE);
                        //下一页显示
                        tv_next.setVisibility(View.VISIBLE);
                    }
                }else {
                    //集合为空
                    //上一页和下一页都隐藏
                    tv_up.setVisibility(View.GONE);
                    tv_next.setVisibility(View.GONE);
                }
            }
        });
    }

    /**
     * 结束调查的弹框
     */
    private AlertView tipAlert;
    public void showTipAlert(int page,int pos) {
        //判空
        if (tipAlert == null) {
            //初始化
            tipAlert = new AlertView("结束调查", "结束调查吗？", "取消", new String[]{"确定"}, null, DoSurveyActivity.this, AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {

                    if(position<0){
                        //点击了取消
                        sendBroadcast(page,pos);
                    }else {
                        //点击了确定
                        saveAnswer2(page,pos);
                    }
                    //隐藏tipAlert
                    tipAlert.dismiss();
                }
            });
        }
        //设置点击空白地方不能隐藏
        tipAlert.setCancelable(false);
        //消失事件
        tipAlert.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(Object o) {
                tipAlert = null;
            }
        });
        //显示
        tipAlert.show();
    }

    /**
     * 发广播
     * @param position
     * @param page
     */
    private void sendBroadcast(  int page,int position) {
        Intent intent = new Intent(String.valueOf(page));
        //设置位置
        intent.putExtra("sort", position);
        //点击了end
        intent.putExtra("end", true);
        //发广播
        LocalBroadcastManager.getInstance(MyApplication.getContext()).sendBroadcast(intent);
    }

}
