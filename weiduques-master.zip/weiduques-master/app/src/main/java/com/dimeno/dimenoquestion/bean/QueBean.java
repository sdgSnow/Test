package com.dimeno.dimenoquestion.bean;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class QueBean {

    public int ComplateStatus;
    public String CreateDate;
    public String CreateUserName;
    public String CreateUserRoles;
    public String Creator;
    public String CustomAreaList;
    public String Divisions;
    public int DoneCount;
    public String ID;
    public String IntExt1;
    public String IntExt2;
    public String IntExt3;
    public String IntExt4;
    public String IntExt5;
    public String IsCusView;
    public boolean IsCustomArea;
    public boolean IsDelete;
    public Integer IsPublic;
    public String IsPublic_Show;
    public String IsRatio;
    public boolean IsRelease;
    public boolean IsTape;
    public Integer MaxCount;
    public String Modifier;
    public String ModifyDate;
    public String NumFormat;
    public String ProCode;
    public int QueAreaType;
    public Integer QueCategory;
    public String QueObject;
    public String QueObject_Show;
    public Integer QueStatus;
    public String QueTitle;
    public int QueType;
    public String QueTypeName;
    public String Rmk;
    public String StatusText;
    public String StrExt1;
    public String Uid;
    public String isNew;
    public List<QuePageBean> QuePage;


    //手动填的字段
    public String userId;
    public String queID;
    public String queTitle;
    public String answerId;
    public String answerLoc;
    public String answerCode;
    public Long answerStartTime;
    public Long answerFinishTime;
    public String queCreateDate;
    public String CatalogID;
    public String queModifyDate;
    public double queLatitude;
    public double queLongitude;
    public String queAddressCode;


    public List<QuePageBean> getQuePage() {
        return QuePage;
    }

    public void setQuePage(List<QuePageBean> quePage) {
        QuePage = quePage;
    }

    public int getComplateStatus() {
        return ComplateStatus;
    }

    public void setComplateStatus(int complateStatus) {
        ComplateStatus = complateStatus;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String createDate) {
        CreateDate = createDate;
    }

    public String getCreateUserName() {
        return CreateUserName;
    }

    public void setCreateUserName(String createUserName) {
        CreateUserName = createUserName;
    }

    public String getCreateUserRoles() {
        return CreateUserRoles;
    }

    public void setCreateUserRoles(String createUserRoles) {
        CreateUserRoles = createUserRoles;
    }

    public String getCreator() {
        return Creator;
    }

    public void setCreator(String creator) {
        Creator = creator;
    }

    public String getCustomAreaList() {
        return CustomAreaList;
    }

    public void setCustomAreaList(String customAreaList) {
        CustomAreaList = customAreaList;
    }

    public String getDivisions() {
        return Divisions;
    }

    public void setDivisions(String divisions) {
        Divisions = divisions;
    }

    public int getDoneCount() {
        return DoneCount;
    }

    public void setDoneCount(int doneCount) {
        DoneCount = doneCount;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getIntExt1() {
        return IntExt1;
    }

    public void setIntExt1(String intExt1) {
        IntExt1 = intExt1;
    }

    public String getIntExt2() {
        return IntExt2;
    }

    public void setIntExt2(String intExt2) {
        IntExt2 = intExt2;
    }

    public String getIntExt3() {
        return IntExt3;
    }

    public void setIntExt3(String intExt3) {
        IntExt3 = intExt3;
    }

    public String getIntExt4() {
        return IntExt4;
    }

    public void setIntExt4(String intExt4) {
        IntExt4 = intExt4;
    }

    public String getIntExt5() {
        return IntExt5;
    }

    public void setIntExt5(String intExt5) {
        IntExt5 = intExt5;
    }

    public String getIsCusView() {
        return IsCusView;
    }

    public void setIsCusView(String isCusView) {
        IsCusView = isCusView;
    }

    public boolean isCustomArea() {
        return IsCustomArea;
    }

    public void setCustomArea(boolean customArea) {
        IsCustomArea = customArea;
    }

    public boolean isDelete() {
        return IsDelete;
    }

    public void setDelete(boolean delete) {
        IsDelete = delete;
    }

    public Integer getIsPublic() {
        return IsPublic;
    }

    public void setIsPublic(Integer isPublic) {
        IsPublic = isPublic;
    }

    public String getIsPublic_Show() {
        return IsPublic_Show;
    }

    public void setIsPublic_Show(String isPublic_Show) {
        IsPublic_Show = isPublic_Show;
    }

    public String getIsRatio() {
        return IsRatio;
    }

    public void setIsRatio(String isRatio) {
        IsRatio = isRatio;
    }

    public boolean isRelease() {
        return IsRelease;
    }

    public void setRelease(boolean release) {
        IsRelease = release;
    }

    public boolean isTape() {
        return IsTape;
    }

    public void setTape(boolean tape) {
        IsTape = tape;
    }

    public Integer getMaxCount() {
        return MaxCount;
    }

    public void setMaxCount(Integer maxCount) {
        MaxCount = maxCount;
    }

    public String getModifier() {
        return Modifier;
    }

    public void setModifier(String modifier) {
        Modifier = modifier;
    }

    public String getModifyDate() {
        return ModifyDate;
    }

    public void setModifyDate(String modifyDate) {
        ModifyDate = modifyDate;
    }

    public String getNumFormat() {
        return NumFormat;
    }

    public void setNumFormat(String numFormat) {
        NumFormat = numFormat;
    }

    public String getProCode() {
        return ProCode;
    }

    public void setProCode(String proCode) {
        ProCode = proCode;
    }

    public int getQueAreaType() {
        return QueAreaType;
    }

    public void setQueAreaType(int queAreaType) {
        QueAreaType = queAreaType;
    }

    public Integer getQueCategory() {
        return QueCategory;
    }

    public void setQueCategory(Integer queCategory) {
        QueCategory = queCategory;
    }

    public String getQueObject() {
        return QueObject;
    }

    public void setQueObject(String queObject) {
        QueObject = queObject;
    }

    public String getQueObject_Show() {
        return QueObject_Show;
    }

    public void setQueObject_Show(String queObject_Show) {
        QueObject_Show = queObject_Show;
    }

    public Integer getQueStatus() {
        return QueStatus;
    }

    public void setQueStatus(Integer queStatus) {
        QueStatus = queStatus;
    }

    public String getQueTitle() {
        return QueTitle;
    }

    public void setQueTitle(String queTitle) {
        QueTitle = queTitle;
    }

    public int getQueType() {
        return QueType;
    }

    public void setQueType(int queType) {
        QueType = queType;
    }

    public String getQueTypeName() {
        return QueTypeName;
    }

    public void setQueTypeName(String queTypeName) {
        QueTypeName = queTypeName;
    }

    public String getRmk() {
        return Rmk;
    }

    public void setRmk(String rmk) {
        Rmk = rmk;
    }

    public String getStatusText() {
        return StatusText;
    }

    public void setStatusText(String statusText) {
        StatusText = statusText;
    }

    public String getStrExt1() {
        return StrExt1;
    }

    public void setStrExt1(String strExt1) {
        StrExt1 = strExt1;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }
}
