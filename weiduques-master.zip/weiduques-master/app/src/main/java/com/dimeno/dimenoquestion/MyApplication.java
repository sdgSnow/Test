package com.dimeno.dimenoquestion;

import android.text.InputFilter;
import android.text.Spanned;
import android.widget.Toast;

import androidx.multidex.MultiDex;

import com.baidu.mapapi.SDKInitializer;
import com.czt.mp3recorder.Mp3RecorderUtil;
import com.dimeno.common.base.BaseApplication;
import com.dimeno.common.utils.AppUtils;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.http.HttpConstant;
import com.dimeno.dimenoquestion.service.LocationService;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.socks.library.KLog;
import com.tencent.bugly.crashreport.CrashReport;

import org.litepal.LitePal;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.dimeno.dimenoquestion.constant.Constant.DB_PATH;


public class MyApplication extends BaseApplication {
    public LocationService locationService;

    @Override
    public void onCreate() {
        super.onCreate();
        CrashReport.initCrashReport(this, "337e453645", HttpConstant.isDebug());
        AppUtils.init(this);

        KLog.init(true);
        // 主要是添加下面这句代码
        MultiDex.install(this);
        //数据库
        LitePal.initialize(this);
        Mp3RecorderUtil.init(this, true);
        initBaiduMap();

        MyUtils.reLogin();
        setInstallTime();
    }

    @Override
    public void onLowMemory() {
        System.gc();
        super.onLowMemory();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
    }

    /***
     * 初始化定位sdk，建议在Application中创建
     */
    private void initBaiduMap() {
        locationService = new LocationService(getApplicationContext());
        SDKInitializer.initialize(getApplicationContext());
    }


    public LocationService getLocationService() {
        return locationService;
    }

    public void setInstallTime() {
        boolean install = SpUtil.get().isInstall();
        //install默认值为false 如果它为 false，则说明是第一次安装，同时赋值为true并更新时间值
        if (install == false) {
            SpUtil.get().setInstall(true);
            SpUtil.get().setInstallTime(TimeUtil.getCurrentTime());
        }
        File file = new File(DB_PATH);

    }

    /**
     * 验证输入不能为表情
     */
    public static InputFilter inputFilter= new InputFilter() {
        Pattern emoji = Pattern.compile("[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]|[\ue000-\uf8ff]",
                Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE);

        private long time=System.currentTimeMillis();
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher emojiMatcher = emoji.matcher(source);
            if (emojiMatcher.find()) {
                if(System.currentTimeMillis()-time>1000){
                    time=System.currentTimeMillis();
                    Toast.makeText(getContext(),"不支持输入表情",Toast.LENGTH_LONG).show();
                }
                return "";
            }
            return null;
        }
    };

//    public static InputFilter inputFilter = new InputFilter() {
//        Pattern pattern = Pattern.compile("[^a-zA-Z0-9\\u4E00-\\u9FA5_]");
//        @Override
//        public CharSequence filter(CharSequence charSequence, int i, int i1, Spanned spanned, int i2, int i3) {
//            Matcher matcher = pattern.matcher(charSequence);
//            if (!matcher.find()) {
//                return null;
//            } else {
//                Toast.makeText(getContext(), "不支持输入表情", Toast.LENGTH_LONG).show();
//                return "";
//            }
//
//        }
//    };

    public static InputFilter getInputFilter() {
        return inputFilter;
    }
}
