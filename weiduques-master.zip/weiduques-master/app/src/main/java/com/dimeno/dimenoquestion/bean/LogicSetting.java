package com.dimeno.dimenoquestion.bean;


import java.io.Serializable;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :题目隐藏逻辑
 */
public class LogicSetting implements Serializable {

    /**
     * LogicID : 7496f606-4afb-96c8-1cb1-378258c3a455
     * QueID : 9c55e84b-09d5-4fbd-9087-46c061a757c1
     * SubID : 2
     * LogicType : 2
     * SubIDs : 9,10,11,12
     * OpCode : 2
     * DecimalRange1 : null
     * DecimalRange2 : null
     * DateRange1 : null
     * DateRange2 : null
     * Province : null
     * City : null
     * Area : null
     * QuestionText : null
     */

    public String LogicID;
    public String QueID;
    public int SubID;
    public int LogicType;
    public String SubIDs;
    public String OpCode;
    public int DecimalRange1;
    public int DecimalRange2;
    public String DateRange1;
    public String DateRange2;
    public String Province;
    public String City;
    public String Area;
    public String QuestionText;

}
