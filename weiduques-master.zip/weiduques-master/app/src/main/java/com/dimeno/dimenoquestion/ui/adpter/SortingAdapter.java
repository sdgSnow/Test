package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.holder.base.BaseViewHolder;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :排序
 */
public class SortingAdapter extends RecyclerView.Adapter<SortingAdapter.ViewHolder>{
    //保存多选状态下的变量
    private ArrayList<String> set=new ArrayList<>();
    private List<QueOptionBean> mData=new ArrayList<>();
    private Context mContent;
    private SurveyAnswer answer;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param context
     * @param type
     */
    public SortingAdapter(Context context,String type) {
        this.mContent = context;
        this.type=type;
    }
    /**
     * 重置set
     */
    public void resetSet(SurveyAnswer answer){
        this.answer=answer;
        set.clear();
        if(answer.choiceList!=null && answer.choiceList.size()!=0){
            for (QueOptionBean item : answer.choiceList) {
                set.add(item.getOpCode());
            }
        }
    }
    public void setData(List<QueOptionBean> mData){
        this.mData=mData;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sorting_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(type.equals("look")){
            holder.etFillBlank.setClickable(false);
            holder.etFillBlank.setEnabled(false);
            holder.etFillBlank.setHint("");
        }
        holder.etFillBlank.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        if(mData.get(position).isMust()){
            holder.mark.setVisibility(View.VISIBLE);
        }else {
            holder.mark.setVisibility(View.GONE);
        }
        if(!StringUtils.isEmpty(mData.get(position).getFillText())){
            holder.unit.setVisibility(View.VISIBLE);
            holder.unit.setText(mData.get(position).getFillText());
        }else {
            holder.unit.setVisibility(View.GONE);
            holder.unit.setText("");
        }
        if (set.contains(mData.get(position).getOpCode())) {
            holder.ll_home.setSelected(true);
            holder.ivSelect.setBackground(mContent.getResources().getDrawable(R.drawable.sort_select));
            holder.ivSelect.setText(getPosition(mData.get(position).getOpCode())==-1?"":getPosition(mData.get(position).getOpCode())+"");
            if(mData.get(position).isFill()){
                holder.ll_edit.setVisibility(View.VISIBLE);
                holder.etFillBlank.addTextChangedListener(new AbsTextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        if(answer.choiceList!=null && answer.choiceList.size()!=0){
                            for (int i = 0; i < answer.choiceList.size(); i++) {
                                if(answer.choiceList.get(i).getOpCode()==mData.get(position).getOpCode()){
                                    answer.choiceList.get(i).setFillContent(s.toString());
                                }
                            }
                        }
                        if (!StringUtils.isEmpty(s.toString())) {
                            if (myOnItemClickListener != null) {
                                myOnItemClickListener.onItemClick();
                            }
                        }
                    }
                });
                if (answer != null && answer.choiceList != null) {
                    for (int i = 0; i < answer.choiceList.size(); i++) {
                        if (answer.choiceList.get(i).getOpCode().equals(mData.get(position).getOpCode())) {
                            holder.etFillBlank.setText(StringUtils.isEmpty(answer.choiceList.get(i).getFillContent()) ?
                                    "" : answer.choiceList.get(i).getFillContent());
                        }
                    }
                }
            }else {
                holder.ll_edit.setVisibility(View.GONE);
            }
        }else {
            holder.ll_home.setSelected(false);
            holder.ivSelect.setText("");
            holder.ivSelect.setBackground(mContent.getResources().getDrawable(R.drawable.sort_unselect));
            holder.ll_edit.setVisibility(View.GONE);
        }


        holder.tv_title.setText(mData.get(position).getOpText());
        holder.ll_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!type.equals("look")) {
                    if (set.contains(mData.get(position).getOpCode())) {
                        set.remove(mData.get(position).getOpCode());
                        mData.get(position).setFillContent("");
                        if (myOnItemClickListener != null) {
                            myOnItemClickListener.onItemClick(false, mData.get(position));
                        }
                    } else {
//                        //显示箭头光标
//                        if(mData.get(position).isFill()) {
//                            holder.etFillBlank.setVisibility(View.VISIBLE);
//                            holder.etFillBlank.setFocusableInTouchMode(true);
//                            holder.etFillBlank.requestFocus();
//                        }
                        set.add(mData.get(position).getOpCode());
                        if (myOnItemClickListener != null) {
                            myOnItemClickListener.onItemClick(true, mData.get(position));
                        }
                    }
                }
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }
    public class ViewHolder extends BaseViewHolder {
        TextView ivSelect;
        TextView tv_title;
        LinearLayout ll_home;
        EditText etFillBlank;
        TextView mark;
        TextView unit;
        LinearLayout ll_edit;
        ViewHolder(View itemView) {
            super(itemView);
            ivSelect=itemView.findViewById(R.id.ivSelect);
            tv_title=itemView.findViewById(R.id.tv_title);
            ll_home=itemView.findViewById(R.id.ll_home);
            etFillBlank=itemView.findViewById(R.id.etFillBlank);
            mark=itemView.findViewById(R.id.mark);
            unit=itemView.findViewById(R.id.unit);
            ll_edit=itemView.findViewById(R.id.ll_edit);
            etFillBlank.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        }
    }

    public int getPosition(String str){
        int position=-1;
        for (int i=0;i<set.size();i++) {
            if(str.equals(set.get(i))){
                position=i+1;
            }
        }
        return position;
    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private MyOnItemClickListener myOnItemClickListener;

    public interface MyOnItemClickListener {
        void onItemClick();
        void onItemClick(boolean isSelect, QueOptionBean queOptionBean);
    }
}
