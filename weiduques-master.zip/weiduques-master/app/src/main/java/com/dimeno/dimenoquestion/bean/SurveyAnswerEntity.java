package com.dimeno.dimenoquestion.bean;


import com.dimeno.dimenoquestion.mode.GlobalRecordSections;

import java.util.ArrayList;
import java.util.List;

/**
 * 上传答案实体
 * Created by lenovo on 2017/6/19.
 */

public class SurveyAnswerEntity {
    /**
     * "1":未上传录音，显示上传录音按钮
     * "0":已上传，隐藏上传录音按钮
     */
    public String userId;
    public String queID;
    public String queTitle;
    public String answerId;
    public String answerLoc;
    public String answerCode;
    public Long answerStartTime;
    public Long answerFinishTime;
    public String queCreateDate;
    public String CatalogID;
    public String queModifyDate;
    public double queLatitude;
    public double queLongitude;
    public String queAddressCode;
    //答案列表
    public List<AnswerPage> surveyAnswers;
    //    public List<PageSubjectBean> quePageList;//答案列表
    //上传的图片类型 1代表签名，2代表问卷图片
    public int imageType;
    //录音文件集合
    public List<RecordFileBean> recordList;
    //签名文件集合
    public List<SignFileBean> signFileList;


    /**
     * 需要将附件放到答案外部json中，方便上传
     */
    public ArrayList<String> answerAccessories;
    /**
     * 上传多个答卷文件
     */
    public AnsFile ansFile;



    public AnsFile getAnsFile() {
        return ansFile;
    }

    public void setAnsFile(AnsFile ansFile) {
        this.ansFile = ansFile;
    }

    /**
     * 一页的答案
     */
    public static class AnswerPage {
        private int pIndex;
        private String pageID;
        private ArrayList<SurveyAnswer> surveyAnswers;

        public int getpIndex() {
            return pIndex;
        }

        public void setpIndex(int pIndex) {
            this.pIndex = pIndex;
        }

        public String getPageID() {
            return pageID;
        }

        public void setPageID(String pageID) {
            this.pageID = pageID;
        }

        public ArrayList<SurveyAnswer> getSurveyAnswers() {
            return surveyAnswers;
        }

        public void setSurveyAnswers(ArrayList<SurveyAnswer> surveyAnswers) {
            this.surveyAnswers = surveyAnswers;
        }
    }

    public static class AnsFile {
        //项目代码
        private String ProCode;
        //问卷ID
        private String queId;
        //答卷ID
        private String answerId;
        //附件列表
        private List<CustMap> custMaps;

        public static class CustMap {
            //题目id == 文件id
            private String key;
            //文件路径 == 截取文件名称
            private String value;

            public String getKey() {
                return key == null ? "" : key;
            }

            public void setKey(String key) {
                this.key = key;
            }

            public String getValue() {
                return value == null ? "" : value;
            }

            public void setValue(String value) {
                this.value = value;
            }
        }

        public String getProCode() {
            return ProCode == null ? "" : ProCode;
        }

        public void setProCode(String proCode) {
            ProCode = proCode;
        }

        public String getQueId() {
            return queId == null ? "" : queId;
        }

        public void setQueId(String queId) {
            this.queId = queId;
        }

        public String getAnswerId() {
            return answerId == null ? "" : answerId;
        }

        public void setAnswerId(String answerId) {
            this.answerId = answerId;
        }

        public List<CustMap> getCustMaps() {
            if (custMaps == null) {
                return new ArrayList<>();
            }
            return custMaps;
        }

        public void setCustMaps(List<CustMap> custMaps) {
            this.custMaps = custMaps;
        }
    }
}


