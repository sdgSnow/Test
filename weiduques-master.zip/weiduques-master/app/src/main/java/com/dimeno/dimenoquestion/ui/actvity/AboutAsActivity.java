package com.dimeno.dimenoquestion.ui.actvity;

import android.os.Bundle;
import android.widget.TextView;

import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BaseApplication;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AboutUsBean;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.ui.presenter.AboutAsPresenter;
import com.dimeno.dimenoquestion.ui.presenter.LoginPresenter;
import com.dimeno.dimenoquestion.ui.view.AboutAsView;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.TextViewUtil;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :
 */
public class AboutAsActivity extends  BaseActivity<AboutAsPresenter> implements AboutAsView {
    @BindView(R.id.tvContent_01)
    TextView tvContent_01;
    @BindView(R.id.tvContent_02)
    TextView tvContent_02;
    @BindView(R.id.tvContent_03)
    TextView tvContent_03;
    @BindView(R.id.tv_version)
    TextView tv_version;

    /**
     * 设置布局文件
     *
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_about_we;
    }

    /**
     * Toolbar
     *
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"关于我们");
    }

    /**
     * initThings
     *
     * @param savedInstanceState 缓存数据
     *                           <p>
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
    }

    /**
     * initViews
     *
     */
    @Override
    protected void initViews() {
        //设置版本号
        tv_version.setText(TextViewUtil.getString(R.string.version) + MyUtils.getVersionName(BaseApplication.getContext()));
        //接口获取数据
        presenter.AboutUs(AboutAsActivity.this);

    }

    /**
     * createPresenter
     * @return
     */
    @Override
    protected AboutAsPresenter createPresenter() {
        return new AboutAsPresenter();
    }

    /**
     * initListeners
     */
    @Override
    public void initListeners() {

    }

    /**
     * 成功回调
     */
    @Override
    public void OnSucess(AboutUsBean aboutUsBean) {
        //数据返回成功，判空并重新赋值
        if (aboutUsBean != null) {
            tvContent_01.setText(StringUtils.isEmpty(aboutUsBean.getC_Website())?"":aboutUsBean.getC_Website());
            tvContent_02.setText(StringUtils.isEmpty(aboutUsBean.getC_ServicePhone())?"":aboutUsBean.getC_ServicePhone());
            tvContent_03.setText(StringUtils.isEmpty(aboutUsBean.getC_QQ())?"":aboutUsBean.getC_QQ());
        }
    }
    /**
     * 失败回调
     * @param msg
     */
    @Override
    public void OnFail(String msg) {

    }
}
