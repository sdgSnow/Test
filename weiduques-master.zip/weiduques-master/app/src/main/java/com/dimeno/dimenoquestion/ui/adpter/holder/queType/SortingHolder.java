package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.ui.adpter.MultiChoiceAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.ui.adpter.SingleChoiceAdapter;
import com.dimeno.dimenoquestion.ui.adpter.SortingAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.VerticalDecoration;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :13 排序
 */
public class SortingHolder extends RecyclerViewHolder<PageSubjectBean> {

    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final RecyclerView rvSingle;
    private SortingAdapter adapter;
    private SpannableStringBuilder title;
    private SurveyAnswer surveyAnswer;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private QueAdapter.OnChildClickLisener onChildClickLisener;
    private Map<Integer, SortingAdapter> map=new HashMap<>();
    //add新添加，edit编辑，look查看
    private String type;
    private boolean flag;
    private List<PageSubjectBean> subjecList=new ArrayList<>();

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     * @param subjecList
     */
    public SortingHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type,List<PageSubjectBean> subjecList) {
        super(parent, R.layout.item_single_choice);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        rvSingle = findViewById(R.id.rvSingle);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.onChildClickLisener=onChildClickLisener;
        this.subjecList=subjecList;
        this.type=type;
    }


    @Override
    public void bind() {
        //获取答案
        if (mData.getSurveyAnswer() == null) {
            mData.setSurveyAnswer(new SurveyAnswer());
        }
        surveyAnswer = mData.getSurveyAnswer();
        //获取单多选答案list
        if (surveyAnswer.choiceList == null) {
            surveyAnswer.choiceList = new ArrayList<>();
        }

        if (mData.getAttr() != null && mData.getQueOption()!=null ) {

            surveyAnswer.MaxCount = mData.getAttr().getMaxCount();
            surveyAnswer.MinCount = mData.getAttr().getMinCount();

            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            rvSingle.setLayoutManager(new LinearLayoutManager(itemView.getContext()));
            if (map.get(getAdapterPosition()) == null) {
                if (rvSingle.getItemDecorationCount() == 0) {
                    rvSingle.addItemDecoration(new VerticalDecoration(30));
                }
                if (mData.getQueOption() != null && mData.getQueOption().size() > 1) {
                    Collections.sort(mData.getQueOption(), new Comparator<QueOptionBean>() {
                        @Override
                        public int compare(QueOptionBean o1, QueOptionBean o2) {
                            return o1.getSort() - o2.getSort();
                        }
                    });
                }
                adapter = new SortingAdapter(itemView.getContext(), type);
                adapter.resetSet(mData.getSurveyAnswer());
                rvSingle.setAdapter(adapter);
                adapter.setData(mData.getQueOption());
                map.put(getAdapterPosition(), adapter);
            } else {
                adapter = map.get(getAdapterPosition());
                adapter.resetSet(mData.getSurveyAnswer());
                rvSingle.setAdapter(adapter);
            }
            adapter.setMyOnItemClickListener(new SortingAdapter.MyOnItemClickListener() {
                @Override
                public void onItemClick() {
                    flag = false;
                    if (mData.getSurveyAnswer() != null && mData.getSurveyAnswer().choiceList != null && mData.getSurveyAnswer().choiceList.size() != 0) {
                        for (int i = 0; i < mData.getSurveyAnswer().choiceList.size(); i++) {
                            if (mData.getSurveyAnswer().choiceList.get(i).isFill() && mData.getSurveyAnswer().choiceList.get(i).isMust()) {
                                if (StringUtils.isEmpty(mData.getSurveyAnswer().choiceList.get(i).getFillContent())) {
                                    flag = true;
                                }
                            }
                        }
                        if (mData.getAttr().getMinCount() != 0) {
                            //最少选择未达标
                            if (mData.getSurveyAnswer().choiceList.size() < mData.getAttr().getMinCount()) {
                                flag = true;
                            }
                        }
                    }
                    if (!flag) {
                        if (mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }

                }

                @Override
                public void onItemClick(boolean isSelect, QueOptionBean queOptionBean) {
                    if(queOptionBean!=null) {
                        //获取关联的题目在列表所在的位置position
                        Map<String, List<Integer>> map = mData.getHidePosition();
                        if (map != null && map.size() != 0) {
                            //如果选择，则遍历显示题目
                            if (map.get(queOptionBean.getOpCode()) != null && map.get(queOptionBean.getOpCode()).size() != 0) {
                                List<Integer> list = map.get(queOptionBean.getOpCode());
                                for (int i = 0; i < list.size(); i++) {
                                    if (subjecList.size() > list.get(i)) {
                                        if (isSelect) {
                                            //选择了，则显示
                                            subjecList.get(list.get(i)).setIsHide(ConstantType.queHide.VISIBLE);//显示
                                            subjecList.get(list.get(i)).getSurveyAnswer().logicShow = ConstantUtil.VISIBLE;
                                        } else {
                                            //隐藏
                                            subjecList.get(list.get(i)).setIsHide(ConstantType.queHide.GONE);//隐藏
                                            subjecList.get(list.get(i)).getSurveyAnswer().logicShow = ConstantUtil.GONE;
                                        }
                                    }
                                }
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.onChildClick(itemView, getAdapterPosition());
                                }
                            }
                        }
                        //根据选项修改单多选答案的选项
                        if (isSelect) {
                            if (surveyAnswer != null && surveyAnswer.choiceList!=null) {
                                surveyAnswer.choiceList.add(queOptionBean);
                            }
                        } else {
                            if (surveyAnswer != null) {
                                if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                                    for (int i = 0; i < surveyAnswer.choiceList.size(); i++) {
                                        if (surveyAnswer.choiceList.get(i).getOpCode().equals(queOptionBean.getOpCode())) {
                                            surveyAnswer.choiceList.remove(surveyAnswer.choiceList.get(i));
                                            i--;
                                        }
                                    }
                                }
                            }
                        }
                        if (mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }
                }
            });
        }
    }
}