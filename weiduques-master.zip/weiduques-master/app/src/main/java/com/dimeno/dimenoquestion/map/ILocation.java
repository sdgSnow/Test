package com.dimeno.dimenoquestion.map;

/**
 * 此接口用于回调获取到的定位信息
 * 需要定位信息的实现此接口，并setLocationInfoInterface，即可，前提是先初始化这个类获取到定位信息
 * */
public interface ILocation {
    void locationInfo(String longitude, String latitude, String address, String currentTime);
}
