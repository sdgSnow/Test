package com.dimeno.dimenoquestion.ui.actvity;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.db.UserOperationLog;
import com.dimeno.dimenoquestion.ui.presenter.DiaryDbPresenter;
import com.dimeno.dimenoquestion.ui.view.DiaryDbView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;

import org.litepal.LitePal;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/8/25
 * Description :上传日记，日记保存在数据库中
 */
public class DiaryDbActivity extends  BaseActivity<DiaryDbPresenter> implements DiaryDbView {
    private TextView tv_upfile;
    private NewQuesBean newQuesBean;

    /**
     * 设置布局文件
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_diary_up;
    }

    /**
     * 设置Toolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"日记上传");
    }

    @Override
    protected void initThings(Bundle savedInstanceState) {
        newQuesBean = (NewQuesBean) getIntent().getSerializableExtra("newQuesBean");
        tv_upfile=findViewById(R.id.tv_upfile);
    }

    @Override
    protected void initViews() {
        //按钮点击事件
        tv_upfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //展示loading
                ProgressHelper.getInstance().show(DiaryDbActivity.this,"开始上传...",false);
                //调接口
                presenter.initUpload(DiaryDbActivity.this,newQuesBean);
            }
        });
    }


    /**
     * Presenter
     * @return
     */
    @Override
    protected DiaryDbPresenter createPresenter() {
        return new DiaryDbPresenter();
    }

    @Override
    public void initListeners() {

    }

    @Override
    public void success(boolean isMore,String progress) {
        //防止activity销毁还进行该方法造成崩溃
        if(!isFinishing()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //是否还有更多
                    if (isMore) {
                        //显示进度
                        ProgressHelper.getInstance().setTitle("已上传"+Integer.parseInt(progress)+"%");
                    } else {
                        //进度100%
                        ProgressHelper.getInstance().setTitle("已上传100%");
                        //取消loading
                        ProgressHelper.getInstance().cancel();
                        //土司
                        Toast.makeText(DiaryDbActivity.this,"上传成功",Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    @Override
    public void fail(String msg) {
        //防止activity销毁还进行该方法造成崩溃
        if(!isFinishing()) {
            //土司
            MyToast.showShortToast(msg);
            //loading消失
            ProgressHelper.getInstance().cancel();
        }
    }



}
