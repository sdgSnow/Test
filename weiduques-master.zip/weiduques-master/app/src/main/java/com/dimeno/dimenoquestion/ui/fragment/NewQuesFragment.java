package com.dimeno.dimenoquestion.ui.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.blankj.utilcode.util.NetworkUtils;
import com.dimeno.common.base.BaseFragment;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.QueBean;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.constant.Constant;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.db.Que;
import com.dimeno.dimenoquestion.ui.actvity.AnswerListActivity;
import com.dimeno.dimenoquestion.ui.actvity.DoSurveyActivity;
import com.dimeno.dimenoquestion.ui.adpter.NewQuesAdapter;
import com.dimeno.dimenoquestion.ui.presenter.NewQuesPresenter;
import com.dimeno.dimenoquestion.ui.view.NewQuesView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.PermissionCallback;
import com.dimeno.threadlib.ExecutorHandler;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.socks.library.KLog;

import org.litepal.LitePal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class NewQuesFragment extends BaseFragment<NewQuesPresenter>  implements  NewQuesView {
    private RecyclerView rcy_new_ques;
    public SmartRefreshLayout mRefreshLayout;
    private NewQuesAdapter newQuesAdapter ;
    private LinearLayout ll_Empty ;
    private TextView tv_Empty_Msg ;
    //未成功上传答卷
    private long successAnswers;

    private boolean isFrist=false;//是否第一次获取
    private boolean isSavedInstanceState=false;//数据暂存
    public static NewQuesFragment newInstance() {
        NewQuesFragment fragment = new NewQuesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_new_ques;
    }

    @Override
    public NewQuesPresenter createPresenter() {
        return new NewQuesPresenter();
    }

    @Override
    protected void initThings(View view,Bundle savedInstanceState) {
        if(savedInstanceState==null){
            //savedInstanceState为空，则改Activity为新建
            isSavedInstanceState=false;
        }else {
            //savedInstanceState不为空，则表明Activity被销毁重新创建，使用savedInstanceState恢复到之前的状态
            isSavedInstanceState=true;
        }
        ll_Empty = view.findViewById(R.id.ll_Empty);
        tv_Empty_Msg = view.findViewById(R.id.tv_Empty_Msg);

        //设置上下拉刷新的配置
        mRefreshLayout = view.findViewById(R.id.refresh_Layout);
        mRefreshLayout.setPrimaryColorsId(R.color.f5f4, R.color.app_back2);
        mRefreshLayout.setBackgroundColor(getResources().getColor(R.color.f5f4));
        mRefreshLayout.setRefreshHeader(new ClassicsHeader(getContext()));
        mRefreshLayout.setRefreshFooter(new ClassicsFooter(getContext()).setSpinnerStyle(SpinnerStyle.Scale));
        rcy_new_ques = view.findViewById(R.id.rcy_new_ques);
        rcy_new_ques.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));
    }

    @Override
    protected void initData() {

        newQuesAdapter = new NewQuesAdapter(new ArrayList<>());
        newQuesAdapter.setChildClickLisener(new NewQuesAdapter.OnChildClickLisener() {
            @Override
            public void onChildClick(View view,NewQuesBean newQuesBean) {
                switch (view.getId()){
                    case R.id.tv_see:
                        //跳转到答卷列表
                        Intent intent=new Intent();
                        intent.setClass(getActivity(), AnswerListActivity.class);
                        intent.putExtra("newQuesBean",  (Serializable) newQuesBean);
                        startActivity(intent);
                        break;
                    case R.id.tv_start_survey:
                        //跳转到立即调查
                        //先做权限判断
                        PermissionManager.request(getActivity(), new PermissionCallback() {
                            @Override
                            public void onGrant(String[] permissions) {
                                if(getActivity()!=null){
                                    Intent intent1=new Intent();
                                    intent1.putExtra("type","add");
                                    intent1.putExtra("newQuesBean", (Serializable) newQuesBean);
                                    intent1.setClass(getActivity(), DoSurveyActivity.class);
                                    startActivity(intent1);
                                }
                            }

                            @Override
                            public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                                if(getActivity()!=null) {
                                    MyToast.showShortToast("为了正常使用，请授予权限");
                                }
                            }

                            @Override
                            public void onNotDeclared(String[] permissions) {
                            }
                        }, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.RECORD_AUDIO);
                        break;
                }
            }
        });

        rcy_new_ques.setAdapter(newQuesAdapter);
        InitD();
    }

    public void InitD(){
        //判断是否有网络
        if(NetworkUtils.isConnected()) {
            //接口获取数据
            presenter.loadQuesList(getActivity());
        }else {
            //无网络获取本地
            List<Que> ques =null;
            if(!StringUtils.isEmpty(UserUtil.getUserId())){
                ques = LitePal.select().where("UserID = ?", UserUtil.getUserId()).find(Que.class);
            }
            ArrayList<NewQuesBean> localQueList = new ArrayList<>();
            if(ques!= null && ques.size()>0){
                //循环把所有数据添加到list中
                for (Que que : ques) {
                    String queBean = que.getQueBean();
                    NewQuesBean newQuesBean = JsonUtil.toObj(queBean, NewQuesBean.class);
                    localQueList.add(newQuesBean);
                }
                //根据创建时间手动排序列表
                Collections.sort(localQueList, new Comparator<NewQuesBean>() {
                    @Override
                    public int compare(NewQuesBean bean1, NewQuesBean bean2) {
                        return bean2.getCreateDate().compareTo(bean1.getCreateDate());
                    }
                });
                //展示list
                initQuesList(false,localQueList);
            }
        }
    }

    @Override
    public void initListeners() {
        //暂无数据刷新
        tv_Empty_Msg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                presenter.loadQuesList(getActivity());
                InitD();
            }
        });
        //下拉刷新
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(final RefreshLayout refreshlayout) {
                //恢复没有更多数据的原始状态 1.0.5
                mRefreshLayout.setNoMoreData(false);
                InitD();
            }
        });
        //上拉刷新
        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(final RefreshLayout refreshlayout) {
                InitD();
            }
        });
    }


    @Override
    public void initQuesList(boolean loadMore,ArrayList<NewQuesBean> quesBeanList) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //第一次创建，Activity第一次创建
                if(!isFrist && !isSavedInstanceState){
                    isFrist=true;
                    //检查是否有为上传的数据
                    checkData();
                }
                if(ProgressHelper.getInstance().isShow()){
                    ProgressHelper.getInstance().cancel();
                }
                //根据创建时间，重新排序
                Collections.sort(quesBeanList, new Comparator<NewQuesBean>() {
                    @Override
                    public int compare(NewQuesBean bean1, NewQuesBean bean2) {
                        return bean2.getCreateDate().compareTo(bean1.getCreateDate());
                    }
                });
                newQuesAdapter.setData(quesBeanList);
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
                if(quesBeanList.size() == 0){
                    ll_Empty.setVisibility(View.VISIBLE);
                }else {
                    if(ll_Empty.getVisibility()==View.VISIBLE){
                        ll_Empty.setVisibility(View.GONE);
                    }
                }
                if (!loadMore) {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if(tipAlert!=null){
            tipAlert = null;
        }
    }

    @Override
    public void loadFailure(boolean sucess, String message) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(ProgressHelper.getInstance().isShow()){
                    ProgressHelper.getInstance().cancel();
                }
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
            }
        });
    }

    private AlertView tipAlert;
    public void showTipAlert(String tip, Activity activity) {
        if (tipAlert == null) {
            tipAlert = new AlertView("", tip, null, new String[]{"确定"}, null, activity, AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {
                    tipAlert.dismiss();
                }
            });
        }
        if(tipAlert != null && tipAlert.isShowing()){
            tipAlert.dismiss();
        }
        tipAlert.setCancelable(true);
        tipAlert.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(Object o) {

            }
        });
        tipAlert.show();
    }

    /**
     * 检查是否还有未提交的数据未提交
     */
    public void checkData(){
        if(!StringUtils.isEmpty(UserUtil.getUserId())){
            successAnswers=  LitePal.where(" AnswerState < ? and userId= ?", AnswerState.UPLOAD+"",UserUtil.getUserId()).count(Answer.class);
        }
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        if(successAnswers>0){
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    showTipAlert("您还有问卷未上传",getActivity());
                                }
                            });
                        }
                    }
                });
    }
}
