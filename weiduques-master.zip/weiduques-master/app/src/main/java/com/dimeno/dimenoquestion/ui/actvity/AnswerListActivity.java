package com.dimeno.dimenoquestion.ui.actvity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.czt.mp3recorder.Log;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.constant.AnnexFileType;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.pop.AlertPopup;
import com.dimeno.dimenoquestion.ui.adpter.AnswerListRecyclerAdapter;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.presenter.AnswerListPresenter;
import com.dimeno.dimenoquestion.ui.view.AnswerListView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyLinearLayoutManager;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.OSSManager;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.dimeno.threadlib.ExecutorHandler;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.socks.library.KLog;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.LitePal;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.dimeno.dimenoquestion.constant.ApiConstant.getOssInfo;
import static com.dimeno.dimenoquestion.constant.OperationType.API;
import static com.dimeno.dimenoquestion.constant.OperationType.OPERATION;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :
 */
public class AnswerListActivity extends BaseActivity<AnswerListPresenter> implements AnswerListView {
    @BindView(R.id.rcy_new_ques)
    RecyclerView mRecyclerView;
    @BindView(R.id.refresh_Layout)
    SmartRefreshLayout mRefreshLayout;
    @BindView(R.id.ll_Empty)
    LinearLayout ll_Empty;
    @BindView(R.id.tv_Empty_Msg)
    TextView tv_Empty_Msg;

    private TextView tvSuccessAnswer, tvAllAnswer;
    private AnswerListRecyclerAdapter answerListAdapter;
    private long allAnswerCount;
    //上传成功答卷
    private long successAnswers;
    private String qId;
    private NewQuesBean newQuesBean;
    private int page = 1;
    private SurveyAnswerEntity surveyAnswerEntity;
    private long upTime = 0;//上传时间
    private long toastTime=0;//点击土司时间
    @Override
    protected int getLayoutId() {
        return R.layout.activity_answer_list;
    }

    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this, "答卷列表");
    }

    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
        //获取参数
        newQuesBean = (NewQuesBean) getIntent().getSerializableExtra("newQuesBean");
        //上下拉刷新设置配置
        mRefreshLayout.setPrimaryColorsId(R.color.f5f4, R.color.app_back2);
        mRefreshLayout.setBackgroundColor(getResources().getColor(R.color.f5f4));
        mRefreshLayout.setRefreshHeader(new ClassicsHeader(this));
        mRefreshLayout.setRefreshFooter(new ClassicsFooter(this).setSpinnerStyle(SpinnerStyle.Scale));

        mRecyclerView.setLayoutManager(new MyLinearLayoutManager(this));
        //使用AnswerListAdapter方式
//        answerListAdapter = new AnswerListRecyclerAdapter(this, R.layout.item_answer_layout);
        //使用AnswerListRecyclerAdapter方式
        answerListAdapter = new AnswerListRecyclerAdapter(this,null);
        mRecyclerView.setAdapter(answerListAdapter);
        //适配器设置头部
        View headerView = View.inflate(this, R.layout.answerlist_header_layout, null);
        headerView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UIUtils.dip2px(MyApplication.getContext(), 45)));
//        answerListAdapter.addHeaderView(headerView);
        answerListAdapter.addHeader(headerView);
        tvSuccessAnswer = headerView.findViewById(R.id.tvSuccessAnswer);
        tvAllAnswer = headerView.findViewById(R.id.tvAllAnswer);

        //判空
        if (newQuesBean != null) {
            qId = newQuesBean.ID;
            //根据QueID和UserId获取数据
            if(!StringUtils.isEmpty(qId) && !StringUtils.isEmpty(UserUtil.getUserId())) {
                allAnswerCount = LitePal.where("QueID=? and UserId = ?", qId, UserUtil.getUserId()).count(Answer.class);
                successAnswers = LitePal.where("QueID=? and UserId = ? and AnswerState = ?", qId, UserUtil.getUserId(), AnswerState.UPLOAD + "").count(Answer.class);
            }
            //如果有数据，显示与隐藏“没有数据”界面
            if (allAnswerCount == 0) {
                ll_Empty.setVisibility(View.VISIBLE);
            } else {
                ll_Empty.setVisibility(View.GONE);
            }

            tvAllAnswer.setText(allAnswerCount + "");
            tvSuccessAnswer.setText(successAnswers + "");
            //调接口获取数据
            presenter.quesList(qId, 1);
        }
    }

    @Override
    protected void initViews() {

    }

    @Override
    protected AnswerListPresenter createPresenter() {
        return new AnswerListPresenter();
    }

    @Override
    public void initListeners() {
        answerListAdapter.setMyOnItemClickListener(new AnswerListRecyclerAdapter.MyOnItemClickListener() {
            @Override
            public void onItemClick(int positon, Answer item) {
                //判断网络
                if(NetworkUtils.isConnected()){
                    //有网络情况
                    uploadAnswer(item);
                }else {
                    //没有网络
                    if(System.currentTimeMillis()-toastTime>1000){
                        //点击超过1S才显示土司
                        toastTime=System.currentTimeMillis();
                        Toast.makeText(AnswerListActivity.this,"当前网络不可用...",Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onItemLongClick(int positon, Answer answer) {
//                showTipUploadDialog(answer);
            }
        });


        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(final RefreshLayout refreshlayout) {
                //恢复没有更多数据的原始状态 1.0.5
                mRefreshLayout.setNoMoreData(false);
                //重新设置获取第一页数据
                page = 1;
                //调接口
                presenter.quesList(qId, page);
            }
        });
        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(final RefreshLayout refreshlayout) {
                //上拉加载更多，page加一
                page++;
                //调接口
                presenter.quesList(qId, page);
            }
        });
        tv_Empty_Msg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判空
                if (newQuesBean != null) {
                    //intent带参
                    Intent intent1 = new Intent();
                    intent1.putExtra("type", "add");
                    intent1.putExtra("newQuesBean", (Serializable) newQuesBean);
                    intent1.setClass(AnswerListActivity.this, DoSurveyActivity.class);
                    startActivity(intent1);
                    finish();
                }
            }
        });

    }

    @Override
    public void initQuesList(boolean loadMore, List<Answer> quesBeanList) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                answerListAdapter.notifyDataSetChanged();
                //设置新的数据
                answerListAdapter.setData(quesBeanList);
                //结束刷新
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                //结束刷新
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
                //结束加载更多
                if (!loadMore) {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    private ArrayList<SurveyAnswer> surveyList = new ArrayList<>();//有文件的题目答案
    private int current = 0;//当前题目里面上传的进度
    private int surveyPosition = 0;//当前问卷题目上传答案position
    private int uploadCount = 0;//要上传的文件总数
    private int sucessuploadCount = 0;//已上传的文件总数
    private String ossDirectory = "";

    /**
     * 获取文件总数
     */
    private void getUploadCount() {
        //判空
        if (surveyList.size() != 0) {
            //循环
            for (int i = 0; i < surveyList.size(); i++) {
                //判空
                if (surveyList.get(i).annexList != null && surveyList.get(i).annexList.size() != 0) {
                    uploadCount = uploadCount + surveyList.get(i).annexList.size();
                }
            }
        }
    }

    /**
     * 上传文件df
     */
    public void getOssInfo(Answer answer) {
        if (surveyList.size() != 0) {
            if (surveyPosition < surveyList.size()) {
                //获取surveyList中的第uploadSize个item
                SurveyAnswer surveyAnswer = surveyList.get(surveyPosition);
                //获取答案列表中的第currunt个文件
                if (surveyAnswer.annexList != null && surveyAnswer.annexList.size() != 0) {
                    if (current < surveyAnswer.annexList.size()) {
//                        //录音文件，路径是filepath，其他是path
//                        if (surveyAnswer.annexList.get(current).fileType == FileType.RECORD) {
//                            upload(answer,surveyAnswer,surveyAnswer.annexList.get(current).filepath);
//                        } else {
//                            upload(answer,surveyAnswer,surveyAnswer.annexList.get(current).path);
//                        }

                        //录音文件，路径是filepath，其他是path
                        String filepath="";
                        int fileType= surveyAnswer.annexList.get(current).fileType;
                        if (surveyAnswer.annexList.get(current).fileType == FileType.RECORD) {
                            filepath=surveyAnswer.annexList.get(current).filepath;
//
//                            //如果录音路径为空，兼容是否是附件
//                            if(StringUtils.isEmpty(filepath)){
//                                filepath=surveyAnswer.annexList.get(current).path;
//                                //如果路径不为空，强制
//                                if(!StringUtils.isEmpty(filepath)) {
//                                    switch (fileType) {
//                                        case AnnexFileType.ALL:
//                                            fileType = FileType.FILE;
//                                            break;
//                                        case AnnexFileType.IMAGE:
//                                            fileType = FileType.IMAGE;
//                                            break;
//                                        case AnnexFileType.AUDIO:
//                                            fileType = FileType.AUDIO;
//                                            break;
//                                        case AnnexFileType.VIDEO:
//                                            fileType = FileType.VIDEO;
//                                            break;
//                                        case AnnexFileType.FILE:
//                                            fileType = FileType.DOCUMENT;
//                                            break;
//                                    }
//                                }
//                            }
                        }else {
                            filepath=surveyAnswer.annexList.get(current).path;
                        }
                        //判空
                        if (!StringUtils.isEmpty(filepath)) {
                            //录音文件
                            if (FileUtils.fileExist(filepath)) {
                                if(surveyAnswer.annexList.get(current).ossUpload){
                                    //因为已上传，这里sucessuploadCount++，添加进度，只能这里有ossUpload判断，才能添加 sucessuploadCount++
                                    sucessuploadCount++;
                                    current++;
                                    getOssInfo(answer);
                                }else {
                                    presenter.getOssInfo(answer, AnswerListActivity.this, surveyAnswer, filepath, fileType,surveyAnswer.annexList.get(current));
                                }
                            } else {
                                showTipDialog(answer, surveyAnswer.annexList.get(current).fileType,filepath);
                            }
                        } else {
                            current++;
                            //没有文件，成功总数也要加1
                            sucessuploadCount++;
                            getOssInfo(answer);
                        }

                    } else {
                        if (surveyPosition < surveyList.size() - 1) {
                            //如果上一个答案的附件为0，则进行下一个答案的文件上传
                            surveyPosition++;
                            current = 0;
                            getOssInfo(answer);
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //如果上传成功数等于要上传的总数
                                    if (sucessuploadCount == uploadCount) {
                                        ProgressHelper.getInstance().setTitle("已上传100%");
                                        presenter.dealWithAnswerDataUpload(AnswerListActivity.this, answer, surveyAnswerEntity, ossDirectory);
                                    }
                                }
                            });
                        }
                    }
                } else {
                    //如果上一个答案的附件为0，则进行下一个答案的文件上传
                    surveyPosition++;
                    current = 0;
                    getOssInfo(answer);
                }
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //如果上传成功数等于要上传的总数
                        if (sucessuploadCount == uploadCount) {
                            ProgressHelper.getInstance().setTitle("已上传100%");
                            presenter.dealWithAnswerDataUpload(AnswerListActivity.this, answer, surveyAnswerEntity, ossDirectory);
                        }
                    }
                });
            }
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ProgressHelper.getInstance().setTitle("已上传100%");
                    presenter.dealWithAnswerDataUpload(AnswerListActivity.this, answer, surveyAnswerEntity, ossDirectory);
                }
            });
        }
    }

    public void upload(Answer answer,SurveyAnswer surveyAnswer,String path){
        if (!StringUtils.isEmpty(path)) {
            if (FileUtils.fileExist(path)) {
                //添加文件是否为0kb的异常处理
                if(new File(path).length() == 0){
                    MyToast.showShortToast("文件异常：" + path);
                    return;
                }
                if(surveyAnswer.annexList.get(current).ossUpload){
                    //因为已上传，这里sucessuploadCount++，添加进度，只能这里有ossUpload判断，才能添加 sucessuploadCount++
                    sucessuploadCount++;
                    current++;
                    getOssInfo(answer);
                }else {
                    presenter.getOssInfo(answer, AnswerListActivity.this, surveyAnswer, path, surveyAnswer.annexList.get(current).fileType,surveyAnswer.annexList.get(current));
                }
            } else {
                showTipDialog(answer, surveyAnswer.annexList.get(current).fileType, path);
            }
        } else {
            current++;
            sucessuploadCount++;
            getOssInfo(answer);
        }
    }

    @Override
    public void success(Answer answer, OssInfoEntity ossInfoEntity, SurveyAnswer surveyAnswer, String filepath, int type,AnnexEntity annexEntity) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                OSSManager.get()
                        .setContext(MyApplication.getContext())
                        .accessKeyId(ossInfoEntity.AccessKeyId)
                        .accessKeySecret(ossInfoEntity.AccessKeySecret)
                        .securityToken(ossInfoEntity.SecurityToken)
                        .endPoint(ossInfoEntity.endpoint)
                        .bucket(ossInfoEntity.BucketName)
                        .directory(ossInfoEntity.Directory)
                        .queId(answer.getQueID())
//                        .file(filepath)
                        .callback(new OSSManager.Callback() {
                            @Override
                            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                            }

                            @Override
                            public void onSuccess(String ossPath) {
                                //MyToast.showShortToast("上传成功");

                                //添加oss路径前缀
                                if (!StringUtils.isEmpty(ossInfoEntity.Directory)) {
                                    ossDirectory = ossInfoEntity.Directory;
                                }
                                if(type == FileType.RECORD) {
                                    //录音文件，转成mp3格式
                                    String recordDetail = answer.getRecordDetail();
                                    KLog.e("2021-9:" + recordDetail);
                                    if (!TextUtils.isEmpty(recordDetail)) {
                                        SurveyAnswer recordAnswer = JsonUtil.toObj(recordDetail, SurveyAnswer.class);
                                        if (recordAnswer.annexList != null) {
                                            for (AnnexEntity entity : recordAnswer.annexList) {
                                                if (entity.record_id.equals(annexEntity.record_id)) {
                                                    entity.ossPath = ossPath;
                                                    entity.ossUpload=true;
                                                    //更新答案
                                                    answer.setRecordDetail(JsonUtil.toJson(recordAnswer));
                                                    int update= answer.update(answer.getId());
                                                    if(update!=1){
                                                        ProgressHelper.getInstance().cancel();
                                                        Toast.makeText(AnswerListActivity.this,"系统繁忙，请稍后重试 10002",Toast.LENGTH_LONG).show();
                                                        return;
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }else {
                                    //答题详情
                                    String sury = answer.getAnswerDetail();
                                    if (!StringUtils.isEmpty(sury)) {
                                        //获取答案详情
                                        surveyAnswerEntity = JsonUtil.toObj(sury, SurveyAnswerEntity.class);
                                        if (surveyAnswerEntity != null) {
                                            //获取答案页
                                            if (surveyAnswerEntity.surveyAnswers != null && surveyAnswerEntity.surveyAnswers.size() != 0) {
                                                for (SurveyAnswerEntity.AnswerPage answerItem : surveyAnswerEntity.surveyAnswers) {
                                                    //获取每页答案的答案列表
                                                    if (answerItem.getSurveyAnswers() != null && answerItem.getSurveyAnswers().size() != 0) {
                                                        for (SurveyAnswer surveyAnswerItem : answerItem.getSurveyAnswers()) {
                                                            boolean flag=false;
                                                            if(surveyAnswerItem.subId==surveyAnswer.subId){
                                                                for (AnnexEntity entity : surveyAnswerItem.annexList) {
                                                                    if (!StringUtils.isEmpty(entity.path) && !StringUtils.isEmpty(annexEntity.path)
                                                                            && entity.path.equals(annexEntity.path) && !entity.ossUpload) {
                                                                        //路径相同，且没有上传过
                                                                        entity.ossPath = ossPath;
                                                                        entity.ossUpload=true;
                                                                        //更新答案
                                                                        answer.setAnswerDetail(JsonUtil.toJson(surveyAnswerEntity));
                                                                        int update= answer.update(answer.getId());
                                                                        if(update!=1){
                                                                            ProgressHelper.getInstance().cancel();
                                                                            Toast.makeText(AnswerListActivity.this,"系统繁忙，请稍后重试 10001",Toast.LENGTH_LONG).show();
                                                                            return;
                                                                        }
                                                                        flag=true;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                            if(flag){
                                                                //退出循环
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                LogUtils.addLog(getOssInfo, API, answer.getQueID(),answer.getAnswerStartTime(), "oss上传成功", JsonUtil.toJson(answer)+"------------------"+JsonUtil.toJson(annexEntity));
                                MyLog.i("OSSManager", "oss sucess path=" + filepath);
                                //上传文件总数加1
                                sucessuploadCount++;
                                String progress = MyUtils.getProgress(sucessuploadCount, uploadCount);
                                MyLog.i("OSSManager", "uploadCount=" + uploadCount + "      sucessuploadCount=" + sucessuploadCount + "  progress=" + progress);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        ProgressHelper.getInstance().setTitle("已上传" + Integer.parseInt(progress) + "%");
//                                        PopManager.get().setProgress(Integer.parseInt(progress));
                                    }
                                });

                                if (sucessuploadCount == uploadCount) {
                                    //上传文件数等于要上传的文件总数
                                    presenter.dealWithAnswerDataUpload(AnswerListActivity.this, answer, surveyAnswerEntity, ossDirectory);
                                }else {
                                    //该题目里的下一个文件
                                    current++;
                                    //surveyList的uploadSize个item的文件上传完成
                                    if (current < surveyAnswer.annexList.size()) {
                                        getOssInfo(answer);
                                    } else {
                                        //surveyList的uploadSize+1,获取列表第uploadSize+1个item进行上传，并设置 currunt=0，从第一个文件开始上传
                                        if (surveyPosition < surveyList.size()) {
                                            //surveyList的uploadSize个item
                                            current = 0;
                                            surveyPosition++;
                                            getOssInfo(answer);
                                        }
                                    }
                                }
                            }

                            @Override
                            public void onFailure(String message) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
//                                        T.show(message);
                                        Toast.makeText(AnswerListActivity.this,"通讯异常，请稍后重试：" + message,Toast.LENGTH_LONG).show();
                                        LogUtils.addLog(getOssInfo, API, answer.getQueID(),answer.getAnswerStartTime(), "oss上传失败", JsonUtil.toJson(answer)+"------------------"+JsonUtil.toJson(annexEntity));
                                        ProgressHelper.getInstance().cancel();
                                    }
                                });
//                                PopManager.get().hideProgress();
                            }
                        }).upload(surveyAnswer.subType,type,filepath);
            }
        });

    }

    @Override
    public void success(UploadEntity entity, Answer answer) {
        if (!isFinishing()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //判空
                    if (entity != null) {
                        //获取数据
                        String resultObj = entity.getResultObj();
                        String resultAnswerId = "";
                        if (!TextUtils.isEmpty(resultObj)) {
                            String[] split = resultObj.split(",");
                            try {
                                resultAnswerId = split[0];
                            } catch (Exception e) {
                                ToastUtils.showShort("解析返回答卷id异常");
                            }
                        }
                        if (entity.getFlag() == 0 && answer.getAnswerCode().equals(resultAnswerId)) {
                            if (answer != null) {
                                answer.setAnswerState(AnswerState.UPLOAD);
                                answer.update(answer.getId());
                            }
                            MyToast.showLongToast("上传成功");
                            mRefreshLayout.setNoMoreData(false);//恢复没有更多数据的原始状态 1.0.5
                            //重新获取数据
                            page = 1;
                            presenter.quesList(qId, page);
                            if(!StringUtils.isEmpty(qId) && !StringUtils.isEmpty(UserUtil.getUserId())) {
                                allAnswerCount = LitePal.where("QueID=? and UserId = ?", qId, UserUtil.getUserId()).count(Answer.class);
                                successAnswers = LitePal.where("QueID=? and UserId = ? and AnswerState = ?", qId, UserUtil.getUserId(), AnswerState.UPLOAD + "").count(Answer.class);
                            }
                            tvSuccessAnswer.setText(successAnswers + "");
                            tvAllAnswer.setText(allAnswerCount + "");
                        } else {
                            MyToast.showLongToast(entity.getMsg());
                        }
                    }
                    ProgressHelper.getInstance().cancel();
//                    PopManager.get().hideProgress();
                }
            });
        }
    }

    @Override
    public void fail() {
        if (!isFinishing()) {
//            PopManager.get().hideProgress();
            ProgressHelper.getInstance().cancel();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //重新刷新数据
        if (requestCode == ConstantUtil.ACTIVITY_FLUSH && resultCode == 1) {
            ExecutorHandler.getInstance().forBackgroundTasks().execute(new Runnable() {
                @Override
                public void run() {
                    page = 1;
                    presenter.quesList(qId, page);
                    if(!StringUtils.isEmpty(qId) && !StringUtils.isEmpty(UserUtil.getUserId())) {
                        allAnswerCount = LitePal.where("QueID=? and UserId = ?", qId, UserUtil.getUserId()).count(Answer.class);
                        successAnswers = LitePal.where("QueID=? and UserId = ? and AnswerState = ?", qId, UserUtil.getUserId(), AnswerState.UPLOAD + "").count(Answer.class);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mRefreshLayout.setNoMoreData(false);//恢复没有更多数据的原始状态 1.0.5
                            tvSuccessAnswer.setText(successAnswers + "");
                            tvAllAnswer.setText(allAnswerCount + "");
                        }
                    });
                }
            });
        }
    }

    /**
     *
     */
    private void uploadTipDialog(SurveyAnswerEntity surveyAnswerEntity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.dialog);
        LayoutInflater inflater = LayoutInflater.from(this);
        View vw = inflater.inflate(R.layout.alert_tip_quit, null);
        final AlertDialog dialog = builder.setView(vw).create();
        dialog.show();
        View btnYes = vw.findViewById(R.id.btn_del_yes);
        TextView tvTip = vw.findViewById(R.id.tvTip);
        View btnNo = vw.findViewById(R.id.btn_del_no);

        tvTip.setText(getString(R.string.continue_use_gprs));
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    private AlertPopup uploadPopup;

    private void showTipUploadDialog(Answer answer) {
        ProgressHelper.getInstance().cancel();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                uploadPopup = new AlertPopup(AnswerListActivity.this, "提示", "是否仍然上传已上传答卷");
                uploadPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                    @Override
                    public void onItemClick(boolean flag) {
                        if (uploadPopup != null && uploadPopup.isShowing()) {
                            uploadPopup.dismiss();
                            uploadPopup = null;
                        }
                        if (flag) {
                            uploadAnswer(answer);
                        }
                    }
                });
                uploadPopup.showAtLocation(mRecyclerView, Gravity.CENTER, 0, 0);
            }
        });
    }

    private void uploadAnswer(Answer itemAnswer) {
        //1000ms以内的点击才有效
        if (System.currentTimeMillis() - upTime > 1000 ) {
            Log.d("onItemClick", "开始上传");
            upTime = System.currentTimeMillis();
            if (presenter.getMvpView() != null) {
                ProgressHelper.getInstance().show(AnswerListActivity.this, "请稍等...", false);
            }
            Answer answer = null;
            List<Answer> answers=null;
            if(itemAnswer.getId()!=null){
                answers = LitePal.select().where("id= ?", itemAnswer.getId() + "").find(Answer.class);
            }
            if (answers != null && answers.size() != 0) {
                answer = answers.get(0);
            }
            if (answer != null) {
                surveyList.clear();
                String sury = answer.getAnswerDetail();
                if (!StringUtils.isEmpty(sury)) {
                    //获取答案详情
                    surveyAnswerEntity = JsonUtil.toObj(sury, SurveyAnswerEntity.class);
                    if (surveyAnswerEntity != null) {
                        //获取答案页
                        if (surveyAnswerEntity.surveyAnswers != null && surveyAnswerEntity.surveyAnswers.size() != 0) {
                            for (SurveyAnswerEntity.AnswerPage answerItem : surveyAnswerEntity.surveyAnswers) {
                                //获取每页答案的答案列表
                                if (answerItem.getSurveyAnswers() != null && answerItem.getSurveyAnswers().size() != 0) {
                                    for (SurveyAnswer surveyAnswer : answerItem.getSurveyAnswers()) {
                                        switch (surveyAnswer.subType) {
                                            case QueFormat.Annex://15;//附件
                                            case QueFormat.Sign://28;//签名

                                                surveyList.add(surveyAnswer);
                                                break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                String recordDetail = answer.getRecordDetail();
                if (!StringUtils.isEmpty(recordDetail)) {
                    SurveyAnswer recordAnswer = JsonUtil.toObj(recordDetail, SurveyAnswer.class);
                    if (recordAnswer != null) {
                        surveyList.add(recordAnswer);
                    }
                }
                current = 0;
                surveyPosition = 0;//当前上传答案position
                uploadCount = 0;//要上传的文件总数
                sucessuploadCount = 0;//已上传的文件总数
                ossDirectory = "";//清空oss路径
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (presenter.getMvpView() != null) {
//                                    ProgressHelper.getInstance().cancel();
//                                    PopManager.get().showProgress(AnswerListActivity.this);
                            ProgressHelper.getInstance().setTitle("开始上传...");
                        }
                    }
                });
                getUploadCount();
                getOssInfo(answer);
            }
        }
    }

    private AlertView tipAlert;

    public void showTipAlert(Answer answer) {
        if (tipAlert == null) {
            tipAlert = new AlertView("是否删除？", "删除答卷会清除所有相关数据（包括附件资料）", "取消", new String[]{"确定"}, null, AnswerListActivity.this, AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {
                    if (position >= 0) {
                        if (answer != null) {
                            LogUtils.addLog("", OPERATION, answer.getQueID(),answer.getAnswerStartTime(), "答卷列表删除答卷", JsonUtil.toJson(answer));
                            ArrayList<SurveyAnswer> anx = presenter.getAnx(surveyAnswerEntity, answer);
                            if (anx != null && anx.size() != 0) {
                                for (int i = 0; i < anx.size(); i++) {
                                    if (anx.get(i).annexList != null) {
                                        for (int i1 = 0; i1 < anx.get(i).annexList.size(); i1++) {
//                                            //录音文件是filepath
//                                            if (!StringUtils.isEmpty(anx.get(i).annexList.get(i1).filepath)) {
//                                                FileUtils.deleteFile(anx.get(i).annexList.get(i1).filepath);
//                                            }
                                            //其他文件是path
                                            if (!StringUtils.isEmpty(anx.get(i).annexList.get(i1).path)) {
                                                FileUtils.deleteFile(anx.get(i).annexList.get(i1).path);
                                            }
                                        }
                                    }
                                }
                            }
                            answer.delete();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    answerListAdapter.getDatas().remove(answer);
                                    answerListAdapter.notifyDataSetChanged();
                                    successAnswers = successAnswers - 1;
                                    allAnswerCount = allAnswerCount - 1;
                                    tvSuccessAnswer.setText(successAnswers >= 0 ? (successAnswers + "") : "0");
                                    tvAllAnswer.setText(allAnswerCount >= 0 ? (allAnswerCount + "") : "0");
                                    MyToast.showLongToast("删除成功");
                                }
                            });

                        }
                    }
                    tipAlert.dismiss();
                }
            });
        }
        tipAlert.setCancelable(true);
        tipAlert.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(Object o) {
                tipAlert = null;
            }
        });
        tipAlert.show();
    }

    private AlertPopup tipPopup;

    private void showTipDialog(Answer answer, int fileType, String path) {
        ProgressHelper.getInstance().cancel();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                tipPopup = new AlertPopup(AnswerListActivity.this, "提示",(fileType==FileType.RECORD?"录音":"附件") + "文件不存在或者已经删除，答卷无法上传\n\n" + path);
                tipPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                    @Override
                    public void onItemClick(boolean flag) {
                        if (tipPopup != null && tipPopup.isShowing()) {
                            tipPopup.dismiss();
                            tipPopup = null;
                        }
                    }
                });
                tipPopup.showAtLocation(mRecyclerView, Gravity.CENTER, 0, 0);
            }
        });
    }

    private AlertPopup alertPopup;

    private void showQuitDialog(Answer answer, String fileType, String path) {
        //如果使用改功能
        ProgressHelper.getInstance().cancel();
        if (true) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!isFinishing()) {
                        alertPopup = new AlertPopup(AnswerListActivity.this, "提示", fileType + "文件不存在或者已经删除，是否继续上传？\n\n" + path);
                        alertPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                            @Override
                            public void onItemClick(boolean flag) {
                                if (alertPopup != null && alertPopup.isShowing()) {
                                    alertPopup.dismiss();
                                    alertPopup = null;
                                }
                                if (flag) {
                                    sucessuploadCount++;
                                    current++;
                                    getOssInfo(answer);
                                } else {
//                                    PopManager.get().hideProgress();
                                }
                            }
                        });
                        alertPopup.showAtLocation(mRecyclerView, Gravity.CENTER, 0, 0);
                    }
                }
            });
        } else {
            sucessuploadCount++;
            current++;
            getOssInfo(answer);
        }
    }


}
