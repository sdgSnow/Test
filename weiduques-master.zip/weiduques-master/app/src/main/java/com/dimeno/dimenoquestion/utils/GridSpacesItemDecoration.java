package com.dimeno.dimenoquestion.utils;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.common.utils.UIUtils;

public class GridSpacesItemDecoration extends RecyclerView.ItemDecoration {
    //列数
    private int mSpanCount;
    //间隔
    private int mSpacing;
    //是否有边缘
    private boolean mIsIncludeEdge;

    /**
     * GridSpacesItemDecoration
     * @param context
     * @param spanCount
     * @param spacing
     * @param isIncludeEdge
     */
    public GridSpacesItemDecoration(Context context, int spanCount, int spacing, boolean isIncludeEdge) {
        this.mSpanCount = spanCount;
        this.mSpacing = UIUtils.px2dp(spacing);
        this.mIsIncludeEdge = isIncludeEdge;
    }

    /**
     * getItemOffsets
     * @param outRect
     * @param view
     * @param parent
     * @param state
     */
    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        //判断你有几列，设置item
        int position = parent.getChildAdapterPosition(view); // item position
        int column = position % mSpanCount; // item column

        if (mIsIncludeEdge) {
            outRect.left = mSpacing - column * mSpacing / mSpanCount; // spacing - column * ((1f / spanCount) * spacing)
            outRect.right = (column + 1) * mSpacing / mSpanCount; // (column + 1) * ((1f / spanCount) * spacing)

            if (position < mSpanCount) { // top edge
                outRect.top = mSpacing;
            }
            outRect.bottom = mSpacing; // item bottom
        } else {
            outRect.left = column * mSpacing / mSpanCount; // column * ((1f / spanCount) * spacing)
            outRect.right = mSpacing - (column + 1) * mSpacing / mSpanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
            if (position >= mSpanCount) {
                outRect.top = mSpacing; // item top
            }
        }
    }

}
