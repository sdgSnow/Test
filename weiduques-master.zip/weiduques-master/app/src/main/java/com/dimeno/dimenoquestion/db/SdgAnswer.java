package com.dimeno.dimenoquestion.db;

import org.litepal.crud.LitePalSupport;

import java.util.List;

public class SdgAnswer extends LitePalSupport {

    public Long id;
    public String answerCode;
    public String answerId;
    public String queID;
    public String queTitle;
    // 所选的区域名称
    public String answerLoc;
    public String queCreateDate;
    public String queModifyDate;
    public Long answerFinishTime;
    public Long answerStartTime;
    public String answerDetail;
    public String userId;

    //答案存储
    public List<SubjectAnswer> subjectAnswers;
}
