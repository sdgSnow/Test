package com.dimeno.dimenoquestion.utils;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.RemoteException;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.core.content.ContextCompat;

import com.blankj.utilcode.util.RegexUtils;
import com.dimeno.common.base.BaseApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.mode.DateCharFormat;

import java.lang.reflect.Method;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class StringUtils {

    /**
     * 判断给定字符串是否空白串。 空白串是指由空格、制表符、回车符、换行符组成的字符串 若输入字符串为null或空字符串，返回true
     *
     * @param input
     * @return boolean
     */
    public static boolean isEmpty(String input) {
        if (input == "null" || input == null || "".equals(input) || input.equals("null") || input.equals("NaN"))
            return true;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c != ' ' && c != '\t' && c != '\r' && c != '\n' && c != '"') {
                return false;
            }
        }
        return true;
    }

    public static SpannableStringBuilder getTitle(String title, boolean isMust) {
        if(isEmpty(title))
            return null;
        SpannableStringBuilder builder = new SpannableStringBuilder(title);
        if (isMust) {
            int start = builder.length();
            builder.append("*");
            int end = builder.length();
            builder.setSpan(new ForegroundColorSpan(ContextCompat.getColor(BaseApplication.getContext(), R.color.color_red)), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return builder;
    }

    /**
     *
     * @param pattern
     * @param value
     * @return
     */
    public static boolean checkValue(String pattern, Object value) {
        return RegexUtils.isMatch(pattern, String.valueOf(value));
    }

    public static boolean[] getTimeTypes(int charFormat) {
        switch (charFormat) {
            case DateCharFormat.ymd_hms:
                return new boolean[]{true, true, true, true, true, true};
            case DateCharFormat.ymd:
                return new boolean[]{true, true, true, false, false, false};
            case DateCharFormat.ym:
                return new boolean[]{true, true, false, false, false, false};
            case DateCharFormat.hms:
                return new boolean[]{false, false, false, true, true, true};
            case DateCharFormat.hm:
                return new boolean[]{false, false, false, true, true, false};
        }
        return new boolean[]{true, true, true, false, false, false};
    }

    public static String getTimeFormat(int charFormat) {
        switch (charFormat) {
            case DateCharFormat.ymd_hms:
                return "yyyy年MM月dd日 HH时mm分ss秒";
            case DateCharFormat.ymd:
                return "yyyy年MM月dd日";
            case DateCharFormat.ym:
                return "yyyy年MM月";
            case DateCharFormat.hms:
                return "HH时mm分ss秒";
            case DateCharFormat.hm:
                return "HH时mm分";
        }
        return "yyyy年MM月dd日";
    }

    //获取系统字体大小
    //0.85 小, 1 标准大小, 1.15 大，1.3 超大 ，1.45 特大
    public static float getFontSize() {
        try {
            Class iActivityManager = Class.forName("android.app.IActivityManager");
            Class activityManagerNative = Class.forName("android.app.ActivityManagerNative");
            Method getDefault = activityManagerNative.getDeclaredMethod("getDefault");
            Object objIActMag = getDefault.invoke(activityManagerNative);
            Method getConfiguration = iActivityManager.getDeclaredMethod("getConfiguration");
            Configuration mCurConfig = (Configuration) getConfiguration.invoke(objIActMag);
            Log.w("getFontSize", "getFontSize(), Font size is " + mCurConfig.fontScale);
            return mCurConfig.fontScale;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 隐藏软键盘(只适用于Activity，不适用于Fragment)
     */
    public static void hideSoftKeyboard(Activity activity) {
        if(activity!=null && !activity.isDestroyed()) {
            View view = activity.getCurrentFocus();
            if (view != null) {
                InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }


    /**
     * 获取文件名及后缀
     */
    public static String getFileNameWithSuffix(String path) {
        if (TextUtils.isEmpty(path)) {
            return "";
        }
        int start = path.lastIndexOf("/");
        if (start != -1) {
            return path.substring(start + 1);
        } else {
            return "";
        }
    }

    /**
     * 判断是否是数字或字符
     * @param pwd
     * @return
     */
    public static boolean isPassword(String pwd){
        String regex = "^[a-zA-Z0-9]+$";
        return pwd.matches(regex);
    }
}
