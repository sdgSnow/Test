package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.pop.AlertPopup;
import com.dimeno.dimenoquestion.ui.actvity.AnswerListActivity;
import com.dimeno.dimenoquestion.ui.adpter.AutoIncrementAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;
import com.sdg.dialoglibrary.pop.PopManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :自增表格
 */
public class AutoIncrementHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_new_line;
    private final TextView tv_del_last;
    private final RecyclerView recyclerView;
    //保存AttrBean
    private List<List<AttrBean>> cusAttrList = new ArrayList<>();
    //map保存适配器
    private Map<Integer,AutoIncrementAdapter> map=new HashMap<>();
    //mapdata保存数据
    private Map<Integer,List<List<AttrBean>>> mapData=new HashMap<>();
    private SpannableStringBuilder title;
    //红色边框
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    //add新添加，edit编辑，look查看
    private String type;
    //弹框
    private AlertPopup alertPopup;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public AutoIncrementHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_auto_increment);
        //title
        tvTitle = findViewById(R.id.tvTitle);
        //注释
        tv_remark = findViewById(R.id.tv_remark);
        tv_new_line = findViewById(R.id.tv_new_line);
        tv_del_last = findViewById(R.id.tv_del_last);
        recyclerView = findViewById(R.id.rcy_auto_increment);
        //红色边框
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
        MyLog.d("adpterFlush","自增表格 create");
    }

    @Override
    public void bind() {
        //attr不为空
        if(mData.getAttr()!=null) {
            //获取title
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            //设置title
            tvTitle.setText(title == null ? "" : title);
            //设置注释
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            //注释显示与隐藏
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                //红色边框显示
                frame_error.setVisibility(View.VISIBLE);
            } else {
                //红色边框隐藏
                frame_error.setVisibility(View.GONE);
            }
            if (type.equals("look")) {
                //查看状态
                tv_new_line.setVisibility(View.GONE);
                tv_del_last.setVisibility(View.GONE);
            }
            //设置方向
            recyclerView.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));
            MyLog.d("adpterFlush", "自增表格 flush position=" + getAdapterPosition());
            if(mData.getAttr().getCusAttr()!=null) {
                if (map.get(getAdapterPosition()) == null) {
                    cusAttrList.clear();
                    //如果答案有多个题,则复制题
                    if (mData.getSurveyAnswer().mAutoIncrementAnswer != null && mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers != null && mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size() != 0) {
                        //循环答案
                        for (int i = 0; i < mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size(); i++) {
                            cusAttrList.add(mData.getAttr().getCusAttr());
                        }
                    } else {
                        cusAttrList.add(mData.getAttr().getCusAttr());
                    }
                    //循环cusAttrList
                    for (int i = 0; i < cusAttrList.size(); i++) {
                        //初始化答案
                        addInit(i);
                    }
                    //初始化适配器
                    AutoIncrementAdapter autoIncrementAdapter = new AutoIncrementAdapter(cusAttrList, mData, type);
                    //设置适配器
                    recyclerView.setAdapter(autoIncrementAdapter);
                    //适配器监听
                    autoIncrementAdapter.setChildClickLisener(new AutoIncrementAdapter.OnChildClickLisener() {
                        @Override
                        public void onChildClick() {
                            if (mData.isError()) {
                                //红色边框显示，设置不显示
                                mData.setError(false);
                                //隐藏红色边框
                                frame_error.setVisibility(View.GONE);
                            }
                        }
                    });
                    //map保存视频且
                    map.put(getAdapterPosition(), autoIncrementAdapter);
                    mapData.put(getAdapterPosition(), cusAttrList);
                    //继续填写监听
                    tv_new_line.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //行数添加
                            cusAttrList.add(mData.getAttr().getCusAttr());
                            //新的行初始化答案
                            addInit(cusAttrList.size() - 1);
                            //刷新数据
                            autoIncrementAdapter.notifyDataSetChanged();
                        }
                    });
                    //删除监听
                    tv_del_last.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //单总行数大于1
                            if (cusAttrList.size() > 1) {
                                //提示是否删除
                                alertPopup = new AlertPopup(itemView.getContext(), "提示", "是否删除该末行?");
                                //点击事件
                                alertPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                                    @Override
                                    public void onItemClick(boolean flag) {
                                        if (flag) {
                                            //点击确定
                                            //去掉最后一行
                                            cusAttrList.remove(cusAttrList.size() - 1);
                                            //答案去掉改行
                                            mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.remove(cusAttrList.size());
                                            //核验规则
                                            autoIncrementAdapter.check();
                                            //刷新
                                            autoIncrementAdapter.notifyDataSetChanged();
                                        }
                                        //弹框隐藏
                                        alertPopup.dismiss();
                                        alertPopup = null;
                                    }
                                });
                                //显示弹框
                                alertPopup.showAtLocation(recyclerView, Gravity.CENTER, 0, 0);

                            } else {
                                //土司
                                MyToast.showLongToast("至少保留一行");
                            }
                        }
                    });
                } else {
                    //map中有适配器
                    cusAttrList = mapData.get(getAdapterPosition());
                    AutoIncrementAdapter autoIncrementAdapter = map.get(getAdapterPosition());
                    //判空
                    if (mData.getSurveyAnswer().mAutoIncrementAnswer != null && mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers != null /*&& mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size()!=0*/) {
                        //如果数据不一致了，则重新更新数据,防止隐藏题目清除答案之后，要重新初始化答题，不然易报错
                        if (cusAttrList.size() != mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size()) {
                            //清空
                            cusAttrList.clear();
                            //判空
                            if (mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size() != 0) {
                                //循环
                                for (int i = 0; i < mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size(); i++) {
                                    //添加
                                    cusAttrList.add(mData.getAttr().getCusAttr());
                                }
                            } else {
                                cusAttrList.add(mData.getAttr().getCusAttr());
                            }
                            //循环初始化
                            for (int i = 0; i < cusAttrList.size(); i++) {
                                addInit(i);
                            }
                            //设置数据
                            autoIncrementAdapter.setNewData(cusAttrList);
                        }
                    }
                    recyclerView.setAdapter(autoIncrementAdapter);
                    autoIncrementAdapter.setChildClickLisener(new AutoIncrementAdapter.OnChildClickLisener() {
                        @Override
                        public void onChildClick() {
                            if (mData.isError()) {
                                //红色边框显示，设置不显示
                                mData.setError(false);
                                //隐藏红色边框
                                frame_error.setVisibility(View.GONE);
                            }
                        }
                    });
                    //继续填写监听
                    tv_new_line.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //行数添加
                            cusAttrList.add(mData.getAttr().getCusAttr());
                            //新的行初始化答案
                            addInit(cusAttrList.size() - 1);
                            //刷新数据
                            autoIncrementAdapter.notifyDataSetChanged();
                        }
                    });
                    tv_del_last.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //单总行数大于1
                            if (cusAttrList.size() > 1) {
                                //提示是否删除
                                alertPopup = new AlertPopup(itemView.getContext(), "提示", "是否删除该末行?");
                                //点击事件
                                alertPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                                    @Override
                                    public void onItemClick(boolean flag) {
                                        if (flag) {
                                            //点击确定
                                            //去掉最后一行
                                            cusAttrList.remove(cusAttrList.size() - 1);
                                            //答案去掉改行
                                            mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.remove(cusAttrList.size());
                                            //核验规则
                                            autoIncrementAdapter.check();
                                            //刷新
                                            autoIncrementAdapter.notifyDataSetChanged();
                                        }
                                        //弹框隐藏
                                        alertPopup.dismiss();
                                        alertPopup = null;
                                    }
                                });
                                //展示弹框
                                alertPopup.showAtLocation(recyclerView, Gravity.CENTER, 0, 0);
                            } else {
                                //土司
                                MyToast.showLongToast("至少保留一行");
                            }
                        }
                    });
                }
            }
        }
    }

    /**
     * 初始哈答案
     * @param position
     */
    public void addInit( int position){
        //判空
        if(mData.getSurveyAnswer().mAutoIncrementAnswer==null){
            //为空，新建
            mData.getSurveyAnswer().mAutoIncrementAnswer=new SurveyAnswer.AutoIncrementAnswer();
            mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers=new HashMap<>();
        }
        //判空
        if(mData.getSurveyAnswer().mAutoIncrementAnswer!=null && mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers!=null) {
            //获取数据
            Map<Integer, Map<String, Object>> values = mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.get(position);
            //判空
            if (values == null) {
                values = new HashMap<>();
            }
            //如果不一致
            if (values.size() != mData.getAttr().getCusAttr().size()) {
                values.clear();
                //循环重新赋值
                for (int i = 0; i < mData.getAttr().getCusAttr().size(); i++) {
                    Map<String, Object> map = new HashMap<>();
                    map.put(QueFormat.KEY_MUST, mData.getAttr().getCusAttr().get(i).isMust());
                    map.put(QueFormat.KEY_VALUE, values.get(i) == null ? null : values.get(i).get(QueFormat.KEY_VALUE));
                    map.put(QueFormat.KEY_FORMAT, (int) mData.getAttr().getCusAttr().get(i).getCharFormat());
                    values.put(i, map);
                }
                //答案中添加
                mData.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.put(position, values);
            }
        }
    }
}
