package com.dimeno.dimenoquestion.ui.adpter;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.widget.OptionBubble;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.dimeno.dimenoquestion.utils.DimenValue.TOP_ITEM_DECORATION_10;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :矩阵单选
 */
public class MatrixSingleAdapter extends BaseQuickAdapter<String, com.chad.library.adapter.base.BaseViewHolder> {

    private List<QueOptionBean> beanList=new ArrayList<>();
    private OptionBubble mOptionBubble;
    private Map<Integer,MatrixSingleOptionAdapter> map=new HashMap<>();
    private  ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers=new ArrayList<>();
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param data
     * @param queList
     * @param matrixAnswers
     * @param type
     */
    public MatrixSingleAdapter(List<String> data,List<QueOptionBean> queList, ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers,String type) {
        super(R.layout.item_matrix_single_select, data);
        if(queList!=null){
            this.beanList = queList;
        }
        this.matrixAnswers=matrixAnswers;
        this.type=type;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        TextView tv_ques_title = helper.getView(R.id.tv_ques_title);
        RecyclerView rcy_matrix_single = helper.getView(R.id.rcy_matrix_single);
        tv_ques_title.setText(item);
        //每次刷新的时候，必须设置LayoutManager，否则再次刷新的时候，item显示不出
        if (rcy_matrix_single.getItemDecorationCount() == 0) {
            rcy_matrix_single.addItemDecoration(new GridSpacesItemDecoration(mContext, beanList.size(), TOP_ITEM_DECORATION_10, false));
            rcy_matrix_single.setLayoutManager(new GridLayoutManager(mContext, beanList.size(), GridLayoutManager.VERTICAL, false));
        }
        if(map.get(helper.getAdapterPosition())==null) {
            MatrixSingleOptionAdapter adapter = new MatrixSingleOptionAdapter(beanList, mContext);
            //重新初始化数据源
            if(matrixAnswers!=null && matrixAnswers.size()!=0 ){
                if(matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes!=null &&  matrixAnswers.get(helper.getAdapterPosition()).opCodes.size()!=0){
                    adapter.getSet().clear();
                    adapter.getSet().addAll(matrixAnswers.get(helper.getAdapterPosition()).opCodes);
                }else {
                    adapter.getSet().clear();
                    adapter.notifyDataSetChanged();
                }
            }else {
                adapter.getSet().clear();
                adapter.notifyDataSetChanged();
            }
            rcy_matrix_single.setAdapter(adapter);
            adapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter mAdapter, View view, int position) {
                    if(beanList.size()>position) {
                        if (!type.equals("look")) {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                            if (adapter.getSet().contains(beanList.get(position).getOpCode())) {
                                adapter.getSet().remove(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.remove(beanList.get(position).getOpCode());
                                }
                            } else {
                                adapter.getSet().clear();
                                adapter.getSet().add(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.clear();
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.add(beanList.get(position).getOpCode());
                                }
                                //弹出气泡
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.showOptionBubble(view.findViewById(R.id.iv_matrix_single_choose), beanList.get(position).getOpText());
                                }
//                            showOptionBubble(view.findViewById(R.id.iv_matrix_single_choose), beanList.get(position).getOpText());
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
            });
            map.put(helper.getAdapterPosition(),adapter);
        }else {
            //因为有两个RecyclerView，所以adapter不能放到全局里面
            MatrixSingleOptionAdapter adapter = map.get(helper.getAdapterPosition());
            //重新初始化数据源
            if(matrixAnswers!=null && matrixAnswers.size()!=0){
                if(matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes!=null && matrixAnswers.get(helper.getAdapterPosition()).opCodes.size()!=0){
                    adapter.getSet().clear();
                    adapter.getSet().addAll(matrixAnswers.get(helper.getAdapterPosition()).opCodes);
                }else {
                    adapter.getSet().clear();
                    adapter.notifyDataSetChanged();
                }
            }else {
                adapter.getSet().clear();
                adapter.notifyDataSetChanged();
            }
            rcy_matrix_single.setAdapter(adapter);
            //必须要重新设置监听，否则helper.getAdapterPosition()因为mOwnerRecyclerView为空，返回-1从而报错
            adapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter mAdapter, View view, int position) {
                    if(beanList.size()>position) {
                        if (!type.equals("look")) {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                            if (adapter.getSet().contains(beanList.get(position).getOpCode())) {
                                adapter.getSet().remove(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.remove(beanList.get(position).getOpCode());
                                }
                            } else {
                                adapter.getSet().clear();
                                adapter.getSet().add(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.clear();
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.add(beanList.get(position).getOpCode());
                                }
                                //弹出气泡
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.showOptionBubble(view.findViewById(R.id.iv_matrix_single_choose), beanList.get(position).getOpText());
                                }
//                            showOptionBubble(view.findViewById(R.id.iv_matrix_single_choose), mData.get(position));
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
            });
        }
    }

    /**
     * 显示选项气泡
     *
     * @param anchor anchor
     * @param option option
     */
    private void showOptionBubble(View anchor, String option) {
//        hideOptionBubble();
        int[] location = new int[2];
        anchor.getLocationOnScreen(location);
        mOptionBubble = new OptionBubble(mContext, option);
        Activity current = ActivityManager.getAppManager().currentActivity();
        if (current != null) {
            int x = location[0] - (mOptionBubble.getWidth() - anchor.getMeasuredWidth()) / 2;
            int y = location[1] - mOptionBubble.getHeight() - UIUtils.dip2px(MyApplication.getContext(), 2);
            mOptionBubble.showAtLocation(current.getWindow().getDecorView(), Gravity.NO_GRAVITY, x, y);
        }
    }

    /**
     * 隐藏选项气泡
     */
    public void hideOptionBubble() {
        if (mOptionBubble != null && mOptionBubble.isShowing()) {
            mOptionBubble.dismiss();
        }
    }

    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
        void showOptionBubble(View anchor, String option);
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}