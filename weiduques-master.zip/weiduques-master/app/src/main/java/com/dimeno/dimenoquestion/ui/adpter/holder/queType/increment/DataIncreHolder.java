package com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment;

import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.TimePickerView;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.AutoIncrementAdapter2;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.Date;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :日期
 */
public class DataIncreHolder extends RecyclerViewHolder<AttrBean> {
    private SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer;
    private TextView mLeftText;
    private TextView editText;
    private SpannableStringBuilder title;
    private AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;
    private int index;
    private String value;

    /**
     * DataIncreHolder
     * @param parent
     * @param index
     * @param mAutoIncrementAnswer
     * @param onChildClickLisener
     * @param type
     */
    public DataIncreHolder(@NonNull ViewGroup parent,int index, SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer, AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_auto_increment_blank_data);
        this.mAutoIncrementAnswer = mAutoIncrementAnswer;
        mLeftText =findViewById(R.id.tv_title);
        editText =findViewById(R.id.et_auto_increment_blank);
        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
        this.index=index;
    }

    @Override
    public void bind() {
        if(type.equals("look")){
            //查看，editText不能编辑
            editText.setClickable(false);
            editText.setEnabled(false);
        }
        //获取title
        title= StringUtils.getTitle(mData.getTitle(),mData.isMust());
        //设置title
        mLeftText.setText(title);
        editText.setHint("请选择时间");

        //判空
        if(mAutoIncrementAnswer!=null && mAutoIncrementAnswer.mAnswers!=null) {

            if (mAutoIncrementAnswer.mAnswers.size() > index && mAutoIncrementAnswer.mAnswers.get(index).size() > getAdapterPosition()) {
                value = (String) mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).get(QueFormat.KEY_VALUE);
                editText.setText(StringUtils.isEmpty(value) ? "" : value);

                //时间选择器
                TimePickerView pvTime = new TimePickerBuilder(itemView.getContext(), new OnTimeSelectListener() {
                    @Override
                    public void onTimeSelect(Date date, View v) {
                        editText.setText(TimeUtil.date2YMD(date));
                        mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).put(QueFormat.KEY_VALUE, TimeUtil.date2YMD(date));
                        if (mData.isMust()) {
                            //必须
                            if (!StringUtils.isEmpty(TimeUtil.date2YMD(date)) && onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                        } else {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                        }
                    }
                }).build();
                //监听
                editText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!type.equals("look")) {
                            //不是查看，显示时间选择器
                            pvTime.show();
                        }
                    }
                });
            }
        }
    }
}
