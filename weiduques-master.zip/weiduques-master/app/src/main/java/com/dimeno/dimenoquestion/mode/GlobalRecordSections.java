package com.dimeno.dimenoquestion.mode;

import java.util.ArrayList;
import java.util.List;

/**
 * GlobalRecordSections
 * Created by wangzhen on 2020/5/12.
 */
public class GlobalRecordSections {
    private static List<Section> sList = new ArrayList<>();

    /**
     * put
     * @param subId
     * @param slice
     */
    public static void put(int subId, Slice slice) {
        Section section = findSection(subId);
        if (section == null) {
            section = new Section();
            section.subId = subId;
            sList.add(section);
        }
        List<Slice> slices = section.slices;
        if (slices == null) {
            slices = new ArrayList<>();
        }
        slices.add(slice);
        section.slices = slices;
    }

    /**
     * findSection
     * @param subId
     * @return
     */
    private static Section findSection(int subId) {
        for (Section section : sList) {
            if (section.subId == subId) {
                return section;
            }
        }
        return null;
    }

    public static List<Section> getStore() {
        return sList;
    }

    public static class Section {
        int subId;
        List<Slice> slices;
    }

    public static class Slice {
        public long start;
        public long end;

        public Slice(long start, long end) {
            this.start = start;
            this.end = end;
        }
    }
}
