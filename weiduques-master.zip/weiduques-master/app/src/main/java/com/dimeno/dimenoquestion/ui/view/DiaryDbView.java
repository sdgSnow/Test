package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.db.Answer;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface DiaryDbView extends BaseView {
    /**
     * 成功回调
     * @param isMore
     * @param progress
     */
    void success(boolean isMore,String progress);

    /**
     * 失败回调
     * @param msg
     */
    void fail(String msg);
}
