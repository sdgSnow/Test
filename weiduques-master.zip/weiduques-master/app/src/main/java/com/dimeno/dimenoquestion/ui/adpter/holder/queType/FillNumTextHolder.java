package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.blankj.utilcode.util.RegexUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :6 数值填空题
 */
public class FillNumTextHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_right_text;
    private final EditText editText;
    private SpannableStringBuilder title;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public FillNumTextHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_fill_text);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        editText = findViewById(R.id.et_fill_text_blank);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        editText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        this.type=type;
    }

    //小数点位数
    private int point;
    //小数点后几位
    private int pointCount;
    /**
     *
     */
    @Override
    public void bind() {
        Log.d("adpterFlush","数值填空题 flush position="+getAdapterPosition());
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getLeftText(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);//数字和小数点
            mData.getSurveyAnswer().rangeEnd = mData.getAttr().getNumRange1();
            mData.getSurveyAnswer().rangeStart = mData.getAttr().getNumRange2();
            mData.getSurveyAnswer().pointCount = mData.getAttr().getNumCount();
            mData.getSurveyAnswer().subTitle = mData.getAttr().getLeftText();
        }
        if(mData.isError()){
            frame_error.setVisibility(View.VISIBLE);
        }else {
            frame_error.setVisibility(View.GONE);
        }
        if(type.equals("look")){
            editText.setClickable(false);
            editText.setEnabled(false);
        }else {
            editText.setHint("请输入数值");
        }
        //设置初始值
        point=0;
        pointCount=0;
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        editText.setText(StringUtils.isEmpty(mData.getSurveyAnswer().answerFillContent)?"":mData.getSurveyAnswer().answerFillContent);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                //add 动态校验数值是否在范围内
                if(!TextUtils.isEmpty(s)){
                    try{
                        Double aDouble = Double.parseDouble(s.toString());
                        double numRange2 = mData.getAttr().getNumRange2();
                        double numRange1 = mData.getAttr().getNumRange1();
                        if(numRange2 != 0.0 && numRange1 != 0.0) {
                            if (aDouble < numRange2 || aDouble > numRange1) {
                                ToastUtils.showShort(String.format("该数值不在%s-%s范围内", numRange2, numRange1));
                            }
                        }
                    }catch (Exception e){
                        ToastUtils.showShort(e.getMessage());
                    }
                }
                mData.getSurveyAnswer().answerFillContent=s.toString();

                if(!StringUtils.isEmpty(s.toString()) && mData.isError()){
                    if ( mData.getSurveyAnswer().rangeStart != 0 &&  mData.getSurveyAnswer().rangeEnd != 0) {
                        try{
                            //校验小数位数
                            point = s.toString().lastIndexOf(".");
                            if(point>0){
                                pointCount = s.toString().length() - point - 1;
                            }
                            if (Double.parseDouble(s.toString()) < mData.getSurveyAnswer().rangeStart || Double.parseDouble(s.toString()) >  mData.getSurveyAnswer().rangeEnd || pointCount >mData.getSurveyAnswer().pointCount || !checkValue(CharFormatPattern.DIGITS, s.toString())) {
                                //小数点位数不符合，不是一个符合规则的数值，或则最大最小值不符合等。条件不满足，红色边框不去掉
                            }else {
                                //条件满足，红色边框去掉
                                mData.setError(false);
                                frame_error.setVisibility(View.GONE);
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }else {
                        //校验小数位数
                        point = s.toString().lastIndexOf(".");
                        if(point>0){
                            pointCount = s.toString().length() - point - 1;
                        }
                        if (pointCount >mData.getSurveyAnswer().pointCount || !checkValue(CharFormatPattern.DIGITS, s.toString())) {
                            //小数点位数不符合，不是一个符合规则的数值，条件不满足，红色边框不去掉
                        }else {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }
                }
            }
        });
    }
    private boolean checkValue(String pattern, Object value) {
        return RegexUtils.isMatch(pattern, String.valueOf(value));
    }
}
