package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.TimePickerView;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.mode.DateCharFormat;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :7 日期填空题
 */
public class FillDataHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_data;
    private final TextView tv_right_text;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;
    private String date_start;
    private String date_end;
    //日期格式化
    private SimpleDateFormat formatter;
    private Calendar rangeStart;
    private Calendar rangeEnd;
    private Calendar currentDate;
    private int year;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public FillDataHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_fill_data);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        tv_data = findViewById(R.id.tv_fill_data_blank);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
        //日期格式化
        formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINESE);
        //开始时间
        rangeStart = Calendar.getInstance();
        //结束时间
        rangeEnd = Calendar.getInstance();
        currentDate = Calendar.getInstance();
        currentDate.setTime(new Date());
        year=currentDate.get(Calendar.YEAR);//获取年份
    }


    @Override
    public void bind() {
        if (mData.getAttr() != null) {
            title = StringUtils.getTitle(mData.getAttr().getLeftText(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            date_start = mData.getAttr().getDateRange2();
            date_end = mData.getAttr().getDateRange1();
            //控制时间范围(如果不设置范围，则使用默认时间1900-2100年，此段代码可注释)
            //因为系统Calendar的月份是从0-11的,所以如果是调用Calendar的set方法来设置时间,月份的范围也要是从0-11
            if (TextUtils.isEmpty(date_start)) {
                date_start = "1900-01-01 00:00:00";
            }
            if (TextUtils.isEmpty(date_end)) {
                date_end = (year + 100) + "-01-01 00:00:00";
            }

            try {
                if(mData.getAttr().getCharFormat() == DateCharFormat.ym){
                    date_start = date_start + "-01";
                }
                Date start = formatter.parse(date_start);
                if (start != null) {
                    rangeStart.setTime(start);
                } else {
                    rangeStart.set(1900, 0, 1);
                }
            } catch (Exception e) {
                rangeStart.set(1900, 0, 1);
            }

            try {
                if(mData.getAttr().getCharFormat() == DateCharFormat.ym){
                    date_end = date_end + "-01";
                }
                Date end = formatter.parse(date_end);
                if (end != null) {
                    rangeEnd.setTime(end);
                } else {
                    rangeEnd.set(2100, 0, 1);
                }
            } catch (ParseException e) {
                rangeEnd.set(2100, 0, 1);
            }

            tv_data.setText(StringUtils.isEmpty(mData.getSurveyAnswer().answerFillContent) ? "" : mData.getSurveyAnswer().answerFillContent);
            //时间选择器
            TimePickerView pvTime = new TimePickerBuilder(itemView.getContext(), new OnTimeSelectListener() {
                @Override
                public void onTimeSelect(Date date, View v) {
                    SimpleDateFormat format = new SimpleDateFormat(StringUtils.getTimeFormat(mData.getAttr().getCharFormat()), Locale.CHINESE);
                    tv_data.setText(format.format(date));
                    mData.getSurveyAnswer().answerFillContent = format.format(date);
                    if (mData.isError()) {
                        mData.setError(false);
                        frame_error.setVisibility(View.GONE);
                    }
                }
            }).setDate(currentDate).setRangDate(rangeStart, rangeEnd).setType(StringUtils.getTimeTypes(mData.getAttr().getCharFormat())).build();
            tv_data.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!type.equals("look")) {
                        pvTime.show();
                    }
                }
            });
        }
    }



}
