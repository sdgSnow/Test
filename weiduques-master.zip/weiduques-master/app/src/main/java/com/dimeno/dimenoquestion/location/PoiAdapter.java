package com.dimeno.dimenoquestion.location;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * PoiAdapter
 * Created by wangzhen on 2020/9/10.
 */
public class PoiAdapter extends RecyclerView.Adapter<PoiViewHolder> {
    private List<PoiEntity> mData;
    private onSyncAddressCallback mCallback;

    public PoiAdapter(List<PoiEntity> list, onSyncAddressCallback callback) {
        this.mData = list;
        this.mCallback = callback;
    }

    @NonNull
    @Override
    public PoiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PoiViewHolder(parent, mCallback);
    }

    @Override
    public void onBindViewHolder(@NonNull PoiViewHolder holder, int position) {
        holder.bind(mData.get(position));
    }

    public void setData(List<PoiEntity> list) {
        this.mData = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }
}
