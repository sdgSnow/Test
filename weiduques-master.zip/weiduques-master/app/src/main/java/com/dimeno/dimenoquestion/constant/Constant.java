/**
 * Copyright 2016 JustWayward Team
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.dimeno.dimenoquestion.constant;

import android.os.Environment;

import com.dimeno.common.base.BaseApplication;
import com.dimeno.dimenoquestion.http.HttpConstant;


/**
 * 统一常量
 *
 * @author yuyh.
 * @date 16/8/5.
 */
public class Constant {
    public static final String PRO_CODE = "weiduques";
    //问卷APP内目录
    public static String WDQUES_CACHE_PATH = BaseApplication.getContext().getExternalFilesDir("") + "/weiduques/";
    //问卷APP外目录
    public static String WDQUES_STORAGE_PATH = Environment.getExternalStorageDirectory() + "/weiduquescopy/";
    //问卷详情保存路径
    public static String QUE_DETAIL = BaseApplication.getContext().getExternalFilesDir("") + "/weiduques/queDetail/";

    //录音
//    public static String AUDIO_BASE_PATH = Environment.getExternalStorageDirectory() + "/weiduques/audio/";
    public static String AUDIO_BASE_PATH = BaseApplication.getContext().getExternalFilesDir("") + "/weiduques/audio/";
    //签名图片
    public static String SIGN_PIC_BASE_PATH = BaseApplication.getContext().getExternalFilesDir("")  + "/weiduques/picture/";
    //    public static String SIGN_PIC_BASE_PATH = Environment.getExternalStorageDirectory() + "/weiduques/picture/";
    //日记
//    public static String  MYLOG_PATH = Environment.getExternalStorageDirectory() + "/weiduques/diary";
    public static String MYLOG_PATH = BaseApplication.getContext().getExternalFilesDir("") + "/weiduques/diary/";
    //db文件路径
//    public static String  DB_PATH = "Android/data/com.dimeno.dimenoquestion/files/weiduques/database/WeiDu.db";
    public static String  DB_PATH =  BaseApplication.getContext().getExternalFilesDir("") +"/weiduques/database/WeiDu.db";
    public static String  DB_PATHDIR =  BaseApplication.getContext().getExternalFilesDir("") +"/weiduques/database";
    //拷贝目标文件
    public static String  COPY_PATH = BaseApplication.getContext().getExternalFilesDir("") +"/weiduques/copy";
    public static String  ZIP_PATH = BaseApplication.getContext().getExternalFilesDir("") +"/weiduques/zip";
    //附件拷贝目录
    public static String  ANNEX_PATH = BaseApplication.getContext().getExternalFilesDir("") +"/weiduques/annex/";
    //附件题目最大上传附件数量
    public static final int MAX_ANNEX_COUNT = 10;
    //文件直传的oss路径
    public static final String OSS_DIRECT_PATH = "android/weiduques/";

    public static String mUpdateUrl;

    static {
        mUpdateUrl = HttpConstant.getUrl() + "api/AppInfo/GetAppInfo?project=1282578680089976834";
    }

    public static final String AppUpdateUrl = "http://wm.dimenosys.com/icsscore/api/getAppInfo";//测试使用
}
