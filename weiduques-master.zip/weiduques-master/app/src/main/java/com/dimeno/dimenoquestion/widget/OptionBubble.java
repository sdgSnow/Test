package com.dimeno.dimenoquestion.widget;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.common.utils.UIUtils;

/**
 * OptionBubble 选项气泡
 * Created by wangzhen on 2020/5/21.
 */
public class OptionBubble extends PopupWindow {
    private static final int DELAY_MILLIS = 3000;

    private TextView mContentView;
    private Handler handler = new Handler();

    public OptionBubble(Context context, String text) {
        super(context);
        mContentView = new TextView(context);
        mContentView.setText(text);
        mContentView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        mContentView.setTextColor(Color.WHITE);
        mContentView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        mContentView.setPadding(10, 10, 10, 10);

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(ContextCompat.getColor(context, R.color.color_09bb07));
        drawable.setCornerRadius(UIUtils.dip2px(MyApplication.getContext(), 5));
        mContentView.setBackground(drawable);

        setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        setContentView(mContentView);

        mContentView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
    }

    @Override
    public void showAtLocation(View parent, int gravity, int x, int y) {
        super.showAtLocation(parent, gravity, x, y);
        handler.removeCallbacks(runnable);
        handler.postDelayed(runnable, DELAY_MILLIS);
    }

    @Override
    public void dismiss() {
        super.dismiss();
        handler.removeCallbacks(runnable);
    }

    private Runnable runnable = () -> {
        if (isShowing()) {
            dismiss();
        }
    };

    public int getWidth() {
        return mContentView.getMeasuredWidth();
    }

    public int getHeight() {
        return mContentView.getMeasuredHeight();
    }
}
