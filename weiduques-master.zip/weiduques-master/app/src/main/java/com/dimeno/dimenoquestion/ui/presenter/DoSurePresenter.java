package com.dimeno.dimenoquestion.ui.presenter;


import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.AudioRecordingConfiguration;
import android.os.Build;
import android.text.TextUtils;
import android.widget.Toast;


import androidx.localbroadcastmanager.content.LocalBroadcastManager;

//import com.af.audio.AudioRecordManager;
//import com.af.audio.IAudioRecordListener;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.RegexUtils;
import com.czt.mp3recorder.Mp3Recorder;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.GsonUtils;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.LogicSetting;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.ResultBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.Constant;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.db.Que;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.map.ILocation;
import com.dimeno.dimenoquestion.map.LocationOnceUtils;
import com.dimeno.dimenoquestion.map.OfflineAlwaysUtils;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.actvity.DoSurveyActivity;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.view.DoSureView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.QuesUtil;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UUIDUtil;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.threadlib.ExecutorHandler;
import com.socks.library.KLog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.Observable;

import static com.czt.mp3recorder.Mp3Recorder.ACTION_STOP_ONLY;
import static com.dimeno.dimenoquestion.constant.Constant.AUDIO_BASE_PATH;
import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;
import static com.dimeno.dimenoquestion.constant.ConstantUtil.DROPDOWN_DEFAULT_VALUE;
import static com.dimeno.dimenoquestion.constant.OperationType.OPERATION;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class DoSurePresenter extends BasePresenter<DoSureView> {
    private ArrayList<PageSubjectBean> quesList = new ArrayList<>();
    /**
     * 答案实体
     */
    private SurveyAnswerEntity surveyAnswerEntity;

    /**
     * 答案数据库表
     */
    private Answer answer;
    //用户id
    private String userId;
    private String queCatalogID;
    //问卷id
    private String queId;
    //问卷标题
    private String queTitle;

    /**
     * 是否保存录音
     */
    private boolean saveRecord;
    //    private AudioRecordManager recordManager;
    //题目的答案实体
    private SurveyAnswer surveyAnswer;

    private int listSize;
    //定位的方式
    private boolean locationType=false;

    /**
     * 加载数据
     *
     * @param context
     * @param queId
     */
    public void loadQuesList(Context context, String queId) {
        //传参
        HashMap<String, String> params = new HashMap<>();
        params.put("ProCode", PRO_CODE);
        params.put("id", queId);
        params.put("onlyQue", "False");
        //请求
        Observable<Res<ResultBean>> observable = RetrofitManager.getInstance().getAppService()
                .loadQues(RetrofitManager.getInstance().getCacheControl(), params);
        RetrofitUtil.get().request(context, this, observable, new BaseObserver<ResultBean>() {
            @Override
            protected void onHandleSuccess(Res<ResultBean> data) {
                ExecutorHandler.getInstance().forBackgroundTasks()
                        .execute(new Runnable() {
                            @Override
                            public void run() {
//                                JsonUtil.toJson(data)
                                //判空
                                if (data == null || data.ResultObj == null) return;
                                if (data.Flag == 0) {
                                    //回调成功
                                    //数据列表清空
                                    quesList.clear();
                                    //判段activity销毁
                                    if (getMvpView() != null) {
                                        //成功回调
                                        getMvpView().initQueEntity(data.ResultObj.getQue());
                                    }
                                } else {
                                    //判段activity销毁
                                    if (getMvpView() != null) {
                                        //失败回调
                                        getMvpView().loadFailure(false, data.Msg);
                                    }
                                }
                            }
                        });
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //判段activity销毁
                if (getMvpView() != null) {
                    //失败回调
                    getMvpView().loadFailure(false, error);
                }
            }
        });
    }


    /**
     * 获取地址信息
     */
    public void location() {
        //判断网络
        if(NetworkUtils.isConnected()) {
            locationType=true;
            //有网络，获取当前位置
            LocationOnceUtils.getInstance().startLocation(MyApplication.getContext(), new ILocation() {
                @Override
                public void locationInfo(String longitude, String latitude, String address, String currentTime) {
                    //答案实体不为空
                    if (surveyAnswerEntity != null) {
                        //答案保存经纬度
                        surveyAnswerEntity.queLatitude = Double.parseDouble(StringUtils.isEmpty(latitude) ? "0.0" : latitude);
                        surveyAnswerEntity.queLongitude = Double.parseDouble(StringUtils.isEmpty(longitude) ? "0.0" : longitude);
                    }
                }
            });
        }else {
            locationType=false;
            //没有网络，获取离线经纬度
            OfflineAlwaysUtils.getInstance().startLocation(MyApplication.getContext(), new ILocation() {
                @Override
                public void locationInfo(String longitude, String latitude, String address, String currentTime) {
                    //答案实体不为空
                    if (surveyAnswerEntity != null) {
                        //答案保存经纬度
                        surveyAnswerEntity.queLatitude = Double.parseDouble(StringUtils.isEmpty(latitude) ? "0.0" : latitude);
                        surveyAnswerEntity.queLongitude = Double.parseDouble(StringUtils.isEmpty(longitude) ? "0.0" : longitude);
                    }
                }
            });
        }
    }

    /**
     * 关闭定位
     */
    public void stopLocation(){
        //定位开启方式
        if(locationType) {
            //有网
            LocationOnceUtils.getInstance().onStop();
        }else {
            //mei'w
            OfflineAlwaysUtils.getInstance().onStop();
        }
    }
    /**
     * 初始化答题实体类
     *
     * @param newQuesBean
     */
    public void initAnswer(NewQuesBean newQuesBean, String type) {
        //获取用户id
        userId = UserUtil.getUserId();
        queCatalogID = newQuesBean.getCatalogID();
        //问卷id
        queId = newQuesBean.getID();
        //问卷标题
        queTitle = newQuesBean.getQueTitle();
        //问卷创建时间
        String queCreateDate = newQuesBean.getCreateDate();
        //问卷修改时间
        String queModifyDate = newQuesBean.getModifyDate();
        //答案开始时间
        Long answerStartTime = TimeUtil.getCurrentTimeMillis();
        String answerCode = UUIDUtil.getUUID();
        QuesUtil.setAnswerCode(answerCode);
        //日期
        String answerId = TimeUtil.getCurrentTime();
        /**
         * 答案数据库表值
         */
        answer = new Answer();
        //设置问卷id
        answer.setQueID(queId);
        //设置用户id
        answer.setUserId(userId);
        //设置问卷标题
        answer.setQueTitle(queTitle);
        //设置问卷创建时间
        answer.setQueCreateDate(queCreateDate);
        //设置问卷修改时间
        answer.setQueModifyDate(queModifyDate);
        //设置答案开始时间
        answer.setAnswerStartTime(answerStartTime);
        answer.setAnswerCode(answerCode);
        //设置答案id
        answer.setAnswerId(answerId);
        //答案状态
        answer.setAnswerState(AnswerState.EDIT);
        /**
         * 答案实体值
         */
        surveyAnswerEntity = new SurveyAnswerEntity();

        surveyAnswerEntity.CatalogID = queCatalogID;
        surveyAnswerEntity.answerStartTime = answerStartTime;
        surveyAnswerEntity.queID = queId;
        surveyAnswerEntity.queTitle = queTitle;
        surveyAnswerEntity.queCreateDate = queCreateDate;
        surveyAnswerEntity.queModifyDate = queModifyDate;
        surveyAnswerEntity.userId = userId;
        surveyAnswerEntity.answerId = answerId;
        surveyAnswerEntity.answerCode = answerCode;


    }

    /**
     * 保存题目
     *
     * @param queBean
     */
    public void initQue(QueBean queBean,String updateTime) {
        //问卷详情转成string
        String queStr = JsonUtil.toJson(queBean);
        Que que = new Que();
        //设置问卷id
        que.setQueId(queBean.getID());
        //根据问卷id更新或者保存数据
        boolean flag= que.saveOrUpdate("queId = ?",queBean.getID());
        if(!flag){
            //保存失败，土司
            MyToast.showLongToast("问卷详情保存失败");
        }
        //保存问卷的更新时间
        queBean.setModifyDate(updateTime);
        //保存问卷详情到文件中
        FileUtils.saveQueDetail(queBean.getID(),queStr);
//      que.setQueDetail(queStr);


        if (answer != null) {
//            answer.setQueDetail(queStr);
        }
    }

    /**
     * 关联隐藏题目
     *
     * @param queBean
     */
    public void findLogic(QueBean queBean) {
        //题目分页判空
        if (queBean.getQuePage() != null && queBean.getQuePage().size() > 0) {
            //循环分页
            for (int i = 0; i < queBean.getQuePage().size(); i++) {
                //当前页的题目列表
                ArrayList<PageSubjectBean> subjectBeans = queBean.getQuePage().get(i).getQueSubject();
                //判空
                if (subjectBeans != null && subjectBeans.size() != 0) {
                    //判断每道题是否有隐藏逻辑
                    for (int y = 0; y < subjectBeans.size(); y++) {
                        //为每道题初始化创建答案
                        if (subjectBeans.get(y).getSurveyAnswer() == null) {
                            SurveyAnswer answer = new SurveyAnswer();
                            subjectBeans.get(y).setSurveyAnswer(answer);
                        }
                        if (subjectBeans.get(y).getAttr() != null) {
                            subjectBeans.get(y).getSurveyAnswer().isMust = subjectBeans.get(y).getAttr().isMust();
                            switch (subjectBeans.get(y).getSubType()) {
                                case QueFormat.Single://1单选
                                case QueFormat.Multiple://2多选
                                case QueFormat.Drop_down://3 下拉题
                                case QueFormat.Question_answer://4 问答题
                                case QueFormat.Sorting://13 排序
                                case QueFormat.Annex://15 附件
                                case QueFormat.Multi_pull_down://25多级下拉，连续下拉
                                case QueFormat.Location://26定位
                                case QueFormat.Sign://28 签名
                                default:
                                    subjectBeans.get(y).getSurveyAnswer().subTitle = subjectBeans.get(y).getAttr().getTitle();
                                    break;
                                case QueFormat.Auto_increment://24 自增表格
                                    subjectBeans.get(y).getSurveyAnswer().mAutoIncrementAnswer = new SurveyAnswer.AutoIncrementAnswer();
                                    subjectBeans.get(y).getSurveyAnswer().mAutoIncrementAnswer.mAnswers = new HashMap<>();
                                    if (subjectBeans.get(y).getAttr() != null && subjectBeans.get(y).getAttr().getCusAttr() != null) {
                                        List<List<AttrBean>> cusAttrList = new ArrayList<>();
                                        cusAttrList.add(subjectBeans.get(y).getAttr().getCusAttr());
                                        if (cusAttrList != null && cusAttrList.size() != 0) {
                                            for (int i1 = 0; i1 < cusAttrList.size(); i1++) {
                                                Map<Integer, Map<String, Object>> values = subjectBeans.get(y).getSurveyAnswer().mAutoIncrementAnswer.mAnswers.get(i1);
                                                if (values == null) {
                                                    values = new HashMap<>();
                                                }
                                                for (int k = 0; k < subjectBeans.get(y).getAttr().getCusAttr().size(); k++) {
                                                    Map<String, Object> map = new HashMap<>();
                                                    map.put(QueFormat.KEY_MUST, subjectBeans.get(y).getAttr().getCusAttr().get(k).isMust());
                                                    map.put(QueFormat.KEY_VALUE, values.get(k) == null ? null : values.get(k).get(QueFormat.KEY_VALUE));
                                                    map.put(QueFormat.KEY_FORMAT, (int) subjectBeans.get(y).getAttr().getCusAttr().get(k).getCharFormat());
                                                    values.put(k, map);
                                                }
                                                subjectBeans.get(y).getSurveyAnswer().mAutoIncrementAnswer.mAnswers.put(i1, values);
                                            }
                                        }
                                    }
                                    subjectBeans.get(y).getSurveyAnswer().subTitle = subjectBeans.get(y).getAttr().getTitle();
                                    break;
                                case QueFormat.Gauge://10 量表题
                                case QueFormat.Matrix_single://11矩阵单选
                                case QueFormat.Matrix_multi://12矩阵多选
                                case QueFormat.Matrix_gauge://18 矩阵量表
                                    subjectBeans.get(y).getSurveyAnswer().matrixAnswers = new ArrayList<>();
                                    subjectBeans.get(y).getSurveyAnswer().subTitle = subjectBeans.get(y).getAttr().getTitle();
                                    break;

                                case QueFormat.Fill_text://5 文本填空题
                                case QueFormat.Fill_num_text://6 数值填空题
                                case QueFormat.Fill_data://7 日期填空题
                                case QueFormat.Fill_time://9 时间填空题
                                    subjectBeans.get(y).getSurveyAnswer().subTitle = subjectBeans.get(y).getAttr().getLeftText();
                                    break;
                                case QueFormat.Multi_blank://8 多项填空题,连续填空
                                    if (subjectBeans.get(y).getSurveyAnswer().multiFillBlankList == null) {
                                        ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlankList = new ArrayList<>();
                                        //初始化答案，没有则创建
                                        if (subjectBeans.get(y).getAttr() != null && subjectBeans.get(y).getAttr().getCusAttr() != null) {
                                            for (int k = 0; k < subjectBeans.get(y).getAttr().getCusAttr().size(); k++) {
                                                SurveyAnswer.MultiFillBlank multiFillBlank = new SurveyAnswer.MultiFillBlank();
                                                multiFillBlank.isMust = subjectBeans.get(y).getAttr().getCusAttr().get(k).isMust();
                                                multiFillBlank.format = subjectBeans.get(y).getAttr().getCusAttr().get(k).getCharFormat();
                                                StringBuilder builder = new StringBuilder();
                                                if (!TextUtils.isEmpty(subjectBeans.get(y).getAttr().getCusAttr().get(k).getLeftText())) {
                                                    builder.append(subjectBeans.get(y).getAttr().getCusAttr().get(k).getLeftText());
                                                }
                                                builder.append("( )");
                                                if (!TextUtils.isEmpty(subjectBeans.get(y).getAttr().getCusAttr().get(k).getRightText())) {
                                                    builder.append(subjectBeans.get(y).getAttr().getCusAttr().get(k).getRightText());
                                                }
                                                multiFillBlank.pattern = builder.toString();
                                                multiFillBlankList.add(k, multiFillBlank);
                                            }
                                        }
                                        subjectBeans.get(y).getSurveyAnswer().multiFillBlankList = multiFillBlankList;
                                    }
                                    subjectBeans.get(y).getSurveyAnswer().subTitle = subjectBeans.get(y).getAttr().getLeftText();
                                    break;

                            }
                            subjectBeans.get(y).getSurveyAnswer().answerFillContentCharFormat = subjectBeans.get(y).getAttr().getCharFormat();
                        }
                        subjectBeans.get(y).getSurveyAnswer().subType = subjectBeans.get(y).getSubType();
                        subjectBeans.get(y).getSurveyAnswer().queId = subjectBeans.get(y).getQueID();
                        subjectBeans.get(y).getSurveyAnswer().subId = subjectBeans.get(y).getID();
                        subjectBeans.get(y).getSurveyAnswer().sort = subjectBeans.get(y).getSort();

                        //有隐藏逻辑
                        if (subjectBeans.get(y).getQueLogicSetting() != null
                                && subjectBeans.get(y).getQueLogicSetting().size() != 0) {
                            hideQues(subjectBeans.get(y), subjectBeans);
                        }
                    }
                }
            }
        }
    }

    /**
     * 找到相关选项的隐藏题
     *
     * @param subjectBean 当前含有隐藏逻辑的题目
     * @param subjectList 当前分页的所有题目
     */
    private void hideQues(PageSubjectBean subjectBean, ArrayList<PageSubjectBean> subjectList) {
        if (subjectBean != null) {
            if (subjectBean.getQueLogicSetting() != null && subjectBean.getQueLogicSetting().size() != 0) {
                Map<String, List<Integer>> map = new HashMap<>();
                //隐藏逻辑列表
                for (LogicSetting logicSetting : subjectBean.getQueLogicSetting()) {
                    //关联的题目SubIDs不为空
                    if (!StringUtils.isEmpty(logicSetting.SubIDs)) {
                        List<Integer> list = new ArrayList<>();

                        //循环关联的题目，找出id是隐藏题目的问卷
                        for (String s : logicSetting.SubIDs.split(",")) {
                            //如果是结束位
                            if (s.equals("end")) {
                                //结束位，查找结束位所在的选项
                                if (subjectBean.getQueOption() != null) {
                                    List<QueOptionBean> queOption = subjectBean.getQueOption();
                                    for (int i = 0; i < queOption.size(); i++) {
                                        if (queOption.get(i).getOpCode().equals(logicSetting.OpCode)) {
                                            //设置选项为结束位
                                            queOption.get(i).setEnd(true);
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                            //循环所有题型，获取被关联题目在题目列表所在的位置
                            for (int position = 0; position < subjectList.size(); position++) {
                                if (s.equals(subjectList.get(position).getID() + "")) {
                                    subjectList.get(position).setIsHide(ConstantType.queHide.GONE);//隐藏
                                    list.add(position);
                                    break;
                                }
                            }

                        }
                        map.put(logicSetting.OpCode, list);
                        subjectBean.setHidePosition(map);
                    }
                }
            }
        }
    }

    /**
     * state:
     * 0 是未上传(继续编辑)
     * 1 是保存在本地，未上传（上传问卷）
     * 2 是有网已上传
     */
    public boolean saveDb(Context context,int state) {
        surveyAnswerEntity.answerFinishTime = TimeUtil.getCurrentTimeMillis();
        answer.setAnswerFinishTime(surveyAnswerEntity.answerFinishTime);
        surveyAnswerEntity.answerAccessories = new ArrayList<>();
        answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
        //录音文件
        List<SurveyAnswerEntity.AnsFile.CustMap> custMapList = new ArrayList<>();
        if (surveyAnswerEntity.surveyAnswers == null) {
            surveyAnswerEntity.surveyAnswers = new ArrayList<>();
        }
        for (SurveyAnswerEntity.AnswerPage ap : surveyAnswerEntity.surveyAnswers) {
            for (SurveyAnswer sa : ap.getSurveyAnswers()) {
//                if (sa.logicShow == 0) {
                if (sa.logicShow == ConstantUtil.VISIBLE) {
                    //逻辑显示，添加录音
                    surveyAnswerEntity.answerAccessories.add(sa.subRecordPath);

                    SurveyAnswerEntity.AnsFile.CustMap custMap = new SurveyAnswerEntity.AnsFile.CustMap();
                    custMap.setKey(sa.subUuid);
                    custMap.setValue(sa.subRecordPath);
                    custMapList.add(custMap);
                } else if (sa.logicShow == ConstantUtil.GONE) {
                    //逻辑隐藏，不用添加录音
                    KLog.e("逻辑隐藏,不用添加录音");
                }
            }
        }
        SurveyAnswerEntity.AnsFile af = new SurveyAnswerEntity.AnsFile();
        af.setProCode(Constant.PRO_CODE);
        af.setAnswerId(answer.getAnswerId());
        af.setQueId(queId);
        af.setCustMaps(custMapList);

        String surveyAnswerJson = GsonUtils.getInstance().toJson(surveyAnswerEntity);
        answer.setAnswerDetail(surveyAnswerJson);
        answer.setAnswerState(state);
        //所选区域
        //answer.setAnswerLoc(chooseArea);
        surveyAnswerEntity.ansFile = af;

        //数据库保存
        boolean save = answer.save();
        if(save){
            stopRecord(true);
            //保存成功
            return true;
        }else {
            //保存失败
            return false;
        }
    }

    /**
     * 根据答案页配置答题
     *
     * @param currentPage
     * @param subjectBeans
     */
    public void addAnswerPage(int currentPage, List<PageSubjectBean> subjectBeans) {
        if (currentPage == 0) {
            if (surveyAnswerEntity.surveyAnswers == null) {
                surveyAnswerEntity.surveyAnswers = new ArrayList<>();
            }
            surveyAnswerEntity.surveyAnswers.clear();
        }
        SurveyAnswerEntity.AnswerPage answerPage = new SurveyAnswerEntity.AnswerPage();
        answerPage.setSurveyAnswers(new ArrayList<>());
        answerPage.setpIndex(currentPage);
        if (subjectBeans != null) {
            for (PageSubjectBean item : subjectBeans) {
                if (item.getSurveyAnswer() != null) {
                    answerPage.getSurveyAnswers().add(item.getSurveyAnswer());
                }
            }
        }
        surveyAnswerEntity.surveyAnswers.add(answerPage);
    }


    /**
     * @param currentPage  fragment 页数
     * @param subjectBeans 题目数据
     * @param pos          -1,全部检测，大于0，只检测到大于零到pos的这段部分
     * @return
     */
    public boolean check(int currentPage, List<PageSubjectBean> subjectBeans, int pos) {
        if (subjectBeans != null) {
            if (pos >= 0) {
                if (pos < subjectBeans.size()) {
                    for (int position = 0; position <= pos; position++) {
                        if (subjectBeans.get(position).getSurveyAnswer() != null) {
                            if (!doCheck(currentPage, position,  subjectBeans.get(position).getSubType(),subjectBeans.get(position).getSurveyAnswer())) {
                                return false;
                            }
                        } else {
                            String msg;
                            if (StringUtils.isEmpty(subjectBeans.get(position).getAttr().getTitle())) {
                                msg = subjectBeans.get(position).getAttr().getTitle();
                            } else {
                                msg = StringUtils.isEmpty(subjectBeans.get(position).getAttr().getLeftText()) ? "" : subjectBeans.get(position).getAttr().getLeftText();
                            }
                            sendBroadcast(msg + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                }
            } else {
                for (int position = 0; position < subjectBeans.size(); position++) {
                    if (subjectBeans.get(position).getSurveyAnswer() != null) {
                        if (!doCheck(currentPage, position, subjectBeans.get(position).getSubType(),subjectBeans.get(position).getSurveyAnswer())) {
                            return false;
                        }
                    } else {
                        String msg;
                        if (StringUtils.isEmpty(subjectBeans.get(position).getAttr().getTitle())) {
                            msg = subjectBeans.get(position).getAttr().getTitle();
                        } else {
                            msg = StringUtils.isEmpty(subjectBeans.get(position).getAttr().getLeftText()) ? "" : subjectBeans.get(position).getAttr().getLeftText();
                        }
                        sendBroadcast(msg + "未答完，不能提交", position, currentPage);
                        return false;
                    }
                }
            }

        }
        return true;
    }

    /**
     * 核验各个题目是否符合条件
     *
     * @param currentPage
     * @param position
     * @param surveyAnswer
     * @return
     */
    private boolean doCheck(int currentPage, int position,int subType, SurveyAnswer surveyAnswer) {
        if (surveyAnswer.logicShow == ConstantUtil.VISIBLE) {
            MyLog.d("doCheck", "position=" + position);
            switch (subType) {
                case QueFormat.Single://1单选
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.choiceList != null) {
                            if (surveyAnswer.choiceList.size() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        } else {
                            //surveyAnswer.choiceList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    } else {
                        if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Multiple://2多选
                case QueFormat.Sorting://13 排序
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.choiceList != null) {
                            if (surveyAnswer.choiceList.size() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                            //选中总条数
                            int size = surveyAnswer.choiceList.size();
                            int minCount = 0, maxCount = 0;
                            maxCount = surveyAnswer.MaxCount;
                            minCount = surveyAnswer.MinCount;
                            if (minCount > 0) {
                                //设置了最少选项
                                if (size < minCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少选择" + minCount + "个选项", position, currentPage);
                                    return false;
                                }
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }else {
                                //未设置最少选项
                                //设置了最多选项
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }
//
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        } else {
                            //surveyAnswer.choiceList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    } else {
                        if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                            //选中总条数
                            int size = surveyAnswer.choiceList.size();
                            int minCount = 0, maxCount = 0;
                            maxCount = surveyAnswer.MaxCount;
                            minCount = surveyAnswer.MinCount;
                            if (minCount > 0) {
                                if (size < minCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少选择" + minCount + "个选项", position, currentPage);
                                    return false;
                                }
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }else {
                                //未设置最少选项
                                //设置了最多选项
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Drop_down://3 下拉题
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.OptionList != null) {
                            if (surveyAnswer.OptionList.size() == 0 || surveyAnswer.OptionList.contains(DROPDOWN_DEFAULT_VALUE)) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        } else {
                            //surveyAnswer.OptionList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Question_answer://4 问答题
                case QueFormat.Fill_data://7 日期填空题
                case QueFormat.Fill_time://9 时间填空题
                    if (surveyAnswer.isMust) {
                        if (TextUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Fill_text://5 文本填空题
                    if (surveyAnswer.isMust) {
                        String wordContent = surveyAnswer.answerFillContent;
                        if (TextUtils.isEmpty(wordContent)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }
                        int max = surveyAnswer.lenghtMax;
                        int min = surveyAnswer.lenghtMin;

                        if (min > 0 && max > 0) {
                            int length = wordContent.length();
                            if (length < min) {
                                sendBroadcast(surveyAnswer.subTitle + "最少输入" + min + "个字符", position, currentPage);
                                return false;
                            }
                            if (length > max) {
                                sendBroadcast(surveyAnswer.subTitle + "最多输入" + max + "个字符", position, currentPage);
                                return false;
                            }
                        }

                        if (!checkFillWordBlank(position, currentPage, surveyAnswer)) {
                            return false;
                        }
                    } else {
                        //不为空，检测格式
                        if (!TextUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            int max = surveyAnswer.lenghtMax;
                            int min = surveyAnswer.lenghtMin;

                            if (min > 0 && max > 0) {
                                int length = surveyAnswer.answerFillContent.length();
                                if (length < min) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少输入" + min + "个字符", position, currentPage);
                                    return false;
                                }
                                if (length > max) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多输入" + max + "个字符", position, currentPage);
                                    return false;
                                }
                            }

                            if (!checkFillWordBlank(position, currentPage, surveyAnswer)) {
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Fill_num_text://6 数值填空题
                    if (surveyAnswer.isMust) {
                        String content = surveyAnswer.answerFillContent;
                        if (TextUtils.isEmpty(content)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }

                        if (!TextUtils.isEmpty(content) && surveyAnswer.answerFillContentCharFormat == 7) {
                            if (!RegexUtils.isMobileExact(content)) {
                                sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                                return false;
                            }
                        }
                        //校验是否是整数或者正负数
                        if (!checkValue(CharFormatPattern.DIGITS, content)) {
                            sendBroadcast(surveyAnswer.subTitle + "请输入一个正确的数值", position, currentPage);
                            return false;
                        }
                        //校验输入值范围
                        double rangeStart = surveyAnswer.rangeStart;
                        double rangeEnd = surveyAnswer.rangeEnd;
                        //小数位数
                        int numCount = surveyAnswer.pointCount;
                        try {
                            double value = Double.parseDouble(content);
                            if (rangeStart != 0 && rangeEnd != 0) {
                                if (value < rangeStart || value > rangeEnd) {
                                    sendBroadcast(surveyAnswer.subTitle + "正确范围(" + rangeStart + "," + rangeEnd + ")", position, currentPage);
                                    return false;
                                }
                            }

                            //校验小数位数
                            if (numCount >= 0) {
                                int indexOf = content.lastIndexOf(".");
                                if (indexOf > 0) {
                                    int count = content.length() - indexOf - 1;
                                    if (count > numCount) {
                                        String suffix;
                                        if (numCount == 0) {
                                            suffix = "请输入整数";
                                        } else {
                                            suffix = "小数点后最长输入" + numCount + "位";
                                        }
                                        sendBroadcast(surveyAnswer.subTitle + suffix, position, currentPage);
                                        return false;
                                    }
                                }
                            }
                        } catch (Exception ignore) {
                            sendBroadcast(surveyAnswer.subTitle + "请输入正确的格式", position, currentPage);
                            return false;
                        }
                    } else {
                        //如果内容不为空
                        if (!StringUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            String content = surveyAnswer.answerFillContent;
                            //校验是否是整数或者正负数
                            if (!checkValue(CharFormatPattern.DIGITS, content)) {
                                sendBroadcast(surveyAnswer.subTitle + "请输入一个正确的数值", position, currentPage);
                                return false;
                            }
                            //校验输入值范围
                            double rangeStart = surveyAnswer.rangeStart;
                            double rangeEnd = surveyAnswer.rangeEnd;
                            //小数位数
                            int numCount = surveyAnswer.pointCount;
                            try {
                                double value = Double.parseDouble(content);
                                if (rangeStart != 0 && rangeEnd != 0) {
                                    if (value < rangeStart || value > rangeEnd) {
                                        sendBroadcast(surveyAnswer.subTitle + "正确范围(" + rangeStart + "," + rangeEnd + ")", position, currentPage);
                                        return false;
                                    }
                                }

                                //校验小数位数
                                if (numCount >= 0) {
                                    int indexOf = content.lastIndexOf(".");
                                    if (indexOf > 0) {
                                        int count = content.length() - indexOf - 1;
                                        if (count > numCount) {
                                            String suffix;
                                            if (numCount == 0) {
                                                suffix = "请输入整数";
                                            } else {
                                                suffix = "小数点后最长输入" + numCount + "位";
                                            }
                                            sendBroadcast(surveyAnswer.subTitle + suffix, position, currentPage);
                                            return false;
                                        }
                                    }
                                }
                            } catch (Exception ignore) {
                                sendBroadcast(surveyAnswer.subTitle + "请输入正确的格式", position, currentPage);
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Multi_blank://8 多项填空题,连续填空
                    ArrayList<SurveyAnswer.MultiFillBlank> list = surveyAnswer.multiFillBlankList;
                    if (list == null || list.isEmpty()) {
                        sendBroadcast((surveyAnswer.subTitle == null ? "" : surveyAnswer.subTitle) + "未答完，不能提交", position, currentPage);
                        return false;
                    } else {
                        for (SurveyAnswer.MultiFillBlank blank : list) {
                            if (blank.isMust) {
                                if (TextUtils.isEmpty(blank.fillText)) {
                                    sendBroadcast((surveyAnswer.subTitle == null ? "第" + (position + 1) + "道题," + blank.pattern + "," : surveyAnswer.subTitle) + "未答完，不能提交", position, currentPage);
                                    return false;
                                } else {
                                    if (!checkMultiBlankFormat(position, currentPage, surveyAnswer, blank)) {
                                        return false;
                                    }
                                }
                            } else {
                                if (!checkMultiBlankFormat(position, currentPage, surveyAnswer, blank)) {
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Gauge://10 量表题
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.matrixAnswers != null && surveyAnswer.matrixAnswers.size() != 0) {
                            if (surveyAnswer.matrixAnswers.get(0).opCodes != null) {
                                if (surveyAnswer.matrixAnswers.get(0).opCodes.size() == 0) {
                                    sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            } else {
                                //surveyAnswer.matrixAnswers.get(0).opCodes==null
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        } else {
                            //surveyAnswer.matrixAnswers==null || surveyAnswer.matrixAnswers.size()=0
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Matrix_single://11矩阵单选
                case QueFormat.Matrix_multi://12矩阵多选
                case QueFormat.Matrix_gauge://18 矩阵量表
                    if (surveyAnswer.isMust) {
                        //答题内容不为空
                        if (surveyAnswer.matrixAnswers != null) {
                            if (surveyAnswer.matrixAnswers.size() != 0) {
                                for (SurveyAnswer.MatrixAnswer matrixAnswer : surveyAnswer.matrixAnswers) {
                                    if (matrixAnswer.opCodes != null) {
                                        if (matrixAnswer.opCodes.size() == 0) {
                                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                            return false;
                                        }
                                    } else {
                                        sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                        return false;
                                    }
                                }
                            } else {
                                //答题内容为空
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        } else {
                            //答题内容为空
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    //2021/7/2 需求变更：非必填题不做是否答完校验
//                    else {
//                        //非必须
//                        //答题内容不为空
//                        if(surveyAnswer.matrixAnswers!=null) {
//                            if (surveyAnswer.matrixAnswers.size() != 0) {
//                                listSize=0;
//                                //如果有选项，判断是否每项选择都有答案。
//                                for (SurveyAnswer.MatrixAnswer matrixAnswer : surveyAnswer.matrixAnswers) {
//                                    if (matrixAnswer.opCodes != null) {
//                                        if (matrixAnswer.opCodes.size() == 0) {
//                                            //没有答案
//                                            listSize++;
//                                        }
//                                    } else {
//                                        //没有答案
//                                        listSize++;
//                                    }
//                                }
//                                //如果有答案，且未答完。则提示
//                                if(listSize!=0 && listSize!=surveyAnswer.matrixAnswers.size()){
//                                    sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
//                                    return false;
//                                }
//                            }
//                        }
//                    }
                    break;

                case QueFormat.Explan://14 文字说明
                    break;
                case QueFormat.Annex://15 附件
                case QueFormat.Sign://28 签名
                    if (surveyAnswer.isMust) {
                        List<AnnexEntity> medias = surveyAnswer.annexList;
                        if (medias == null || medias.isEmpty()) {
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Separator://19 分隔符
                    break;
                case QueFormat.Auto_increment://24 自增表格
                    if (surveyAnswer.mAutoIncrementAnswer != null && surveyAnswer.mAutoIncrementAnswer.mAnswers != null) {
                        Map<Integer, Map<Integer, Map<String, Object>>> answers = surveyAnswer.mAutoIncrementAnswer.mAnswers;
                        if (answers != null && answers.size() != 0) {
                            for (Map.Entry<Integer, Map<Integer, Map<String, Object>>> entry : answers.entrySet()) {
                                Map<Integer, Map<String, Object>> values = entry.getValue();
                                int pos = entry.getKey();//第几项
                                for (int i = 0; i < values.size(); i++) {
                                    Map<String, Object> map = values.get(i);
                                    if (map != null) {
                                        boolean isMust = (boolean) map.get(QueFormat.KEY_MUST);
                                        Object value = map.get(QueFormat.KEY_VALUE);
                                        Object forma = map.get(QueFormat.KEY_FORMAT);
                                        int format = (int) Double.parseDouble(forma.toString() + "");
                                        if (isMust) {
                                            if (value == null || TextUtils.isEmpty(String.valueOf(value))) {
                                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                                return false;
                                            } else {
                                                if (!checkAutoIncrementFormat(pos + 1, i + 1, position, currentPage, surveyAnswer, value, format)) {
                                                    return false;
                                                }
                                            }
                                        } else {
                                            if (!checkAutoIncrementFormat(pos + 1, i + 1, position, currentPage, surveyAnswer, value, format)) {
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Multi_pull_down://25多级下拉，连续下拉
                    if (surveyAnswer.isMust) {
                        List<String> multi_dropdown_value = surveyAnswer.multi_dropdown_value;
                        if (multi_dropdown_value == null || multi_dropdown_value.isEmpty()) {
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        } else {
                            StringBuilder builder = new StringBuilder();
                            for (String s : multi_dropdown_value) {
                                if (!TextUtils.isEmpty(s)) {
                                    if (builder.length() > 0) {
                                        builder.append("-");
                                    }
                                    builder.append(s);
                                }
                            }
                            if (builder.length() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Location://26定位
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.isMust && TextUtils.isEmpty(surveyAnswer.mLocationAddress)) {
                            sendBroadcast(surveyAnswer.subTitle, position, currentPage);
                            return false;
                        }
                    }
                    break;
            }
        }
        return true;
    }

    /**
     * 核验文字是否符合条件
     *
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @return
     */
    private boolean checkFillWordBlank(int position, int currentPage, SurveyAnswer surveyAnswer) {
        String value = surveyAnswer.answerFillContent;
        int format = surveyAnswer.answerFillContentCharFormat;
        if (format == CharFormat.EMAIL) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.EMAIL, value)) {
                sendBroadcast(String.format("\"%s\"邮箱格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.TEXT, value)) {
                sendBroadcast(String.format("\"%s\"请输入中文", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.ENGLISH, value)) {
                sendBroadcast(String.format("\"%s\"请输入英文", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.WEBSITE, value)) {
                sendBroadcast(String.format("\"%s\"网址格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.ID, value)) {
                sendBroadcast(String.format("\"%s\"身份证格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.QQ, value)) {
                sendBroadcast(String.format("\"%s\"QQ格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.MOBILE_PHONE, value)) {
                sendBroadcast(String.format("\"%s\"手机格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.TELEPHONE, value)) {
                sendBroadcast(String.format("\"%s\"固话格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        return true;
    }

    private boolean checkValue(String pattern, Object value) {
        return RegexUtils.isMatch(pattern, String.valueOf(value));
    }

    /**
     * 核验文字是否符合条件
     *
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @return
     */
    private boolean checkMultiBlankFormat(int position, int currentPage, SurveyAnswer surveyAnswer, SurveyAnswer.MultiFillBlank blank) {
        int format = blank.format;
        if (format == CharFormat.EMAIL) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.EMAIL, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 邮箱格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.TEXT, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 请输入中文", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.ENGLISH, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 请输入英文", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.WEBSITE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 网址格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.ID, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 身份证格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.QQ, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" QQ格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.MOBILE_PHONE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 手机格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.TELEPHONE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 固话格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        return true;
    }

    /**
     * @param pos          答题的第几项
     * @param current      答题第几项的第几个
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @param value
     * @param format
     * @return
     */
    private boolean checkAutoIncrementFormat(int pos, int current, int position, int currentPage, SurveyAnswer surveyAnswer, Object value, int format) {
        if (format == CharFormat.EMAIL) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.EMAIL, value)) {
                sendBroadcast(surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，邮箱格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.TEXT, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，请输入中文", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.ENGLISH, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，请输入英文", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.WEBSITE, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，网址格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.ID, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，身份证格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.QQ, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，QQ格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.MOBILE_PHONE, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，手机格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.TELEPHONE, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格" + pos + "的第" + current + "行，固话格式不正确", position, currentPage);
                return false;
            }
        }
        return true;
    }

    private boolean objectEmpty(Object obj) {
        return obj == null || TextUtils.isEmpty(String.valueOf(obj));
    }

    /**
     * 发广播
     *
     * @param title
     * @param sort
     * @param page
     */
    private void sendBroadcast(String title, int sort, int page) {
        Intent intent = new Intent(String.valueOf(page));
        intent.putExtra("sort", sort);
        intent.putExtra("end", false);
        LocalBroadcastManager.getInstance(MyApplication.getContext()).sendBroadcast(intent);
        MyToast.showLongToast(title);
    }

    public Answer getAnswer() {
        return answer;
    }


    /**
     * 开启录音
     *
     * @param newQuesBean
     */
    private Mp3Recorder mRecorder;
    private double currDuration;
    private AudioManager mAudioManger;
    private boolean mMicIsBusy = false;

    public void initRecorder(NewQuesBean newQuesBean) {
        mAudioManger = (AudioManager) MyApplication.getContext().getSystemService(MyApplication.getContext().AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            List<AudioRecordingConfiguration> llsit = mAudioManger.getActiveRecordingConfigurations();
            if (mAudioManger.getActiveRecordingConfigurations().isEmpty()) {
                mMicIsBusy = false;
            } else {
                mMicIsBusy = true;
            }
        }

        mRecorder = new Mp3Recorder();
        //强制执行为需要录音
        saveRecord = true;
        currDuration = 0;
        if (answer == null) return;
        FileUtils.createDir(AUDIO_BASE_PATH + newQuesBean.getID() + "/" + answer.getAnswerCode() + "/");
        String path = AUDIO_BASE_PATH + newQuesBean.getID() + "/" + answer.getAnswerCode() + "/" + TimeUtil.getCurrentTimeMillis() + ".mp3";
        AnnexEntity annexEntity = new AnnexEntity();
        LogUtils.addLog("", OPERATION, answer.getQueID(),answer.getAnswerStartTime(), "开始录音", JsonUtil.toJson(answer));
        if (answer != null) {
            surveyAnswer = new SurveyAnswer();
            surveyAnswer.annexList = new ArrayList<>();
            annexEntity.que_id = newQuesBean.ID;
            annexEntity.que_title = newQuesBean.QueTitle;
            annexEntity.record_id = UUIDUtil.getUUID();
            annexEntity.user_id = SpUtil.get().getUserId();
            annexEntity.user_name = SpUtil.get().getUserName();
            annexEntity.create_time = TimeUtil.getCurrentTime();
//            annexEntity.path = path;
            annexEntity.filepath = path;
//            annexEntity.type = 3;
            annexEntity.fileType = FileType.RECORD;

            annexEntity.ossPath = MyUtils.getOssPath(path, newQuesBean.getID());
            surveyAnswer.annexList.add(annexEntity);

            mRecorder.setOutputFile(path)
                    .setCallback(new Mp3Recorder.Callback() {
                        @Override
                        public void onStart() {
//                        KLog.i("record","录音开始了");
                        }

                        @Override
                        public void onPause() {
                            KLog.i("record", "录音暂停了");
                        }

                        @Override
                        public void onResume() {
                            KLog.i("record", "录音恢复了");
                        }

                        @Override
                        public void onStop(int action) {
//                        KLog.d("record","录音停止了, duration="+currDuration);
                            annexEntity.duration = (int) currDuration;
                            if (answer != null && saveRecord && currDuration >= 3000) {
                                if (!StringUtils.isEmpty(path)) {
                                    String filepath = null;
                                    try {
                                        filepath = FileUtils.changePhoto2wm(path, "wd");
                                    } catch (Exception e) {
                                        filepath = path;
                                        e.printStackTrace();
                                    }
//                                    annexEntity.path = filepath;
                                    annexEntity.filepath = filepath;
                                    if (answer != null) {
                                        answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
                                        //数据库保存
                                        answer.update(answer.getId());
                                    }
                                }
                            } else {
                                if (saveRecord) {
                                    surveyAnswer.annexList.remove(annexEntity);
                                    answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
                                    //数据库保存
                                    answer.update(answer.getId());
                                }
                            }

                            //2021-9-9临时修改
//                            if (currDuration >= 3000) {
//                                surveyAnswer = new SurveyAnswer();
//                                surveyAnswer.annexList = new ArrayList<>();
//                                annexEntity.que_id = newQuesBean.ID;
//                                annexEntity.que_title = newQuesBean.QueTitle;
//                                annexEntity.record_id = UUIDUtil.getUUID();
//                                annexEntity.user_id = SpUtil.get().getUserId();
//                                annexEntity.user_name = SpUtil.get().getUserName();
//                                annexEntity.create_time = TimeUtil.getCurrentTime();
//                                annexEntity.filepath = path;
//                                annexEntity.type = 3;
//                                annexEntity.fileType = AnnexFileType.RECORD;
//                                annexEntity.duration = (int) currDuration;
//                                annexEntity.ossPath = MyUtils.getOssPath(path, newQuesBean.getID());
//                                if (!StringUtils.isEmpty(path)) {
//                                    String filepath = null;
//                                    try {
//                                        filepath = FileUtils.changePhoto2wm(path, "wd");
//                                    } catch (Exception e) {
//                                        filepath = path;
//                                        e.printStackTrace();
//                                    }
//                                    annexEntity.filepath = filepath;
//                                    if (answer != null) {
//                                        answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
//                                        //数据库保存
//                                        answer.update(answer.getId());
//                                    }
//                                }
//                                surveyAnswer.annexList.add(annexEntity);
//                            }

                            LogUtils.addLog("", OPERATION, answer.getQueID(),answer.getAnswerStartTime(), "录音停止并生成文件", JsonUtil.toJson(answer));
                        }

                        @Override
                        public void onReset() {
//                        KLog.i("record","录音撤销了");
                        }

                        @Override
                        public void onRecording(double duration, double volume) {
//                            KLog.d("record","onRecording, duration="+duration  +"  volume="+volume);
                            currDuration = duration;
                        }

                        @Override
                        public void onMaxDurationReached() {
                        }
                    });

            startRecord();
        }
    }

    //开始录音
    public void startRecord() {
        if (mRecorder != null) {
            mRecorder.start();
        }
    }

    /**
     * 结束录音
     *
     * @param saveRecord
     */
    public void stopRecord(boolean saveRecord) {
        this.saveRecord = saveRecord;
        if (mRecorder != null) {
            mRecorder.stop(ACTION_STOP_ONLY);
        }
    }


}
