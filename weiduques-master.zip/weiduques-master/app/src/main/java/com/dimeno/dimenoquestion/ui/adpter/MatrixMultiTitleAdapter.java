package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;

import java.util.List;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :矩阵多选,选项头
 */
public class MatrixMultiTitleAdapter extends BaseQuickAdapter<QueOptionBean, BaseViewHolder> {

    private List<QueOptionBean> beanList;
    private Context mContext;

    /**
     * 构造器
     * @param data
     * @param context
     */
    public MatrixMultiTitleAdapter(@Nullable List<QueOptionBean> data, Context context) {
        super(R.layout.item_matrix_single_title, data);
        this.beanList = data;
        this.mContext = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, QueOptionBean item) {
        TextView tv_matrix_multi_title = helper.getView(R.id.tv_matrix_single_title);
        tv_matrix_multi_title.setText(item.getOpText());
    }
}
