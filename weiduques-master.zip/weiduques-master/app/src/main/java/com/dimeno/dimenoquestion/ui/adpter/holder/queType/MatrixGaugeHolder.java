package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.MatrixGaugeAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static com.dimeno.dimenoquestion.utils.DimenValue.TOP_ITEM_DECORATION_10;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :18 矩阵量表
 */
public class MatrixGaugeHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_left_text;
    private final TextView tv_right_text;
    private final RecyclerView recyclerView;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private MatrixGaugeAdapter matrixGaugeAdapter;
    private SpannableStringBuilder title;
    private Map<Integer,MatrixGaugeAdapter> map=new HashMap<>();
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public MatrixGaugeHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_matrix_gauge);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        tv_left_text = findViewById(R.id.tv_left_text);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        recyclerView = findViewById(R.id.rcy_matrix_gauge);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            tv_left_text.setText(StringUtils.isEmpty(mData.getAttr().getLeftText()) ? "" : mData.getAttr().getLeftText());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            //每次刷新都要设置一下LayoutManager
            recyclerView.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));

            if(!StringUtils.isEmpty(mData.getAttr().getQuestionList())) {

                if (map.get(getAdapterPosition()) == null) {

                    //初始化题目+选项
                    String[] quesList = mData.getAttr().getQuestionList().split("\n");
                    List<QueOptionBean> titleList = new ArrayList<>();
                    for (int i = 0; i < quesList.length; i++) {
                        QueOptionBean multiBlankBean = new QueOptionBean();
                        multiBlankBean.setOpText(quesList[i]);
                        multiBlankBean.setSort(mData.getAttr().getScaleRange());
                        titleList.add(multiBlankBean);
                    }
                    //初始化答案
                    if (mData.getSurveyAnswer().matrixAnswers == null) {
                        ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers = new ArrayList<>();
                        mData.getSurveyAnswer().matrixAnswers = matrixAnswers;
                    }
                    if (mData.getSurveyAnswer().matrixAnswers.size() == 0) {
                        for (int i = 0; i < quesList.length; i++) {
                            SurveyAnswer.MatrixAnswer answer = new SurveyAnswer.MatrixAnswer();
                            answer.opCodes = new HashSet<>();
                            mData.getSurveyAnswer().matrixAnswers.add(answer);
                        }
                    }

                    if (recyclerView.getItemDecorationCount() == 0) {
                        recyclerView.addItemDecoration(new GridSpacesItemDecoration(itemView.getContext(), 1, TOP_ITEM_DECORATION_10, false));
                    }
                    matrixGaugeAdapter = new MatrixGaugeAdapter(titleList, mData, type);
                    recyclerView.setAdapter(matrixGaugeAdapter);
                    map.put(getAdapterPosition(), matrixGaugeAdapter);
                } else {
                    matrixGaugeAdapter = map.get(getAdapterPosition());
                    recyclerView.setAdapter(matrixGaugeAdapter);
                }
                matrixGaugeAdapter.setChildClickLisener(new MatrixGaugeAdapter.OnChildClickLisener() {
                    @Override
                    public void onChildClick() {
                        if (mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }
                });
            }
        }
    }

}
