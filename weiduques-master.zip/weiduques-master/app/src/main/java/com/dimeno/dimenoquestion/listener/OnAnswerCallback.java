package com.dimeno.dimenoquestion.listener;


/**
 * OnAnswerCallback
 * Created by wangzhen on 2020/5/9.
 */
public interface OnAnswerCallback {
    void onSyncGlobalRecord(String path);

//    void onSyncGlobalSections(List<GlobalRecordSections.Section> sections);

    void openFileBrowser(int subPosition, int fileType);
}
