package com.dimeno.dimenoquestion.map;

import android.content.Context;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.socks.library.KLog;

import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * 后台持续定位获取经纬度信息
 * 并保存到数据库
 * 离线定位只能获取经纬度
 */
public class LocationAlwaysUtils {
    private static LocationAlwaysUtils locationLibraryUtil;
    //记录是否第一次启动定位
    private boolean isFirst = false;
    //记录上一次的经度
    private Double lastLatitude;
    //记录上一次的纬度
    private Double lastLongitude;
    //记录上一次的定位时间
    private Long lastTime;
    private Context mContext;
    private String proCode;
    private String ptCode;
    private String sfCode;

    public static LocationAlwaysUtils getInstance() {
        if (locationLibraryUtil == null) {
            locationLibraryUtil = new LocationAlwaysUtils();
            return locationLibraryUtil;
        }
        return locationLibraryUtil;
    }

    private LocationService locationService;

    /**
     * 初始化并开始定位sdk
     * 初始化的场景最好是在activity里面，需要的时候就初始化
     *
     * @param context 上下文
     */
    public void startLocation(Context context, String pro_code, String pt_code, String sf_code) {
        this.proCode = pro_code;
        this.ptCode = pt_code;
        this.sfCode = sf_code;
        mContext = context;
        isFirst = false;//开始定位将第一次定位置为false
        KLog.i("test_location", "开始定位 context = " + context);
        locationService = new LocationService(context);
        //获取locationservice实例，建议应用中只初始化1个location实例，然后使用，可以参考其他示例的activity，都是通过此种方式获取locationservice实例的
        locationService.registerListener(mListener);
        locationService.setLocationOption(locationService.getDefaultLocationClientOption());
        locationService.start();// 定位SDK
    }

    /**
     * 定位结果回调，重写onReceiveLocation方法，可以直接拷贝如下代码到自己工程中修改
     */
    private BDAbstractLocationListener mListener = new BDAbstractLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation location) {
//            Log.i("test_location", "onReceiveLocation location = " + location + ",getLocType = " + location.getLocType());
            if (null != location && location.getLocType() != BDLocation.TypeServerError) {
                switch (location.getLocType()) {
                    case BDLocation.TypeGpsLocation:   // GPS定位结果
                    case BDLocation.TypeNetWorkLocation:   // 网络定位结果
                    case BDLocation.TypeOffLineLocation:   // 离线定位结果
//                        Log.i("test_location","经度：" + location.getLongitude() + "，纬度：" + location.getLatitude() + "，地址信息：" + location.getAddrStr());
                        double latitude = location.getLatitude();
                        double longitude = location.getLongitude();
                        String longitudestr = String.valueOf(longitude);
                        String latitudestr = String.valueOf(latitude);
                        String addrStr = location.getAddrStr();
                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        long l = System.currentTimeMillis();
                        String timestr = df.format(new Date(l));
                        if (isFirst) {
                            LatlngDistance start = new LatlngDistance(longitude, latitude);
                            LatlngDistance end = new LatlngDistance(lastLongitude, lastLatitude);
                            double distance = CalculatDistance.calculateLineDistance(start, end);
                            if (l - lastTime > 6000) {
                                KLog.i("test_location", "大于11秒时前后两次定位时间差为 = " + (l - lastTime));
                                if (distance > 3.0 && distance < 20) {
                                    saveLocationInfo(latitudestr, longitudestr, timestr, addrStr);
                                }
                            } else {
                                KLog.i("test_location", "当前两点距离为:" + distance + ",前后两次定位时间差为 = " + (l - lastTime));
                                if (distance > 2.0 && distance < 12) {
                                    saveLocationInfo(latitudestr, longitudestr, timestr, addrStr);
                                }
                            }
                        } else {
                            isFirst = true;
                            KLog.i("test_location", "进入任务第一次定位 addrStr = " + addrStr);
                            saveLocationInfo(latitudestr, longitudestr, timestr, addrStr);

                            //无网络状态下第一次定位成功且有经纬度信息的时候则toast提示
                            boolean available = NetworkUtils.isConnected();
                            if (!available) {
                                ToastUtils.showLong("离线定位经纬度为：" + location.getLongitude() + "," + location.getLatitude());
                            }
                        }
                        //记录本次经度定位信息，好和下次的相比较
                        lastLongitude = longitude;
                        //记录本次纬度定位信息，好和下次的相比较
                        lastLatitude = latitude;
                        //记录本次时间定位信息，好和下次的相比较
                        lastTime = l;

                        break;
                    case BDLocation.TypeServerError:     //服务端网络定位失败，可以反馈IMEI号和大体定位时间到loc-bugs@baidu.com，会有人追查原因
                    case BDLocation.TypeNetWorkException:  //网络不同导致定位失败，请检查网络是否通畅
                    case BDLocation.TypeCriteriaException:   //无法获取有效定位依据导致定位失败，一般是由于手机的原因，处于飞行模式下一般会造成这种结果，可以试着重启手机
                        //定位失败
                        KLog.i("sdg_location", location.getLocType() + "");
//                        locationService.stop();
                        break;
                }
            }
        }
    };

    /**
     * 保存位置信息到本地
     */
    public void saveLocationInfo(String lat, String lng, String currentTime, String Address) {
//        try {
//            DBLocationInfo locationList = new DBLocationInfo();
//            DealLocationBean locationBean = new DealLocationBean();
//            locationBean.setLat(lat);
//            locationBean.setLng(lng);
//            locationBean.setCurrentTime(currentTime);
//            locationBean.setAddress(Address);
//            String s = JSON.toJSONString(locationBean);
//            locationList.setProCode(proCode);
//            locationList.setPtCode(ptCode);
//            locationList.setSfCode(sfCode);
//            locationList.setSystemCode(SPUtil.get(mContext, sp_system_code, "").toString());
//            locationList.setUserId(SPUtil.get(mContext, sp_user_id, "").toString());
//            locationList.setLocationInfo(s);
//            locationList.save();
//        }catch (Exception e){
//            KLog.e(e.toString());
//        }
    }

    /**
     * 注销监听，停止定位
     * 注销之后必须再次初始化才能起作用
     */
    public void onStop() {
        KLog.i("test_location", "停止定位 locationService = " + locationService);
        if (locationService != null) {
            //注销掉监听
            locationService.unregisterListener(mListener);
            //停止定位服务
            locationService.stop();
        }
    }

}
