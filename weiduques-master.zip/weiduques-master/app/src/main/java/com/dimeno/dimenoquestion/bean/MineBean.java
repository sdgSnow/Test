package com.dimeno.dimenoquestion.bean;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class MineBean extends BaseVO{
    /**
     * 类型
     */
    public int type;
    /**
     * 图标路径
     */
    public int icon;
    /**
     * 名称
     */
    public String name;

    public MineBean(int type, int icon, String name) {
        this.type = type;
        this.icon = icon;
        this.name = name;
    }

    public MineBean(int icon, String name) {
        this.type = type;
        this.icon = icon;
        this.name = name;
    }
}
