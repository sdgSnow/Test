package com.dimeno.dimenoquestion.ui.presenter;


import android.content.Context;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.db.UserOperationLog;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.DiaryDbView;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;

import org.litepal.LitePal;
import java.util.ArrayList;
import java.util.List;
import io.reactivex.Observable;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class DiaryDbPresenter extends BasePresenter<DiaryDbView> {
    //日志总数
    private int allLogCount;
    //上传数
    private int uplodCount;
    //是否还有更多
    private boolean isMore=false;
    //进度
    private String progress;
    //每次上传条数
    private int size=20;
    //list
    private List<UserOperationLog> logList=new ArrayList<>();

    /**
     * 初始化数据，并上传数据
     * @param context
     */
    public void initUpload(Context context, NewQuesBean newQuesBean){
        //根据isUpload和userId查询数据的总条数
        allLogCount=  LitePal.where("isUpload=? and userId = ? and queId=?","0",UserUtil.getUserId(),newQuesBean.ID).count(UserOperationLog.class);
        //上传数初始化为0
        uplodCount=0;
        //数据大于0
        if(allLogCount>0){
            //开始上传数据
            startUpload(context,newQuesBean);
        }else {
            //如果总数据为0，直接成功
            if(getMvpView()!=null) {
                //成功回调
                getMvpView().success(false,"100");
            }
        }

    }

    /**
     * 上传数据
     * @param context
     */
    public void startUpload(Context context,NewQuesBean newQuesBean){
        //根据isUpload和userId查询数据的list集合
        logList=LitePal.where("isUpload=? and userId = ? and queId=?","0",UserUtil.getUserId(),newQuesBean.ID).limit(size).find(UserOperationLog.class);
        //判空以及总条数大于0
        if(allLogCount>0 && logList!=null){
            if(logList.size()>=size){
                //当前查询的数据小于size，表明还有更多数据
                isMore=true;
            }else {
                //当前查询的数据小于size，表明已经没有更多数据
                isMore=false;
            }
            //网络请求
            Observable<Res<String>> observable = RetrofitManager.getInstance().getAppService()
                    .addBatch(logList);
            RetrofitUtil.get().request(context, false,this, observable, new BaseNormalObserver<Res<String>>(false) {
                @Override
                protected void onHandleSuccess(Res<String> res) {
                    //成功
                    if(res.Flag==0){
                        //防止activity销毁还进行该方法造成崩溃
                        if(getMvpView()!=null) {
                            //上传总数增加
                            uplodCount=uplodCount+logList.size();
                            //循环列表
                            for (int i = 0; i < logList.size(); i++) {
                                //获取实体
                                UserOperationLog item=logList.get(i);
                                //标志已上传
                                item.isUpload= ConstantType.UserOperationLog_isUpload.YES_UPLOAD;
                                //更新数据库
                                item.update(item.getId());
                            }
                            //获取进度
                            progress= MyUtils.getProgress(uplodCount,allLogCount);
                            //成功回调
                            getMvpView().success(isMore,progress);
                            //如果还有更多数据
                            if(isMore){
                                //继续
                                startUpload(context,newQuesBean);
                            }
                        }
                    }else {
                        //防止activity销毁还进行该方法造成崩溃
                        if(getMvpView()!=null) {
                            //失败回调
                            getMvpView().fail(res.Msg);
                        }
                    }

                }

                @Override
                protected void onHandleFaild(int code, String error) {
                    //防止activity销毁还进行该方法造成崩溃
                    if(getMvpView()!=null) {
                        //失败回调
                        getMvpView().fail(error);
                    }
                }
            });
        }
    }


}
