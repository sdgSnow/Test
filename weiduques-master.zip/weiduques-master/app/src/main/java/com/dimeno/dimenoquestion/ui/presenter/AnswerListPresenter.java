package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.GsonUtils;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SortA;
import com.dimeno.dimenoquestion.bean.SortB;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.bean.UploadSurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.AnnexFileType;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.db.UserOperationLog;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.actvity.AnswerListActivity;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.view.AnswerListView;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.threadlib.ExecutorHandler;
import com.sdg.dialoglibrary.pop.PopManager;
import com.socks.library.KLog;

import org.litepal.LitePal;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MediaType;
import okhttp3.RequestBody;

import static com.dimeno.dimenoquestion.constant.ApiConstant.saveAnswer;
import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;
import static com.dimeno.dimenoquestion.constant.OperationType.API;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class AnswerListPresenter extends BasePresenter<AnswerListView> {
    private List<Answer> allAnswers = new ArrayList<>();
    private List<Answer> searchAnswers = new ArrayList<>();
    private int size = 10;

    public void quesList(String qId, int page) {
        searchAnswers.clear();
        if (page == 1) {
            allAnswers.clear();
        }

        Answer answer = new Answer();
        answer.setQueDetail("");
        //把所有queDetail数据情况，以防quedetial数据过大造成崩溃
        answer.updateAll();

        if (!StringUtils.isEmpty(qId) && !StringUtils.isEmpty(UserUtil.getUserId())) {
            searchAnswers = LitePal.where("QueID=? and UserId = ?", qId, UserUtil.getUserId())
                    .order("AnswerState asc,AnswerFinishTime desc").limit(size).offset(allAnswers.size()).find(Answer.class);
        }
        if (searchAnswers.size() != 0) {
            allAnswers.addAll(searchAnswers);
            if (searchAnswers.size() < size) {
                if (getMvpView() != null) {
                    getMvpView().initQuesList(false, allAnswers);
                }
            } else {
                if (getMvpView() != null) {
                    getMvpView().initQuesList(true, allAnswers);
                }
            }
        } else {
            if (getMvpView() != null) {
                getMvpView().initQuesList(false, allAnswers);
            }
        }
    }

    /**
     * @param activity
     * @param path
     */
    public void getOssInfo(Answer answer, AppCompatActivity activity, SurveyAnswer surveyAnswer, String path, int type, AnnexEntity annexEntity) {
        Observable<OssInfoEntity> observable = RetrofitManager.getInstance().getAppService()
                .getOssInfo(RetrofitManager.getInstance().getCacheControl());
        RetrofitUtil.get().request(activity, false, this, observable, new BaseNormalObserver<OssInfoEntity>(false) {
            @Override
            protected void onHandleSuccess(OssInfoEntity res) {
                if (getMvpView() != null) {
                    getMvpView().success(answer, res, surveyAnswer, path, type, annexEntity);
                }

            }

            @Override
            protected void onHandleFaild(int code, String error) {
                if (getMvpView() != null) {
                    MyToast.showShortToast("上传附件失败：" + error);
                }
            }
        });

    }


    /**
     * 处理答卷数据的上传：正常上传、再次上传、文件不存在的上传、流量上传
     *
     * @param entity entity
     */
    public void dealWithAnswerDataUpload(Context context, Answer answer, SurveyAnswerEntity entity, String ossDirectory) {
        if (entity == null) {
            return;
        }
        UploadSurveyAnswerEntity uploadSurveyAnswerEntity = new UploadSurveyAnswerEntity();

        UploadSurveyAnswerEntity.Answer1Bean answer1Bean = new UploadSurveyAnswerEntity.Answer1Bean();
        uploadSurveyAnswerEntity.Answer1 = answer1Bean;

        UploadSurveyAnswerEntity.Answer2Bean answer2Bean = new UploadSurveyAnswerEntity.Answer2Bean();
        uploadSurveyAnswerEntity.Answer2 = answer2Bean;

        UploadSurveyAnswerEntity.Answer3Bean answer3Bean = new UploadSurveyAnswerEntity.Answer3Bean();
        uploadSurveyAnswerEntity.Answer3 = answer3Bean;

        UploadSurveyAnswerEntity.Answer4Bean answer4Bean = new UploadSurveyAnswerEntity.Answer4Bean();
        uploadSurveyAnswerEntity.Answer4 = answer4Bean;

        UploadSurveyAnswerEntity.Answer5Bean answer5Bean = new UploadSurveyAnswerEntity.Answer5Bean();
        uploadSurveyAnswerEntity.Answer5 = answer5Bean;

        UploadSurveyAnswerEntity.Answer6Bean answer6Bean = new UploadSurveyAnswerEntity.Answer6Bean();
        uploadSurveyAnswerEntity.Answer6 = answer6Bean;

        String Answer_ID = entity.answerCode;
        String Question_ID = entity.queID;
        String queLatitude = entity.queLatitude + "";
        String queLongitude = entity.queLongitude + "";
        int Enter_Mark = 0;
        String Enter_ID = entity.userId;
        String Enter_Answer_ID = TimeUtil.getTime(entity.answerFinishTime);
        String Start_Date = TimeUtil.getTime(entity.answerStartTime);
        String End_Date = TimeUtil.getTime(entity.answerFinishTime);
        String Submit_Date = "";
        int Status = 0;

        answer1Bean.Answer_ID = Answer_ID;
        answer1Bean.ProCode = PRO_CODE;
        answer1Bean.Question_ID = Question_ID;
        answer1Bean.Enter_Mark = Enter_Mark;
        answer1Bean.Enter_ID = Enter_ID;
        answer1Bean.Enter_Answer_ID = Enter_Answer_ID;
        answer1Bean.Start_Date = Start_Date;
        answer1Bean.Answer_Start_Time_Code = entity.answerStartTime + "";
        answer1Bean.End_Date = End_Date;
        answer1Bean.Submit_Date = Submit_Date;
        answer1Bean.Status = Status;
        answer1Bean.Reserved1 = queLatitude;
        answer1Bean.Reserved2 = queLongitude;
        answer1Bean.A_Preside = entity.queAddressCode;
        answer1Bean.TapeUrl = "1";//注意：这个字段赋值为字符串1是后台需求，用1去当做有录音，查询有无录音功能
        /// TODO: 2021/4/1
//        answer1Bean.TapeUrl = mTapeOssPath;

        answer2Bean.Answer2_ID = Answer_ID;
        answer3Bean.Answer3_ID = Answer_ID;
        answer4Bean.Answer4_ID = Answer_ID;
        answer5Bean.Answer5_ID = Answer_ID;
        answer6Bean.Answer6_ID = Answer_ID;

        ArrayList<SurveyAnswer> surveyAnswers = new ArrayList<>();
        for (SurveyAnswerEntity.AnswerPage answerPage : entity.surveyAnswers) {
            surveyAnswers.addAll(answerPage.getSurveyAnswers());
        }

        //通过反射设置对应值
        for (int i = 0; i < surveyAnswers.size(); i++) {
            //题目编码A1~A300 B1~B300
            int sub = surveyAnswers.get(i).subId;
            if (sub <= 50) {
                reflectSetValue(answer1Bean, surveyAnswers.get(i), answer1Bean.getClass(), ossDirectory);
            } else if (sub <= 100) {
                reflectSetValue(answer2Bean, surveyAnswers.get(i), answer2Bean.getClass(), ossDirectory);
            } else if (sub <= 150) {
                reflectSetValue(answer3Bean, surveyAnswers.get(i), answer3Bean.getClass(), ossDirectory);
            } else if (sub <= 200) {
                reflectSetValue(answer4Bean, surveyAnswers.get(i), answer4Bean.getClass(), ossDirectory);
            } else if (sub <= 250) {
                reflectSetValue(answer5Bean, surveyAnswers.get(i), answer5Bean.getClass(), ossDirectory);
            } else if (sub <= 300) {
                reflectSetValue(answer6Bean, surveyAnswers.get(i), answer6Bean.getClass(), ossDirectory);
            }
        }

        List<UploadSurveyAnswerEntity.AnswerEx> extList = new ArrayList<>();
        List<UploadSurveyAnswerEntity.TB_AnswerFile> fileList = new ArrayList<>();
        UploadSurveyAnswerEntity.AnswerEx ext;
        for (SurveyAnswer surveyAnswer : surveyAnswers) {
            switch (surveyAnswer.subType) {
                // 处理连续填空题
                case QueFormat.Multi_blank:
                    ArrayList<SurveyAnswer.MultiFillBlank> list = surveyAnswer.multiFillBlankList;
                    if (list != null && !list.isEmpty()) {
                        for (int i = 0; i < list.size(); i++) {
                            ext = new UploadSurveyAnswerEntity.AnswerEx();
                            ext.Question_ID = surveyAnswer.queId;
                            ext.Answer_ID = Answer_ID;
                            ext.Enter_ID = UserUtil.getUserId();
                            ext.Sub_ID = surveyAnswer.subId;
                            ext.Sub_Type = surveyAnswer.subType;
                            ext.Op_ID = "sub-" + surveyAnswer.subId + "-" + i;
                            ext.Op_Value = list.get(i).fillText;
                            extList.add(ext);
                        }
                    }
                    break;
                // 处理自增表格题
                case QueFormat.Auto_increment:
                    if (surveyAnswer.mAutoIncrementAnswer != null) {
                        HashMap<Integer, Map<Integer, Map<String, Object>>> datas = surveyAnswer.mAutoIncrementAnswer.mAnswers;
                        int index = 0;
                        for (Map.Entry<Integer, Map<Integer, Map<String, Object>>> entry : datas.entrySet()) {
                            Map<Integer, Map<String, Object>> array = entry.getValue();
                            for (int i = 0; i < array.size(); i++) {
                                Map<String, Object> map = array.get(i);
                                if (map != null) {
                                    // 如答案为空则跳过
                                    Object value = map.get(QueFormat.KEY_VALUE);
                                    if (value != null) {
                                        if (value instanceof String && TextUtils.isEmpty(String.valueOf(value))) {
                                            continue;
                                        }
                                        ext = new UploadSurveyAnswerEntity.AnswerEx();
                                        ext.Question_ID = surveyAnswer.queId;
                                        ext.Answer_ID = Answer_ID;
                                        ext.Enter_ID = UserUtil.getUserId();
                                        ext.Sub_ID = surveyAnswer.subId;
                                        ext.Sub_Type = surveyAnswer.subType;
                                        ext.Op_ID = "ipt-" + surveyAnswer.subId + "-" + index + "-" + i;
                                        ext.Op_Value = String.valueOf(value);
                                        ext.Ex_Value1 = index;
                                        extList.add(ext);
                                    }
                                }
                            }
                            index++;
                        }
                    }
                    break;

                case QueFormat.Annex:
                    if (surveyAnswer.annexList != null && surveyAnswer.annexList.size() != 0) {
                        UploadSurveyAnswerEntity.TB_AnswerFile tb_answerFile;
                        for (AnnexEntity attach : surveyAnswer.annexList) {
                            tb_answerFile = new UploadSurveyAnswerEntity.TB_AnswerFile();
                            tb_answerFile.ID = MyUtils.getCode();
                            tb_answerFile.Question_ID = surveyAnswer.queId;
                            tb_answerFile.Answer_ID = Answer_ID;
                            tb_answerFile.QueSubject_ID = String.valueOf(surveyAnswer.subId);
//                            tb_answerFile.Url = ossDirectory + attach.ossPath;
                            tb_answerFile.Url = attach.ossPath;
                            tb_answerFile.FileType = attach.fileType;
//                            switch (attach.fileType){
//                                case AnnexFileType.ALL:
//                                    tb_answerFile.FileType = FileType.FILE;
//                                    break;
//                                case AnnexFileType.IMAGE:
//                                    tb_answerFile.FileType = FileType.IMAGE;
//                                    break;
//                                case AnnexFileType.AUDIO:
//                                    tb_answerFile.FileType = FileType.AUDIO;
//                                    break;
//                                case AnnexFileType.VIDEO:
//                                    tb_answerFile.FileType = FileType.VIDEO;
//                                    break;
//                                case AnnexFileType.FILE:
//                                    tb_answerFile.FileType = FileType.DOCUMENT;
//                                    break;
//                            }
                            tb_answerFile.Status = 0;
                            tb_answerFile.CreateDate = TimeUtil.getCurrentTime();
                            fileList.add(tb_answerFile);
                        }
                    }
                    break;
            }
        }


        //处理录音文件
        String recordDetail = answer.getRecordDetail();
        if (!StringUtils.isEmpty(recordDetail)) {
            SurveyAnswer recordAnswer = JsonUtil.toObj(recordDetail, SurveyAnswer.class);
            if (recordAnswer != null) {
                if (recordAnswer.annexList != null && recordAnswer.annexList.size() != 0) {
                    UploadSurveyAnswerEntity.TB_AnswerFile tb_answerFile;
                    for (AnnexEntity attach : recordAnswer.annexList) {
                        tb_answerFile = new UploadSurveyAnswerEntity.TB_AnswerFile();
                        tb_answerFile.ID = MyUtils.getCode();
                        tb_answerFile.Question_ID = recordAnswer.queId;
                        tb_answerFile.Answer_ID = Answer_ID;
                        tb_answerFile.QueSubject_ID = String.valueOf(recordAnswer.subId);
                        tb_answerFile.Url = attach.ossPath;
//                        tb_answerFile.Url = ossDirectory + attach.ossPath;
                        tb_answerFile.FileType = attach.fileType;
                        tb_answerFile.Status = 0;
                        tb_answerFile.CreateDate = TimeUtil.getCurrentTime();
                        fileList.add(tb_answerFile);
                    }
                }
            }
        }


        uploadSurveyAnswerEntity.AnswerExList = extList;
        uploadSurveyAnswerEntity.AnswerFileList = fileList;

        List<UploadSurveyAnswerEntity> surveyAnswerEntities = new ArrayList<>();
        surveyAnswerEntities.add(uploadSurveyAnswerEntity);
        String answerJsons = GsonUtils.getInstance().toJson(surveyAnswerEntities);
        KLog.e("提交的答卷数据= " + answerJsons);
        UserOperationLog log = LogUtils.addLog2(saveAnswer, API, answer.getQueID(), answer.getAnswerStartTime(), "上传答卷", answerJsons);

        Map<String, RequestBody> params = new HashMap<>();
        RequestBody queIDListBody = RequestBody.create(MediaType.parse("multipart/form-data"),
                answerJsons);
        params.put("AnswerList", queIDListBody);

        saveAnswer(context, params, answer, log);
    }

    private void reflectSetValue(Object answer, SurveyAnswer surveyAnswer, Class answerBeanCla, String ossDirectory) {

        try {
            /**
             * 得到指定的属性
             * fieldA 选择题类型
             * fieldB 选择题后面的备注填空题
             */
            Field fieldA = answerBeanCla.getDeclaredField("A" + surveyAnswer.subId);
            Field fieldB = answerBeanCla.getDeclaredField("B" + surveyAnswer.subId);
            fieldA.setAccessible(true);
            fieldB.setAccessible(true);
            switch (surveyAnswer.subType) {
                case QueFormat.Multi_pull_down://25 多级下拉
                    List<String> list = surveyAnswer.multi_dropdown_value;
                    if (list != null && !list.isEmpty()) {
                        StringBuilder builder = new StringBuilder();
                        for (String s : list) {
                            if (!TextUtils.isEmpty(s)) {
                                if (builder.length() > 0) {
                                    builder.append("-");
                                }
                                builder.append(s);
                            }
                        }
                        fieldA.set(answer, builder.toString());
                    }
                    break;
                case QueFormat.Single://1单选:
                    if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                        for (QueOptionBean s : surveyAnswer.choiceList) {
                            fieldA.set(answer, s.getOpCode());
                            fieldB.set(answer, s.getFillContent());
                        }
                    }
                    break;
                case QueFormat.Multiple://2;//多选
                    StringBuilder str = new StringBuilder(",");
                    ArrayList<String> opString = new ArrayList<>();
                    if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                        for (QueOptionBean s : surveyAnswer.choiceList) {
                            str.append(s.getOpCode() + ",");
                            opString.add(s.getFillContent());
                        }
                    }

                    //处理前后逗号问题
                    String substring = "";
                    try {
                        substring = str.substring(1, str.length() - 1);
                    } catch (Exception e) {
                        KLog.e("截取多选题答案异常：" + e.getMessage());
                    }

                    fieldA.set(answer, substring);
                    String opStringJson = GsonUtils.getInstance().toJson(opString);
                    fieldB.set(answer, opStringJson);
                    break;
                case QueFormat.Drop_down:// 3;//下拉题
                    if (surveyAnswer.OptionList != null && surveyAnswer.OptionList.size() != 0) {
                        for (String s : surveyAnswer.OptionList) {
                            fieldA.set(answer, s);
                        }
                    }
                    break;
                case QueFormat.Question_answer://:4;//问答题
                case QueFormat.Fill_text://5;//文本填空题
                case QueFormat.Fill_num_text://6;//数值填空题
                case QueFormat.Fill_data://7;//日期填空题
                case QueFormat.Fill_time://9 时间填空题
                    fieldA.set(answer, surveyAnswer.answerFillContent);
                    break;
                case QueFormat.Multi_blank://8;//多项填空题
                    break;
                case QueFormat.Gauge://10;//量表题
                    if (surveyAnswer.matrixAnswers != null) {
                        for (SurveyAnswer.MatrixAnswer matrixAnswers : surveyAnswer.matrixAnswers) {
                            for (String s : matrixAnswers.opCodes) {
                                fieldA.set(answer, s);
                                KLog.e("单个量表题,选中值==" + s + ",编号==" + fieldA.getName());
                            }
                        }
                    }
                    break;
                case QueFormat.Matrix_single:// 11;//矩阵单选
                    StringBuilder matrixSingleStr = new StringBuilder();
                    if (surveyAnswer.matrixAnswers != null) {
                        for (SurveyAnswer.MatrixAnswer matrixAnswers : surveyAnswer.matrixAnswers) {
                            for (String s : matrixAnswers.opCodes) {
                                matrixSingleStr.append(s + ",");
                                KLog.e("矩阵单选题,选中值==" + s + ",编号==" + fieldA.getName());
                            }
                        }
                    }

                    //处理前后逗号问题
                    String matrixSingleStrSubstring = "";
                    try {
                        matrixSingleStrSubstring = matrixSingleStr.substring(0, matrixSingleStr.length() - 1);
                    } catch (Exception e) {
                        KLog.e("截取矩阵单选题答案异常：" + e.getMessage());
                    }

                    fieldA.set(answer, matrixSingleStrSubstring);
                    KLog.e("矩阵单选题，全部值==" + matrixSingleStr.toString() + "matrixSingleStrSubstring = " + matrixSingleStrSubstring);
                    break;
                case QueFormat.Matrix_multi://12;//矩阵多选
                    StringBuilder allMatrixMultiStr = new StringBuilder();
                    if (surveyAnswer.matrixAnswers != null) {
                        for (SurveyAnswer.MatrixAnswer matrixAnswers : surveyAnswer.matrixAnswers) {
                            StringBuilder matrixMultiStr = new StringBuilder();
                            if (matrixAnswers.opCodes != null && matrixAnswers.opCodes.size() > 0) {
                                //如果有选择选项，则开始拼接答案
                                matrixMultiStr.append("[");
                                for (String s : matrixAnswers.opCodes) {
                                    matrixMultiStr.append(s + ",");
                                    KLog.e("矩阵多选题,选中值==" + s + ",编号==" + fieldA.getName() + "&&matrixMultiStr = " + matrixMultiStr.toString());
                                }

                                //处理前后逗号问题
                                String matrixMultiStrSubstring = "";
                                try {
                                    matrixMultiStrSubstring = matrixMultiStr.toString().substring(0, matrixMultiStr.toString().length() - 1);
                                } catch (Exception e) {
                                    KLog.e("截取矩阵量表题答案异常：" + e.getMessage());
                                }
                                KLog.e("矩阵多选题,全部值==" + matrixMultiStrSubstring);
                                allMatrixMultiStr.append(matrixMultiStrSubstring + "];");
                            } else {
                                //如果没有选择选项，则直接不拼接答案
                                allMatrixMultiStr.append("");
                            }
                        }
                    }

                    //处理前后逗号问题
                    String allMatrixMultiStrSubstring = "";
                    try {
                        if (!TextUtils.isEmpty(allMatrixMultiStr.toString())) {
                            allMatrixMultiStrSubstring = allMatrixMultiStr.toString().substring(0, allMatrixMultiStr.toString().length() - 1);
                        }
                    } catch (Exception e) {
                        KLog.e("截取矩阵量表题答案异常：" + e.getMessage());
                    }

                    fieldA.set(answer, allMatrixMultiStrSubstring);
                    KLog.e("矩阵多选题,全部值==" + allMatrixMultiStrSubstring);
                    break;

                case QueFormat.Sorting://13;//排序
                    ArrayList<SortA> sortAS = new ArrayList<>();
                    ArrayList<SortB> sortBS = new ArrayList<>();
                    if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size() != 0) {
                        for (int i = 0; i < surveyAnswer.choiceList.size(); i++) {
                            sortAS.add(new SortA(surveyAnswer.choiceList.get(i).getOpCode(), (i + 1) + ""));
                            sortBS.add(new SortB(surveyAnswer.choiceList.get(i).getOpCode(), surveyAnswer.choiceList.get(i).getFillContent() + ""));
                        }
                    }
                    String mapA = GsonUtils.getInstance().toJson(sortAS);
                    String mapB = GsonUtils.getInstance().toJson(sortBS);
                    fieldA.set(answer, mapA);
                    fieldB.set(answer, mapB);
                    break;
                case QueFormat.Explan://14;//文字说明
                    break;
                case QueFormat.Annex://15;//附件
                    break;
                case QueFormat.Matrix_gauge://18;//矩阵量表
                    StringBuilder gaugeStr = new StringBuilder();
                    if (surveyAnswer.matrixAnswers != null) {
                        for (SurveyAnswer.MatrixAnswer matrixAnswers : surveyAnswer.matrixAnswers) {
                            for (String s : matrixAnswers.opCodes) {
                                gaugeStr.append(s + ",");
                                KLog.e("矩阵量表题,选中值==" + s + ",编号==" + fieldA.getName());
                            }
                        }
                    }

                    //处理前后逗号问题
                    String gaugeStrSubstring = "";
                    try {
                        gaugeStrSubstring = gaugeStr.substring(0, gaugeStr.length() - 1);
                    } catch (Exception e) {
                        KLog.e("截取矩阵量表题答案异常：" + e.getMessage());
                    }

                    fieldA.set(answer, gaugeStrSubstring);
                    KLog.e("矩阵量表题，全部值==" + gaugeStr.toString() + "gaugeStrSubstring = " + gaugeStrSubstring);
                    break;
                case QueFormat.Location://26;//定位
                    fieldA.set(answer, String.format(Locale.CHINESE, "%f,%f", surveyAnswer.mLocationLongitude, surveyAnswer.mLocationLatitude));
                    fieldB.set(answer, surveyAnswer.mLocationAddress);
                    break;
                case QueFormat.Sign://28;//签名
                    if (surveyAnswer.annexList != null && surveyAnswer.annexList.size() > 0) {
//                        fieldA.set(answer, ossDirectory + surveyAnswer.annexList.get(0).ossPath);
                        fieldA.set(answer, surveyAnswer.annexList.get(0).ossPath);
                    }
                    break;
                default:
                    throw new RuntimeException(surveyAnswer.subType + "there is no " +
                            "type that matches the type " +
                            " + make sure your using types correctly");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * @param activity
     * @param maps
     */
    public void saveAnswer(Context activity, Map<String, RequestBody> maps, Answer answer, UserOperationLog log) {
        Observable<UploadEntity> observable = RetrofitManager.getInstance().getAppService()
                .saveAnswer(RetrofitManager.getInstance().getCacheControl(), maps);
        RetrofitUtil.get().request(activity, false, this, observable, new BaseNormalObserver<UploadEntity>(false) {
            @Override
            protected void onHandleSuccess(UploadEntity res) {
                if (getMvpView() != null) {
                    if (log != null) {
                        log.setResult(res != null ? JsonUtil.toJson(res) : "上传返回的数据为空");
                        log.save();
                    }
                    getMvpView().success(res, answer);
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                if (getMvpView() != null) {
                    if (log != null) {
                        log.setResult(error);
                        log.save();
                    }
                    getMvpView().fail();
                }
            }
        });

    }

    /**
     * @param answer
     */
    private ArrayList<SurveyAnswer> surveyList = new ArrayList<>();

    public ArrayList<SurveyAnswer> getAnx(SurveyAnswerEntity surveyAnswerEntity, Answer answer) {
        if (answer != null) {
            surveyList.clear();
            String sury = answer.getAnswerDetail();
            if (!StringUtils.isEmpty(sury)) {
                //获取答案详情
                surveyAnswerEntity = JsonUtil.toObj(sury, SurveyAnswerEntity.class);
                if (surveyAnswerEntity != null) {
                    //获取答案页
                    if (surveyAnswerEntity.surveyAnswers != null && surveyAnswerEntity.surveyAnswers.size() != 0) {
                        for (SurveyAnswerEntity.AnswerPage item : surveyAnswerEntity.surveyAnswers) {
                            //获取每页答案的答案列表
                            if (item.getSurveyAnswers() != null && item.getSurveyAnswers().size() != 0) {
                                for (SurveyAnswer surveyAnswer : item.getSurveyAnswers()) {
                                    switch (surveyAnswer.subType) {
                                        case QueFormat.Sign://28;//签名
                                            surveyList.add(surveyAnswer);
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            String recordDetail = answer.getRecordDetail();
            SurveyAnswer recordAnswer = JsonUtil.toObj(recordDetail, SurveyAnswer.class);
            if (recordAnswer != null) {
                surveyList.add(recordAnswer);
            }

            return surveyList;
        }
        return null;
    }


}
