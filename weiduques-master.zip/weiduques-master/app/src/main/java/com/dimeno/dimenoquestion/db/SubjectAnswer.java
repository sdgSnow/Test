package com.dimeno.dimenoquestion.db;

import java.util.List;

public class SubjectAnswer {

    public String subId;
    //单选题选中的选项id
    public String optionId;
    //单选题选中的选项补充文本
    public String optionFill;
    //多选题被选中的选项id
    public List<String> optionIdList;
    //多选题被选中的选项填空答案
    public List<String> optionFillList;
    //文本填空题答案
    public String textAnswer;
    //数值填空题答案
    public String numTextAnswer;
    //日期填空题答案
    public String dateTextAnswer;
    //多项填空题答案
    public List<String> multiTextAnswer;
    //问答题答案
    public String quesAnswer;
    //矩阵单选题答案
    public List<MatrixSingerAnswer> matrixSingerAnswerList;
    //矩阵多选题答案
    public List<MatrixMultiAnswer> matrixMultiAnswers;
    //量标题答案
    public int gaugeAnswer;
    //矩阵量标题答案
    public List<MatrixGaudeAnswer> matrixGaudeAnswerList;
    //签名题答案
    public SignAnswer signAnswer;
    //附件题答案
    public List<AnnexFile> annexFileList;

    private class MatrixSingerAnswer {
        //矩阵单选里面的子题目id
        public String quesId;
        //被选中的选项id
        public String optionId;
    }

    private class MatrixMultiAnswer {
        //矩阵多选里面的子题目id
        public String quesId;
        //被选中的选项id列表
        public List<String> optionIdList;
    }

    private class MatrixGaudeAnswer {
        //矩阵量表里面的子题目id
        public String quesId;
        //矩阵量表里面子题目的答案
        public int matrixGaugeAnswer;
    }

    private class AnnexFile {
        public String fileId;
        public String localPath;
        public String ossPath;
    }

    private class SignAnswer {
        public String fileId;
        public String localPath;
        public String ossPath;
    }
}
