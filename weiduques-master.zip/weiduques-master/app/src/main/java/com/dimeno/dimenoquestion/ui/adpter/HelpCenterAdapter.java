package com.dimeno.dimenoquestion.ui.adpter;

import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.MineBean;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/4/27
 * Description :
 */
public class HelpCenterAdapter extends BaseQuickAdapter<MineBean, BaseViewHolder> {
    /**
     * HelpCenterAdapter
     * @param list
     */
    public HelpCenterAdapter(List<MineBean> list) {
        super(R.layout.item_help_center,list);
    }

    /**
     * convert
     * @param helper
     * @param item
     */
    @Override
    protected void convert(BaseViewHolder helper, MineBean item) {
        ImageView ivAudio = helper.getView(R.id.iv_icon);
        ivAudio.setImageResource(item.icon);
        TextView content=helper.getView(R.id.tv_mine_content);
        content.setText(item.name);
    }
}
