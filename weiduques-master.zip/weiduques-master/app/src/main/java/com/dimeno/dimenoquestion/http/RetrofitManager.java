package com.dimeno.dimenoquestion.http;

import com.blankj.utilcode.util.NetworkUtils;

import okhttp3.OkHttpClient;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :二次封装网络请求
 */
public class RetrofitManager {
    public static RetrofitManager retrofitManager;
    private static volatile OkHttpClient okHttpClient;
    private AppService mMallService = null;
    //构造器
    public static RetrofitManager getInstance() {
        if (retrofitManager == null) {
            retrofitManager = new RetrofitManager();
            return retrofitManager;
        }
        return retrofitManager;
    }


    public AppService getAppService() {
        if (mMallService == null) {
            mMallService= OkHttpUtils.getRetrofit().create(AppService.class);
        }
        return mMallService;
    }

    /**
     * 根据网络状况获取缓存的策略
     */

    public String getCacheControl() {
        return NetworkUtils.isConnected() ? HttpConstant.sCACHE_CONTROL_AGE : HttpConstant.sCACHE_CONTROL_CACHE;
    }

}
