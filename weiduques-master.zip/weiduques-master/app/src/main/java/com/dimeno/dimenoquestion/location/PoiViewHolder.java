package com.dimeno.dimenoquestion.location;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.R;


/**
 * PoiViewHolder
 * Created by wangzhen on 2020/9/10.
 */
public class PoiViewHolder extends RecyclerView.ViewHolder {

    private final TextView mTvPoiName;
    private onSyncAddressCallback mCallback;
    private PoiEntity mData;

    public PoiViewHolder(@NonNull ViewGroup parent, onSyncAddressCallback callback) {
        super(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_location_poi_holder_layout, parent, false));
        this.mCallback = callback;
        mTvPoiName = itemView.findViewById(R.id.tv_poi_name);
        itemView.setOnClickListener(v -> {
            if (mCallback != null && mData != null) {
                mCallback.onSync(mData);
            }
        });
    }

    public void bind(PoiEntity data) {
        this.mData = data;
        String address = data.address;
        if (!TextUtils.isEmpty(data.name)) {
            address += data.name;
        }
        mTvPoiName.setText(address);
    }
}
