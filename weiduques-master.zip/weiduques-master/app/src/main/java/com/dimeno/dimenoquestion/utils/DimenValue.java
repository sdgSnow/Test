package com.dimeno.dimenoquestion.utils;

public class DimenValue {

    //选项列表的top间距 10最终转化为10dp
    public static final int TOP_ITEM_DECORATION_10 = 10;

    //选项列表的top间距 20最终转化为20dp
    public static final int TOP_ITEM_DECORATION_20 = 20;

}
