package com.dimeno.dimenoquestion.ui.adpter.holder;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.ui.adpter.NewQuesAdapter;
import com.dimeno.dimenoquestion.utils.MyToast;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class NewQuesViewHolder extends RecyclerViewHolder<NewQuesBean> {

    private final TextView tvQueTitle;
    private final TextView tv_see;
    private final TextView tv_start_survey;
    private final View other;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     */
    public NewQuesViewHolder(@NonNull ViewGroup parent, NewQuesAdapter.OnChildClickLisener onChildClickLisener) {
        super(parent, R.layout.item_new_ques);
        tvQueTitle = findViewById(R.id.tvQueTitle);
        tv_see = findViewById(R.id.tv_see);
        tv_start_survey = findViewById(R.id.tv_start_survey);
        other=findViewById(R.id.other);
        tv_see.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onChildClickLisener.onChildClick(view,mData);
            }
        });
        tv_start_survey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onChildClickLisener.onChildClick(view,mData);
            }
        });
    }

    @Override
    public void bind() {
        tvQueTitle.setText(mData.QueTitle);
        if(getAdapterPosition()==0){
            other.setVisibility(View.VISIBLE);
        }else {
            other.setVisibility(View.GONE);
        }
    }

}
