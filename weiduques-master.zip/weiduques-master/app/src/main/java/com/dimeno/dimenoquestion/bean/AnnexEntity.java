package com.dimeno.dimenoquestion.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * AnnexEntity
 * Created by wangzhen on 2020/5/18.
 */
public class AnnexEntity implements Serializable {
    public static final int TYPE_DATA = 0;
    public static final int TYPE_UPLOAD = 1;
    //题目位置
    public int position;
    //附件路径
    public String path;
    //名称
    public String fileName;
    //0 附件 1上传附件按钮,3录音文件，4签名
    public int type;
    //0是新问卷  1是编辑问卷  2是查看已经上传的问卷
    public int mode;
    //附件类型限制 //文件类别 1：录音文件  2：图片  3：签名文件 4：附件  5.视频 6.音频
    public int fileType;
    //oss路径
    public String ossPath;
    //是否上传了oss
    public boolean ossUpload;
    public String uOssPath;//
    //问卷id
    public String que_id;
    //录音id
    public String record_id;
    //问卷题目名称
    public String que_title;
    //用户id
    public String user_id;
    //用户名
    public String user_name;
    //创建时间
    public String create_time;
    //录音本地存储路径
    public String filepath;
    //录音时长
    public int duration;
    //空构造
    public AnnexEntity() {
    }
    //带参构造
    public AnnexEntity(int position, int type) {
        this.position = position;
        this.type = type;
    }
    //带参构造
    public AnnexEntity(int position, String path, int type) {
        this.position = position;
        this.path = path;
        this.type = type;
    }
    //带参构造
    protected AnnexEntity(Parcel in) {
        position = in.readInt();
        path = in.readString();
        type = in.readInt();
        mode = in.readInt();
        fileType = in.readInt();
    }

//    public static final Creator<AnnexEntity> CREATOR = new Creator<AnnexEntity>() {
//        @Override
//        public AnnexEntity createFromParcel(Parcel in) {
//            return new AnnexEntity(in);
//        }
//
//        @Override
//        public AnnexEntity[] newArray(int size) {
//            return new AnnexEntity[size];
//        }
//    };
//
//    @Override
//    public int describeContents() {
//        return 0;
//    }
//
//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeInt(position);
//        dest.writeString(path);
//        dest.writeInt(type);
//        dest.writeInt(mode);
//        dest.writeInt(fileType);
//    }
}
