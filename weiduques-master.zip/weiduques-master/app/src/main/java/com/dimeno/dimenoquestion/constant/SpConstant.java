package com.dimeno.dimenoquestion.constant;

public class SpConstant {
    //记住账号
    public static final String SP_ACCOUNT = "account";
    //记住密码
    public static final String SP_PSW = "psw";
    //用户名
    public static final String SP_NAME = "name";
    //记住用户id
    public static final String SP_USER_ID = "user_id";
    //是否自动登录
    public static final String SP_IS_LOGIN = "is_login";
    //上传方式 0=本地上传；1=oss上传
    public static final String SP_UPLOAD_WAY = "upload_way";
    //是否卸载后安装
    public static final String SP_IS_INSTALL = "is_install";
    //最近一次卸载后的安装时间
    public static final String SP_INSTALL_TIME = "install_time";
    //文件夹最近一次创建时间
    public static final String SP_CREATE_DIR_TIME = "create_dir_time";
    //文件夹最近一次备份时间
    public static final String SP_BACKUP_TIME = "backup_time";
    /**
     * 第一次进入app
     */
    public static final String SInitialize = "initialize";
    //问卷列表
    public static final String QuesList = "QuesList";
}
