package com.dimeno.dimenoquestion.location;

/**
 * onSyncAddressCallback
 * Created by wangzhen on 2020/9/10.
 */
public interface onSyncAddressCallback {
    void onSync(PoiEntity entity);
}
