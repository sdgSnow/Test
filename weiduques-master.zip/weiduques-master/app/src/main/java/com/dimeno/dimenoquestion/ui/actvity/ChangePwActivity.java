package com.dimeno.dimenoquestion.ui.actvity;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.event.Event;
import com.dimeno.common.event.EventBusUtils;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.presenter.ChangePwPresenter;
import com.dimeno.dimenoquestion.ui.presenter.LoginPresenter;
import com.dimeno.dimenoquestion.ui.view.ChangPwView;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.dimeno.dimenoquestion.constant.ConstantUtil.SOURCE;

/**
 * Create by   :PNJ
 * Date        :2021/3/15
 * Description :
 */
public class ChangePwActivity extends BaseActivity<ChangePwPresenter> implements ChangPwView {
    @BindView(R.id.et_password)
    EditText et_password;
    @BindView(R.id.et_newPw)
    EditText et_newPw;
    @BindView(R.id.et_repPw)
    EditText et_repPw;
    @BindView(R.id.tv_save)
    TextView tv_save;
    private int source;

    /**
     * initThings
     * 初始化一些事情
     * @param savedInstanceState 缓存数据
     *                           <p>
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
        fitDarkStatusBar(true);
    }

    /**
     * createToolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"修改密码");
    }

    /**
     * getLayoutId
     * 设置布局
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_chang_pw;
    }

    /**
     * initViews
     * 初始化界面
     */
    @Override
    protected void initViews() {
        source = getIntent().getIntExtra(SOURCE, 0);
    }

    /**
     * initListeners
     * 初始化事件监听者
     */
    @Override
    public void initListeners() {
        tv_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取旧密码
                String oldPwd =et_password.getText().toString().trim();
                //获取新密码
                String newPwd = et_newPw.getText().toString().trim();
                //获取再次输入密码
                String repPwd = et_repPw.getText().toString().trim();
                //判空旧密码
                if (StringUtils.isEmpty(oldPwd)) {
                    ToastUtils.showShort("请输入原密码");
                    return;
                }
                //判空新密码
                if (StringUtils.isEmpty(newPwd)) {
                    ToastUtils.showShort("请输入新密码");
                    return;
                }
                //验证新密码的格式
                if(!StringUtils.checkValue(CharFormatPattern.PASSWORD,newPwd)){
                    ToastUtils.showLong("密码为8-16位大小写字母、数字、特殊字符。密码必须包含大小写字母、数字，并以大小写字母开头。");
                    return;
                }
                //判空再次输入密码
                if (StringUtils.isEmpty(repPwd)) {
                    ToastUtils.showShort("请输入确认密码");
                    return;
                }
                //判断两次密码是否一直
                if (!newPwd.equals(repPwd)) {
                    ToastUtils.showShort("新密码和确认密码不一致");
                    return;
                }
                //传参
                HashMap<String, String> params = new HashMap<>();
                params.put("id", UserUtil.getUserId());
                params.put("oldPwd", oldPwd);
                params.put("newPwd", newPwd);
                presenter.ChangePw(ChangePwActivity.this,params);
            }
        });

    }

    /**
     * createPresenter
     * @return
     */
    @Override
    protected ChangePwPresenter createPresenter() {
        return new ChangePwPresenter();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void LoginSucess() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //修改成功，去掉用户密码，让用户重新登录
                UserUtil.setUserPwd("");
                //重新设置登录状态
                UserUtil.setIsLogin(false);
                MyToast.showShortToast("密码修改成功,请重新登录");
                //关闭当前所有的页面
                ActivityManager.getAppManager().finishAllActivity();
                //重新跳转到登陆页面
                startActivity(new Intent(ChangePwActivity.this, LoginActivity.class));
            }
        });
    }

    @Override
    public void LoginFail(String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //登录失败
                MyToast.showShortToast(msg);
            }
        });

    }
}