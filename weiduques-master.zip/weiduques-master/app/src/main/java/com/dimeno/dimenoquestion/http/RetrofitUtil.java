package com.dimeno.dimenoquestion.http;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.helper.ProgressHelper;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class RetrofitUtil {

    public static RetrofitUtil retrofitUtil;

    public static RetrofitUtil get() {
        if (retrofitUtil == null) {
            retrofitUtil = new RetrofitUtil();
            return retrofitUtil;
        }
        return retrofitUtil;
    }

    public void request(Context context,BasePresenter p, Observable o, Observer s) {
        o.doOnSubscribe(new Consumer<Disposable>() {
            @Override
            public void accept(Disposable disposable) throws Exception {
                //请求加入管理,统一管理订阅,防止内存泄露
                p.addDisposable(disposable);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if(p.getMvpView()!=null){
                            ProgressHelper.getInstance().show(context,false);
                        }
                    }
                });
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(s);
    }

    public void request(Context context,boolean showLoading,BasePresenter p, Observable o, Observer s) {
        o.doOnSubscribe(new Consumer<Disposable>() {
            @Override
            public void accept(Disposable disposable) throws Exception {
                //请求加入管理,统一管理订阅,防止内存泄露
                p.addDisposable(disposable);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if(showLoading && p.getMvpView()!=null){
                            ProgressHelper.getInstance().show(context,false);
                        }
                    }
                });
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(s);
    }

}
