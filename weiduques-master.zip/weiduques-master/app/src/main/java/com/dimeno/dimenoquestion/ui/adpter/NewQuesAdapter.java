package com.dimeno.dimenoquestion.ui.adpter;

import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;


import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.ui.adpter.holder.NewQuesViewHolder;

import java.util.List;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class NewQuesAdapter extends RecyclerAdapter<NewQuesBean> {
    public NewQuesAdapter(List<NewQuesBean> list) {
        super(list);
    }
    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new NewQuesViewHolder(parent,onChildClickLisener);
    }

    private OnChildClickLisener onChildClickLisener;
    public interface OnChildClickLisener {
        void onChildClick(View view,NewQuesBean newQuesBean);
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
