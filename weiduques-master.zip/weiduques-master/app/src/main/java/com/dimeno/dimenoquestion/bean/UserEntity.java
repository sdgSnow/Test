package com.dimeno.dimenoquestion.bean;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class UserEntity {
    /**
     * 文件上传方式
     *  0=本地上传；
     *  1=oss上传
     */
    private int uploadWay;
    private String ID;
    private String Account;
    private String Pwd;
    private String TrueName;
    private String ProID;
    private String CatalogID;
    private String Divisions;
    private String A_Name;
    private int status;
    private Object AreaList;
    private List<CustomAreaListBean> CustomAreaList;

    public int getUploadWay() {
        return uploadWay;
    }

    public void setUploadWay(int uploadWay) {
        this.uploadWay = uploadWay;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getAccount() {
        return Account;
    }

    public void setAccount(String Account) {
        this.Account = Account;
    }

    public String getPwd() {
        return Pwd;
    }

    public void setPwd(String Pwd) {
        this.Pwd = Pwd;
    }

    public String getTrueName() {
        return TrueName;
    }

    public void setTrueName(String TrueName) {
        this.TrueName = TrueName;
    }

    public String getProID() {
        return ProID;
    }

    public void setProID(String ProID) {
        this.ProID = ProID;
    }

    public String getCatalogID() {
        return CatalogID;
    }

    public void setCatalogID(String CatalogID) {
        this.CatalogID = CatalogID;
    }

    public String getDivisions() {
        return Divisions;
    }

    public void setDivisions(String Divisions) {
        this.Divisions = Divisions;
    }

    public String getA_Name() {
        return A_Name;
    }

    public void setA_Name(String A_Name) {
        this.A_Name = A_Name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Object getAreaList() {
        return AreaList;
    }

    public void setAreaList(Object AreaList) {
        this.AreaList = AreaList;
    }

    public List<CustomAreaListBean> getCustomAreaList() {
        return CustomAreaList;
    }

    public void setCustomAreaList(List<CustomAreaListBean> CustomAreaList) {
        this.CustomAreaList = CustomAreaList;
    }

    public static class CustomAreaListBean {
        /**
         * A_Code : 010000000000
         * A_Name : 蔡甸区
         * A_Father : 420100
         * A_Remark : null
         * A_Top : 420100
         */

        private String A_Code;
        private String A_Name;
        private String A_Father;
        private String A_Remark;
        private String A_Top;

        public String getA_Code() {
            return A_Code;
        }

        public void setA_Code(String A_Code) {
            this.A_Code = A_Code;
        }

        public String getA_Name() {
            return A_Name;
        }

        public void setA_Name(String A_Name) {
            this.A_Name = A_Name;
        }

        public String getA_Father() {
            return A_Father;
        }

        public void setA_Father(String A_Father) {
            this.A_Father = A_Father;
        }

        public String getA_Remark() {
            return A_Remark;
        }

        public void setA_Remark(String A_Remark) {
            this.A_Remark = A_Remark;
        }

        public String getA_Top() {
            return A_Top;
        }

        public void setA_Top(String A_Top) {
            this.A_Top = A_Top;
        }
    }
}

