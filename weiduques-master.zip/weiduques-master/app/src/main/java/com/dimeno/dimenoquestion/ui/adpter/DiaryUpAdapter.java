package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;

import java.util.List;

/**
 * DiaryUpAdapter
 */
public class DiaryUpAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
    /**
     * 构造器
     * @param data
     * @param context
     */
    public DiaryUpAdapter(@Nullable List<String> data, Context context) {
        super(R.layout.item_diary_up, data);
        this.mContext = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        TextView tv_single_choose = helper.getView(R.id.tv_single_choose);
        //设置内容
        tv_single_choose.setText(item);
    }
}
