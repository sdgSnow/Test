package com.dimeno.dimenoquestion.ui.fragment;

import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;

import com.dimeno.common.base.BaseFragment;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.widget.bar.CustomViewPager;
import com.dimeno.dimenoquestion.R;
import com.flyco.tablayout.SlidingTabLayout;

import java.util.ArrayList;
/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class HomeFragment extends BaseFragment {
    private SlidingTabLayout tab;
    private CustomViewPager viewPager;
    private ArrayList<Fragment> mFragments;
    private String[] mTitles = new String[]{"最新问卷", "已完成"};

    /**
     * HomeFragment
     * @return
     */
    public static HomeFragment newInstance() {
       HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * getLayoutId
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    /**
     * createPresenter
     * @return
     */
    @Override
    public BasePresenter createPresenter() {
        return null;
    }

    /**
     * initThings
     * @param view
     * @param savedInstanceState
     */
    @Override
    protected void initThings(View view,Bundle savedInstanceState) {
        tab = view.findViewById(R.id.tab);
        viewPager = view.findViewById(R.id.viewPager);

    }

    /**
     * initData
     */
    @Override
    protected void initData() {
        initTab();
    }

    /**
     * initListeners
     */
    @Override
    public void initListeners() {

    }

    /**
     * initTab
     */
    private void initTab() {
        mFragments = new ArrayList<>();
        mFragments.add(NewQuesFragment.newInstance());
        mFragments.add(CompleteQuesFragment.newInstance());

        viewPager.setScanScroll(true);
        //设置缓存页数
        viewPager.setOffscreenPageLimit(1);
        viewPager.setAdapter(new CustomViewPager.MyPagerAdapter(getActivity().getSupportFragmentManager(),mFragments,mTitles));
        //设置初始化显示页面，该设置需要在setAdapter之后
        viewPager.setCurrentItem(0);
        tab.setViewPager(viewPager);
    }
}
