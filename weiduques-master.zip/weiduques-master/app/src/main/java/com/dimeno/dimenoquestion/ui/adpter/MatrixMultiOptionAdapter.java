package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;

import java.util.HashSet;
import java.util.List;


public class MatrixMultiOptionAdapter extends BaseQuickAdapter<QueOptionBean, BaseViewHolder> {

    private List<QueOptionBean> beanList;
    private Context mContext;
    //保存多选状态下的变量
    private HashSet<String> set=new HashSet<>();

    /**
     * 构造器
     * @param data
     * @param context
     */
    public MatrixMultiOptionAdapter(@Nullable List<QueOptionBean> data, Context context) {
        super(R.layout.item_matrix_multi_option, data);
        this.beanList = data;
        this.mContext = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, QueOptionBean item) {
        ImageView ivSelect = helper.getView(R.id.iv_matrix_multi_choose);
        if (set.contains(item.getOpCode())) {
            ivSelect.setImageResource(R.mipmap.checkbox_selected);
        } else {
            ivSelect.setImageResource(R.mipmap.checkbox_unselected);
        }
    }
    //获取存储的set集合
    public HashSet<String> getSet() {
        return set;
    }

    //多选之添加
    public void add(int position) {
        set.add(beanList.get(position).getOpCode());
        this.notifyDataSetChanged();
    }

    //多选之删除
    public void remove(int position) {
        set.remove(beanList.get(position).getOpCode());
        this.notifyDataSetChanged();
    }

    //清空set集合
    public void clear() {
        set.clear();
        this.notifyDataSetChanged();
    }
}
