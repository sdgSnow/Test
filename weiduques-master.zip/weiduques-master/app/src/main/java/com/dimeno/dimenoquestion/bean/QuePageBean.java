package com.dimeno.dimenoquestion.bean;

import java.io.Serializable;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :答题页
 */
public class QuePageBean implements Serializable {
    /**
     * PageID : 1329341540929896449
     * QueID : 1329341540904730625
     * Sort : 1
     */

    private String PageID;
    private String QueID;
    private int Sort;
    private ArrayList<PageSubjectBean> QueSubject;

    public String getPageID() {
        return PageID;
    }

    public void setPageID(String pageID) {
        PageID = pageID;
    }

    public String getQueID() {
        return QueID;
    }

    public void setQueID(String queID) {
        QueID = queID;
    }

    public int getSort() {
        return Sort;
    }

    public void setSort(int sort) {
        Sort = sort;
    }

    public ArrayList<PageSubjectBean> getQueSubject() {
        return QueSubject;
    }

    public void setQueSubject(ArrayList<PageSubjectBean> queSubject) {
        QueSubject = queSubject;
    }
}
