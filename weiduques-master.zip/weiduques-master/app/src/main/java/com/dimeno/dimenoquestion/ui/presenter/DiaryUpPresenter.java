package com.dimeno.dimenoquestion.ui.presenter;


import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.DiaryUpView;

import io.reactivex.Observable;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class DiaryUpPresenter extends BasePresenter<DiaryUpView> {

    /**
     *获取oss的token
     * @param activity
     * @param path
     */
    public void getOssInfo(AppCompatActivity activity,String path) {
        Observable<OssInfoEntity> observable = RetrofitManager.getInstance().getAppService()
                .getOssInfo(RetrofitManager.getInstance().getCacheControl());
        RetrofitUtil.get().request(activity, false,this, observable, new BaseNormalObserver<OssInfoEntity>(false) {
            @Override
            protected void onHandleSuccess(OssInfoEntity res) {
                //防止activity销毁还进行该方法造成崩溃
                if(getMvpView()!=null) {
                    //成功回调
                    getMvpView().success(res, path);
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {

            }
        });

    }



}
