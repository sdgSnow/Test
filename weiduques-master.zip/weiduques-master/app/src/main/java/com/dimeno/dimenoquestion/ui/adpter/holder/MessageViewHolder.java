package com.dimeno.dimenoquestion.ui.adpter.holder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.actvity.EditSurveyActivity;
import com.dimeno.dimenoquestion.ui.adpter.AnswerListRecyclerAdapter;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class MessageViewHolder extends RecyclerViewHolder<MessageEntity.RecordsBean> {

    private Context mContext;
    private final TextView tvTitle;
    private final TextView tvMessage;

    /**
     * 构造器
     *
     * @param parent
     */
    public MessageViewHolder(Context context, @NonNull ViewGroup parent) {
        super(parent, R.layout.item_message);
        this.mContext = context;
        tvTitle = findViewById(R.id.tvTitle);
        tvMessage = findViewById(R.id.tvMessage);
    }

    @Override
    public void bind() {
        tvTitle.setText(mData.getMsgTitle() == null ? "" : mData.getMsgTitle());
        tvMessage.setText(mData.getMsgContent() == null ? "" : mData.getMsgContent());
    }

}
