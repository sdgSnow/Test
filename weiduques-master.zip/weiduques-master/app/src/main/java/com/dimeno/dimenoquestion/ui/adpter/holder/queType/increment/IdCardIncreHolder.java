package com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment;

import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.AutoIncrementAdapter2;
import com.dimeno.dimenoquestion.ui.adpter.MultiBlankAdapter;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :身份证号码
 */
public class IdCardIncreHolder extends RecyclerViewHolder<AttrBean> {
    private SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer;
    private TextView mLeftText;
    private EditText editText;
    private SpannableStringBuilder title;
    private AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;
    private int index;
    private String value;

    /**
     * IdCardIncreHolder
     *
     * @param parent
     * @param index
     * @param mAutoIncrementAnswer
     * @param onChildClickLisener
     * @param type
     */
    public IdCardIncreHolder(@NonNull ViewGroup parent,int index, SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer, AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_auto_increment_blank);
        this.mAutoIncrementAnswer = mAutoIncrementAnswer;
        mLeftText =findViewById(R.id.tv_title);
        editText =findViewById(R.id.et_auto_increment_blank);
        editText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
        this.index=index;
    }

    @Override
    public void bind() {
        if(type.equals("look")){
            editText.setClickable(false);
            editText.setEnabled(false);
        }
        title= StringUtils.getTitle(mData.getTitle(),mData.isMust());
        mLeftText.setText(title);
        editText.setHint("请输入身份证号码");
        //editText软键盘的EditorAction监控
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        if(mAutoIncrementAnswer!=null && mAutoIncrementAnswer.mAnswers!=null) {
            if (mAutoIncrementAnswer.mAnswers.size() > index && mAutoIncrementAnswer.mAnswers.get(index).size() > getAdapterPosition()) {
                value = (String) mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).get(QueFormat.KEY_VALUE);
                editText.setText(StringUtils.isEmpty(value) ? "" : value);
                editText.addTextChangedListener(new AbsTextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).put(QueFormat.KEY_VALUE, s.toString());
                        if (mData.isMust()) {
                            //必须
                            if (!StringUtils.isEmpty(s.toString()) && StringUtils.checkValue(CharFormatPattern.ID, s.toString()) && onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                        } else {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                        }
                    }
                });
            }
        }
    }
}
