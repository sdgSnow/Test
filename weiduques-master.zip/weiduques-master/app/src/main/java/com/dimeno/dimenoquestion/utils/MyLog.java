package com.dimeno.dimenoquestion.utils;

import com.socks.library.KLog;

/**
 * MyLog
 * Created by sdg on 2021/2/1.
 * desc:只用MyLog包装KLog的目的是便于切换log的使用方
 */
public class MyLog {

    public static void init(boolean isShowLog){
        KLog.init(isShowLog);
    }

    public static void init(boolean isShowLog,String tag){
        KLog.init(isShowLog,tag);
    }

    public static void i(String msg){
        KLog.i(msg);
    }

    public static void i(String tag,String msg){
        KLog.i(tag,msg);
    }

    public static void d(String msg){
        KLog.d(msg);
    }

    public static void d(String tag,String msg){
        KLog.d(tag,msg);
    }

    public static void w(String msg){
        KLog.w(msg);
    }

    public static void w(String tag,String msg){
        KLog.w(tag,msg);
    }

    public static void e(String msg){
        KLog.e(msg);
    }

    public static void e(String tag,String msg){
        KLog.e(tag,msg);
    }

}
