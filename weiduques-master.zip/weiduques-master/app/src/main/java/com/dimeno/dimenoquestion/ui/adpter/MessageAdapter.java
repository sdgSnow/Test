package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.annotation.LoadMoreState;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.event.LoadMessageEvent;
import com.dimeno.dimenoquestion.ui.adpter.holder.AnswerListViewHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.MessageViewHolder;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class MessageAdapter extends LoadRecyclerAdapter<MessageEntity.RecordsBean> {
    private Context mContext;
    private int page = 1;

    /**
     * 构造器
     * @param mContext
     */
    public MessageAdapter(Context mContext, List<MessageEntity.RecordsBean> answerList,RecyclerView parent) {
        super(answerList,parent);
        this.mContext = mContext;
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new MessageViewHolder(mContext,parent);
    }

    @Override
    public void onLoadMore() {
        if(mDatas.size() < 10){
            setState(LoadMoreState.NO_MORE);
            return;
        }
        EventBus.getDefault().post(new LoadMessageEvent());
    }
}
