package com.dimeno.dimenoquestion.bean;

/**
 * Create by   :PNJ
 * Date        :2021/4/1
 * Description :排序 B
 */
public class SortB {
    /**
     * 值
     */
    public String value;

    public String datab;

    public SortB(String value, String datab) {
        this.value = value;
        this.datab = datab;
    }
}
