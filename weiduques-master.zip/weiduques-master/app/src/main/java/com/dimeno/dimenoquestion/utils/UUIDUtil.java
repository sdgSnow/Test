package com.dimeno.dimenoquestion.utils;


import java.util.UUID;

/**
 * UUIDUtil
 * Created by sdg on 2020/9/22.
 */
public class UUIDUtil {

    public static String getUUID(){
        UUID uuid = UUID.randomUUID();
        String uniqueId = uuid.toString();
        return uniqueId;
    }
}
