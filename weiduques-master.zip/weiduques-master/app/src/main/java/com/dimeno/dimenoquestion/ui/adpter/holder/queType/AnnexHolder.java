package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.event.Event;
import com.dimeno.common.event.EventBusUtils;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.constant.AnnexFileType;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.ui.adpter.AnnexUploadAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UUIDUtil;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.dimeno.dimenoquestion.constant.Constant.OSS_DIRECT_PATH;
import static com.dimeno.dimenoquestion.constant.EventConstant.ACCEPT_ANNEX;
import static com.dimeno.dimenoquestion.constant.EventConstant.ADD_ANNEX;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :15 附件
 */
public class AnnexHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final RecyclerView recyclerView;
    private final LinearLayout ll_upload;
    private LinearLayout ll_home;
    private AnnexUploadAdapter annexUploadAdapter;
    private FrameLayout frame_error;
    private Map<Integer,AnnexUploadAdapter> map=new HashMap<>();
    private SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public AnnexHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_annex);
        //标题
        tvTitle = findViewById(R.id.tvTitle);
        //备注
        tv_remark = findViewById(R.id.tv_remark);
        //recyclerView
        recyclerView = findViewById(R.id.rcy_annex_upload);
        //立即上传
        ll_upload = findViewById(R.id.ll_annex_upload);
        //红色边框
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        //注册eventbus
        EventBusUtils.getInstance().register(this);
        this.type=type;
    }


    @Override
    public void bind() {
        //attr不为空
        if(mData.getAttr()!=null) {
            //获取标题
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            //设置标题
            tvTitle.setText(title == null ? "" : title);
            //设置备注
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            //备注显示与否
            tv_remark.setVisibility(TextUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            //是否显示红色边框
            if (mData.isError()) {
                //红色边框显示
                frame_error.setVisibility(View.VISIBLE);
            } else {
                //红色边框隐藏
                frame_error.setVisibility(View.GONE);
            }
            if (!type.equals("look")) {
                //不是查看状态，显示
                ll_upload.setVisibility(View.VISIBLE);
            } else {
                //查看状态隐藏
                ll_upload.setVisibility(View.GONE);
            }
            //设置方向
            recyclerView.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));
            //获取AnnexUploadAdapter是否为空
            if (map.get(getAdapterPosition()) == null) {
                //为空
                if (mData.getSurveyAnswer() == null) {
                    //创建新的答案
                    SurveyAnswer answer = new SurveyAnswer();
                    //答案列表初始化
                    answer.annexList = new ArrayList<>();
                    //题目设置答案
                    mData.setSurveyAnswer(answer);
                }
                //判断答案中的文件列表是否为空
                if (mData.getSurveyAnswer().annexList == null) {
                    //为空初始化
                    mData.getSurveyAnswer().annexList = new ArrayList<>();
                }
                //初始化适配器
                annexUploadAdapter = new AnnexUploadAdapter(mData.getSurveyAnswer().annexList, itemView.getContext(), type);
                //设置适配器
                recyclerView.setAdapter(annexUploadAdapter);
                //map存储适配器
                map.put(getAdapterPosition(), annexUploadAdapter);
            } else {
                //map含有该适配器，直接获取
                annexUploadAdapter = map.get(getAdapterPosition());
                //适配器设置数据
                annexUploadAdapter.setData(mData.getSurveyAnswer().annexList);
                //设置适配器
                recyclerView.setAdapter(annexUploadAdapter);
            }
            //上传点击监听
            ll_upload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!type.equals("look")) {
                        //不是查看状态
                        tv_remark.post(new Runnable() {
                            @Override
                            public void run() {
                                //判断显示红色边框否
                                if (mData.isError()) {
                                    //显示，则改为不显示
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                                //参数
                                String[] list = new String[3];
                                list[0] = mData.getAttr().getFileType() + "";
                                list[1] = getAdapterPosition() + "";
                                list[2] = mData.getID() + "";
                                EventBusUtils.getInstance().postEvent(new Event(ADD_ANNEX, list));
                            }
                        });
                    }
                }
            });
        }
    }

    /**
     * 注销EventBus
     */
    public void unregister(){
        EventBusUtils.getInstance().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventListener(Event event) {
        switch (event.getTag()) {
            case ACCEPT_ANNEX:
                //接收附件
                String[] list= (String[]) event.data;
                //参数判空
                if(list!=null && list.length>=3) {
                    //获取路径
                    String path = list[0];
                    //获取该题目在当前页的位置
                    int position = Integer.parseInt(list[1]);
                    //获取该题目id
                    int queId = Integer.parseInt(list[2]);

                    //该题目是该页的题目，位置相同，id相同
                    if (position == getAdapterPosition() && mData.getSurveyAnswer().annexList != null && queId==mData.getID()) {
                        //创建附件实体类
                        AnnexEntity annexEntity = new AnnexEntity();
//                        annexEntity.ossPath = MyUtils.getOssPath(path,mData.getQueID());
                        annexEntity.fileType = mData.getAttr().getFileType();
                        //根据后台返回的类型，重新适配类型
                        //根据后台返回的类型，重新适配类型
                        switch (mData.getAttr().getFileType()){
                            case AnnexFileType.ALL:
                                annexEntity.fileType  = FileType.FILE;
                                break;
                            case AnnexFileType.IMAGE:
                                annexEntity.fileType  = FileType.IMAGE;
                                break;
                            case AnnexFileType.AUDIO:
                                annexEntity.fileType  = FileType.AUDIO;
                                break;
                            case AnnexFileType.VIDEO:
                                annexEntity.fileType = FileType.VIDEO;
                                break;
                            case AnnexFileType.FILE:
                                annexEntity.fileType = FileType.DOCUMENT;
                                break;
                        }
                        //附件创建时间
                        annexEntity.create_time=System.currentTimeMillis()+"";
//                        annexEntity.fileType =FileType.FILE;
                        //附件名称
                        annexEntity.fileName = StringUtils.getFileNameWithSuffix(path);
                        //附件路径
                        annexEntity.path = path;
                        //答案添加改附件
                        mData.getSurveyAnswer().annexList.add(annexEntity);
                        //刷新界面
                        bind();
                    }
                }
                break;
        }
    }
}
