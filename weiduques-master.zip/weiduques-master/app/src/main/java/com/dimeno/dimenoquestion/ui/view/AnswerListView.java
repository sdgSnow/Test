package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.db.Answer;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface AnswerListView extends BaseView {
    /**
     * 获取问卷列表
     * @param loadMore
     * @param quesBeanList
     */
    void initQuesList(boolean loadMore, List<Answer> quesBeanList);
    /**
     * oss获取OssInfoEntity 成功回调
     * @param
     */
    void success(Answer answer, OssInfoEntity ossInfoEntity, SurveyAnswer surveyAnswer, String filepath, int type, AnnexEntity annexEntity);
    /**
     * 上传问卷 成功回调
     * @param
     */
    void success(UploadEntity entity,Answer answer);
    /**
     * 失败回调
     */
    void fail();
}
