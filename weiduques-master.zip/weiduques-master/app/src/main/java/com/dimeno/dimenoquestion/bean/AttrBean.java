package com.dimeno.dimenoquestion.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AttrBean implements Serializable {
    private int CascadeID;
    private String CellList;
    private int CharFormat;
    private String DateRange1;
    private String DateRange2;
    private String DefaultValue;
    private String DesText;
    private int FileType;
    private String FillText;
    private int FixedCID;
    private int FixedPID;
    private String InputLen;
    private String IsFill;
    private String IsFixedC;
    private String IsFixedP;
    private String IsLinefeed;
    private String IsMulti;
    private boolean IsMust;
    private boolean IsRandom;
    private String IsRepeat;
    private String LeftText;
    //最大范围
    private int Length1;
    //最小返回
    private int Length2;
    private String Level;
    private int MaxCount;
    private int MinCount;
    private boolean NoModify;
    private int NumCount;
    private double NumRange1;
    private double NumRange2;
    private String OpText;
    private String QuestionList;
    private String RefID;
    private String RightText;
    private String Rmk;
    private int RowCount;
    private int ScaleRange;
    private String SearchText;
    private String Title;
    private boolean customLocation;
    private List<AttrBean> CusAttr;
    private List<List<AttrBean>> CusAttrList;

    public List<List<AttrBean>> getCusAttrList() {
        return CusAttrList;
    }

    public void setCusAttrList(List<List<AttrBean>> cusAttrList) {
        CusAttrList = cusAttrList;
    }

    public int getCascadeID() {
        return CascadeID;
    }

    public void setCascadeID(int cascadeID) {
        CascadeID = cascadeID;
    }

    public String getCellList() {
        return CellList;
    }

    public void setCellList(String cellList) {
        CellList = cellList;
    }

    public int getCharFormat() {
        return CharFormat;
    }

    public void setCharFormat(int charFormat) {
        CharFormat = charFormat;
    }

    public String getDateRange1() {
        return DateRange1;
    }

    public void setDateRange1(String dateRange1) {
        DateRange1 = dateRange1;
    }

    public String getDateRange2() {
        return DateRange2;
    }

    public void setDateRange2(String dateRange2) {
        DateRange2 = dateRange2;
    }

    public String getDefaultValue() {
        return DefaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        DefaultValue = defaultValue;
    }

    public String getDesText() {
        return DesText;
    }

    public void setDesText(String desText) {
        DesText = desText;
    }

    public int getFileType() {
        return FileType;
    }

    public void setFileType(int fileType) {
        FileType = fileType;
    }

    public String getFillText() {
        return FillText;
    }

    public void setFillText(String fillText) {
        FillText = fillText;
    }

    public int getFixedCID() {
        return FixedCID;
    }

    public void setFixedCID(int fixedCID) {
        FixedCID = fixedCID;
    }

    public int getFixedPID() {
        return FixedPID;
    }

    public void setFixedPID(int fixedPID) {
        FixedPID = fixedPID;
    }

    public String getInputLen() {
        return InputLen;
    }

    public void setInputLen(String inputLen) {
        InputLen = inputLen;
    }

    public String getIsFill() {
        return IsFill;
    }

    public void setIsFill(String isFill) {
        IsFill = isFill;
    }

    public String getIsFixedC() {
        return IsFixedC;
    }

    public void setIsFixedC(String isFixedC) {
        IsFixedC = isFixedC;
    }

    public String getIsFixedP() {
        return IsFixedP;
    }

    public void setIsFixedP(String isFixedP) {
        IsFixedP = isFixedP;
    }

    public String getIsLinefeed() {
        return IsLinefeed;
    }

    public void setIsLinefeed(String isLinefeed) {
        IsLinefeed = isLinefeed;
    }

    public String getIsMulti() {
        return IsMulti;
    }

    public void setIsMulti(String isMulti) {
        IsMulti = isMulti;
    }

    public boolean isMust() {
        return IsMust;
    }

    public void setMust(boolean must) {
        IsMust = must;
    }

    public boolean isRandom() {
        return IsRandom;
    }

    public void setRandom(boolean random) {
        IsRandom = random;
    }

    public String getIsRepeat() {
        return IsRepeat;
    }

    public void setIsRepeat(String isRepeat) {
        IsRepeat = isRepeat;
    }

    public String getLeftText() {
        return LeftText;
    }

    public void setLeftText(String leftText) {
        LeftText = leftText;
    }

    public int getLength1() {
        return Length1;
    }

    public void setLength1(int length1) {
        Length1 = length1;
    }

    public int getLength2() {
        return Length2;
    }

    public void setLength2(int length2) {
        Length2 = length2;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public int getMaxCount() {
        return MaxCount;
    }

    public void setMaxCount(int maxCount) {
        MaxCount = maxCount;
    }

    public int getMinCount() {
        return MinCount;
    }

    public void setMinCount(int minCount) {
        MinCount = minCount;
    }

    public boolean isNoModify() {
        return NoModify;
    }

    public void setNoModify(boolean noModify) {
        NoModify = noModify;
    }

    public int getNumCount() {
        return NumCount;
    }

    public void setNumCount(int numCount) {
        NumCount = numCount;
    }

    public double getNumRange1() {
        return NumRange1;
    }

    public void setNumRange1(double numRange1) {
        NumRange1 = numRange1;
    }

    public double getNumRange2() {
        return NumRange2;
    }

    public void setNumRange2(double numRange2) {
        NumRange2 = numRange2;
    }

    public String getOpText() {
        return OpText;
    }

    public void setOpText(String opText) {
        OpText = opText;
    }

    public String getQuestionList() {
        return QuestionList;
    }

    public void setQuestionList(String questionList) {
        QuestionList = questionList;
    }

    public String getRefID() {
        return RefID;
    }

    public void setRefID(String refID) {
        RefID = refID;
    }

    public String getRightText() {
        return RightText;
    }

    public void setRightText(String rightText) {
        RightText = rightText;
    }

    public String getRmk() {
        return Rmk;
    }

    public void setRmk(String rmk) {
        Rmk = rmk;
    }

    public int getRowCount() {
        return RowCount;
    }

    public void setRowCount(int rowCount) {
        RowCount = rowCount;
    }

    public int getScaleRange() {
        return ScaleRange;
    }

    public void setScaleRange(int scaleRange) {
        ScaleRange = scaleRange;
    }

    public String getSearchText() {
        return SearchText;
    }

    public void setSearchText(String searchText) {
        SearchText = searchText;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public boolean isCustomLocation() {
        return customLocation;
    }

    public void setCustomLocation(boolean customLocation) {
        this.customLocation = customLocation;
    }

    public List<AttrBean> getCusAttr() {
        return CusAttr;
    }

    public void setCusAttr(List<AttrBean> cusAttr) {
        CusAttr = cusAttr;
    }
}
