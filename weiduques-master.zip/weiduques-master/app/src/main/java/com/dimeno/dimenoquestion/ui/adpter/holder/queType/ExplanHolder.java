package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :14 文字说明
 */
public class ExplanHolder extends RecyclerViewHolder<PageSubjectBean> {

    private final TextView tv_explain;
    private LinearLayout ll_home;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public ExplanHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_explan);
        tv_explain = findViewById(R.id.tv_explain);
        ll_home = findViewById(R.id.ll_home);
    }


    @Override
    public void bind() {
        tv_explain.setText(StringUtils.isEmpty(mData.getAttr().getDesText())?"":mData.getAttr().getDesText());
        tv_explain.setVisibility(StringUtils.isEmpty(mData.getAttr().getDesText()) ? View.GONE : View.VISIBLE);
    }
}
