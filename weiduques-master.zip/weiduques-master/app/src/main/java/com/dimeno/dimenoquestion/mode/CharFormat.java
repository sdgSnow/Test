package com.dimeno.dimenoquestion.mode;

/**
 * CharFormat
 * Created by wangzhen on 2020/5/8.
 */
public class CharFormat {
    //不限制
    public static final int LIMIT = 0;
    //邮箱
    public static final int EMAIL = 1;
    //中文
    public static final int TEXT = 2;
    //英文
    public static final int ENGLISH = 3;
    //网址
    public static final int WEBSITE = 4;
    //身份证号码
    public static final int ID = 5;
    //QQ号
    public static final int QQ = 6;
    //手机号
    public static final int MOBILE_PHONE = 7;
    //固话
    public static final int TELEPHONE = 8;
    //数值
    public static final int NUMBER = 9;
    //日期
    public static final int DATE = 10;
    //下拉选项
    public static final int DROP_DOWN = 11;
    //多行文本
    public static final int MULTI_TEXT = 12;
}
