package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.DataEntity;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.DropDownSpinnerAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.lang.ref.PhantomReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :25多级下拉，连续下拉
 */
public class MultiPullDownHolder extends RecyclerViewHolder<PageSubjectBean> {

    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private Spinner spinnerProvince;
    private Spinner spinnerCity;
    private Spinner spinnerDistrict;
    private Spinner spinnerStreet;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private SpannableStringBuilder title;
    private DataEntity data;
    private Map<Integer,DataEntity> map=new HashMap<>();
    private Map<Integer,List<String>> dataMap=new HashMap<>();
    private List<String> mDropdownValue;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public MultiPullDownHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_multi_pull_down);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        spinnerProvince=itemView.findViewById(R.id.spinner_province);
        spinnerCity=itemView.findViewById(R.id.spinner_city);
        spinnerDistrict=itemView.findViewById(R.id.spinner_district);
        spinnerStreet=itemView.findViewById(R.id.spinner_street);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
        }
        if(mData.isError()){
            frame_error.setVisibility(View.VISIBLE);
        }else {
            frame_error.setVisibility(View.GONE);
        }
        Log.d("adpterFlush","连续下拉 flush position="+getAdapterPosition());
        if(mData.getQueOption()!=null) {
            //数据只加载一次，防止多次刷新重置状态
            if (map.get(getAdapterPosition()) == null) {
                data = handleData(mData.getQueOption());
                map.put(getAdapterPosition(), data);
            } else {
                data = map.get(getAdapterPosition());
            }

            if (type.equals("look")) {
                spinnerProvince.setEnabled(false);
                spinnerCity.setEnabled(false);
                spinnerDistrict.setEnabled(false);
                spinnerStreet.setEnabled(false);
            }

            List<String> provinces = data.provinces;
            if (provinces != null) {
                //答案初始化
                if (mData.getSurveyAnswer().multi_dropdown_value == null) {
                    mData.getSurveyAnswer().multi_dropdown_value = new ArrayList<>();
                }
                mDropdownValue = mData.getSurveyAnswer().multi_dropdown_value;
                spinnerProvince.setVisibility(View.VISIBLE);
                spinnerProvince.setAdapter(new DropDownSpinnerAdapter(itemView.getContext(), provinces.toArray(new String[0]), true));
                spinnerProvince.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int index, long id) {
                        String province = provinces.get(index);
                        if (index == 0) {
                            mDropdownValue.clear();
                        } else {
                            //0的时候是“请选择”
                            if (mData.isError()) {
                                mData.setError(false);
                                frame_error.setVisibility(View.GONE);
                            }

                            if (mDropdownValue.size() > 0) {
                                mDropdownValue.set(0, province);
                            } else {
                                mDropdownValue.add(province);
                            }
                        }
                        bindCity(province);
                    }

                    private void bindCity(String province) {
                        if (data.citiesMap != null) {
                            List<String> cities = data.citiesMap.get(province);
                            if (cities != null) {
                                spinnerCity.setVisibility(View.VISIBLE);
                                spinnerCity.setAdapter(new DropDownSpinnerAdapter(itemView.getContext(), cities.toArray(new String[0]), spinnerProvince.getSelectedItemPosition() == 0));
                                spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int index, long id) {
                                        String city = cities.get(index);
                                        if (spinnerProvince.getSelectedItemPosition() == 0) {
                                            mDropdownValue.clear();
                                        } else {
                                            if (mDropdownValue.size() > 1) {
                                                mDropdownValue.set(1, city);
                                            } else {
                                                mDropdownValue.add(city);
                                            }
                                        }
                                        bindDistrict(city);
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                if (mDropdownValue != null && mDropdownValue.size() > 1) {
                                    int i = cities.indexOf(mDropdownValue.get(1));
                                    if (i >= 0) {
                                        spinnerCity.setSelection(i);
                                    }
                                }
                            } else {
                                spinnerCity.setVisibility(View.GONE);
                                spinnerDistrict.setVisibility(View.GONE);
                                spinnerStreet.setVisibility(View.GONE);
                            }
                        }
                    }

                    private void bindDistrict(String city) {
                        if (data.districtsMap != null) {
                            List<String> districts = data.districtsMap.get(city);
                            if (districts != null) {
                                spinnerDistrict.setVisibility(View.VISIBLE);
                                spinnerDistrict.setAdapter(new DropDownSpinnerAdapter(itemView.getContext(), districts.toArray(new String[0]), spinnerProvince.getSelectedItemPosition() == 0));
                                spinnerDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int index, long id) {
                                        String district = districts.get(index);
                                        if (spinnerProvince.getSelectedItemPosition() == 0) {
                                            mDropdownValue.clear();
                                        } else {
                                            if (mDropdownValue.size() > 2) {
                                                mDropdownValue.set(2, district);
                                            } else {
                                                mDropdownValue.add(district);
                                            }
                                        }
                                        bindStreet(district);
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                if (mDropdownValue != null && mDropdownValue.size() > 2) {
                                    int i = districts.indexOf(mDropdownValue.get(2));
                                    if (i >= 0) {
                                        spinnerDistrict.setSelection(i);
                                    }
                                }
                            } else {
                                spinnerDistrict.setVisibility(View.GONE);
                                spinnerStreet.setVisibility(View.GONE);
                            }
                        }
                    }

                    private void bindStreet(String district) {
                        if (data.streetsMap != null) {
                            List<String> streets = data.streetsMap.get(district);
                            if (streets != null) {
                                spinnerStreet.setVisibility(View.VISIBLE);
                                spinnerStreet.setAdapter(new DropDownSpinnerAdapter(itemView.getContext(), streets.toArray(new String[0]), spinnerProvince.getSelectedItemPosition() == 0));
                                spinnerStreet.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int index, long id) {
                                        String street = streets.get(index);
                                        if (spinnerProvince.getSelectedItemPosition() == 0) {
                                            mDropdownValue.clear();
                                        } else {
                                            if (mDropdownValue.size() > 3) {
                                                mDropdownValue.set(3, street);
                                            } else {
                                                mDropdownValue.add(street);
                                            }
                                        }
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });
                                if (mDropdownValue != null && mDropdownValue.size() > 3) {
                                    int i = streets.indexOf(mDropdownValue.get(3));
                                    if (i >= 0) {
                                        spinnerStreet.setSelection(i);
                                    }
                                }
                            } else {
                                spinnerStreet.setVisibility(View.GONE);
                            }
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                if (mDropdownValue != null && mDropdownValue.size() > 0) {
                    int i = provinces.indexOf(mDropdownValue.get(0));
                    if (i >= 0) {
                        spinnerProvince.setSelection(i);
                    }
                }
            }
        }
    }

    private DataEntity handleData(List<QueOptionBean> datas) {
        DataEntity entity = new DataEntity();
        if(datas!=null && datas.size()>1) {
            Collections.sort(datas, new Comparator<QueOptionBean>() {
                @Override
                public int compare(QueOptionBean o1, QueOptionBean o2) {
                    return o1.getSort() - o2.getSort();
                }
            });
        }
        for (QueOptionBean bean : datas) {
            String opText = bean.getOpText();
            if (!TextUtils.isEmpty(opText)) {
                String[] data = opText.split("/");
                if (data.length > 0) {
                    String province = data[0];
                    List<String> provinces = entity.provinces;
                    if (provinces == null) {
                        provinces = new ArrayList<>();
                    }
                    if (!provinces.contains(province)) {
                        provinces.add(province);
                    }
                    entity.provinces = provinces;

                    if (data.length > 1) {
                        String city = data[1];
                        Map<String, List<String>> citiesMap = entity.citiesMap;
                        if (citiesMap == null) {
                            citiesMap = new HashMap<>();
                        }
                        List<String> cities = citiesMap.get(province);
                        if (cities == null) {
                            cities = new ArrayList<>();
                        }
                        if (!cities.contains(city)) {
                            cities.add(city);
                        }
                        citiesMap.put(province, cities);
                        entity.citiesMap = citiesMap;

                        if (data.length > 2) {
                            String district = data[2];
                            Map<String, List<String>> districtsMap = entity.districtsMap;
                            if (districtsMap == null) {
                                districtsMap = new HashMap<>();
                            }
                            List<String> districts = districtsMap.get(city);
                            if (districts == null) {
                                districts = new ArrayList<>();
                            }
                            if (!districts.contains(district)) {
                                districts.add(district);
                            }
                            districtsMap.put(city, districts);
                            entity.districtsMap = districtsMap;

                            if (data.length > 3) {
                                String street = data[3];
                                Map<String, List<String>> streetsMap = entity.streetsMap;
                                if (streetsMap == null) {
                                    streetsMap = new HashMap<>();
                                }
                                List<String> streets = streetsMap.get(district);
                                if (streets == null) {
                                    streets = new ArrayList<>();
                                }
                                if (!streets.contains(street)) {
                                    streets.add(street);
                                }
                                streetsMap.put(district, streets);
                                entity.streetsMap = streetsMap;
                            }
                        }
                    }
                }
            }
        }
        return entity;
    }

}
