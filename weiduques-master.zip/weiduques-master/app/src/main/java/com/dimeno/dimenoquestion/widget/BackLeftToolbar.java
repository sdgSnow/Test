package com.dimeno.dimenoquestion.widget;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;


public class BackLeftToolbar extends Toolbar {

    private String mTitle;
    private Activity activity;
    private  TextView title;
    private  TextView rightTitle;

    /**
     * 构造器
     * @param activity
     * @param title
     */
    public BackLeftToolbar(Activity activity, String title) {
        super(activity);
        this.activity = activity;
        this.mTitle = title;
    }


    @Override
    public int layoutRes() {
        //设置布局
        return R.layout.toolbar_back_left;
    }

    @Override
    public void onViewCreated( View view) {
        title = view.findViewById(R.id.title);
        rightTitle = view.findViewById(R.id.rightTitle);
        ImageView back = view.findViewById(R.id.back);
        //设置标题
        title.setText(mTitle);
        //返回点击事件
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(myOnItemListener!=null){
                    //监听器不为空
                    myOnItemListener.onClick(view);
                }else {
                    activity.finish();
                }
            }
        });
        rightTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myOnItemListener!=null){
                    //监听器不为空
                    myOnItemListener.onClick(v);
                }
            }
        });
    }
    public TextView getRightTitle(){
        if(rightTitle!=null){
            return rightTitle;
        }
        return null;
    }

    /**
     * 设置标题字符串
     * @param mTitle
     */
    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }
    /**
     * 设置标题显示
     * @param mTitle
     */
    public void setViewTitle(String mTitle) {
        if(title!=null) {
            title.setText(mTitle);
        }
    }
    /**
     * 设置右标题
     * @param mTitle
     */
    public void setRightTitle(String mTitle) {
        if(rightTitle!=null) {
            rightTitle.setText(mTitle);
        }
    }

    /**
     * 设置右标题是否显示
     * @param visible
     */
    public void setRightVisible(boolean visible){
        if(rightTitle!=null){
            if(visible){
                rightTitle.setVisibility(View.VISIBLE);
            }else {
                rightTitle.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 设置监听器
     * @param myOnItemListener
     */
    public void setMyOnClickListener(MyOnClickListener myOnItemListener) {
        this.myOnItemListener = myOnItemListener;
    }

    private MyOnClickListener myOnItemListener;

    public interface MyOnClickListener {
        void onClick(View view);
    }
}
