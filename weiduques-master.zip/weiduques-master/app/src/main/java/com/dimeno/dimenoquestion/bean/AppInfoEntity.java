package com.dimeno.dimenoquestion.bean;

import com.google.gson.annotations.SerializedName;

/**
 * Created by cc on 2018/1/2.
 */

public class AppInfoEntity {

    /**
     * Flag : 0
     * ResultObj : {"V_ID":10001,"appname":"维度问卷","serverVersion":"1","lastForce":1,"updateurl":"dfsfdds","V_Project":"97249f20-a685-49c9-a0aa-2614ebe9deba","yl_01":"<p>\t1.fgdfgd<\/p><p>\t2.ghfghfg<\/p>","yl_02":"","yl_03":"","yl_04":""}
     * Msg : 操作成功
     */

    private int Flag;
    //data数据
    private ResultObjBean ResultObj;
    //msg
    private String Msg;

    public int getFlag() {
        return Flag;
    }

    public void setFlag(int Flag) {
        this.Flag = Flag;
    }

    public ResultObjBean getResultObj() {
        return ResultObj;
    }

    public void setResultObj(ResultObjBean ResultObj) {
        this.ResultObj = ResultObj;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String Msg) {
        this.Msg = Msg;
    }

    public static class ResultObjBean {
        /**
         * V_ID : 10001
         * appname : 维度问卷
         * versionCode : 1
         * versionName : "1.0.2"
         * lastForce : 1
         * updateurl : dfsfdds
         * V_Project : ecd6aa1c-a857-47a1-b444-43b336550028
         * yl_01 : <p>	1.fgdfgd</p><p>	2.ghfghfg</p>
         * yl_02 :
         * yl_03 :
         * yl_04 :
         */


        private int V_ID;

        private String appname;
        private String V_Project;
        private int versionCode;
        private String versionName;
        private int lastForce;
        private String updateurl;
        @SerializedName("yl_01")
        private String updateLog;
        private String yl_02;
        private String yl_03;
        private String yl_04;

        public int getV_ID() {
            return V_ID;
        }

        public void setV_ID(int v_ID) {
            V_ID = v_ID;
        }

        public String getAppname() {
            return appname;
        }

        public void setAppname(String appname) {
            this.appname = appname;
        }

        public int getVersionCode() {
            return versionCode;
        }

        public void setVersionCode(int versionCode) {
            this.versionCode = versionCode;
        }

        public String getVersionName() {
            return versionName;
        }

        public void setVersionName(String versionName) {
            this.versionName = versionName;
        }

        public int getLastForce() {
            return lastForce;
        }

        public void setLastForce(int lastForce) {
            this.lastForce = lastForce;
        }

        public String getUpdateurl() {
            return updateurl;
        }

        public void setUpdateurl(String updateurl) {
            this.updateurl = updateurl;
        }

        public String getV_Project() {
            return V_Project;
        }

        public void setV_Project(String v_Project) {
            V_Project = v_Project;
        }

        public String getUpdateLog() {
            return updateLog;
        }

        public void setUpdateLog(String updateLog) {
            this.updateLog = updateLog;
        }

        public String getYl_03() {
            return yl_03;
        }

        public void setYl_03(String yl_03) {
            this.yl_03 = yl_03;
        }

        public String getYl_04() {
            return yl_04;
        }

        public void setYl_04(String yl_04) {
            this.yl_04 = yl_04;
        }
    }
}
