package com.dimeno.dimenoquestion.bean;

/**
 * Created by cc on 2017/12/25.
 */

public class UploadEntity {

    /**
     * Flag : 0
     * ResultObj : 1
     * Msg : sample string 2
     */

    private int Flag;
    private String ResultObj;
    private String Msg;

    public int getFlag() {
        return Flag;
    }

    public void setFlag(int Flag) {
        this.Flag = Flag;
    }

    public String getResultObj() {
        return ResultObj;
    }

    public void setResultObj(String ResultObj) {
        this.ResultObj = ResultObj;
    }

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String Msg) {
        this.Msg = Msg;
    }
}
