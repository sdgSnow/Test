package com.dimeno.dimenoquestion.constant;

/**
 * Create by   :PNJ
 * Date        :2021/3/19
 * Description :
 */
public class EventConstant {
    //添加附件
    public static final int ADD_ANNEX =0x01;
    //接收附件
    public static final int ACCEPT_ANNEX =0x02;
    //清除冒泡
    public static final int MATRIX =0x03;
    //结束调查
    public static final int SURVEY_STOP =0x04;
}
