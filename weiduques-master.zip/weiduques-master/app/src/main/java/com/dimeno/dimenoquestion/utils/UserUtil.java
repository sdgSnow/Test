package com.dimeno.dimenoquestion.utils;


import com.blankj.utilcode.util.SPUtils;

/**
 * 用户信息sp工具类
 */
public class UserUtil {
    private static final SPUtils spUtils = SPUtils.getInstance(SPkeyConstantUtil.SSP_KEY);

    public static void setAboutUs(String aboutUs) {
        spUtils.put("aboutUs", aboutUs);
    }

    public static String getAboutUs() {
        return spUtils.getString("aboutUs");
    }

    public static void setIMEI(String imei) {
        spUtils.put("imei", imei);
    }

    public static String getIMEI() {
        return spUtils.getString("imei");
    }

    public static void setUserId(String userId) {
        spUtils.put("userId", userId);
    }

    public static String getUserId() {
        return spUtils.getString("userId");
    }

    public static void setUserName(String userName) {
        spUtils.put("userName", userName);
    }

    public static String getUserName() {
        return spUtils.getString("userName");
    }

    public static void setAccount(String account) {
        spUtils.put("account", account);
    }

    public static String getAccount() {
        return spUtils.getString("account");
    }

    public static void setLoginTime(long account) {
        spUtils.put("login_time", account);
    }

    public static long getLoginTime() {
        return spUtils.getLong("login_time");
    }

    //保存密码
    public static void setUserPwd(String pwd) {
        spUtils.put("user_pwd", pwd);
    }

    public static String getUserPwd() {
        return spUtils.getString("user_pwd");
    }

    public static int getUploadWay() {
        return spUtils.getInt("uploadWay");
    }

    public static void setUploadWay(int uploadWay) {
        spUtils.put("uploadWay", uploadWay);
    }


    public static void setIsLogin(boolean isLogin) {
        spUtils.put("isLogin", isLogin);
    }

    public static boolean getIsLogin() {
        return spUtils.getBoolean("isLogin", false);
    }

    public static void set2GetArea(boolean toGetArea) {
        spUtils.put("toGetArea", toGetArea);
    }

    public static boolean get2GetArea() {
        return spUtils.getBoolean("toGetArea", false);
    }

    public static void setIsFirst(boolean existData) {
        spUtils.put("isFirst", existData);
    }

    public static boolean getIsFirst() {
        return spUtils.getBoolean("isFirst", true);
    }

    public static String getRepeatContent(String repeatKey) {
        return spUtils.getString(repeatKey, "");
    }

    public static void putRepeatContent(String repeatKey, String content) {
        spUtils.put(repeatKey, content);
    }

    //区域选择框
//    public static void setAllArea(String a) {
//        spUtils.put("userArea", a);
//    }
//
//    public static String getAllArea() {
//        return spUtils.getString("userArea", "");
//    }

    public static void clear() {
        spUtils.clear();
    }
}

//    public static void setIMEI(String imei) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString("imei", imei);
//    }
//
//    public static String getIMEI() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString("imei");
//    }
//
//    public static void setUserId(String userId) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString("userId", userId);
//    }
//
//    public static String getUserId() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString("userId");
//    }
//
//    public static void setUserName(String userName) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString("userName", userName);
//    }
//
//    public static String getUserName() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString("userName");
//    }
//
//    public static void setAccount(String account) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString("account", account);
//    }
//
//    public static String getAccount() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString("account");
//    }
//
//    public static void setIsLogin(boolean isLogin) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putBoolean("isLogin", isLogin);
//    }
//
//    public static boolean getIsLogin() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getBoolean("isLogin", false);
//    }
//
//    public static void setIsFirst(boolean existData) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putBoolean("isFirst", existData);
//    }
//
//    public static boolean getIsFirst() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getBoolean("isFirst", true);
//    }
//
//    public static String getRepeatContent(String repeatKey) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString(repeatKey, "");
//    }
//
//    public static void putRepeatContent(String repeatKey, String content) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString(repeatKey, content);
//    }
//
//    //区域选择框
//    public static void setAllArea(String a) {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        spUtils.putString("userArea", a);
//    }
//
//    public static String getAllArea() {
//        if (spUtils == null) {
//            spUtils = new SPUtils(SPkeyConstantUtil.SSP_KEY);
//        }
//        return spUtils.getString("userArea", "");
//    }
