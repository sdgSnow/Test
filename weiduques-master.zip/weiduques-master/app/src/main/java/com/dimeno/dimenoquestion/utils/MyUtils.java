/*
 * Copyright (c) 2016 咖枯 <kaku201313@163.com | 3772304@qq.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.dimeno.dimenoquestion.utils;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.LogUtils;
import com.dimeno.common.base.BaseApplication;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.ConstantUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import static com.dimeno.dimenoquestion.constant.Constant.OSS_DIRECT_PATH;


/**
 * @author 咖枯
 * @version 1.0 2016/5/31
 */
public class MyUtils {


    /**
     * from yyyy-MM-dd HH:mm:ss to MM-dd HH:mm
     */
    public static String formatDate(String before) {
        String after;
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    .parse(before);
            after = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(date);
        } catch (ParseException e) {
            LogUtils.e("转换新闻日期格式异常：" + e.toString());
            return before;
        }
        return after;
    }


    public static String getTime(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }

    public static int getStatusBarHeight(Activity activity) {
        int height = 0;
        int resourceId = activity.getResources().getIdentifier("status_bar_height", "dimen",
                "android");
        if (resourceId > 0) {
            height = activity.getResources().getDimensionPixelSize(resourceId);
        }
        return height;
    }


    /**
     * encodeBase64File:(将文件转成base64 字符串). <br/>
     *
     * @param path 文件路径
     * @return
     * @throws Exception
     * @author guhaizhou@126.com
     * @since JDK 1.6
     */
    public static String encodeBase64File(String path) throws Exception {
        File file = new File(path);
        FileInputStream inputFile = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        inputFile.read(buffer);
        inputFile.close();
        return Base64.encodeToString(buffer, Base64.DEFAULT);
    }

    public static void changeState(Button button, int res, boolean state) {
        button.setEnabled(state);
        button.setBackgroundResource(res);
    }


    public static Bitmap getImageFromAssetsFile(Context context, String fileName) {
        Bitmap image = null;
        AssetManager am = context.getResources().getAssets();
        try {
            InputStream is = am.open(fileName);
            image = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return image;

    }

    public static int getScreenWith() {
        return BaseApplication.getContext().getResources().getDisplayMetrics().widthPixels;
    }

    /**
     * 解决InputMethodManager内存泄露现象
     */
    public static void fixInputMethodManagerLeak(Context destContext) {
        if (destContext == null) {
            return;
        }

        InputMethodManager imm = (InputMethodManager) destContext
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) {
            return;
        }

        String[] arr = new String[]{"mCurRootView", "mServedView", "mNextServedView"};
        Field f;
        Object obj_get;
        for (String param : arr) {
            try {
                f = imm.getClass().getDeclaredField(param);
                if (!f.isAccessible()) {
                    f.setAccessible(true);
                } // author: sodino mail:sodino@qq.com
                obj_get = f.get(imm);
                if (obj_get != null && obj_get instanceof View) {
                    View v_get = (View) obj_get;
                    if (v_get
                            .getContext() == destContext) { // 被InputMethodManager持有引用的context是想要目标销毁的
                        f.set(imm, null); // 置空，破坏掉path to gc节点
                    } else {
                        // 不是想要目标销毁的，即为又进了另一层界面了，不要处理，避免影响原逻辑,也就不用继续for循环了
                        /*if (QLog.isColorLevel()) {
                            QLog.d(ReflecterHelper.class.getSimpleName(), QLog.CLR, "fixInputMethodManagerLeak break, context is not suitable, get_context=" + v_get.getContext()+" dest_context=" + destContext);
                        }*/
                        break;
                    }
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    public static View getRootView(Activity context) {
        return ((ViewGroup) context.findViewById(android.R.id.content)).getChildAt(0);
    }


    /**
     * @return String 生成32位的随机数作为id
     */
    public static String getCode() {
        return UUID.randomUUID().toString();
    }


    public static String decimalFormData(int data) {
        if (data <= 99) {
            DecimalFormat df = new DecimalFormat("00");
            String str2 = df.format(data);
            return str2;
        } else {
            return data + "";
        }
    }


    //版本名
    public static String getVersionName(Context context) {
        return getPackageInfo(context).versionName;
    }

    //版本号
    public static int getVersionCode(Context context) {
        return getPackageInfo(context).versionCode;
    }

    private static PackageInfo getPackageInfo(Context context) {
        PackageInfo pi = null;

        try {
            PackageManager pm = context.getPackageManager();
            pi = pm.getPackageInfo(context.getPackageName(),
                    PackageManager.GET_CONFIGURATIONS);

            return pi;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pi;
    }

    public static String randomColor() {
        //红色
        String red;
        //绿色
        String green;
        //蓝色
        String blue;
        //生成随机对象
        Random random = new Random();
        //生成红色颜色代码
        red = Integer.toHexString(random.nextInt(256)).toUpperCase();
        //生成绿色颜色代码
        green = Integer.toHexString(random.nextInt(256)).toUpperCase();
        //生成蓝色颜色代码
        blue = Integer.toHexString(random.nextInt(256)).toUpperCase();

        //判断红色代码的位数
        red = red.length() == 1 ? "0" + red : red;
        //判断绿色代码的位数
        green = green.length() == 1 ? "0" + green : green;
        //判断蓝色代码的位数
        blue = blue.length() == 1 ? "0" + blue : blue;
        //生成十六进制颜色值
        String color = "#" + red + green + blue;
        return color;
    }

    /**
     * 隐藏虚拟按键，并且全屏
     */
    public static void hideBottomUIMenu(Activity activity) {
        //隐藏虚拟按键，并且全屏
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = activity.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            //for new api versions.
            View decorView = activity.getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    /**
     * 将问卷的页次序排序
     */

//    public static void sortByPageSortCollator(List<QueEntity.ResultObjBean.QuePageBean> pageBeanList) {
//        Collections.sort(pageBeanList, (o1, o2) -> {
//            QueEntity.ResultObjBean.QuePageBean stu1 = o1;
//            QueEntity.ResultObjBean.QuePageBean stu2 = o2;
//            if (stu1.getSort() > stu2.getSort()) {
//                return 1;
//            } else if (stu1.getSort() == stu2.getSort()) {
//                return 0;
//            } else {
//                return -1;
//            }
//        });
//    }
//
//    /**
//     * 将页的题目排序
//     */
//
//    public static void sortBySubjectSortCollator(List<SurveyQues.PageListBean.SubListBean> subListBeans) {
//        Collections.sort(subListBeans, (o1, o2) -> {
//            SurveyQues.PageListBean.SubListBean stu1 = o1;
//            SurveyQues.PageListBean.SubListBean stu2 = o2;
//            if (stu1.getSort() > stu2.getSort()) {
//                return 1;
//            } else if (stu1.getSort() == stu2.getSort()) {
//                return 0;
//            } else {
//                return -1;
//            }
//        });
//    }
//
//    /**
//     * 将题目的选项排序
//     */
//
//    public static void sortByQueOptionSortCollator(List<QueEntity.ResultObjBean.QueOptionBean> queOptionBeans) {
//        Collections.sort(queOptionBeans, (o1, o2) -> {
//            QueEntity.ResultObjBean.QueOptionBean stu1 = o1;
//            QueEntity.ResultObjBean.QueOptionBean stu2 = o2;
//            if (stu1.getSort() > stu2.getSort()) {
//                return 1;
//            } else if (stu1.getSort() == stu2.getSort()) {
//                return 0;
//            } else {
//                return -1;
//            }
//        });
//    }

    /**
     * RecyclerView 移动到当前位置，
     *
     * @param manager 设置RecyclerView对应的manager
     * @param position       要跳转的位置
     */
    public static void MoveToPosition(LinearLayoutManager manager, int position) {
        manager.scrollToPositionWithOffset(position, 0);
//        manager.setStackFromEnd(true);
    }

    /**
     * 滑动到指定位置
     * @param mRecyclerView
     * @param position
     */
    public static void smoothMoveToPosition(RecyclerView mRecyclerView, final int position) {
        // 第一个可见位置
        int firstItem = mRecyclerView.getChildLayoutPosition(mRecyclerView.getChildAt(0));
        // 最后一个可见位置
        int lastItem = mRecyclerView.getChildLayoutPosition(mRecyclerView.getChildAt(mRecyclerView.getChildCount() - 1));

        if (position < firstItem) {
            // 如果跳转位置在第一个可见位置之前，就smoothScrollToPosition可以直接跳转
            mRecyclerView.smoothScrollToPosition(position);
        } else if (position <= lastItem) {
            // 跳转位置在第一个可见项之后，最后一个可见项之前
            // smoothScrollToPosition根本不会动，此时调用smoothScrollBy来滑动到指定位置
            int movePosition = position - firstItem;
            if (movePosition >= 0 && movePosition < mRecyclerView.getChildCount()) {
                int top = mRecyclerView.getChildAt(movePosition).getTop();
                mRecyclerView.smoothScrollBy(0, top);
            }
        } else {
            // 如果要跳转的位置在最后可见项之后，则先调用smoothScrollToPosition将要跳转的位置滚动到可见位置
            // 再通过onScrollStateChanged控制再次调用smoothMoveToPosition，执行上一个判断中的方法

            //因为有头部，所以加1
            mRecyclerView.smoothScrollToPosition(position+1);
        }
    }

    public static String getProgress(Integer currentSize, Integer totalSize) {
        double progress = (currentSize.doubleValue() / totalSize.doubleValue()) * 100;
        //如果要保留两位小数点，则 DecimalFormat("0.00")
        DecimalFormat decimalFormat =new DecimalFormat("0");//构造方法的字符格式这里如果小数不足2位,会以0补足.
        String distanceString = decimalFormat.format(progress);//format 返回的是字符串
        return distanceString;
    }

    public static String getProgress(Long currentSize, Long totalSize) {
        if(currentSize != null && totalSize != null && currentSize > 0 && totalSize > 0) {
            double progress = (currentSize.doubleValue() / totalSize.doubleValue()) * 100;
            //如果要保留两位小数点，则 DecimalFormat("0.00")
            String value = String.valueOf(progress);
            if(TextUtils.isEmpty(value)){
                return "0";
            }
            NumberFormat nf = NumberFormat.getNumberInstance();
            nf.setMaximumFractionDigits(2);
            String format = nf.format(progress);
//            MyLog.i("format:" + nf.format(progress));
//            DecimalFormat decimalFormat = new DecimalFormat("0.00");//构造方法的字符格式这里如果小数不足2位,会以0补足.
//            String distanceString = decimalFormat.format(progress);//format 返回的是字符串
            return format;
        }else {
            return "0";
        }
    }


    public static String getOssFileName(String pathandname) {
        int start = pathandname.lastIndexOf("/");
        int end = pathandname.lastIndexOf(".");
        if (start != -1 && end != -1) {
            return pathandname.substring(start + 1, end);
        } else {
            return null;
        }
    }

    /**
     * 获取osspath
     * @param path
     * @return
     */
    public static String getOssPath(String path,String queId){
       return OSS_DIRECT_PATH + queId + "/" + new File(path).getName();
    }

    public static void reLogin(){
        if(SpUtil.get().isInitialize()) {
            int tokenDays = 7;//有效期时间
            //保证有数据
            if(UserUtil.getLoginTime()>0) {
                int loginDays = TimeUtil.loginDays(UserUtil.getLoginTime(), TimeUtil.getCurrentTimeMillis());
                if (loginDays > tokenDays) {
                    MyToast.showShortToast("登录过期，请重新登录");
                    UserUtil.setIsLogin(false);
                }
            }
        }else {
            SpUtil.get().setsInstance(true);
        }
    }

    /**
     * 递归隐藏逻辑
     * */
    public static void hideQues(List<PageSubjectBean> subjecList,PageSubjectBean queitem){
        //获取关联的题目在列表所在的位置position
        Map<String, List<Integer>> map = queitem.getHidePosition();
        if (map != null && map.size() != 0) {
            //获取选项
            List<QueOptionBean> queOption=queitem.getQueOption();
            if(queOption!=null && queOption.size()>0){
                for (QueOptionBean queOptionBean : queOption) {
                    //如果选择，则遍历显示题目
                    if (map.get(queOptionBean.getOpCode()) != null && map.get(queOptionBean.getOpCode()).size() != 0) {

                        //先全部隐藏，再显示
                        for (List<Integer> list : map.values()) {
                            if (list != null && list.size() != 0) {
                                for (int i = 0; i < list.size(); i++) {
                                    if (subjecList.size() > list.get(i)) {
                                        //隐藏
                                        subjecList.get(list.get(i)).setIsHide(ConstantType.queHide.GONE);//隐藏
//                                                subjecList.get(list.get(i)).getSurveyAnswer().logicShow = 2;
                                        subjecList.get(list.get(i)).getSurveyAnswer().logicShow = ConstantUtil.GONE;
                                        hideQues(subjecList,subjecList.get(list.get(i)));
                                    }
                                }
                            }
                        }

                    }
                }
            }

        }
    }

}
