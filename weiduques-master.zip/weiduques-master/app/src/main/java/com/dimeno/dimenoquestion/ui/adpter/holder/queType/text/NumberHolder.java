package com.dimeno.dimenoquestion.ui.adpter.holder.queType.text;

import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.MultiBlankAdapter;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :数值
 */
public class NumberHolder extends RecyclerViewHolder<AttrBean> {

    private ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks;
    private TextView mLeftText;
    private TextView mRightText;
    private EditText editText;
    private SpannableStringBuilder title;
    private MultiBlankAdapter.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param multiFillBlanks
     * @param onChildClickLisener
     * @param type
     */
    public NumberHolder(@NonNull ViewGroup parent, ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks, MultiBlankAdapter.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_multi_blank);
        this.multiFillBlanks = multiFillBlanks;
        mLeftText =findViewById(R.id.tv_title);
        mRightText =findViewById(R.id.tv_right_text);
        editText =findViewById(R.id.et_fill_multi_blank);
        editText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});

        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
    }

    @Override
    public void bind() {
        if(type.equals("look")){
            editText.setClickable(false);
            editText.setEnabled(false);
        }
        title= StringUtils.getTitle(mData.getLeftText(),mData.isMust());
        mLeftText.setText(title);
//        editText.setHint("请输入数值");
        mRightText.setText(mData.getRightText());
        editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);//数字和小数点
//        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        //editText软键盘的EditorAction监控
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        editText.addTextChangedListener(new AbsTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
                    multiFillBlanks.get(getAdapterPosition()).fillText = s.toString();
                }
                if(mData.isMust()) {
                    if(!StringUtils.isEmpty(s.toString()) && onChildClickLisener!=null){
                        onChildClickLisener.onChildClick();
                    }
                }else {
                    if (onChildClickLisener != null) {
                        onChildClickLisener.onChildClick();
                    }
                }
            }
        });
        if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
            multiFillBlanks.get(getAdapterPosition()).format = CharFormat.NUMBER;
            editText.setText(multiFillBlanks.get(getAdapterPosition()).fillText);
        }
    }
}
