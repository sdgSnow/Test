package com.dimeno.dimenoquestion.ui.actvity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;


import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.event.Event;
import com.dimeno.common.widget.bar.BottomBar;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.widget.fitwindows.FitWindowsFrameLayout;
import com.dimeno.dimenoquestion.BuildConfig;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.pop.AlertPopup;
import com.dimeno.dimenoquestion.ui.fragment.MineFragment;
import com.dimeno.dimenoquestion.ui.fragment.NewQuesFragment;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.ChangePswPop;
import com.dimeno.dimenoquestion.widget.RightToolbar;
import com.dimeno.dimenoquestion.widget.TitleToolbar;
import com.sdg.dialoglibrary.pop.PopManager;
import com.socks.library.KLog;

import java.util.concurrent.TimeUnit;

import butterknife.ButterKnife;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

import static com.dimeno.dimenoquestion.constant.ConstantUtil.MAINACTIVITY;
import static com.dimeno.dimenoquestion.constant.ConstantUtil.SOURCE;

/**
 * Create by   :PNJ
 * Date        :2021/3/15
 * Description :
 */
public class MainActivity extends BaseActivity implements BottomBar.OnItemListener {
    private NewQuesFragment newQuesFragment;
    private MineFragment mineFragment;
    private FitWindowsFrameLayout fl_main;
    private ChangePswPop changePswPop;

    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);

        fl_main=findViewById(R.id.fl_main);
        //根据savedInstanceState是否等于null判断activity是新建还是销毁重建
        if(savedInstanceState==null){
            //activity第一次创建的时候，savedInstanceState=null，创建NewQuesFragment
            newQuesFragment=NewQuesFragment.newInstance();
            mineFragment=MineFragment.newInstance();
        }else {
            //恢复状态
            newQuesFragment = (NewQuesFragment) getSupportFragmentManager().getFragment(savedInstanceState, "newQuesFragment");
            if(newQuesFragment==null){
                newQuesFragment=NewQuesFragment.newInstance();
            }
            mineFragment = (MineFragment) getSupportFragmentManager().getFragment(savedInstanceState, "mineFragment");
            if(mineFragment==null){
                mineFragment=MineFragment.newInstance();
            }
        }
    }



    @Override
    public Toolbar createToolbar() {
        RightToolbar r = new RightToolbar(this, BuildConfig.APP_DEBUG ? "维度问卷（测试）":"维度问卷",true);
        r.setRightClick(new RightToolbar.RightClick() {
            @Override
            public void onClick() {
                gotoActivity(MessageActivity.class);
            }
        });
        return r;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initViews() {
        initBar();
        timer();
    }

    private void timer() {
        Observable.timer(2,TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
                        /// TODO: 2021/4/12
                        if(!StringUtils.isEmpty(UserUtil.getUserPwd()) && UserUtil.getUserPwd().equals("Weidu.123")){
                            //强制提示更改密码
                            changePswPop = new ChangePswPop(mActivity);
                            changePswPop.setTitle("提示").setMessage("请修改密码!").setYes("确定").setCallback(new ChangePswPop.Callback() {
                                @Override
                                public void yes() {
                                    Intent intent = new Intent(mActivity,ChangePwActivity.class);
                                    intent.putExtra(SOURCE,MAINACTIVITY);
                                    startActivity(intent);
                                }
                            }).show();
                        }
                    }
                });
    }

    /**
     * 保存状态
     * @param outState
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        KLog.d("MainActivity","dosurvey onSaveInstanceState");
        //保存frament
        if(newQuesFragment!=null){
            getSupportFragmentManager().putFragment(outState, "newQuesFragment", newQuesFragment);
        }
        if(mineFragment!=null){
            getSupportFragmentManager().putFragment(outState, "mineFragment", mineFragment);
        }
    }
    @Override
    public void initListeners() {

    }
    public void initBar() {
        BottomBar bottomBar = findViewById(R.id.bottomBar);
        bottomBar.init(getSupportFragmentManager(), R.id.fl_main)
                .addItem("首页", R.mipmap.home_selected, R.mipmap.home_default, newQuesFragment, false)
                .addItem("我的", R.mipmap.my_selected, R.mipmap.my_default, mineFragment, false)
                .defaultIndext(0);
        bottomBar.setOnItemListener(this);
    }

    @Override
    public void onItem(int i) {
    }

    @Override
    protected BasePresenter createPresenter() {
        return null;
    }


    @Override
    protected void onResume() {
        super.onResume();
        KLog.d("MainActivity","main onResume");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        KLog.d("MainActivity","main onDestroy");
    }
    private AlertPopup alertPopup;
    private void showQuitDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                alertPopup = new AlertPopup(MainActivity.this, "","确定","提示", "密码尚未修改,请修改密码!" );
                alertPopup.setonMyItemClickListener(new AlertPopup.onMyItemClickListener() {
                    @Override
                    public void onItemClick(boolean flag) {
                        startActivity(new Intent(MainActivity.this,ChangePwActivity.class));
                        if(alertPopup!=null && alertPopup.isShowing()){
                            alertPopup.dismiss();
                            alertPopup = null;
                        }
                    }
                });
                alertPopup.showAtLocation(fl_main, Gravity.CENTER, 0, 0);
            }
        });
    }

}