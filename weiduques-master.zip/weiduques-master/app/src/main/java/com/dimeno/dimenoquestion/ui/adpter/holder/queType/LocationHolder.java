package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.Manifest;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import com.blankj.utilcode.util.NetworkUtils;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.location.LocationDialog;
import com.dimeno.dimenoquestion.map.ILocation;
import com.dimeno.dimenoquestion.map.OfflineAlwaysUtils;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;
import com.dimeno.permission.PermissionManager;
import com.dimeno.permission.callback.AbsPermissionCallback;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :定位
 */
public class LocationHolder extends RecyclerViewHolder<PageSubjectBean> {

    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_location;
    private final ConstraintLayout containerGetLocation;
    private SpannableStringBuilder title;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public LocationHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_location);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        tv_location = findViewById(R.id.tv_location);
        frame_error = findViewById(R.id.frame_error);
        containerGetLocation = findViewById(R.id.container_get_location);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            if (mData.getSurveyAnswer() != null) {
                tv_location.setVisibility(TextUtils.isEmpty(mData.getSurveyAnswer().mLocationAddress) ? View.GONE : View.VISIBLE);
                tv_location.setText(TextUtils.isEmpty(mData.getSurveyAnswer().mLocationAddress) ? "" : mData.getSurveyAnswer().mLocationAddress);
            } else {
                mData.setSurveyAnswer(new SurveyAnswer());
                tv_location.setVisibility(View.GONE);
                tv_location.setText("");
            }
            if (type.equals("look")) {
                containerGetLocation.setVisibility(View.GONE);
            }
            containerGetLocation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PermissionManager.request(itemView.getContext(), new AbsPermissionCallback() {
                        @Override
                        public void onGrant(String[] permissions) {
                            if(NetworkUtils.isConnected()) {
                                //有网络则显示定位地图
                                if (itemView.getContext() instanceof FragmentActivity) {
                                    new LocationDialog().setCustomLocation(mData.getAttr().isCustomLocation()).setCallback((address, latitude, longitude) -> {
                                        tv_location.setVisibility(View.VISIBLE);
                                        tv_location.setText(StringUtils.isEmpty(address) ? "" : address);
                                        mData.getSurveyAnswer().mLocationAddress = address;
                                        mData.getSurveyAnswer().mLocationLatitude = latitude;
                                        mData.getSurveyAnswer().mLocationLongitude = longitude;
                                    }).show(((FragmentActivity) itemView.getContext()).getSupportFragmentManager(), LocationDialog.class.getName());
                                }
                            }else {
                                //无网络则直接显示地址信息
                                OfflineAlwaysUtils.getInstance().startLocation(MyApplication.getContext(), new ILocation() {
                                    @Override
                                    public void locationInfo(String longitude, String latitude, String address, String currentTime) {
                                        tv_location.setVisibility(View.VISIBLE);
                                        tv_location.setText(latitude + "," + longitude);
                                        mData.getSurveyAnswer().mLocationAddress = address;
                                        mData.getSurveyAnswer().mLocationLatitude = Double.parseDouble(StringUtils.isEmpty(latitude) ? "0.0" : latitude);;
                                        mData.getSurveyAnswer().mLocationLongitude = Double.parseDouble(StringUtils.isEmpty(longitude) ? "0.0" : longitude);
                                    }
                                });
                            }
                        }

                        @Override
                        public void onDeny(String[] deniedPermissions, String[] neverAskPermissions) {
                            new AlertDialog.Builder(itemView.getContext()).setTitle("提示").setMessage("请权限定位权限").setNegativeButton("取消", null)
                                    .setPositiveButton("去设置", (dialog, which) -> {
                                        itemView.getContext().startActivity(PermissionManager.getSettingIntent(itemView.getContext()));
                                    }).create().show();
                        }
                    }, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
//
                }
            });
        }
    }
}
