package com.dimeno.dimenoquestion.widget;

import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.dimenoquestion.R;
import com.sdg.dialoglibrary.pop.BasePop;

public class ChangePswPop extends BasePop {

    //标题
    private TextView tv_title;
    //内容
    private TextView tv_message;
    //确定按钮
    private TextView tv_yes;
    //回调
    private Callback callback;
    private String title;
    private String message;
    private String yes = "确定";
    private float width = 9/10f;
    //默认false，点击返回键不消失
    private boolean backDismiss = false;

    /**
     * 构造器
     * @param context
     */
    public ChangePswPop(AppCompatActivity context) {
        super(context,true,true);
    }

    /**
     * 设置布局
     * @return
     */
    @Override
    public int getLayoutRes() {
        return R.layout.dialog_psw_tip;
    }

    /**
     * init
     * @param view
     */
    @Override
    public void init(View view) {
        tv_title = view.findViewById(R.id.tv_title);
        tv_message = view.findViewById(R.id.tv_message);
        tv_yes = view.findViewById(R.id.tv_yes);
        //确定按钮监听
        tv_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callback.yes();
            }
        });

        setKeyDownDismiss(backDismiss);
    }

    /**
     * 设置监听器
     * @param callback
     * @return
     */
    public ChangePswPop setCallback(Callback callback) {
        this.callback = callback;
        return this;
    }

    /**
     * 设置标题
     * @param title
     * @return
     */
    public ChangePswPop setTitle(String title) {
        this.title = title;
        tv_title.setText(title);
        return this;
    }

    /**
     * 设置内容
     * @param message
     * @return
     */
    public ChangePswPop setMessage(String message) {
        this.message = message;
        tv_message.setText(message);
        return this;
    }

    /**
     * setBackDismiss
     * @param backDismiss
     * @return
     */
    public ChangePswPop setBackDismiss(boolean backDismiss) {
        this.backDismiss = backDismiss;
        return this;
    }

    /**
     * 按钮设置标题
     * @param yes
     * @return
     */
    public ChangePswPop setYes(String yes) {
        this.yes = yes;
        tv_yes.setText(yes);
        return this;
    }

    /**
     * setWidth
     * @param width
     * @return
     */
    public ChangePswPop setWidth(float width) {
        this.width = width;
        return this;
    }

    /**
     * Callback
     */
    public interface Callback {
        void yes();
    }

}
