package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :没有适配改题型
 */
public class NothingHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     */
    public NothingHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener) {
        super(parent, R.layout.item_noting);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            tvTitle.setText((StringUtils.isEmpty(mData.getAttr().getTitle()) ?
                    (StringUtils.isEmpty(mData.getAttr().getLeftText()) ?
                            "" : mData.getAttr().getLeftText()) : mData.getAttr().getTitle()) + "没有适配该题型");
            tv_remark.setText("没有适配该题型");
        }
    }

}
