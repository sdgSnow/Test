package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface HelpCenterView extends BaseView {
    /**
     * 获取token值 成功回调
     * @param ossInfoEntity
     * @param filepath
     */
    void success(OssInfoEntity ossInfoEntity, String filepath);
    /**
     * 成功回调
     * @param messageEntityList
     */
    void onSucess(ArrayList<MessageEntity> messageEntityList);

    /**
     * 失败回调
     * @param msg
     */
    void onFail(String msg);
}
