package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.AboutUsBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.HttpConstant;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import java.util.Map;
import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.ApiConstant.loginUser;
import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;
import static com.dimeno.dimenoquestion.constant.OperationType.API;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class LoginPresenter extends BasePresenter<LoginView> {
    /**
     * 登录
     * @param context
     * @param params
     */
    public void Login(Context context,Map<String, String> params){
        Observable<Res<UserEntity>> observable= RetrofitManager.getInstance().getAppService()
                .loginUser(RetrofitManager.getInstance().getCacheControl(),params);
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<UserEntity>() {
            @Override
            protected void onHandleSuccess(Res<UserEntity> userEntity) {
                if (userEntity.Flag == 0) {
                    //接口成功
                    //防止activity销毁
                    if(getMvpView()!=null) {
                        //成功回调
                        getMvpView().LoginSucess(userEntity.ResultObj);
                    }
                } else {
                    //防止activity销毁
                    if(getMvpView()!=null) {
                        //失败回调
                        getMvpView().LoginFail(userEntity.Msg);
                    }

                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //添加日志
                LogUtils.addLog(loginUser,API,"",0l,"登录",JsonUtil.toJson(params));
                //防止activity销毁
                if(getMvpView()!=null) {
                    //失败回调
                    getMvpView().LoginFail(error);
                }
            }
        });
    }

}
