package com.dimeno.dimenoquestion.ui.actvity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.FileUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.MineBean;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.QueBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.adpter.DirectAdapter;
import com.dimeno.dimenoquestion.ui.adpter.HelpCenterAdapter;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.presenter.NewQuesPresenter;
import com.dimeno.dimenoquestion.ui.view.NewQuesView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.scwang.smartrefresh.layout.constant.RefreshState;

import org.litepal.LitePal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.dimeno.dimenoquestion.constant.Constant.ANNEX_PATH;


/**
 * Create by   :PNJ
 * Date        :2021/4/26
 * Description :文件直传
 */
public class DirectActivity extends BaseActivity {
    private RecyclerView recyclerView;
    private String queList;
    //adapter
    private DirectAdapter directAdapter;
    //list
    private List<NewQuesBean> list = new ArrayList<>();
    private int type;

    /**
     * 布局文件
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_direct;
    }

    /**
     * Toolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"选择问卷");
    }

    /**
     * 初始化数据
     * @param
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        type = getIntent().getIntExtra("type",0);

        recyclerView=findViewById(R.id.recycler);
        //设置方向
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));
        //offset 忽略前面的个数
        queList= SpUtil.get().getQueList();
        //判空
        if(!StringUtils.isEmpty(queList)){
            list=  JsonUtil.jsonToArrayList(queList, NewQuesBean.class);
        }
        //根据创建时间排序
        Collections.sort(list, new Comparator<NewQuesBean>() {
            @Override
            public int compare(NewQuesBean bean1, NewQuesBean bean2) {
                return bean2.getCreateDate().compareTo(bean1.getCreateDate());
            }
        });
        //初始化adapter
        directAdapter = new DirectAdapter(list,this);
    }

    @Override
    protected void initViews() {
        //directAdapter的点击事件
        directAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                //判空
                if(list!=null && list.size()>position) {
                    //获取实体
                    NewQuesBean quesBean = list.get(position);
                    Intent intent = new Intent();
                    if(type == ConstantType.HelpType.DIARY_TYPE){
                        intent.setClass(DirectActivity.this, DiaryDbActivity.class);
                        //携带参数
                        intent.putExtra("newQuesBean", (Serializable) quesBean);
                    }else {
                        intent.setClass(DirectActivity.this, DealExceptionQueActivity.class);
                        //携带参数
                        intent.putExtra("newQuesBean", (Serializable) quesBean);
                    }
                    //跳转
                    startActivity(intent);
                }
            }
        });
        //设置adapter
        recyclerView.setAdapter(directAdapter);
    }

    /**
     * createPresenter
     * @return
     */
    @Override
    protected NewQuesPresenter createPresenter() {
        return new NewQuesPresenter();
    }

    @Override
    public void initListeners() {

    }


}
