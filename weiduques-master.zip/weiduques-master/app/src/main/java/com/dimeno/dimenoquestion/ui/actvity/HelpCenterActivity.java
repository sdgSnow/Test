package com.dimeno.dimenoquestion.ui.actvity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.bigkoo.alertview.AlertView;
import com.blankj.utilcode.util.FileUtils;
import com.blankj.utilcode.util.ZipUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dimeno.common.base.BaseApplication;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.commons.utils.T;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.ExceptionLog;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.MineBean;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.adpter.HelpCenterAdapter;
import com.dimeno.dimenoquestion.ui.presenter.HelpCenterPresenter;
import com.dimeno.dimenoquestion.ui.view.HelpCenterView;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.OSSManager;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.dimeno.dimenoquestion.widget.CircleProgressDialog;
import com.dimeno.threadlib.ExecutorHandler;
import com.socks.library.KLog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.Constant.WDQUES_CACHE_PATH;
import static com.dimeno.dimenoquestion.constant.Constant.WDQUES_STORAGE_PATH;


/**
 * Create by   :PNJ
 * Date        :2021/4/26
 * Description :帮助中心
 */
public class HelpCenterActivity extends BaseActivity<HelpCenterPresenter> implements HelpCenterView {
    private RecyclerView recyclerView;
    private List<MineBean> list;
    private CircleProgressDialog mProgressDialog;
    private TextView backupTime;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_help_center;
    }

    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this, "帮助中心");
    }

    /**
     * initThings
     *
     * @param savedInstanceState 缓存数据
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        TextView time = findViewById(R.id.time);
        backupTime = findViewById(R.id.backupTime);
        recyclerView = findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));
        //初始化数据
        list = new ArrayList<>();
        list.add(new MineBean(R.mipmap.iv_diary, "日记上传"));
        list.add(new MineBean(R.mipmap.iv_upfile, "文件直传"));
        list.add(new MineBean(R.mipmap.data, "数据备份"));

        //显示文件夹创建时间和是否最新卸载安装时间
        String installTime = SpUtil.get().getInstallTime();
        String createDirTime = SpUtil.get().getCreateDirTime();
        String curbackupTime = SpUtil.get().getBackupTime();
        time.setText("更新时间：" + installTime + "/" + createDirTime);
        backupTime.setText("备份时间：" + curbackupTime);
    }

    @Override
    protected void initViews() {
        HelpCenterAdapter helpCenterAdapter = new HelpCenterAdapter(list);
        //适配器监听
        helpCenterAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                switch (position) {
                    case 0:
                        //日记上传
                        Intent intent1 = new Intent(HelpCenterActivity.this, DirectActivity.class);
                        intent1.putExtra("type", ConstantType.HelpType.DIARY_TYPE);
                        startActivity(intent1);
//                        gotoActivity(DiaryDbActivity.class);
                        break;
                    case 1:
                        //文件直传
                        Intent intent2 = new Intent(HelpCenterActivity.this, DirectActivity.class);
                        intent2.putExtra("type", ConstantType.HelpType.DEAL_TYPE);
                        startActivity(intent2);
//                        gotoActivity(DirectActivity.class);
                        break;
                    case 2:
                        //数据备份
//                        showUploadDialog();
                        if(!isFinishing()){
                            ProgressHelper.getInstance().show(mActivity, "请稍等...", false);
                        }
                        ExecutorHandler.getInstance().forBackgroundTasks().execute(new Runnable() {
                            @Override
                            public void run() {
                                //拷贝文件
                                boolean copy = FileUtils.copy(WDQUES_CACHE_PATH, WDQUES_STORAGE_PATH);
                                if (copy) {
                                    //拷贝成功
                                    MyToast.showShortToast("备份完成");
                                    if(!isFinishing()) {
                                        ProgressHelper.getInstance().cancel();
                                    }
                                } else {
                                    //拷贝失败
                                    MyToast.showShortToast("备份失败");
                                    if(!isFinishing()) {
                                        ProgressHelper.getInstance().cancel();
                                    }
                                }
                            }
                        });

                        break;
                }
            }
        });
        recyclerView.setAdapter(helpCenterAdapter);

    }

    @Override
    protected HelpCenterPresenter createPresenter() {
        return new HelpCenterPresenter();
    }

    @Override
    public void initListeners() {

    }

    private AlertView alertView;
    private void showUploadDialog() {
        if (alertView == null) {
            alertView = new AlertView("上传", "确定上传吗，该功能耗时较长，上传中无法操作APP其他功能", "取消", new String[]{"确定"}, null, mContext, AlertView.Style.Alert, (o, position) -> {
                if (o == alertView && position == 0) {
                    if (!isFinishing()) {
                        ProgressHelper.getInstance().show(mActivity, "请稍等...", false);
                    }
                    ExecutorHandler.getInstance().forBackgroundTasks().execute(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    //压缩成功否
                                    String zippath = BaseApplication.getContext().getExternalFilesDir("") + "/copy.zip";
                                            boolean isSuccess = ZipUtils.zipFile(WDQUES_CACHE_PATH, zippath);
                                            //activity没有销毁
                                            if (!mActivity.isDestroyed()) {
                                                if (isSuccess) {
                                                    //成功，上次oss
                                                    MyToast.showShortToast("文件压缩成功");
                                                    showCircleProgress();

                                                    presenter.getOssInfo(mActivity,zippath);
                                                } else {
                                                    //失败，提示
                                                    MyToast.showShortToast("文件压缩失败");
                                                }
                                                ProgressHelper.getInstance().cancel();
                                            }
                                } catch (IOException e) {
//                                } catch (Exception e) {
                                    //activity没有销毁
                                    if (!mActivity.isDestroyed()) {
                                        //失败，提示
                                        ProgressHelper.getInstance().cancel();
                                        MyToast.showLongToast("文件上传失败：" + e.getMessage());
                                    }
                                    e.printStackTrace();
                                }
                            }
                    });
                }
            });
        }
        alertView.show();
    }

    @Override
    public void success(OssInfoEntity ossInfoEntity, String filepath) {
        OSSManager.get()
                .setContext(mContext)
                .accessKeyId(ossInfoEntity.AccessKeyId)
                .accessKeySecret(ossInfoEntity.AccessKeySecret)
                .securityToken(ossInfoEntity.SecurityToken)
                .endPoint(ossInfoEntity.endpoint)
                .bucket(ossInfoEntity.BucketName)
                .directory(ossInfoEntity.Directory)
                .queId("backupfile")
//                .file(filepath)
                .callback(new OSSManager.Callback() {
                    @Override
                    public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                        String progress = MyUtils.getProgress(currentSize, totalSize);
//                        ProgressHelper.getInstance().setTitle("已上传" + progress + "%");
//                        MyLog.i("currentSize:" + currentSize + ",totalSize:" + totalSize + ",progress:" + progress);
//                        setCircleProgress(progress);
                        if(currentSize > 0 && totalSize > 0){
                            int percent = (int) ((100 * currentSize) / totalSize);
                            MyLog.i("percent" + percent);
                            setCircleProgress(percent);
                        }
                    }

                    @Override
                    public void onSuccess(String ossPath) {
                        MyToast.showShortToast("上传成功");
                        KLog.i("上传成功");
                        String currentTime = TimeUtil.getCurrentTime();
                        backupTime.setText("备份时间：" + currentTime);
                        SpUtil.get().setBackupTime(currentTime);
                        dismissCircleProgress();
                        ProgressHelper.getInstance().cancel();
                    }

                    @Override
                    public void onFailure(String message) {
                        T.show(message);
                        ProgressHelper.getInstance().cancel();
                    }
                }).upload(0,0,filepath);
    }

    @Override
    public void onSucess(ArrayList<MessageEntity> messageEntityList) {

    }

    @Override
    public void onFail(String msg) {
        ProgressHelper.getInstance().cancel();
        MyToast.showShortToast(msg);
    }
    private void setCircleProgress(int progress) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mProgressDialog == null) {
                    mProgressDialog = new CircleProgressDialog(mContext);
                }
                if (!mProgressDialog.isShowing()) {
                    mProgressDialog.show();
                }
                mProgressDialog.setProgress(progress);
            }
        });
    }

    private void dismissCircleProgress() {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
    }

    private void showCircleProgress() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mProgressDialog == null) {
                    mProgressDialog = new CircleProgressDialog(mContext);
                }
                mProgressDialog.show();
            }
        });
    }
}
