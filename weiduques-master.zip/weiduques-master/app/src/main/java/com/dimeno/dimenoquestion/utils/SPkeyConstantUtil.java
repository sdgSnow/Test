package com.dimeno.dimenoquestion.utils;

public class SPkeyConstantUtil {

    /**
     * 是否登录
     */
    public static final String SLogin = "login";
    /**
     * 第一次进入app
     */
    public static final String SInitialize = "initialize";

    /**
     * SharedPreferences的key
     */
    public static final String SSP_KEY = "configuration";

    /**
     * 讯飞 的SharedPreferences key
     */
    public static final String XUN_FEI = "com.iflytek.setting";
}