package com.dimeno.dimenoquestion.widget;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.db.Answer;

public class RightToolbar extends Toolbar {

    private String mTitle;
    private boolean isShowIcon;

    /**
     * 构造器
     * @param activity
     * @param title
     * @param isShowIcon 是否显示图标
     */
    public RightToolbar(Activity activity, String title,boolean isShowIcon) {
        super(activity);
        this.mTitle = title;
        this.isShowIcon = isShowIcon;
    }

    /**
     * 设置布局文件
     * @return
     */
    @Override
    public int layoutRes() {
        return R.layout.toolbar_right;
    }

    @Override
    public void onViewCreated( View view) {
        TextView title = view.findViewById(R.id.title);
        ImageView icon = view.findViewById(R.id.icon);
        title.setText(mTitle);
        icon.setVisibility(isShowIcon ? View.VISIBLE : View.GONE);
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rightClick != null){
                    rightClick.onClick();
                }
            }
        });
    }

    /**
     * 设置标题
     * @param mTitle
     */
    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public interface RightClick {
        void onClick();
    }

    public void setRightClick(RightClick rightClick) {
        this.rightClick = rightClick;
    }

    private RightClick rightClick;

}
