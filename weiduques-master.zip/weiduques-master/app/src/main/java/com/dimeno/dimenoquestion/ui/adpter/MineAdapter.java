package com.dimeno.dimenoquestion.ui.adpter;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.dimenoquestion.bean.MineBean;
import com.dimeno.dimenoquestion.ui.adpter.holder.MineViewHolder;

import java.util.List;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class MineAdapter extends RecyclerAdapter<MineBean> {

    public MineAdapter(List list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new MineViewHolder(parent);
    }
}
