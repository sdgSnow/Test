package com.dimeno.dimenoquestion.bean;

/**
 * OssParams
 * Created by wangzhen on 2020/5/17.
 */
public class OssParams {
    //0 录音 1图片
    public int type;
    //文件类型 .mp3
    public String fileType;
    //ossPath
    public String ossPath;
    //本地路径
    public String localPath;
    //题目id
    public int subId;
}
