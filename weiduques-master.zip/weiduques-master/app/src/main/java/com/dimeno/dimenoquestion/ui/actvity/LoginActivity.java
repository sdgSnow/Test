package com.dimeno.dimenoquestion.ui.actvity;


import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.ui.presenter.LoginPresenter;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;

/**
 * Create by   :PNJ
 * Date        :2021/3/15
 * Description :
 */
public class LoginActivity extends BaseActivity<LoginPresenter> implements LoginView {
    @BindView(R.id.et_username)
    EditText et_username;
    @BindView(R.id.et_password)
    EditText et_password;
    @BindView(R.id.btnSubmit)
    Button btnSubmit;
    @BindView(R.id.showPsw)
    ImageView showPsw;

    private boolean isShow = true;

    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
        fitDarkStatusBar(true);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    protected void initViews() {

    }

    /**
     * initListeners
     * 设置监听器
     */
    @Override
    public void initListeners() {
        showPsw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(et_password.getText().toString().trim())) {
                    MyToast.showShortToast("请先输入密码");
                } else {
                    if (isShow) {
                        //显示密码
                        et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    } else {
                        //隐藏密码
                        et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    }
                    //光标显示在文本末尾处
                    et_password.setSelection(et_password.getText().length());
                    //将标记制反
                    isShow = !isShow;
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account =et_username.getText().toString().trim();
                String pwd = et_password.getText().toString().trim();
                //判断账号为空
                if (TextUtils.isEmpty(account)) {
                    ToastUtils.showShort("请输入账号");
                    return;
                }
                //判断密码为空
                if (TextUtils.isEmpty(pwd)) {
                    ToastUtils.showShort("请输入密码");
                    return;
                }
                //判断密码规则
                if (pwd.length()<6 || pwd.length()>16) {
                    ToastUtils.showShort("密码必须是6-16位的数字、字符");
                    return;
                }
                HashMap<String, String> params = new HashMap<>();
                params.put("ProCode", PRO_CODE);
                params.put("Account", account);
                params.put("Pwd", pwd);
                presenter.Login(LoginActivity.this,params);
            }
        });

    }

    @Override
    protected LoginPresenter createPresenter() {
        return new LoginPresenter();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void LoginSucess(UserEntity userEntity) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //保存用户id
                UserUtil.setUserId(userEntity.getID());
                //保存用户名称
                UserUtil.setUserName(userEntity.getTrueName());
                //保存用户账号
                UserUtil.setAccount(userEntity.getAccount());
                //保存用户登录时间
                UserUtil.setLoginTime(TimeUtil.getCurrentTimeMillis());
                //保存用户密码
                UserUtil.setUserPwd(et_password.getText().toString());
                UserUtil.setIsLogin(true);
                UserUtil.setUploadWay(userEntity.getUploadWay());
                MyToast.showShortToast("登录成功");
                gotoActivity(MainActivity.class,true);
            }
        });
    }

    @Override
    public void LoginFail(String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                MyToast.showShortToast(msg);
            }
        });

    }
}