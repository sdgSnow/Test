package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import static com.dimeno.dimenoquestion.constant.ConstantUtil.DROPDOWN_DEFAULT_VALUE;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.ui.adpter.SpinnerAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.TextViewUtil;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :3 下拉题
 */
public class DropDownHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private Spinner spinner;
    private FrameLayout frame_error;
    private SpinnerAdapter spinnerAdapter;
    private LinearLayout ll_home;
    private SpannableStringBuilder title;
    private List<QueOptionBean> list =new ArrayList<>();
    private Map<Integer,SpinnerAdapter> map=new HashMap<>();
    private QueAdapter.OnChildClickLisener onChildClickLisener;
    private List<PageSubjectBean> subjecList=new ArrayList<>();
    private QueOptionBean queOptionBean;
    //add新添加，edit编辑，look查看
    private String type;
    private boolean isShow;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     * @param subjecList
     */
    public DropDownHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type,List<PageSubjectBean> subjecList) {
        super(parent, R.layout.item_drop_down);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        spinner = findViewById(R.id.spinner_drop_down);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);

        queOptionBean = new QueOptionBean();
        queOptionBean.setSort(0);
        queOptionBean.setOpText(TextViewUtil.getString(R.string.please_select));
        queOptionBean.setMust(false);
        queOptionBean.setFill(false);
        queOptionBean.setOpCode(DROPDOWN_DEFAULT_VALUE);
        this.type=type;
        this.subjecList=subjecList;
        this.onChildClickLisener=onChildClickLisener;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null){
            title=StringUtils.getTitle(mData.getAttr().getTitle(),mData.getAttr().isMust());
            tvTitle.setText(title==null?"":title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk())?"":mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
        }
        if(mData.isError()){
            frame_error.setVisibility(View.VISIBLE);
        }else {
            frame_error.setVisibility(View.GONE);
        }
        Log.d("adpterFlush","下拉题 flush position="+getAdapterPosition());

        list.clear();
        list.add(queOptionBean);
        if(mData.getQueOption()!=null){
            if(mData.getQueOption().size()>1) {
                Collections.sort(mData.getQueOption(), new Comparator<QueOptionBean>() {
                    @Override
                    public int compare(QueOptionBean o1, QueOptionBean o2) {
                        return o1.getSort() - o2.getSort();
                    }
                });
            }
            list.addAll(mData.getQueOption());
        }

        //判空，防止再次刷新时，状态重置
        if(map.get(getAdapterPosition())==null){
            spinnerAdapter=new SpinnerAdapter(itemView.getContext(),list);
            if(mData.getSurveyAnswer().OptionList==null) {
                mData.getSurveyAnswer().OptionList = new LinkedHashSet();
            }
            spinner.setAdapter(spinnerAdapter);
            map.put(getAdapterPosition(),spinnerAdapter);
        }else {
            spinnerAdapter=map.get(getAdapterPosition());
            spinner.setAdapter(spinnerAdapter);
        }

        for (int i = 0; i < list.size(); i++) {
            String opCode = list.get(i).getOpCode();
            if(mData.getSurveyAnswer().OptionList!=null) {
                if (mData.getSurveyAnswer().OptionList.contains(opCode)) {
                    spinner.setSelection(i, true);
                    break;
                }
            }
        }
        if(type.equals("look")) {
            spinner.setEnabled(false);
        }else {
            spinner.setEnabled(true);
        }
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(list.size()>position) {
                    if (mData.getSurveyAnswer().OptionList != null) {
                        mData.getSurveyAnswer().OptionList.clear();
                        mData.getSurveyAnswer().OptionList.add(list.get(position).getOpCode());
                    }

                    if(StringUtils.isEmpty( mData.getSurveyAnswer().dropDownOpCode)){
                        mData.getSurveyAnswer().dropDownOpCode="";
                    }

                    //防止每次刷新adpter，都到这里，把其他题目和这道下拉题一起管理的隐藏题的显示隐藏都由该题决定
                    if( !mData.getSurveyAnswer().dropDownOpCode.equals(list.get(position).getOpCode())) {
                        mData.getSurveyAnswer().dropDownOpCode=list.get(position).getOpCode();
                        //获取关联的题目在列表所在的位置position
                        Map<String, List<Integer>> mapPs = mData.getHidePosition();
                        //0的时候是“请选择”
                        if (position >= 1) {
                            //如果是结束位
                            if (list.get(position).isEnd()) {
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.onChildEndClick(itemView, getAdapterPosition() - 1);
                                }
                            } else {
                                if (mData.isError()) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                                if (mapPs != null && mapPs.size() != 0) {
                                    //如果选择，则遍历显示题目
                                    if (mapPs.get(list.get(position).getOpCode()) != null && mapPs.get(list.get(position).getOpCode()).size() != 0) {
                                        List<Integer> listValue = mapPs.get(list.get(position).getOpCode());
//                                        //下拉题隐藏切换其他选项的隐藏题目问题 start
//                                        for (int j = 0; j < list.size();j++) {
//                                            if(position != j){
//                                                for (List<Integer> list : mapPs.values()) {
//                                                    if (list != null && list.size() != 0) {
//                                                        for (int i = 0; i < list.size(); i++) {
//                                                            if (subjecList.size() > list.get(i)) {
//                                                                if (subjecList.get(list.get(i)).getIsHide() != ConstantType.queHide.GONE) {
//                                                                    isShow = true;
//                                                                }
//                                                                //隐藏
//                                                                subjecList.get(list.get(i)).setIsHide(ConstantType.queHide.GONE);//隐藏
////                                                subjecList.get(list.get(i)).getSurveyAnswer().logicShow = 2;
//                                                                subjecList.get(list.get(i)).getSurveyAnswer().logicShow = ConstantUtil.GONE;
//                                                            }
//                                                        }
//                                                    }
//                                                }
//                                            }
//                                        }
//                                        //下拉题隐藏切换其他选项的隐藏题目问题 end
                                        for (int i = 0; i < listValue.size(); i++) {
                                            if (subjecList.size() > listValue.get(i)) {
                                                //选择了，则显示
                                                if (subjecList.get(listValue.get(i)).getIsHide() != ConstantType.queHide.VISIBLE) {
                                                    subjecList.get(listValue.get(i)).setIsHide(ConstantType.queHide.VISIBLE);//显示
                                                    if (subjecList.get(listValue.get(i)).getSurveyAnswer() != null) {
//                                                subjecList.get(listValue.get(i)).getSurveyAnswer().logicShow = 0;
                                                        subjecList.get(listValue.get(i)).getSurveyAnswer().logicShow = ConstantUtil.VISIBLE;
                                                    }
                                                    if (onChildClickLisener != null) {
                                                        onChildClickLisener.onChildClick(itemView, getAdapterPosition());
                                                    }
                                                }
                                            }
                                        }

                                    } else {
                                        isShow = false;
                                        //如果取消选择，则遍历隐藏题目

                                        for (List<Integer> list : mapPs.values()) {
                                            if (list != null && list.size() != 0) {
                                                for (int i = 0; i < list.size(); i++) {
                                                    if (subjecList.size() > list.get(i)) {
                                                        if (subjecList.get(list.get(i)).getIsHide() != ConstantType.queHide.GONE) {
                                                            isShow = true;
                                                        }
                                                        //隐藏
                                                        subjecList.get(list.get(i)).setIsHide(ConstantType.queHide.GONE);//隐藏
//                                                subjecList.get(list.get(i)).getSurveyAnswer().logicShow = 2;
                                                        subjecList.get(list.get(i)).getSurveyAnswer().logicShow = ConstantUtil.GONE;
                                                    }
                                                }
                                            }
                                        }
                                        if (onChildClickLisener != null && isShow) {
                                            onChildClickLisener.onChildClick(itemView, getAdapterPosition());
                                        }
                                    }
                                }
                            }
                        } else {
                            isShow = false;
                            //如果取消选择，则遍历隐藏题目
                            if (mapPs != null && mapPs.size() != 0) {
                                for (List<Integer> listValue : mapPs.values()) {
                                    if (listValue != null && listValue.size() != 0) {
                                        for (int i = 0; i < listValue.size(); i++) {
                                            if (subjecList.size() > listValue.get(i)) {
                                                if (subjecList.get(listValue.get(i)).getIsHide() != ConstantType.queHide.GONE) {
                                                    isShow = true;
                                                }
                                                //隐藏
                                                subjecList.get(listValue.get(i)).setIsHide(ConstantType.queHide.GONE);//隐藏
//                                    subjecList.get(listValue.get(i)).getSurveyAnswer().logicShow = 2;
                                                subjecList.get(listValue.get(i)).getSurveyAnswer().logicShow = ConstantUtil.GONE;
                                            }
                                        }
                                    }
                                }
                            }
                            if (onChildClickLisener != null && isShow) {
                                onChildClickLisener.onChildClick(itemView, getAdapterPosition());
                            }
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }



}
