package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;
import com.socks.library.KLog;
import com.warkiz.widget.IndicatorSeekBar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :10 量表题
 */
public class GaugeHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final IndicatorSeekBar seekBar;
    private final TextView tv_left_text;
    private final TextView tv_right_text;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public GaugeHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_gauge);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        seekBar = findViewById(R.id.seekBar);
        tv_left_text = findViewById(R.id.tv_left_text);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            tv_left_text.setText(StringUtils.isEmpty(mData.getAttr().getLeftText()) ? "" : mData.getAttr().getLeftText());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            //初始化答案
            if (mData.getSurveyAnswer().matrixAnswers == null) {
                ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers = new ArrayList<>();
                mData.getSurveyAnswer().matrixAnswers = matrixAnswers;
            }

            if (mData.getSurveyAnswer().matrixAnswers != null && mData.getSurveyAnswer().matrixAnswers.size() == 0) {
                SurveyAnswer.MatrixAnswer answer = new SurveyAnswer.MatrixAnswer();
                answer.opCodes = new HashSet<>();
                mData.getSurveyAnswer().matrixAnswers.add(answer);
            }

            if (mData.getSurveyAnswer().matrixAnswers.size() != 0 && mData.getSurveyAnswer().matrixAnswers.get(0).opCodes == null) {
                mData.getSurveyAnswer().matrixAnswers.get(0).opCodes = new HashSet<>();
            }

            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            SurveyAnswer.MatrixAnswer matrixAnswer = mData.getSurveyAnswer().matrixAnswers.get(0);
            int progress = 0;
            for (String opCode : matrixAnswer.opCodes) {
                try {
                    progress = Integer.parseInt(opCode);
                } catch (NumberFormatException ignore) {

                }
            }
            Log.d("progress", "progress=" + progress);
            seekBar.getBuilder().setMax(mData.getAttr().getScaleRange()).setTickNum(mData.getAttr().getScaleRange()).setMin(1).setProgress(progress).setDrawAgain(false).apply();

            // 禁用 seekBar
            if (type.equals("look")) {
                seekBar.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        return true;
                    }
                });
            }

            seekBar.setOnSeekChangeListener(new IndicatorSeekBar.OnSeekBarChangeListener() {

                @Override
                public void onProgressChanged(IndicatorSeekBar seekBar, int progress,
                                              float progressFloat, boolean fromUserTouch) {
                    KLog.e("progress: " + progress);
                    if(mData.getSurveyAnswer().matrixAnswers!=null && mData.getSurveyAnswer().matrixAnswers.size()>0
                            && mData.getSurveyAnswer().matrixAnswers.get(0).opCodes!=null){
                        mData.getSurveyAnswer().matrixAnswers.get(0).opCodes.clear();
                        mData.getSurveyAnswer().matrixAnswers.get(0).opCodes.add(String.valueOf(progress));
                    }
                    if (progress != 0) {
                        if (mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }
                }

                @Override
                public void onSectionChanged(IndicatorSeekBar seekBar, int thumbPosOnTick,
                                             String tickBelowText, boolean fromUserTouch) {
                    KLog.e("thumbPosOnTick=" + thumbPosOnTick + ";tickBelowText=" + tickBelowText);
                }

                @Override
                public void onStartTrackingTouch(IndicatorSeekBar seekBar, int thumbPosOnTick) {
                }

                @Override
                public void onStopTrackingTouch(IndicatorSeekBar seekBar) {

                }
            });
        }
    }


}
