package com.dimeno.dimenoquestion.db;

import org.litepal.crud.LitePalSupport;

public class Record extends LitePalSupport {

    //问卷id
    public String que_id;
    //录音id
    public String record_id;
    //问卷题目名称
    public String que_title;
    //用户id
    public String user_id;
    //用户名
    public String user_name;
    //创建时间
    public String create_time;
    //录音本地存储路径
    public String filepath;
    //录音oss上传路径
    public String oss_path;

}
