package com.dimeno.dimenoquestion.mode;

/**
 * DateCharFormat
 * Created by wangzhen on 2020/8/12.
 */
public class DateCharFormat {
    // yyyy年MM月dd日 HH时mm分ss秒
    public static final int ymd_hms = 1;
    // yyyy年MM月dd日
    public static final int ymd = 2;
    // yyyy年MM月
    public static final int ym = 3;
    // HH时mm分
    public static final int hm = 4;
    // HH时mm分ss秒
    public static final int hms = 5;
}
