package com.dimeno.dimenoquestion.bean;

import java.io.Serializable;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :选项
 */
public class QueOptionBean implements Serializable {
    private String CascadeID;
    private String FillText;
    private String FillContent;
    private boolean IsFill;
    private boolean IsMust;
    private String OpCode;
    private String OpText;
    private String OptionID;
    private String QueID;
    private String SearchText;
    private int Sort;
    private int SubID;
    private boolean isEnd;//是否是结束位


    public String getFillContent() {
        return FillContent;
    }

    public void setFillContent(String fillContent) {
        FillContent = fillContent;
    }

    public boolean isEnd() {
        return isEnd;
    }

    public void setEnd(boolean end) {
        isEnd = end;
    }
    public String getCascadeID() {
        return CascadeID;
    }

    public void setCascadeID(String cascadeID) {
        CascadeID = cascadeID;
    }

    public String getFillText() {
        return FillText;
    }

    public void setFillText(String fillText) {
        FillText = fillText;
    }

    public boolean isFill() {
        return IsFill;
    }

    public void setFill(boolean fill) {
        IsFill = fill;
    }

    public boolean isMust() {
        return IsMust;
    }

    public void setMust(boolean must) {
        IsMust = must;
    }

    public String getOpCode() {
        return OpCode;
    }

    public void setOpCode(String opCode) {
        OpCode = opCode;
    }

    public String getOpText() {
        return OpText;
    }

    public void setOpText(String opText) {
        OpText = opText;
    }

    public String getOptionID() {
        return OptionID;
    }

    public void setOptionID(String optionID) {
        OptionID = optionID;
    }

    public String getQueID() {
        return QueID;
    }

    public void setQueID(String queID) {
        QueID = queID;
    }

    public String getSearchText() {
        return SearchText;
    }

    public void setSearchText(String searchText) {
        SearchText = searchText;
    }

    public int getSort() {
        return Sort;
    }

    public void setSort(int sort) {
        Sort = sort;
    }

    public int getSubID() {
        return SubID;
    }

    public void setSubID(int subID) {
        SubID = subID;
    }
}
