package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import com.czt.mp3recorder.Log;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.db.Que;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.NewQuesView;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.threadlib.ExecutorHandler;

import org.litepal.LitePal;
import org.litepal.crud.LitePalSupport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import io.reactivex.Observable;
import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class NewQuesPresenter extends BasePresenter<NewQuesView> {
    private ArrayList<NewQuesBean> quesList=new ArrayList<>();
    private int page=1;
    private int size=20;

    /**
     * 获取问卷列表
     * @param context
     */
    public void loadQuesList(Context context){
        HashMap<String, String> params = new HashMap<>();
        params.put("ProCode", PRO_CODE);
        params.put("UserID", UserUtil.getUserId());

        Observable<Res<ArrayList<NewQuesBean>>> observable= RetrofitManager.getInstance().getAppService()
                .loadQuesList(RetrofitManager.getInstance().getCacheControl(),params);
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<ArrayList<NewQuesBean>>() {
            @Override
            protected void onHandleSuccess(Res<ArrayList<NewQuesBean>> res) {
//                ExecutorHandler.getInstance().forBackgroundTasks()
//                        .execute(new Runnable() {
//                            @Override
//                            public void run() {
                //判空
                if(res == null || res.ResultObj == null)return;
                //如果有分页，分页为1的情况下，清空数据库
                if (page == 1) {
                    quesList.clear();
                    //清空数据库
                   int i= LitePal.deleteAll(Que.class);
                }
                //添加数据到queslist中
                quesList.addAll(res.ResultObj);
                //重新保存数据到数据库中,使用克隆的模式，以防queslist改变，saveQue中的循环崩溃
                saveQue((ArrayList<NewQuesBean>) quesList.clone());
                SpUtil.get().setQueLst(JsonUtil.toJson(quesList));
                //获取的数据小于20个，则没有分页了
                if (res.ResultObj.size() < size) { 
                    if(getMvpView()!=null) {
                        getMvpView().initQuesList(false, quesList);
                    }
                } else {
                    //数据等于20，则可能还有分页
                    if(getMvpView()!=null) {
                        getMvpView().initQuesList(true, quesList);
                    }
                }
//                            }
//                        });
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                if(getMvpView()!=null) {
                    getMvpView().loadFailure(false, error);
                }
            }
        });
    }

    public void saveQue(ArrayList<NewQuesBean> quesBeanList){
        if(quesBeanList != null && quesBeanList.size() > 1){
            for (NewQuesBean newQuesBean : quesBeanList) {
                Que que = new Que();
                que.setQueId(newQuesBean.getID());
                que.setUserID(UserUtil.getUserId());
                que.setQueBean(JsonUtil.toJson(newQuesBean));
                que.saveOrUpdate("queId = ?", newQuesBean.getID());
            }
        }
    }
}
