package com.dimeno.dimenoquestion.bean;


import androidx.annotation.Nullable;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class Res<T> {
    /**
     * 状态吗
     */
    public int code;

    /**
     * 状态吗
     */
    public int Flag;

    /**
     * 数据
     */
    @Nullable
    public T ResultObj;

    /**
     * 数据总条数
     */
    @Nullable
    public int recordcount = 0;
    /**
     * 信息msg
     */
    public String Msg;

}