package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.NewQuesBean;

import java.util.ArrayList;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface NewQuesView extends BaseView {
    /**
     * 失败回调
     * @param
     */
    void loadFailure(boolean sucess,String message);

    /**
     * 成功回调
     * @param loadMore
     * @param quesBeanList
     */
    void initQuesList(boolean loadMore,ArrayList<NewQuesBean> quesBeanList);
}
