package com.dimeno.dimenoquestion.ui.actvity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.pop.AlertListPopup;
import com.dimeno.dimenoquestion.pop.AlertPopup;
import com.dimeno.dimenoquestion.ui.presenter.AnswerListPresenter;
import com.dimeno.dimenoquestion.ui.presenter.DiaryUpPresenter;
import com.dimeno.dimenoquestion.ui.view.AnswerListView;
import com.dimeno.dimenoquestion.ui.view.DiaryUpView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.OSSManager;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.dimeno.threadlib.ExecutorHandler;
import com.sdg.dialoglibrary.pop.PopManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :日记上传，日志保存在文件中
 */
public class DiaryUpActivity extends  BaseActivity<DiaryUpPresenter> implements DiaryUpView {
    private TextView tv_upfile;
    private List<String> files=new ArrayList<>();
    //当前上传文件的position
    private int current =0;
    //要上传的文件总数
    private int uploadCount=0;
    //已上传的文件总数
    private int sucessuploadCount=0;
    @Override
    protected int getLayoutId() {
        return R.layout.activity_diary_up;
    }
    @Override
    protected void initThings(Bundle savedInstanceState) {
        tv_upfile=findViewById(R.id.tv_upfile);
    }

    /**
     * Toolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"日记上传");
    }

    @Override
    protected void initViews() {
    }
    /**
     * Presenter
     * @return
     */
    @Override
    protected DiaryUpPresenter createPresenter() {
        return new DiaryUpPresenter();
    }

    @Override
    public void initListeners() {
        //文件直传点击事件
        tv_upfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ProgressHelper.getInstance().show(DiaryUpActivity.this,"请稍等...",false);
                ExecutorHandler.getInstance().forBackgroundTasks()
                        .execute(new Runnable() {
                            @Override
                            public void run() {
                                //集合不为空，清空
                                if (files != null) {
                                    files.clear();
                                }
                                //获取集合
                                files = LogUtils.getFile();
                                //集合判空
                                if (files != null && files.size() > 0) {
                                    //显示列表
                                    showQuitDialog(files);
                                }else {
                                    //集合为空，土司
                                    MyToast.showLongToast("暂无日记上传");
                                }
                            }
                        });
            }
        });
    }

    /**
     * 上传oss
     */
    public void getOssInfo(){
        //集合判空
        if(files!=null && files.size()>0) {
            //判断当前上传的文件数是否小于文件总数
            if (current<files.size()){
                //小于。判空
                if(!StringUtils.isEmpty(files.get(current)) && FileUtils.fileExist(LogUtils.MYLOG_PATH+"/"+files.get(current))){
                    //调oss
                    presenter.getOssInfo(this,LogUtils.MYLOG_PATH+"/"+files.get(current));
                }else {
                    //大于
                    //上传的文件数加一
                    current++;
                    //成功数加一
                    sucessuploadCount++;
                    //继续
                    getOssInfo();
                }
            }else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //上传成功数等于总数
                        if(sucessuploadCount==uploadCount) {
                            //设置百分比
                            PopManager.get().setProgress(100);
                            //土司
                            MyToast.showShortToast("日记上传成功");
                            //隐藏进度
                            PopManager.get().hideProgress();
                            tv_upfile.setEnabled(false);
                            tv_upfile.setClickable(false);
                            tv_upfile.setBackgroundResource(R.drawable.bg_bule_c999_radius2);
                        }
                    }
                });
            }
        }
    }


    @Override
    public void success(OssInfoEntity ossInfoEntity, String filepath) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //oss的token成功，开始上传文件
                OSSManager.get()
                        .setContext(MyApplication.getContext())
                        .accessKeyId(ossInfoEntity.AccessKeyId)
                        .accessKeySecret(ossInfoEntity.AccessKeySecret)
                        .securityToken(ossInfoEntity.SecurityToken)
                        .endPoint(ossInfoEntity.endpoint)
                        .bucket(ossInfoEntity.BucketName)
                        .directory(ossInfoEntity.Directory)
//                        .file(filepath)
                        .callback(new OSSManager.Callback() {
                            @Override
                            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                            }

                            @Override
                            public void onSuccess(String ossPath) {
                                LogUtils.e("OSSManager  上传日记","oss sucess path="+filepath+"\n json="+ JsonUtil.toJson(ossInfoEntity));
                               //当前上传数加一
                                current++;
                                //surveyList的uploadSize个item的文件上传完成
                                //小于总数，继续进行上传
                                if(current <files.size()){
                                    getOssInfo();
                                }
                                //成功数加一
                                sucessuploadCount++;
                                //获取进度
                                String progress=  MyUtils.getProgress(sucessuploadCount,uploadCount);

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //显示进度
                                        PopManager.get().setProgress(Integer.parseInt(progress));
                                        //上传成功数等于总数
                                        if(sucessuploadCount==uploadCount){
                                            //土司
                                            MyToast.showShortToast("日记上传完成");
                                            //隐藏进度
                                            PopManager.get().hideProgress();
                                            tv_upfile.setEnabled(false);
                                            tv_upfile.setClickable(false);
                                            tv_upfile.setBackgroundResource(R.drawable.bg_bule_c999_radius2);

                                        }
                                    }
                                });

                            }

                            @Override
                            public void onFailure(String message) {
                                //上传失败
                                MyToast.showLongToast(message);
                                LogUtils.e("OSSManager  上传日记","oss onFailure path="+filepath+"\n message="+ message);
                                //隐藏进度
                                PopManager.get().hideProgress();
                            }
                        }).upload(0,5,filepath);
            }
        });
    }

    @Override
    public void success(UploadEntity entity, Answer answer) {

    }

    /**
     * 展示日志列表
     */
    private AlertListPopup alertPopup;
    private void showQuitDialog(List<String> list) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //初始化pop
                alertPopup = new AlertListPopup(DiaryUpActivity.this, "提示","日志列表", list);
                //pop点击事件
                alertPopup.setonMyItemClickListener(new AlertListPopup.onMyItemClickListener() {
                    @Override
                    public void onItemClick(boolean flag) {
                        if(flag){
                            //确定
                            //当前上传文件的position初始化为0
                            current = 0;
                            //上传成功数为0
                            sucessuploadCount=0;
                            //设置总共上传总数
                            uploadCount=files.size();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //取消loading
                                    ProgressHelper.getInstance().cancel();
                                    //展示进度条
                                    PopManager.get().showProgress(DiaryUpActivity.this);
                                }
                            });
                            //获取oss的token
                            getOssInfo();
                        }
                        //pop不为空，隐藏
                        if(alertPopup!=null && alertPopup.isShowing()){
                            alertPopup.dismiss();
                            alertPopup = null;
                        }
                    }
                });
                //展示
                alertPopup.showAtLocation(tv_upfile, Gravity.CENTER, 0, 0);
            }
        });
    }

}
