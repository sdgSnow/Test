package com.dimeno.dimenoquestion.ui.adpter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.ui.adpter.holder.base.BaseViewHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :矩阵单选
 */
public class MatrixSingleTitleAdapter extends RecyclerView.Adapter<MatrixSingleTitleAdapter.ViewHolder>{
    private List<QueOptionBean> mData=new ArrayList<>();

    public void setData(List<QueOptionBean> mData){
        this.mData=mData;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_matrix_single_title, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(mData.get(position).getOpText());
    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }
    public class ViewHolder extends BaseViewHolder {
        TextView title;
        ViewHolder(View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.tv_matrix_single_title);
        }
    }

    public void setMyOnItemClickListener(SingleChoiceAdapter.MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private SingleChoiceAdapter.MyOnItemClickListener myOnItemClickListener;

    public interface MyOnItemClickListener {
        void onItemClick(int positon, String title);
    }
}
