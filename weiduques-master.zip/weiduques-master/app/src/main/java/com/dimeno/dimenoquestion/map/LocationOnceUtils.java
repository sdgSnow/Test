package com.dimeno.dimenoquestion.map;

import android.content.Context;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.dimeno.common.utils.TimeUtil;
import com.socks.library.KLog;

/**
 * 一次性定位获取定位信息
 * 离线定位只能获取经纬度
 * */
public class LocationOnceUtils {
    private static LocationOnceUtils locationLibraryUtil;

    public static LocationOnceUtils getInstance(){
        if(locationLibraryUtil == null){
            return new LocationOnceUtils();
        }else {
            return locationLibraryUtil;
        }
    }

    private LocationService locationService;
    /**
     * 初始化并开始定位sdk
     * 初始化的场景最好是在activity里面，需要的时候就初始化
     * @param context 上下文
     * */
    public void startLocation(Context context, ILocation iLocation) {
        setLocationInfoInterface(iLocation);
        locationService = new LocationService(context);
        //获取locationservice实例，建议应用中只初始化1个location实例，然后使用，可以参考其他示例的activity，都是通过此种方式获取locationservice实例的
        locationService.registerListener(mListener);
        locationService.setLocationOption(locationService.getDefaultLocationClientOption());
        locationService.start();// 定位SDK
    }

    /**
     * 定位结果回调，重写onReceiveLocation方法，可以直接拷贝如下代码到自己工程中修改
     */
    private BDAbstractLocationListener mListener = new BDAbstractLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation location) {
            KLog.i("test_location", "onReceiveLocation getLocType = " + location.getLocType()); // 505 签名错误
            if (null != location && location.getLocType() != BDLocation.TypeServerError) {
                switch (location.getLocType()) {
                    case BDLocation.TypeGpsLocation:   // GPS定位结果
                    case BDLocation.TypeNetWorkLocation:   // 网络定位结果
                    case BDLocation.TypeOffLineLocation:   // 离线定位结果
                        KLog.i("test_location","经度：" + location.getLongitude() + "，纬度：" + location.getLatitude() + ",地址：" + location.getStreet() + location.getStreetNumber());
                        String address = location.getDistrict() + location.getStreet() + location.getStreetNumber();
                        locationInfoInterface.locationInfo(location.getLongitude() + "",location.getLatitude() + "",address, TimeUtil.getCurrentTime());
                        onStop();//获取到定位之后就停止定位
                        break;
                    case BDLocation.TypeServerError:     //服务端网络定位失败，可以反馈IMEI号和大体定位时间到loc-bugs@baidu.com，会有人追查原因
                    case BDLocation.TypeNetWorkException:  //网络不同导致定位失败，请检查网络是否通畅
                    case BDLocation.TypeCriteriaException:   //无法获取有效定位依据导致定位失败，一般是由于手机的原因，处于飞行模式下一般会造成这种结果，可以试着重启手机
                        //定位失败
                        KLog.i("sdg_location", location.getLocType() + "");
                        locationService.stop();
                        break;
                }
            }
        }
    };

    /**
     * 注销监听，停止定位
     * 注销之后必须再次初始化才能起作用
     * */
    public void onStop() {
        if (locationService != null) {
            //注销掉监听
            locationService.unregisterListener(mListener);
            //停止定位服务
            locationService.stop();
        }
    }

    private ILocation locationInfoInterface;
    public void setLocationInfoInterface(ILocation locationInfo){
        locationInfoInterface = locationInfo;
    }

}
