package com.dimeno.dimenoquestion.bean;

/**
 * Create by   :PNJ
 * Date        :2021/3/23
 * Description :
 */
public class ResultBean {
    /**
     * 问卷实体
     */
    private QueBean Que;

    public QueBean getQue() {
        return Que;
    }

    public void setQue(QueBean que) {
        Que = que;
    }
}
