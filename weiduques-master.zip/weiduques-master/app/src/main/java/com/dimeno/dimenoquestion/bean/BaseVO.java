package com.dimeno.dimenoquestion.bean;


import com.dimeno.common.utils.JSONHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Type;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :数据类的基础类型
 */
public class BaseVO {

    //将数据转换成Json字符串
    public String Serialize(){
        String result = JSONHelper.toJSON(this);

        return result;
    }

    /**
     * 传入的字符串转换成Json后映射到对应的字段
     * @param data
     */
    public void UnSerialize(String data){
        if(null== data) {
            return;
        }

        Field[]fields;

        try {
            JSONObject objData = new JSONObject(data);
            fields = getClass().getFields();
            for(Field field : fields ){
                handlerType(objData,field);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    /**
     * 处理类型赋值
     * @param objData
     * @param field
     */
    private void handlerType(JSONObject objData, Field field) {

        Type type;
        type = field.getType();
        try {
            if(((Class) type).isPrimitive()){
                //基础类型
                setPrimitive(objData,field);

            }else if(((Class) type).isArray()){
                //数组类型
                    setArray(objData.getJSONArray(field.getName()), field);
            }else{
                //有可能是类泛型或其他
                handlerOtherType(objData,field,type);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 处理非基础类型或数组类型
     * @param objData
     * @param field
     * @param type
     * @throws JSONException
     * @throws IllegalAccessException
     * @throws InstantiationException
     */
    private void handlerOtherType(JSONObject objData, Field field, Type type) throws JSONException, IllegalAccessException, InstantiationException {

        if (String.class.isAssignableFrom(field.getType())) {
            //字符串的处理
            setString(objData, field);
        }else if(field.getType().isAssignableFrom(BaseVO.class)){
        //基础数据类型不做解析
        }else if(BaseVO.class.isAssignableFrom(field.getType())){
            //数据类为基类的话
            BaseVO vo = null;
            vo = (BaseVO) field.getType().newInstance();
            if(null != vo){

                vo.UnSerialize(objData.getString(field.getName()));
                field.set(this,vo);

            }
        }
    }

    /**
     * 设置字符串类型
     * @param objData
     * @param field
     * @throws JSONException
     * @throws IllegalAccessException
     */
    private void setString(JSONObject objData, Field field) throws JSONException, IllegalAccessException {
        field.set(this, objData.optString(field.getName()));
    }


    /**
     * 设置基础类型
     * @param objData
     * @param field
     * @throws JSONException
     * @throws IllegalAccessException
     */
    private void setPrimitive(JSONObject objData, Field field) throws JSONException, IllegalAccessException {

        if(field.getType().getName()=="boolean") {
            field.set(this,objData.optBoolean(field.getName()));
        }else if(field.getType().getName()=="double"){
            field.set(this,objData.optDouble(field.getName()));
        }else if(field.getType().getName()=="float"){
            field.set(this, ((float) objData.optDouble(field.getName())));
        }else if(field.getType().getName()=="long"){
            field.set(this, objData.optLong(field.getName()));
        }else {
            field.set(this,objData.optInt(field.getName()));
        }
    }

    /**
     * 处理基础类型数组结构
     * @param objData
     * @param field
     * @throws IllegalAccessException
     * @throws InstantiationException
     * @throws JSONException
     * @throws ClassNotFoundException
     */
    private void setArray(JSONArray objData, Field field) throws IllegalAccessException, InstantiationException, JSONException, ClassNotFoundException {
        int i,len;
        Object arr = null;
        BaseVO vo=null;
        i=0;
        len = objData.length();
        if(field.getType().getComponentType().isPrimitive()) {
            //基础类型处理
            i=0;
            arr =  Array.newInstance(field.getType().getComponentType(),len);
            while(i<len){
                Array.set(arr, i, objData.get(i));
                i++;
            }
        }else if (String.class.isAssignableFrom(field.getType())){
            //字符串处理
            arr =  Array.newInstance(field.getType().getComponentType(),len);
            i=0;
            while(i<len){
                Array.set(arr,i,objData.get(i));
                i++;
            }
        }else if(field.getType().isAssignableFrom(BaseVO.class)){
            //BaseVO的数据基类不做处理
        }else if(BaseVO.class.isAssignableFrom(field.getType().getComponentType())){
            //BaseVO类型数据处理
            arr = Array.newInstance(field.getType().getComponentType(),len);
            i=0;
            while(i<len){

                    vo = (BaseVO) field.getType().getComponentType().newInstance();
                    vo.UnSerialize( objData.getString(i));
                    Array.set(arr,i,vo);
                    i++;

            }
        }
        field.set(this,arr);
    }


}
