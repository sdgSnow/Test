package com.dimeno.dimenoquestion.bean;

/**
 * OssInfoEntity
 * Created by sdg on 2020/8/26.
 */
public class OssInfoEntity {

    public String SecurityToken;
    public String endpoint;
    public String BucketName;
    public Integer code;
    public String AccessKeyId;
    public Boolean success;
    public String AccessKeySecret;
    public String Expiration;
    public String Host;
    public String Directory;
}
