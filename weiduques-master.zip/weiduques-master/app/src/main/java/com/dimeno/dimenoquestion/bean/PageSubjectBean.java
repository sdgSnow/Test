package com.dimeno.dimenoquestion.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :题目
 */
public class PageSubjectBean implements Serializable {
    /**
     * Attr : {"CascadeID":null,"CellList":null,"CharFormat":null,"CusAttr":[],"DateRange1":null,"DateRange2":null,"DefaultValue":null,"DesText":null,"FileType":null,"FillText":null,"FixedCID":null,"FixedPID":null,"InputLen":null,"IsFill":null,"IsFixedC":null,"IsFixedP":null,"IsLinefeed":null,"IsMulti":null,"IsMust":true,"IsRandom":false,"IsRepeat":null,"LeftText":null,"Length1":null,"Length2":null,"Level":null,"MaxCount":null,"MinCount":null,"NoModify":false,"NumCount":null,"NumRange1":null,"NumRange2":null,"OpText":null,"QuestionList":null,"RefID":null,"RightText":null,"Rmk":"","RowCount":1,"ScaleRange":null,"SearchText":null,"Title":"单选题","customLocation":null}
     * ID : 1
     * PID : 0
     * PageID : 1329341540929896449
     * QueID : 1329341540904730625
     * Sort : 1
     * SubAttr : {"title":"单选题","rmk":"","isMust":true,"rowCount":1,"isRandom":false,"refId":null,"cascadeId":null,"CityArea":null,"searchText":null,"noModify":false,"cusAttr":[]}
     * SubID : 4D3D98C7-096E-9D31-FA9B-5200C8AD8DC0
     * SubJudge : null
     * SubType : 1
     */

    private AttrBean Attr;
    private int ID;
    private int PID;
    private String PageID;
    private String QueID;
    private int Sort;
    private String SubAttr;
    private String SubID;
    private String SubJudge;
    private int SubType;
    private boolean isSelect;
    private boolean isError;
    private String errorMsg;
    private List<QueOptionBean> QueOption;
    private List<LogicSetting> QueLogicSetting;
    private String answerCode;
    //0初始状态，1显示，2隐藏
    private int isHide;
    //关联的题目，在答题列表所在position位置
    private Map<String,List<Integer>> hidePosition;
    //答题
    private SurveyAnswer surveyAnswer;




    public Map<String, List<Integer>> getHidePosition() {
        return hidePosition;
    }

    public void setHidePosition(Map<String, List<Integer>> hidePosition) {
        this.hidePosition = hidePosition;
    }

    public int getIsHide() {
        return isHide;
    }

    public void setIsHide(int isHide) {
        this.isHide = isHide;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }

    public boolean isError() {
        return isError;
    }

    public void setError(boolean error) {
        isError = error;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getAnswerCode() {
        return answerCode;
    }

    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    public List<LogicSetting> getQueLogicSetting() {
        return QueLogicSetting;
    }

    public void setQueLogicSetting(List<LogicSetting> queLogicSetting) {
        QueLogicSetting = queLogicSetting;
    }

    public List<QueOptionBean> getQueOption() {
        return QueOption;
    }

    public void setQueOption(List<QueOptionBean> queOption) {
        QueOption = queOption;
    }

    public AttrBean getAttr() {
        return Attr;
    }

    public void setAttr(AttrBean attr) {
        Attr = attr;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getPID() {
        return PID;
    }

    public void setPID(int PID) {
        this.PID = PID;
    }

    public String getPageID() {
        return PageID;
    }

    public void setPageID(String pageID) {
        PageID = pageID;
    }

    public String getQueID() {
        return QueID;
    }

    public void setQueID(String queID) {
        QueID = queID;
    }

    public int getSort() {
        return Sort;
    }

    public void setSort(int sort) {
        Sort = sort;
    }

    public String getSubAttr() {
        return SubAttr;
    }

    public void setSubAttr(String subAttr) {
        SubAttr = subAttr;
    }

    public String getSubID() {
        return SubID;
    }

    public void setSubID(String subID) {
        SubID = subID;
    }

    public String getSubJudge() {
        return SubJudge;
    }

    public void setSubJudge(String subJudge) {
        SubJudge = subJudge;
    }

    public int getSubType() {
        return SubType;
    }

    public void setSubType(int subType) {
        SubType = subType;
    }

    public void setSurveyAnswer(SurveyAnswer answer) {
        this.surveyAnswer = answer;
    }

    public SurveyAnswer getSurveyAnswer() {
        return surveyAnswer;
    }
}
