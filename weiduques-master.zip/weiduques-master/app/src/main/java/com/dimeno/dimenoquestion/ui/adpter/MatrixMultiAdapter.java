package com.dimeno.dimenoquestion.ui.adpter;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.widget.OptionBubble;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.dimeno.dimenoquestion.utils.DimenValue.TOP_ITEM_DECORATION_10;

/**
 * Create by   :PNJ
 * Date        :2021/4/27
 * Description :
 */
public class MatrixMultiAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    private List<QueOptionBean> beanList=new ArrayList<>();
    private List<String> mData=new ArrayList<>();
    private OptionBubble mOptionBubble;
    private Map<Integer,MatrixMultiOptionAdapter> map=new HashMap<>();
    private ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers=new ArrayList<>();
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * MatrixMultiAdapter
     * @param data
     * @param queList
     * @param matrixAnswers
     * @param type
     */
    public MatrixMultiAdapter(List<String> data,@Nullable List<QueOptionBean> queList,  ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers, String type) {
        super(R.layout.item_matrix_single_select, data);
        if(queList!=null){
            this.beanList = queList;
        }
        this.matrixAnswers = matrixAnswers;
        this.mData=data;
        this.type=type;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        TextView tv_ques_title = helper.getView(R.id.tv_ques_title);
        RecyclerView recyclerView = helper.getView(R.id.rcy_matrix_single);
        tv_ques_title.setText(item);
        //每次刷新的时候，必须设置LayoutManager，否则再次刷新的时候，item显示不出
        if (recyclerView.getItemDecorationCount() == 0) {
            recyclerView.addItemDecoration(new GridSpacesItemDecoration(mContext,beanList.size(), TOP_ITEM_DECORATION_10,false));
            recyclerView.setLayoutManager(new GridLayoutManager(mContext, beanList.size(), GridLayoutManager.VERTICAL, false));
        }
        if(map.get(helper.getAdapterPosition())==null) {
            MatrixMultiOptionAdapter adapter = new MatrixMultiOptionAdapter(beanList, mContext);
            recyclerView.setAdapter(adapter);
            //重新初始化数据源
            if(matrixAnswers!=null && matrixAnswers.size()!=0){
                if(matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes!=null &&  matrixAnswers.get(helper.getAdapterPosition()).opCodes.size()!=0){
                    adapter.getSet().clear();
                    adapter.getSet().addAll(matrixAnswers.get(helper.getAdapterPosition()).opCodes);
                }else {
                    adapter.getSet().clear();
                    adapter.notifyDataSetChanged();
                }
            }else {
                adapter.getSet().clear();
                adapter.notifyDataSetChanged();
            }
            adapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter mAdapter, View view, int position) {
                    if(beanList.size()>position) {
                        if (!type.equals("look")) {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                            if (adapter.getSet().contains(beanList.get(position).getOpCode())) {
                                adapter.getSet().remove(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.remove(beanList.get(position).getOpCode());
                                }
                            } else {
                                adapter.getSet().add(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.add(beanList.get(position).getOpCode());
                                }
                                //弹出气泡
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.showOptionBubble(view.findViewById(R.id.iv_matrix_multi_choose), beanList.get(position).getOpText());
                                }
//                            showOptionBubble(view.findViewById(R.id.iv_matrix_multi_choose), beanList.get(position).getOpText());
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
            });
            map.put(helper.getAdapterPosition(),adapter);
//            Log.d("adpterFlush","矩阵多选 setadpter="+helper.getAdapterPosition());
        }else {
            MatrixMultiOptionAdapter adapter = map.get(helper.getAdapterPosition());
            if(matrixAnswers!=null && matrixAnswers.size()!=0){
                if(matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes!=null && matrixAnswers.get(helper.getAdapterPosition()).opCodes.size()!=0){
                    adapter.getSet().clear();
                    adapter.getSet().addAll(matrixAnswers.get(helper.getAdapterPosition()).opCodes);
                }else {
                    adapter.getSet().clear();
                    adapter.notifyDataSetChanged();
                }
            }else {
                adapter.getSet().clear();
                adapter.notifyDataSetChanged();
            }
//            Log.d("adpterFlush","矩阵多选 helper.getAdapterPosition()="+helper.getAdapterPosition()+"   adapter.getSet()"+adapter.getSet().size());
            recyclerView.setAdapter(adapter);
            //必须要重新设置监听，否则helper.getAdapterPosition()因为mOwnerRecyclerView为空，返回-1从而报错
            adapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter mAdapter, View view, int position) {
                    if(beanList.size()>position) {
                        if (!type.equals("look")) {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.onChildClick();
                            }
                            if (adapter.getSet().contains(beanList.get(position).getOpCode())) {
                                adapter.getSet().remove(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.remove(beanList.get(position).getOpCode());
                                }
                            } else {
                                adapter.getSet().add(beanList.get(position).getOpCode());
                                if (matrixAnswers.size()>helper.getAdapterPosition() && matrixAnswers.get(helper.getAdapterPosition()).opCodes != null) {
                                    matrixAnswers.get(helper.getAdapterPosition()).opCodes.add(beanList.get(position).getOpCode());
                                }
                                //弹出气泡
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.showOptionBubble(view.findViewById(R.id.iv_matrix_multi_choose), beanList.get(position).getOpText());
                                }
//                            showOptionBubble(view.findViewById(R.id.iv_matrix_multi_choose), beanList.get(position).getOpText());
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
            });
        }
    }


    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
        void showOptionBubble(View anchor, String option);
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
