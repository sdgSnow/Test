package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.UserEntity;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface LoginView extends BaseView {
    /**
     * 成功回调
     * @param userEntity
     */
    void LoginSucess(UserEntity userEntity);

    /**
     * 失败回调
     * @param msg
     */
    void LoginFail(String msg);
}
