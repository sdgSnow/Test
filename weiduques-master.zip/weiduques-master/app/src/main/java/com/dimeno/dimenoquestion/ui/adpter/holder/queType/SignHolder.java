package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.SpannableStringBuilder;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.pop.SignPopup;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.ImagUtil;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :签名
 */
public class SignHolder extends RecyclerViewHolder<PageSubjectBean> {

    private RecordTextView tvTitle;
    private TextView tv_remark;
    private TextView tv_text;
    private TextView tv_reset;
    private ImageView iv_icon;
    private RelativeLayout containerGetSign;
    private LinearLayout ll_home;
    private LinearLayout ll_item;
    private SignPopup signPopup;
    private Bitmap bitmap;
    private FrameLayout frame_error;
    private Map<Integer,Bitmap> map=new HashMap<>();
    private SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public SignHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_sign);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        ll_home = findViewById(R.id.ll_home);
        ll_item = findViewById(R.id.ll_item);
        tv_text = findViewById(R.id.tv_text);
        iv_icon = findViewById(R.id.iv_icon);
        tv_reset = findViewById(R.id.tv_reset);
        frame_error = findViewById(R.id.frame_error);
        containerGetSign = findViewById(R.id.container_get_sign);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "电子签名题" : mData.getAttr().getRmk());
        }
        if (mData.getSurveyAnswer() == null) {
            SurveyAnswer answer = new SurveyAnswer();
            answer.annexList = new ArrayList<>();
            mData.setSurveyAnswer(answer);
        }
        if (mData.getSurveyAnswer().annexList == null) {
            mData.getSurveyAnswer().annexList = new ArrayList<>();
        }

        if(mData.isError()){
            frame_error.setVisibility(View.VISIBLE);
        }else {
            frame_error.setVisibility(View.GONE);
        }
        if (map.get(getAdapterPosition()) != null && !map.get(getAdapterPosition()).isRecycled()) {
            if(mData.getSurveyAnswer().annexList.size()==0){
                map.get(getAdapterPosition()).recycle();
                tv_text.setVisibility(View.VISIBLE);
                iv_icon.setVisibility(View.GONE);
                iv_icon.setImageBitmap(null);
                tv_reset.setVisibility(View.GONE);
                containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.color_f3f8ff));
            }else {
                MyLog.d("adpterFlush", "签名 map.get(getAdapterPosition()) != null    position=" + getAdapterPosition());
                bitmap = map.get(getAdapterPosition());
                iv_icon.setImageBitmap(map.get(getAdapterPosition()));
                tv_text.setVisibility(View.GONE);
                iv_icon.setVisibility(View.VISIBLE);
                if (type.equals("look")) {
                    tv_reset.setVisibility(View.GONE);
                } else {
                    tv_reset.setVisibility(View.VISIBLE);
                }
                containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.f6f6f6));
            }
        } else {
            if( mData.getSurveyAnswer().annexList!=null && mData.getSurveyAnswer().annexList.size()!=0 && !StringUtils.isEmpty(mData.getSurveyAnswer().annexList.get(0).path)){
                bitmap = BitmapFactory.decodeFile(mData.getSurveyAnswer().annexList.get(0).path);
                if(bitmap!=null) {
                    //转270度
                    bitmap= ImagUtil.adjustPhotoRotation2(bitmap,270);
                    if(bitmap!=null) {
                        MyLog.d("adpterFlush","签名 mData.getSurveyAnswer().annexList    position="+getAdapterPosition());
                        tv_text.setVisibility(View.GONE);
                        iv_icon.setVisibility(View.VISIBLE);
                        iv_icon.setImageBitmap(bitmap);
                        if(type.equals("look")){
                            tv_reset.setVisibility(View.GONE);
                        }else {
                            tv_reset.setVisibility(View.VISIBLE);
                        }
                        containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.f6f6f6));
                        map.put(getAdapterPosition(),bitmap);
                    }else {
                        if(type.equals("look")){
                            tv_reset.setVisibility(View.GONE);
                            tv_text.setText("图片不存在或者已删除");
                        }
                    }
                }else {
                    if(type.equals("look")){
                        tv_reset.setVisibility(View.GONE);
                        tv_text.setText("图片不存在或者已删除");
                    }
                }
            }else {
                MyLog.d("adpterFlush"," 签名 还未签名过    position="+getAdapterPosition());
                tv_text.setVisibility(View.VISIBLE);
                iv_icon.setVisibility(View.GONE);
                iv_icon.setImageBitmap(null);
                tv_reset.setVisibility(View.GONE);
                containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.color_f3f8ff));
            }
        }
        if(signPopup==null){
            signPopup=new SignPopup(itemView.getContext(),mData.getAnswerCode());
            signPopup.setonMyItemClickListener(new SignPopup.onMyItemClickListener() {
                @Override
                public void onItemClick(String path) {
                    iv_icon.post(new Runnable() {
                        @Override
                        public void run() {
                            mData.getSurveyAnswer().annexList.clear();
                            AnnexEntity annexEntity=new AnnexEntity();
                            annexEntity.fileType= FileType.SIGN;
                            annexEntity.path=path;
//                            annexEntity.type=4;
                            String signOssPath = "";
                            try {
                                signOssPath = MyUtils.getOssPath(path,mData.getQueID()).replace(".wd", ".png");
                            }catch (Exception e){
                                MyToast.showShortToast(e.getMessage());
                            }
                            annexEntity.ossPath= MyUtils.getOssPath(signOssPath,mData.getQueID());
                            mData.getSurveyAnswer().annexList.add(annexEntity);
                            bitmap = BitmapFactory.decodeFile(path);
                            if(bitmap!=null){
                                bitmap= ImagUtil.adjustPhotoRotation2(bitmap,270);
                                if(bitmap!=null) {
                                    tv_text.setVisibility(View.GONE);
                                    iv_icon.setVisibility(View.VISIBLE);
                                    iv_icon.setImageBitmap(bitmap);
                                    tv_reset.setVisibility(View.VISIBLE);
                                    containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.f6f6f6));
                                    //先把之前的bitmap
                                    if (map.get(getAdapterPosition()) != null && !map.get(getAdapterPosition()).isRecycled()) {
                                        map.get(getAdapterPosition()).isRecycled();
                                    }
                                    map.put(getAdapterPosition(),bitmap);
                                }
                            }
                        }
                    });
                }
            });
        }
        containerGetSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!type.equals("look")) {
                    if (tv_reset.getVisibility() == View.GONE) {
                        if (mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                        signPopup.setParam();
                        signPopup.showAtLocation(ll_item, Gravity.CENTER, 0, 0);
                    }
                }
            }
        });
        tv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mData.getSurveyAnswer().annexList.clear();
                tv_text.setVisibility(View.VISIBLE);
                iv_icon.setVisibility(View.GONE);
                recycle();
                tv_reset.setVisibility(View.GONE);
                containerGetSign.setBackgroundColor(itemView.getContext().getResources().getColor(R.color.color_f3f8ff));
            }
        });
    }

    public void recycle(){
        if(bitmap!=null && !bitmap.isRecycled()){
            bitmap.recycle();
            bitmap=null;
        }
    }
    public void destroy(){
        if(map.size()!=0){
            for (Bitmap item:map.values()) {
                if(item!=null && !item.isRecycled()){
                    item.recycle();
                    item=null;
                }
            }
        }
    }
}
