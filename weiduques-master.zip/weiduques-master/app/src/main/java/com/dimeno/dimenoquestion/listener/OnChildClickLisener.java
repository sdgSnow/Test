package com.dimeno.dimenoquestion.listener;

/**
 * Create by   :PNJ
 * Date        :2021/4/9
 * Description :
 */
public interface OnChildClickLisener {
    void onChildClick();
}
