package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.socks.library.KLog;
import com.warkiz.widget.IndicatorSeekBar;

import java.util.List;
/**
 * Create by   :PNJ
 * Date        :2021/4/27
 * Description :
 */
public class MatrixGaugeAdapter extends BaseQuickAdapter<QueOptionBean, BaseViewHolder> {

    private List<QueOptionBean> beanList;
    private PageSubjectBean subject;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * MatrixGaugeAdapter
     * @param data
     * @param subject
     * @param type
     */
    public MatrixGaugeAdapter(@Nullable List<QueOptionBean> data, PageSubjectBean subject,String type) {
        super(R.layout.item_matrix_gauge_content, data);
        this.beanList = data;
        this.subject = subject;
        this.type=type;
    }

    @Override
    protected void convert(BaseViewHolder helper, QueOptionBean item) {
        helper.setText(R.id.tvQueTitle,item.getOpText());
        IndicatorSeekBar seekBar=helper.itemView.findViewById(R.id.matrixSeekBar);

        if(subject.getSurveyAnswer().matrixAnswers!=null && subject.getSurveyAnswer().matrixAnswers.size()>helper.getAdapterPosition() && subject.getSurveyAnswer().matrixAnswers.get(helper.getAdapterPosition()).opCodes!=null) {
            SurveyAnswer.MatrixAnswer matrixAnswer = subject.getSurveyAnswer().matrixAnswers.get(helper.getAdapterPosition());
            int progress = 0;
            for (String opCode : matrixAnswer.opCodes) {
                try {
                    progress = Integer.parseInt(opCode);
                } catch (NumberFormatException ignore) {

                }
            }
            Log.d("progress", "progress=" + progress);
            seekBar.getBuilder().setMax(subject.getAttr().getScaleRange()).setTickNum(subject.getAttr().getScaleRange()).setMin(1).setProgress(progress).setDrawAgain(false).apply();

            // 禁用 seekBar
            if (type.equals("look")) {
                seekBar.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        return true;
                    }
                });
            }

            seekBar.setOnSeekChangeListener(new IndicatorSeekBar.OnSeekBarChangeListener() {

                @Override
                public void onProgressChanged(IndicatorSeekBar seekBar, int progress,
                                              float progressFloat, boolean fromUserTouch) {
                    KLog.d("progress: " + progress);
                    subject.getSurveyAnswer().matrixAnswers.get(helper.getAdapterPosition()).opCodes.clear();
                    subject.getSurveyAnswer().matrixAnswers.get(helper.getAdapterPosition()).opCodes.add(String.valueOf(progress));
                    if(progress!=0) {
                        if (onChildClickLisener!=null) {
                            onChildClickLisener.onChildClick();
                        }
                    }
                }

                @Override
                public void onSectionChanged(IndicatorSeekBar seekBar, int thumbPosOnTick,
                                             String tickBelowText, boolean fromUserTouch) {
                }

                @Override
                public void onStartTrackingTouch(IndicatorSeekBar seekBar, int thumbPosOnTick) {
                }

                @Override
                public void onStopTrackingTouch(IndicatorSeekBar seekBar) {

                }
            });
        }
    }

    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
