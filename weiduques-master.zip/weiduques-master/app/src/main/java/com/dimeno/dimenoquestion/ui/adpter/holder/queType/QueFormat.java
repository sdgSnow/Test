package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

/**
 * CharFormat
 * Created by wangzhen on 2020/5/8.
 */
public class QueFormat {
    /**
     * 题目类型
     * 1.单选题
     * 2.多选题
     * 3.下拉题
     * 4.问答题
     * 5.文本填空题
     * 6.数值填空题
     * 7.日期填空题
     * 8.多项填空题
     * 9.区域地址选择题
     * 10.量表题
     * 11.矩阵单选
     * 12.矩阵多选
     * 13.排序
     * 14.文字说明
     * 15.附件
     * 16.表格
     * 17.联动
     * 18.矩阵量表
     * 19.分隔符
     * 20.
     * 21.
     * 22.
     * 23.
     * 24.自增表格
     * 25.多级下拉
     * 26.定位
     *
     * 28.签名
     */
    public static final int Header = -1;//头部
    public static final int Footer = -2;//底部
    public static final int Single = 1;//单选
    public static final int Multiple = 2;//多选
    public static final int Drop_down = 3;//下拉题
    public static final int Question_answer = 4;//问答题
    public static final int Fill_text = 5;//文本填空题
    public static final int Fill_num_text = 6;//数值填空题
    public static final int Fill_data = 7;//日期填空题
    public static final int Multi_blank = 8;//多项填空题
    public static final int Fill_time = 9;//时间填空题
    public static final int Gauge = 10;//量表题
    public static final int Matrix_single = 11;//矩阵单选
    public static final int Matrix_multi = 12;//矩阵多选
    public static final int Sorting = 13;//排序
    public static final int Explan = 14;//文字说明
    public static final int Annex = 15;//附件
    public static final int Matrix_gauge = 18;//矩阵量表
    public static final int Separator = 19;//分隔符
    public static final int Auto_increment= 24;//自增表格
    public static final int Multi_pull_down = 25;//多级下拉
    public static final int Location = 26;//定位
    public static final int Sign = 28;//签名




    public static final String KEY_MUST = "key_is_must";
    public static final String KEY_VALUE = "key_value";
    public static final String KEY_FORMAT = "key_format";

}
