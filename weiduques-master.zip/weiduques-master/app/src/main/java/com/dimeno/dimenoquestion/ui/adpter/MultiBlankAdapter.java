package com.dimeno.dimenoquestion.ui.adpter;

import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.ChinaTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.DataHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EmailHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EnglishHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.IdCardHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.NoLimitTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.NumberHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.PhoneHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.QQHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.TelephoneHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.WebHolder;
import com.dimeno.dimenoquestion.utils.MyLog;

import java.util.ArrayList;
import java.util.List;

/**
 * 填空题适配
 */
public class MultiBlankAdapter extends RecyclerAdapter<AttrBean> {

    private ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks=new ArrayList<>();
    private List<AttrBean> data=new ArrayList<>();
    private StringBuilder builder;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param data
     * @param multiFillBlanks
     * @param type
     */
    public MultiBlankAdapter(@Nullable List<AttrBean> data,ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks,String type) {
        super(data);
        this.data=data;
        this.multiFillBlanks = multiFillBlanks;
        this.type=type;
    }
    public void setData(List<AttrBean> data,ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks){
        this.data=data;
        this.multiFillBlanks = multiFillBlanks;
        notifyDataSetChanged();
    }

    @Override
    protected int getAbsItemViewType(int position) {
        MyLog.d("getAbsItemViewType","MultiBlankAdapter  data.size="+data.size()+"     position="+position);
        if(position>=data.size()){
            return 0;
        }
        if(data.size()==0){
            return 0;
        }
        return data.get(position).getCharFormat();
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case CharFormat.EMAIL://1 邮箱
                return new EmailHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.TEXT://2 中文
                return new ChinaTextHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.ENGLISH://3 英文
                return new EnglishHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.WEBSITE://4 网址
                return new WebHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.ID://5 身份证号码
                return new IdCardHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.QQ://6 QQ号
                return new QQHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.MOBILE_PHONE://7 电话号码
                return new PhoneHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.TELEPHONE://8 固定电话
                return new TelephoneHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.NUMBER://9 数值
                return new NumberHolder(parent, multiFillBlanks,onChildClickLisener,type);
            case CharFormat.DATE://10 日期
                return new DataHolder(parent, multiFillBlanks,onChildClickLisener,type);
            default:
                return new NoLimitTextHolder(parent, multiFillBlanks,onChildClickLisener,type);
        }
    }


    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }

}
