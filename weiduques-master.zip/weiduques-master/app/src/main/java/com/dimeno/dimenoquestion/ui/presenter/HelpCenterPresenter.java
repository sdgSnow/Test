package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.HelpCenterView;
import com.dimeno.dimenoquestion.ui.view.MessageView;
import com.dimeno.dimenoquestion.utils.MyToast;

import java.util.ArrayList;

import io.reactivex.Observable;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class HelpCenterPresenter extends BasePresenter<HelpCenterView> {
    /**
     * 获取token值
     * @param activity
     * @param uploadFilepath 上传的文件本地路径
     * */
    public void getOssInfo(AppCompatActivity activity, String uploadFilepath){
        Observable<OssInfoEntity> observable = RetrofitManager.getInstance().getAppService()
                .getOssInfo(RetrofitManager.getInstance().getCacheControl());
        RetrofitUtil.get().request(activity, false,this, observable, new BaseNormalObserver<OssInfoEntity>(false)  {
            @Override
            protected void onHandleSuccess(OssInfoEntity res) {
                //防止activity销毁还进行该方法造成崩溃
                if(getMvpView()!=null) {
                    //oss成功回调
                    getMvpView().success(res, uploadFilepath);
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //oss失败回调
                MyToast.showShortToast(error);
            }
        });
    }

}
