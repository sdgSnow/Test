package com.dimeno.dimenoquestion.constant;

public interface ConstantType {
    /**
     * ExceptionLog日志的fileType
     */
    public interface LogFileType{
        //1问卷。
        public static final String QUE = "1";
        //2答卷
        public static final String ANSWER = "2";
    }

    /**
     * UserOperationLog_isUpload
     */
    public interface UserOperationLog_isUpload{
        //未上传
        public static final int NO_UPLOAD = 0;
        //已上传
        public static final int YES_UPLOAD = 1;
    }

    /**
     * 问卷题目是否隐藏
     */
    public interface queHide{
        //显示
        public static final int VISIBLE = 1;
        //隐藏
        public static final int GONE = 2;
    }

    /**
     * 帮助中心跳转类型
     */
    public interface HelpType{
        //日志上传
        public static final int DIARY_TYPE = 1;
        //文件直传
        public static final int DEAL_TYPE = 2;
    }

    /**
     * 分页接口加载数量
     */
    public interface Load{
        //消息列表
        public static final int SIZE = 10;
    }
}
