package com.dimeno.dimenoquestion.ui.presenter;


import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

//import com.af.audio.AudioRecordManager;
//import com.af.audio.IAudioRecordListener;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.RegexUtils;
import com.czt.mp3recorder.Mp3Recorder;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.GsonUtils;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.FileType;
import com.dimeno.dimenoquestion.bean.LogicSetting;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.QuePageBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.ResultBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.Constant;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.map.ILocation;
import com.dimeno.dimenoquestion.map.LocationOnceUtils;
import com.dimeno.dimenoquestion.map.OfflineAlwaysUtils;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.view.DoSureView;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.QuesUtil;
import com.dimeno.dimenoquestion.utils.SpUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UUIDUtil;
import com.dimeno.threadlib.ExecutorHandler;
import com.socks.library.KLog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.Observable;

import static com.czt.mp3recorder.Mp3Recorder.ACTION_STOP_ONLY;
import static com.dimeno.dimenoquestion.constant.Constant.AUDIO_BASE_PATH;
import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;
import static com.dimeno.dimenoquestion.constant.ConstantUtil.DROPDOWN_DEFAULT_VALUE;
import static com.dimeno.dimenoquestion.constant.OperationType.OPERATION;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class EditSurePresenter extends BasePresenter<DoSureView> {
    private ArrayList<PageSubjectBean> quesList=new ArrayList<>();
    /**
     * 答案实体
     */
    private SurveyAnswerEntity surveyAnswerEntity;

    /**
     * 答案数据库表
     */
    private Answer answer;


    //    private AudioRecordManager recordManager;
    private String queId;
    /**
     * 是否保存录音
     */
    private boolean saveRecord;

    private SurveyAnswer surveyAnswer = null;

    private int listSize;
    //定位方式
    private boolean locationType;
    /**
     * 加载数据
     * @param context
     * @param queId
     */
    public void loadQuesList(Context context,String queId){
        HashMap<String, String> params = new HashMap<>();
        params.put("ProCode", PRO_CODE);
        params.put("id", queId);
        params.put("onlyQue", "False");

        Observable<Res<ResultBean>> observable= RetrofitManager.getInstance().getAppService()
                .loadQues(RetrofitManager.getInstance().getCacheControl(),params);
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<ResultBean>() {
            @Override
            protected void onHandleSuccess(Res<ResultBean> data) {
                ExecutorHandler.getInstance().forBackgroundTasks()
                        .execute(new Runnable() {
                            @Override
                            public void run() {
                                if(data == null || data.ResultObj == null)return;
                                if(data.Flag==0){
                                    quesList.clear();
                                    if(getMvpView()!=null) {
                                        getMvpView().initQueEntity(data.ResultObj.getQue());
                                    }
                                }else {
                                    if(getMvpView()!=null) {
                                        getMvpView().loadFailure(false, data.Msg);
                                    }
                                }
                            }
                        });
            }

            @Override
            protected void onHandleFaild(int code, String error) {

            }
        });
    }

    /**
     * 获取地址信息
     */
    public void location() {
        //判断网络
        if(NetworkUtils.isConnected()) {
            locationType=true;
            //有网络，获取当前位置
            LocationOnceUtils.getInstance().startLocation(MyApplication.getContext(), new ILocation() {
                @Override
                public void locationInfo(String longitude, String latitude, String address, String currentTime) {
                    //答案实体不为空
                    if (surveyAnswerEntity != null) {
                        //答案保存经纬度
                        surveyAnswerEntity.queLatitude = Double.parseDouble(StringUtils.isEmpty(latitude) ? "0.0" : latitude);
                        surveyAnswerEntity.queLongitude = Double.parseDouble(StringUtils.isEmpty(longitude) ? "0.0" : longitude);
                    }
                }
            });
        }else {
            locationType=false;
            //没有网络，获取离线经纬度
            OfflineAlwaysUtils.getInstance().startLocation(MyApplication.getContext(), new ILocation() {
                @Override
                public void locationInfo(String longitude, String latitude, String address, String currentTime) {
                    //答案实体不为空
                    if (surveyAnswerEntity != null) {
                        //答案保存经纬度
                        surveyAnswerEntity.queLatitude = Double.parseDouble(StringUtils.isEmpty(latitude) ? "0.0" : latitude);
                        surveyAnswerEntity.queLongitude = Double.parseDouble(StringUtils.isEmpty(longitude) ? "0.0" : longitude);
                    }
                }
            });
        }
    }
    /**
     * 关闭定位
     */
    public void stopLocation(){
        //定位开启方式
        if(locationType) {
            //有网
            LocationOnceUtils.getInstance().onStop();
        }else {
            //mei'w
            OfflineAlwaysUtils.getInstance().onStop();
        }
    }
    /**
     * 初始化答题实体类
     * @param answer
     */
    public void initAnswer(Answer answer,String type) {
        queId = answer.getQueID();
        /**
         * 答案数据库表值
         */
        this.answer=answer;
        String survey=answer.getAnswerDetail();

        /**
         * 答案实体值
         */
        surveyAnswerEntity = JsonUtil.toObj(survey,SurveyAnswerEntity.class);
        QuesUtil.setAnswerCode(surveyAnswerEntity.answerCode);

    }

    /**
     * state:
     * 0 是未上传(继续编辑)
     * 1 是保存在本地，未上传（上传问卷）
     * 2 是有网已上传
     */
    public boolean saveDb(int state){
        surveyAnswerEntity.answerFinishTime = TimeUtil.getCurrentTimeMillis();
        answer.setAnswerFinishTime(surveyAnswerEntity.answerFinishTime);
        surveyAnswerEntity.answerAccessories = new ArrayList<>();
        Log.d("savedb-1",JsonUtil.toJson(surveyAnswer));
        answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
        //录音文件
        List<SurveyAnswerEntity.AnsFile.CustMap> custMapList = new ArrayList<>();
        for (SurveyAnswerEntity.AnswerPage ap : surveyAnswerEntity.surveyAnswers) {
            for (SurveyAnswer sa : ap.getSurveyAnswers()) {
                if (sa.logicShow == ConstantUtil.VISIBLE) {
//                if (sa.logicShow == 0) {
                    //逻辑显示，添加录音
                    surveyAnswerEntity.answerAccessories.add(sa.subRecordPath);

                    SurveyAnswerEntity.AnsFile.CustMap custMap = new SurveyAnswerEntity.AnsFile.CustMap();
                    custMap.setKey(sa.subUuid);
                    custMap.setValue(sa.subRecordPath);
                    custMapList.add(custMap);
                } else if (sa.logicShow == ConstantUtil.GONE) {
                    //逻辑隐藏，不用添加录音
                }
            }
        }
        SurveyAnswerEntity.AnsFile af = new SurveyAnswerEntity.AnsFile();
        af.setProCode(Constant.PRO_CODE);
        af.setAnswerId(answer.getAnswerId());
        af.setQueId(queId);
        af.setCustMaps(custMapList);

        String surveyAnswerJson = GsonUtils.getInstance().toJson(surveyAnswerEntity);
        answer.setAnswerDetail(surveyAnswerJson);
        answer.setAnswerState(state);
        //所选区域
        //answer.setAnswerLoc(chooseArea);
        surveyAnswerEntity.ansFile = af;

        //数据库保存
        int row = answer.update(answer.getId());
        if(row>0){
            //停止录音
            stopRecord(true);
            //保存成功
            return true;
        }else {
            //保存失败
            return false;
        }

    }

    /**
     * 关联隐藏题目
     * @param quePageBean
     */
    public void findLogic(QuePageBean quePageBean){
        //答案页
        if(quePageBean!=null) {
            //答题列表
            ArrayList<PageSubjectBean> subjectBeans=quePageBean.getQueSubject();
            if(subjectBeans!=null && subjectBeans.size()!=0){
                //判断每道题是否有隐藏逻辑
                for (int y = 0; y < subjectBeans.size(); y++) {
                    //为每道题创建答案,且id要一致，以防题目变化或者错位
                    if(subjectBeans.get(y).getSurveyAnswer()==null /*|| subjectBeans.get(y).getSurveyAnswer()!=null && subjectBeans.get(y).getID()!=subjectBeans.get(y).getSurveyAnswer().subId*/){
                        SurveyAnswer answer=new SurveyAnswer();
                        subjectBeans.get(y).setSurveyAnswer(answer);
                    }
                    //重新设置一下subType，以防题目顺序变化，造成隐藏
                    if (subjectBeans.get(y).getAttr() != null) {
                        subjectBeans.get(y).getSurveyAnswer().isMust = subjectBeans.get(y).getAttr().isMust();
                    }
                    subjectBeans.get(y).getSurveyAnswer().subType = subjectBeans.get(y).getSubType();
                    subjectBeans.get(y).getSurveyAnswer().queId = subjectBeans.get(y).getQueID();
                    subjectBeans.get(y).getSurveyAnswer().subId = subjectBeans.get(y).getID();
                    subjectBeans.get(y).getSurveyAnswer().sort = subjectBeans.get(y).getSort();
                    //有隐藏逻辑
                    if(subjectBeans.get(y).getQueLogicSetting()!=null
                            && subjectBeans.get(y).getQueLogicSetting().size()!=0){
                        hideQues(subjectBeans.get(y),subjectBeans);
                    }
                }
            }
        }
    }
    /**
     * 找到相关选项的隐藏题
     * @param subjectBean
     * @param subjectList
     */
    private void hideQues(PageSubjectBean subjectBean,ArrayList<PageSubjectBean> subjectList) {
        if(subjectBean!=null){
            if(subjectBean.getQueLogicSetting()!=null && subjectBean.getQueLogicSetting().size()!=0){
                Map<String, List<Integer>> map = new HashMap<>();
                //第一步，先隐藏
                //隐藏逻辑列表
                for (LogicSetting logicSetting : subjectBean.getQueLogicSetting()) {
                    //关联的题目SubIDs不为空
                    if (!StringUtils.isEmpty(logicSetting.SubIDs)) {
                        List<Integer> list = new ArrayList<>();
                        //循环关联的题目
                        for (String s : logicSetting.SubIDs.split(",")) {
                            //如果是结束位
                            if(s.equals("end")){
                                //结束位，查找结束位所在的选项
                                if(subjectBean.getQueOption()!=null){
                                    List<QueOptionBean> queOption = subjectBean.getQueOption();
                                    for (int i = 0; i < queOption.size(); i++) {
                                        if(queOption.get(i).getOpCode().equals(logicSetting.OpCode)){
                                            //设置选项为结束位
                                            queOption.get(i).setEnd(true);
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                            //循环所有题型，获取被关联题目在题目列表所在的位置
                            for (int position = 0; position < subjectList.size(); position++) {
                                if (s.equals(subjectList.get(position).getID() + "")) {
                                    //如果没有其他选项让它显示，则隐藏
                                    if(subjectList.get(position).getIsHide()!=ConstantType.queHide.VISIBLE){
                                        subjectList.get(position).setIsHide(ConstantType.queHide.GONE);//隐藏
                                    }
                                    list.add(position);
                                    break;
                                }
                            }
                        }
                        map.put(logicSetting.OpCode, list);
                        subjectBean.setHidePosition(map);
                    }
                }

                //第二步，根据选项，再次判断是否隐藏还是显示
                //判断，是否有选项已经选择
                switch (subjectBean.getSubType()){
                    case QueFormat.Single://1单选
                    case QueFormat.Multiple://2多选
                    case QueFormat.Sorting://13排序
                        if(subjectBean.getSurveyAnswer()!=null){
                            //获取答案选项
                            if(subjectBean.getSurveyAnswer().choiceList!=null && subjectBean.getSurveyAnswer().choiceList.size()!=0){
                                List<QueOptionBean> choiceList=subjectBean.getSurveyAnswer().choiceList;
                                //循环答案
                                for (int i = 0; i < choiceList.size(); i++) {
                                    //隐藏逻辑列表
                                    for (LogicSetting logicSetting : subjectBean.getQueLogicSetting()) {
                                        //如果选项中，有隐式逻辑的选项，则该隐式的题目应该显示
                                        if(logicSetting.OpCode.equals(choiceList.get(i).getOpCode())){
                                            //循环关联的题目
                                            for (String s : logicSetting.SubIDs.split(",")) {
                                                //循环所有题型，获取被关联题目在题目列表所在的位置
                                                for (int position = 0; position < subjectList.size(); position++) {
                                                    if (s.equals(subjectList.get(position).getID() + "")) {
                                                        subjectList.get(position).setIsHide(ConstantType.queHide.VISIBLE);//显示
//                                                        subjectList.get(position).getSurveyAnswer().logicShow=0;
                                                        if(subjectList.get(position).getSurveyAnswer() != null) {
                                                            subjectList.get(position).getSurveyAnswer().logicShow = ConstantUtil.VISIBLE;
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break;

                    case QueFormat.Drop_down://3 下拉题
                        if(subjectBean.getSurveyAnswer()!=null){
                            //获取答案选项
                            if(subjectBean.getSurveyAnswer().OptionList!=null && subjectBean.getSurveyAnswer().OptionList.size()!=0){
                                LinkedHashSet<String> choiceList=subjectBean.getSurveyAnswer().OptionList;
                                //循环答案
                                for (int i = 0; i < choiceList.size(); i++) {
                                    //隐藏逻辑列表
                                    for (LogicSetting logicSetting : subjectBean.getQueLogicSetting()) {
                                        //如果选项中，有隐式逻辑的选项，则该隐式的题目应该显示
                                        if(choiceList.contains(logicSetting.OpCode)){
                                            //循环关联的题目
                                            for (String s : logicSetting.SubIDs.split(",")) {
                                                //循环所有题型，获取被关联题目在题目列表所在的位置
                                                for (int position = 0; position < subjectList.size(); position++) {
                                                    if (s.equals(subjectList.get(position).getID() + "")) {
                                                        subjectList.get(position).setIsHide(ConstantType.queHide.VISIBLE);//显示
//                                                        subjectList.get(position).getSurveyAnswer().logicShow=0;
                                                        if(subjectList.get(position).getSurveyAnswer() != null) {
                                                            subjectList.get(position).getSurveyAnswer().logicShow = ConstantUtil.VISIBLE;
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }
    }
    /**
     * 适配答题
     * @param currentPage 页码
     * @param quePageBean
     */
    public void initAnswerPage(int currentPage,QuePageBean quePageBean){
        if(quePageBean!=null && quePageBean.getQueSubject()!=null && quePageBean.getQueSubject().size()!=0){
            if(surveyAnswerEntity.surveyAnswers!=null){
                //surveyAnswerEntity的答案页数大于当前页数
                if(surveyAnswerEntity.surveyAnswers.size()!=0 && surveyAnswerEntity.surveyAnswers.size()>currentPage){
                    //获取当前页的答案页
                    SurveyAnswerEntity.AnswerPage answerPage=surveyAnswerEntity.surveyAnswers.get(currentPage);
                    if(answerPage!=null) {
                        //获取当前页的答案列表
                        ArrayList<SurveyAnswer> answerList = answerPage.getSurveyAnswers();
                        //题目循环适配答案
                        if (answerList != null &&  answerList.size() !=0) {
                            for (int i = 0; i < quePageBean.getQueSubject().size(); i++) {
                                //适配答案,循环
                                for (SurveyAnswer answer : answerList) {
                                    //id一致，匹配答案
                                    if(quePageBean.getQueSubject().get(i).getID()==answer.subId){
                                        quePageBean.getQueSubject().get(i).setSurveyAnswer(answer);
//                                    if(answerList.get(i).logicShow==2){
                                        if(answer.logicShow==ConstantUtil.GONE){
                                            quePageBean.getQueSubject().get(i).setIsHide(ConstantType.queHide.GONE);//隐藏
                                        }
                                        //结束循环
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    /**
     * 根据答案页配置答题
     * @param currentPage
     * @param subjectBeans
     */
    public void addAnswerPage(int currentPage,List<PageSubjectBean> subjectBeans){
        if(currentPage==0){
            if(surveyAnswerEntity.surveyAnswers==null){
                surveyAnswerEntity.surveyAnswers=new ArrayList<>();
            }
            surveyAnswerEntity.surveyAnswers.clear();
        }
        SurveyAnswerEntity.AnswerPage answerPage=new SurveyAnswerEntity.AnswerPage();
        answerPage.setSurveyAnswers(new ArrayList<>());
        answerPage.setpIndex(currentPage);
        if(subjectBeans!=null) {
            for (PageSubjectBean item : subjectBeans) {
                if(item.getSurveyAnswer()!=null) {
                    answerPage.getSurveyAnswers().add(item.getSurveyAnswer());
                }
            }
        }
        surveyAnswerEntity.surveyAnswers.add(answerPage);
    }



    /**
     * @param currentPage fragment 页数
     * @param subjectBeans 题目数据
     * @param pos -1,全部检测，大于0，只检测到大于零到pos的这段部分
     * @return
     */
    public boolean check(int currentPage,List<PageSubjectBean> subjectBeans,int pos){
        if( subjectBeans!=null) {
            if(pos>=0){
                if(pos<subjectBeans.size()){
                    for (int position = 0; position <= pos; position++) {
                        if (subjectBeans.get(position).getSurveyAnswer() != null) {
                            if (!doCheck(currentPage, position, subjectBeans.get(position).getSubType(),subjectBeans.get(position).getSurveyAnswer())) {
                                return false;
                            }
                        } else {
                            String msg;
                            if (StringUtils.isEmpty(subjectBeans.get(position).getAttr().getTitle())){
                                msg=subjectBeans.get(position).getAttr().getTitle();
                            }else {
                                msg= StringUtils.isEmpty(subjectBeans.get(position).getAttr().getLeftText())?"":subjectBeans.get(position).getAttr().getLeftText();
                            }
                            sendBroadcast(msg+ "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                }
            }else {
                for (int position = 0; position < subjectBeans.size(); position++) {
                    if (subjectBeans.get(position).getSurveyAnswer() != null) {
                        if (!doCheck(currentPage, position, subjectBeans.get(position).getSubType(), subjectBeans.get(position).getSurveyAnswer())) {
                            return false;
                        }
                    } else {
                        String msg;
                        if (StringUtils.isEmpty(subjectBeans.get(position).getAttr().getTitle())){
                            msg=subjectBeans.get(position).getAttr().getTitle();
                        }else {
                            msg= StringUtils.isEmpty(subjectBeans.get(position).getAttr().getLeftText())?"":subjectBeans.get(position).getAttr().getLeftText();
                        }
                        sendBroadcast(msg+ "未答完，不能提交", position, currentPage);
                        return false;
                    }
                }
            }

        }
        return true;
    }

    /**
     * 核验各个题目是否符合条件
     * @param currentPage
     * @param position
     * @param surveyAnswer
     * @return
     */
    private boolean doCheck(int currentPage,int position,int subType, SurveyAnswer surveyAnswer) {
        if(surveyAnswer.logicShow==ConstantUtil.VISIBLE) {
            switch (subType) {
                case QueFormat.Single://1单选
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.choiceList != null) {
                            if (surveyAnswer.choiceList.size() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        } else {
                            //surveyAnswer.choiceList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }else {
                        if (surveyAnswer.choiceList != null && surveyAnswer.choiceList.size()!=0) {
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Multiple://2多选
                case QueFormat.Sorting://13 排序
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.choiceList != null) {
                            if (surveyAnswer.choiceList.size() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                            //选中总条数
                            int size = surveyAnswer.choiceList.size();
                            int minCount = 0, maxCount = 0;
                            maxCount = surveyAnswer.MaxCount;
                            minCount = surveyAnswer.MinCount;
                            if (minCount > 0) {
                                if (size < minCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少选择" + minCount + "个选项", position, currentPage);
                                    return false;
                                }
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }else {
                                //未设置最少选项
                                //设置了最多选项
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }
//
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        }else {
                            //surveyAnswer.choiceList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }else {
                        if(surveyAnswer.choiceList != null && surveyAnswer.choiceList.size()!=0) {
                            //选中总条数
                            int size = surveyAnswer.choiceList.size();
                            int minCount = 0, maxCount = 0;
                            maxCount = surveyAnswer.MaxCount;
                            minCount = surveyAnswer.MinCount;
                            if (minCount > 0) {
                                if (size < minCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少选择" + minCount + "个选项", position, currentPage);
                                    return false;
                                }
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }else {
                                //未设置最少选项
                                //设置了最多选项
                                if (maxCount != 0 && size > maxCount) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多选择" + maxCount + "个选项", position, currentPage);
                                    return false;
                                }
                            }
                            for (QueOptionBean s : surveyAnswer.choiceList) {
                                if (s.isMust() && s.isFill() && s.getFillContent().isEmpty()) {
                                    sendBroadcast(surveyAnswer.subTitle + "填空未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Drop_down://3 下拉题
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.OptionList != null) {
                            if (surveyAnswer.OptionList.size() == 0 || surveyAnswer.OptionList.contains(DROPDOWN_DEFAULT_VALUE)) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        } else {
                            //surveyAnswer.OptionList==null
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Question_answer://4 问答题
                case QueFormat.Fill_data://7 日期填空题
                case QueFormat.Fill_time://9 时间填空题
                    if (surveyAnswer.isMust) {
                        if (TextUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Fill_text://5 文本填空题
                    if (surveyAnswer.isMust) {
                        String wordContent = surveyAnswer.answerFillContent;
                        if (TextUtils.isEmpty(wordContent)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }
                        int max = surveyAnswer.lenghtMax;
                        int min = surveyAnswer.lenghtMin;

                        if (min > 0 && max > 0) {
                            int length = wordContent.length();
                            if (length < min) {
                                sendBroadcast(surveyAnswer.subTitle + "最少输入" + min + "个字符", position, currentPage);
                                return false;
                            }
                            if (length > max) {
                                sendBroadcast(surveyAnswer.subTitle + "最多输入" + max + "个字符", position, currentPage);
                                return false;
                            }
                        }

                        if (!checkFillWordBlank(position, currentPage, surveyAnswer)) {
                            return false;
                        }
                    }else {
                        //不为空，检测格式
                        if (!TextUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            int max = surveyAnswer.lenghtMax;
                            int min = surveyAnswer.lenghtMin;

                            if (min > 0 && max > 0) {
                                int length =  surveyAnswer.answerFillContent.length();
                                if (length < min) {
                                    sendBroadcast(surveyAnswer.subTitle + "最少输入" + min + "个字符", position, currentPage);
                                    return false;
                                }
                                if (length > max) {
                                    sendBroadcast(surveyAnswer.subTitle + "最多输入" + max + "个字符", position, currentPage);
                                    return false;
                                }
                            }

                            if (!checkFillWordBlank(position, currentPage, surveyAnswer)) {
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Fill_num_text://6 数值填空题
                    if (surveyAnswer.isMust) {
                        String content = surveyAnswer.answerFillContent;
                        if (TextUtils.isEmpty(content)) {
                            sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                            return false;
                        }

                        if (!TextUtils.isEmpty(content) && surveyAnswer.answerFillContentCharFormat == 7) {
                            if (!RegexUtils.isMobileExact(content)) {
                                sendBroadcast(String.format("\"%s\"未答完，不能提交", surveyAnswer.subTitle), position, currentPage);
                                return false;
                            }
                        }
                        //校验是否是整数或者正负数
                        if (!checkValue(CharFormatPattern.DIGITS, content)) {
                            sendBroadcast(surveyAnswer.subTitle + "请输入一个正确的数值", position, currentPage);
                            return false;
                        }
                        //校验输入值范围
                        double rangeStart = surveyAnswer.rangeStart;
                        double rangeEnd = surveyAnswer.rangeEnd;
                        //小数位数
                        int numCount = surveyAnswer.pointCount;
                        try {
                            double value = Double.parseDouble(content);

                            if (rangeStart != 0 && rangeEnd != 0) {
                                if (value < rangeStart || value > rangeEnd) {
                                    sendBroadcast(surveyAnswer.subTitle + "正确范围(" + rangeStart + "," + rangeEnd + ")", position, currentPage);
                                    return false;
                                }
                            }

                            //校验小数位数
                            if (numCount >= 0) {
                                int indexOf = content.lastIndexOf(".");
                                if (indexOf > 0) {
                                    int count = content.length() - indexOf - 1;
                                    if (count > numCount) {
                                        String suffix;
                                        if (numCount == 0) {
                                            suffix = "请输入整数";
                                        } else {
                                            suffix = "小数点后最长输入" + numCount + "位";
                                        }
                                        sendBroadcast(surveyAnswer.subTitle + suffix, position, currentPage);
                                        return false;
                                    }
                                }
                            }
                        } catch (Exception ignore) {
                            sendBroadcast(surveyAnswer.subTitle + "请输入正确的格式", position, currentPage);
                            return false;
                        }
                    }else {
                        //如果内容不为空
                        if (!StringUtils.isEmpty(surveyAnswer.answerFillContent)) {
                            String content = surveyAnswer.answerFillContent;
                            //校验是否是整数或者正负数
                            if (!checkValue(CharFormatPattern.DIGITS, content)) {
                                sendBroadcast(surveyAnswer.subTitle + "请输入一个正确的数值", position, currentPage);
                                return false;
                            }
                            //校验输入值范围
                            double rangeStart = surveyAnswer.rangeStart;
                            double rangeEnd = surveyAnswer.rangeEnd;
                            //小数位数
                            int numCount = surveyAnswer.pointCount;
                            try {
                                double value = Double.parseDouble(content);

                                if (rangeStart != 0 && rangeEnd != 0) {
                                    if (value < rangeStart || value > rangeEnd) {
                                        sendBroadcast(surveyAnswer.subTitle + "正确范围(" + rangeStart + "," + rangeEnd + ")", position, currentPage);
                                        return false;
                                    }
                                }

                                //校验小数位数
                                if (numCount >= 0) {
                                    int indexOf = content.lastIndexOf(".");
                                    if (indexOf > 0) {
                                        int count = content.length() - indexOf - 1;
                                        if (count > numCount) {
                                            String suffix;
                                            if (numCount == 0) {
                                                suffix = "请输入整数";
                                            } else {
                                                suffix = "小数点后最长输入" + numCount + "位";
                                            }
                                            sendBroadcast(surveyAnswer.subTitle + suffix, position, currentPage);
                                            return false;
                                        }
                                    }
                                }
                            } catch (Exception ignore) {
                                sendBroadcast(surveyAnswer.subTitle + "请输入正确的格式", position, currentPage);
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Multi_blank://8 多项填空题,连续填空
                    ArrayList<SurveyAnswer.MultiFillBlank> list = surveyAnswer.multiFillBlankList;
                    if (list == null || list.isEmpty()) {
                        sendBroadcast((surveyAnswer.subTitle == null ? "" : surveyAnswer.subTitle) + "未答完，不能提交", position, currentPage);
                        return false;
                    } else {
                        for (SurveyAnswer.MultiFillBlank blank : list) {
                            if (blank.isMust) {
                                if (TextUtils.isEmpty(blank.fillText)) {
                                    sendBroadcast((surveyAnswer.subTitle == null ? "第"+(position+1)+"道题,"+blank.pattern+"," : surveyAnswer.subTitle) + "未答完，不能提交", position, currentPage);
                                    return false;
                                } else {
                                    if (!checkMultiBlankFormat(position, currentPage, surveyAnswer, blank)) {
                                        return false;
                                    }
                                }
                            } else {
                                if (!checkMultiBlankFormat(position, currentPage, surveyAnswer, blank)) {
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Gauge://10 量表题
                    if (surveyAnswer.isMust) {
                        if(surveyAnswer.matrixAnswers!=null && surveyAnswer.matrixAnswers.size()!=0) {
                            if (surveyAnswer.matrixAnswers.get(0).opCodes != null) {
                                if (surveyAnswer.matrixAnswers.get(0).opCodes.size() == 0) {
                                    sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                    return false;
                                }
                            } else {
                                //surveyAnswer.matrixAnswers.get(0).opCodes==null
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        }else {
                            //surveyAnswer.matrixAnswers==null || surveyAnswer.matrixAnswers.size()=0
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Matrix_single://11矩阵单选
                case QueFormat.Matrix_multi://12矩阵多选
                case QueFormat.Matrix_gauge://18 矩阵量表
                    if (surveyAnswer.isMust) {
                        //答题内容不为空
                        if(surveyAnswer.matrixAnswers!=null) {
                            if (surveyAnswer.matrixAnswers.size() != 0) {
                                for (SurveyAnswer.MatrixAnswer matrixAnswer : surveyAnswer.matrixAnswers) {
                                    if (matrixAnswer.opCodes != null) {
                                        if (matrixAnswer.opCodes.size() == 0) {
                                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                            return false;
                                        }
                                    } else {
                                        sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                        return false;
                                    }
                                }
                            } else {
                                //答题内容为空
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        }else {
                            //答题内容为空
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    //2021/7/2 需求变更：非必填题不做是否答完校验
//                    else {
//                        //非必须
//                        //答题内容不为空
//                        if(surveyAnswer.matrixAnswers!=null) {
//                            if (surveyAnswer.matrixAnswers.size() != 0) {
//                                listSize=0;
//                                //如果有选项，判断是否每项选择都有答案。
//                                for (SurveyAnswer.MatrixAnswer matrixAnswer : surveyAnswer.matrixAnswers) {
//                                    if (matrixAnswer.opCodes != null) {
//                                        if (matrixAnswer.opCodes.size() == 0) {
//                                            //没有答案
//                                            listSize++;
//                                        }
//                                    } else {
//                                        //没有答案
//                                        listSize++;
//                                    }
//                                }
//                                //如果有答案，且未答完。则提示
//                                if(listSize!=0 && listSize!=surveyAnswer.matrixAnswers.size()){
//                                    sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
//                                    return false;
//                                }
//                            }
//                        }
//                    }
                    break;

                case QueFormat.Explan://14 文字说明
                    break;
                case QueFormat.Annex://15 附件
                case QueFormat.Sign://28 签名
                    if (surveyAnswer.isMust) {
                        List<AnnexEntity> medias = surveyAnswer.annexList;
                        if (medias == null || medias.isEmpty()) {
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        }
                    }
                    break;
                case QueFormat.Separator://19 分隔符
                    break;
                case QueFormat.Auto_increment://24 自增表格
                    if(surveyAnswer.mAutoIncrementAnswer!=null && surveyAnswer.mAutoIncrementAnswer.mAnswers!=null) {
                        Map<Integer, Map<Integer, Map<String, Object>>> answers = surveyAnswer.mAutoIncrementAnswer.mAnswers;
                        if (answers != null && answers.size() != 0) {
                            for (Map.Entry<Integer, Map<Integer, Map<String, Object>>> entry : answers.entrySet()) {
                                Map<Integer, Map<String, Object>> values = entry.getValue();
                                int pos = entry.getKey();//第几项
                                for (int i = 0; i < values.size(); i++) {
                                    Map<String, Object> map = values.get(i);
                                    if (map != null) {
                                        boolean isMust = (boolean) map.get(QueFormat.KEY_MUST);
                                        Object value = map.get(QueFormat.KEY_VALUE);
                                        Object forma=map.get(QueFormat.KEY_FORMAT);
                                        int format = (int) Double.parseDouble(forma.toString()+"");
                                        if (isMust) {
                                            if (value == null || TextUtils.isEmpty(String.valueOf(value))) {
                                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                                return false;
                                            } else {
                                                if (!checkAutoIncrementFormat(pos + 1, i + 1, position, currentPage, surveyAnswer, value, format)) {
                                                    return false;
                                                }
                                            }
                                        } else {
                                            if (!checkAutoIncrementFormat(pos + 1, i + 1, position, currentPage, surveyAnswer, value, format)) {
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                case QueFormat.Multi_pull_down://25多级下拉，连续下拉
                    if (surveyAnswer.isMust) {
                        List<String> multi_dropdown_value = surveyAnswer.multi_dropdown_value;
                        if (multi_dropdown_value == null || multi_dropdown_value.isEmpty()) {
                            sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                            return false;
                        } else {
                            StringBuilder builder = new StringBuilder();
                            for (String s : multi_dropdown_value) {
                                if (!TextUtils.isEmpty(s)) {
                                    if (builder.length() > 0) {
                                        builder.append("-");
                                    }
                                    builder.append(s);
                                }
                            }
                            if (builder.length() == 0) {
                                sendBroadcast(surveyAnswer.subTitle + "未答完，不能提交", position, currentPage);
                                return false;
                            }
                        }
                    }
                    break;
                case QueFormat.Location://26定位
                    if (surveyAnswer.isMust) {
                        if (surveyAnswer.isMust && TextUtils.isEmpty(surveyAnswer.mLocationAddress)) {
                            sendBroadcast(surveyAnswer.subTitle, position, currentPage);
                            return false;
                        }
                    }
                    break;
            }
        }
        return true;
    }

    /**
     * 核验文字是否符合条件
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @return
     */
    private boolean checkFillWordBlank(int position, int currentPage,SurveyAnswer surveyAnswer) {
        String value = surveyAnswer.answerFillContent;
        int format = surveyAnswer.answerFillContentCharFormat;
        if (format == CharFormat.EMAIL) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.EMAIL, value)) {
                sendBroadcast(String.format("\"%s\"邮箱格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.TEXT, value)) {
                sendBroadcast(String.format("\"%s\"请输入中文", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.ENGLISH, value)) {
                sendBroadcast(String.format("\"%s\"请输入英文", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.WEBSITE, value)) {
                sendBroadcast(String.format("\"%s\"网址格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.ID, value)) {
                sendBroadcast(String.format("\"%s\"身份证格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.QQ, value)) {
                sendBroadcast(String.format("\"%s\"QQ格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.MOBILE_PHONE, value)) {
                sendBroadcast(String.format("\"%s\"手机格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!TextUtils.isEmpty(String.valueOf(value)) && !checkValue(CharFormatPattern.TELEPHONE, value)) {
                sendBroadcast(String.format("\"%s\"固话格式不正确", surveyAnswer.subTitle), position, currentPage);
                return false;
            }
        }
        return true;
    }

    private boolean checkValue(String pattern, Object value) {
        return RegexUtils.isMatch(pattern, String.valueOf(value));
    }
    /**
     * 核验文字是否符合条件
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @return
     */
    private boolean checkMultiBlankFormat(int position, int currentPage,SurveyAnswer surveyAnswer, SurveyAnswer.MultiFillBlank blank) {
        int format = blank.format;
        if (format == CharFormat.EMAIL) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.EMAIL, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 邮箱格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.TEXT, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 请输入中文", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.ENGLISH, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 请输入英文", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.WEBSITE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 网址格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.ID, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 身份证格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.QQ, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" QQ格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.MOBILE_PHONE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 手机格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!TextUtils.isEmpty(blank.fillText) && !checkValue(CharFormatPattern.TELEPHONE, blank.fillText)) {
                sendBroadcast(String.format(Locale.CHINA, "\"%s\" 固话格式不正确", blank.pattern), position, currentPage);
                return false;
            }
        }
        return true;
    }
    /**
     *
     * @param pos 答题的第几项
     * @param current  答题第几项的第几个
     * @param position
     * @param currentPage
     * @param surveyAnswer
     * @param value
     * @param format
     * @return
     */
    private boolean checkAutoIncrementFormat(int pos,int current,int position,int currentPage,SurveyAnswer surveyAnswer, Object value, int format) {
        if (format == CharFormat.EMAIL) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.EMAIL, value)) {
                sendBroadcast( surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，邮箱格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TEXT) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.TEXT, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，请输入中文", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ENGLISH) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.ENGLISH, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle+ "，表格"+pos+"的第"+current+"行，请输入英文", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.WEBSITE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.WEBSITE, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，网址格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.ID) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.ID, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，身份证格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.QQ) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.QQ, value)) {
                sendBroadcast(/*surveyAnswer.subId + */surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，QQ格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.MOBILE_PHONE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.MOBILE_PHONE, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，手机格式不正确", position, currentPage);
                return false;
            }
        }
        if (format == CharFormat.TELEPHONE) {
            if (!objectEmpty(value) && !checkValue(CharFormatPattern.TELEPHONE, value)) {
                sendBroadcast(/*surveyAnswer.subId +*/ surveyAnswer.subTitle + "，表格"+pos+"的第"+current+"行，固话格式不正确", position, currentPage);
                return false;
            }
        }
        return true;
    }

    private boolean objectEmpty(Object obj) {
        return obj == null || TextUtils.isEmpty(String.valueOf(obj));
    }
    /**
     * 发广播
     * @param title
     * @param sort
     * @param page
     */
    private void sendBroadcast(String title, int sort, int page) {
        Intent intent = new Intent(String.valueOf(page));
        intent.putExtra("sort", sort);
        intent.putExtra("end", false);
        LocalBroadcastManager.getInstance(MyApplication.getContext()).sendBroadcast(intent);
        MyToast.showLongToast(title);
    }

    /**
     * 开启录音
     * @param newQuesBean
     */
    private Mp3Recorder mRecorder;
    private double currDuration;
    public void initRecorder(Answer answer) {
        mRecorder = new Mp3Recorder();
        currDuration=0;
        FileUtils.createDir(AUDIO_BASE_PATH + answer.getQueID() + "/" + answer.getAnswerCode() + "/");
        String path=AUDIO_BASE_PATH + answer.getQueID() + "/" + answer.getAnswerCode() + "/" + TimeUtil.getCurrentTimeMillis()+"_record" + ".mp3";;
        AnnexEntity annexEntity=new AnnexEntity();
        LogUtils.addLog("",OPERATION,answer.getQueID(),answer.getAnswerStartTime(),"开始录音",JsonUtil.toJson(answer));
        if(answer!=null){
            String recordDetail=answer.getRecordDetail();
            if(!StringUtils.isEmpty(recordDetail)){
                surveyAnswer=JsonUtil.toObj(recordDetail,SurveyAnswer.class);

                annexEntity.que_id = answer.getQueID();
                annexEntity.que_title = answer.getQueTitle();
                annexEntity.record_id = UUIDUtil.getUUID();
                annexEntity.user_id = SpUtil.get().getUserId();
                annexEntity.user_name = SpUtil.get().getUserName();
                annexEntity.create_time = TimeUtil.getCurrentTime();
                annexEntity.filepath = path;
//                annexEntity.type=3;
                annexEntity.ossPath = MyUtils.getOssPath(path,answer.getQueID());
                annexEntity.fileType= FileType.RECORD;
                if(surveyAnswer==null){
                    surveyAnswer=new SurveyAnswer();
                }
                if(surveyAnswer.annexList==null){
                    surveyAnswer.annexList=new ArrayList<>();
                }
                surveyAnswer.annexList.add(annexEntity);
            }

            mRecorder.setOutputFile(path)
                    .setCallback(new Mp3Recorder.Callback() {
                        @Override
                        public void onStart() {
                            KLog.i("record","录音开始了");
                        }

                        @Override
                        public void onPause() {
                            KLog.i("record","录音暂停了");
                        }

                        @Override
                        public void onResume() {
                            KLog.i("record","录音恢复了");
                        }

                        @Override
                        public void onStop(int action) {
//                            KLog.i("record","录音停止了, duration="+currDuration);
                            annexEntity.duration= (int) currDuration;
                            if(answer!=null && saveRecord && currDuration>=3000){
                                if(!StringUtils.isEmpty(path)) {
                                    String filepath = null;
                                    try {
                                        filepath = FileUtils.changePhoto2wm(path, "wd");
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    annexEntity.filepath = filepath;
                                    if(answer!=null) {
                                        answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
                                        //数据库保存
                                        answer.update(answer.getId());
                                    }
                                }
                            }else {
                                KLog.d("record","录音停止了, duration="+currDuration+"  annexList.size="+surveyAnswer.annexList.size());
                                surveyAnswer.annexList.remove(annexEntity);
                                KLog.d("record","录音停止了 annexList.size="+surveyAnswer.annexList.size());
                                if(answer!=null) {
                                    answer.setRecordDetail(JsonUtil.toJson(surveyAnswer));
                                    //数据库保存
                                    answer.update(answer.getId());
                                }
                            }
                            LogUtils.addLog("",OPERATION,answer.getQueID(),answer.getAnswerStartTime(),"录音停止并生成文件",JsonUtil.toJson(answer));
                        }

                        @Override
                        public void onReset() {
                            KLog.i("record","录音撤销了");
                        }

                        @Override
                        public void onRecording(double duration, double volume) {
                            currDuration=duration;
                            KLog.i("record","onRecording  duration="+duration +"  volume="+volume);
                        }

                        @Override
                        public void onMaxDurationReached() {
                        }
                    });
        }
    }

    //开始录音
    public void startRecord() {
        if (mRecorder != null) {
            mRecorder.start();
        }
    }

    /**
     * 结束录音
     * @param saveRecord
     */
    public void stopRecord(boolean saveRecord) {
        this.saveRecord=saveRecord;
        if (mRecorder != null) {
            mRecorder.stop(ACTION_STOP_ONLY);
        }
    }
}
