package com.dimeno.dimenoquestion.ui.adpter;

import android.text.Editable;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.holder.base.BaseViewHolder;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class SingleChoiceAdapter extends RecyclerView.Adapter<SingleChoiceAdapter.ViewHolder>{
    //保存多选状态下的变量
    private HashSet<String> set=new HashSet<>();
    private List<QueOptionBean> mData=new ArrayList<>();
    private SurveyAnswer answer;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param answer
     * @param type
     */
    public SingleChoiceAdapter(SurveyAnswer answer,String type) {
        this.answer = answer;
        this.type=type;
    }

    public void setData(List<QueOptionBean> mData){
        this.mData=mData;
        notifyDataSetChanged();
    }

    /**
     * 重置set
     */
    public void resetSet(SurveyAnswer answer){
        this.answer=answer;
        if(answer.choiceList!=null){
            set.clear();
            for (QueOptionBean item : answer.choiceList) {
                set.add(item.getOpCode());
            }
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_single, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(mData.size()>position && mData.get(position)!=null) {
            if (type.equals("look")) {
                holder.etFillBlank.setClickable(false);
                holder.etFillBlank.setEnabled(false);
            }
            if(mData.get(position).isMust()){
                holder.mark.setVisibility(View.VISIBLE);
            }else {
                holder.mark.setVisibility(View.GONE);
            }
            if(!StringUtils.isEmpty(mData.get(position).getFillText())){
                holder.unit.setVisibility(View.VISIBLE);
                holder.unit.setText(mData.get(position).getFillText());
            }else {
                holder.unit.setVisibility(View.GONE);
                holder.unit.setText("");
            }
            if (set.contains(mData.get(position).getOpCode())) {
                holder.ivSelect.setImageResource(R.mipmap.radio_selected);
                holder.ll_home.setSelected(true);
                if (mData.get(position).isFill()) {
                    holder.ll_edit.setVisibility(View.VISIBLE);
//                    if (answer != null && answer.choiceList != null && answer.choiceList.size() != 0) {
//                        holder.etFillBlank.setText(StringUtils.isEmpty(answer.choiceList.get(0).getFillContent()) ?
//                                "" : answer.choiceList.get(position).getFillContent());
////                    holder.etFillBlank.setCursorVisible(false);
//                    }
                    if (answer != null && answer.choiceList != null) {
                        for (int i = 0; i < answer.choiceList.size(); i++) {
                            if (answer.choiceList.get(i).getOpCode().equals(mData.get(position).getOpCode())) {
                                holder.etFillBlank.setText(StringUtils.isEmpty(answer.choiceList.get(i).getFillContent()) ?
                                        "" : answer.choiceList.get(i).getFillContent());
                            }
                        }
                    }
                } else {
                    holder.ll_edit.setVisibility(View.GONE);
                }
            } else {
                holder.ivSelect.setImageResource(R.mipmap.radio_unselected);
                holder.ll_edit.setVisibility(View.GONE);
                holder.ll_home.setSelected(false);
            }
            holder.etFillBlank.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if(actionId== EditorInfo.IME_ACTION_NEXT){
                        return true;
                    }
                    return false;
                }
            });
            holder.etFillBlank.addTextChangedListener(new AbsTextWatcher() {
                @Override
                public void afterTextChanged(Editable s) {
                    if(answer.choiceList!=null && answer.choiceList.size()!=0){
                        for (int i = 0; i < answer.choiceList.size(); i++) {
                            if(answer.choiceList.get(i).getOpCode().equals(mData.get(position).getOpCode())){
                                answer.choiceList.get(i).setFillContent(s.toString());
                            }
                        }
                    }

                    if (!StringUtils.isEmpty(s.toString())) {
                        if (myOnItemClickListener != null) {
                            myOnItemClickListener.onItemClick();
                        }
                    }
                }
            });
            holder.tv_title.setText(mData.get(position).getOpText());
            holder.ll_home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //如果是结束，则直接提示是否结束
//                if(mData.get(position).isEnd()){
//                    if (!type.equals("look")) {
//                        if (myOnItemClickListener != null) {
//                            myOnItemClickListener.onItemEndClick(false, mData.get(position), position);
//                        }
//                    }
//                }else {
                    if (!type.equals("look")) {
                        if (set.contains(mData.get(position).getOpCode())) {
                            set.clear();
                            mData.get(position).setFillContent("");
                            if (myOnItemClickListener != null) {
                                myOnItemClickListener.onItemClick(false, mData.get(position), position);
                            }
                        } else {
                            set.clear();
                            for (int i = 0; i < mData.size(); i++) {
                                mData.get(i).setFillContent("");
                            }
                            set.add(mData.get(position).getOpCode());
                            if (myOnItemClickListener != null) {
                                myOnItemClickListener.onItemClick(true, mData.get(position), position);
                            }
                        }
                        notifyDataSetChanged();
                    }
                }
//            }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }
    public class ViewHolder extends BaseViewHolder {
        ImageView ivSelect;
        TextView tv_title;
        TextView mark;
        TextView unit;
        LinearLayout ll_edit;
        LinearLayout ll_home;
        EditText etFillBlank;
        ViewHolder(View itemView) {
            super(itemView);
            ivSelect=itemView.findViewById(R.id.ivSelect);
            tv_title=itemView.findViewById(R.id.tv_title);
            ll_home=itemView.findViewById(R.id.ll_home);
            mark=itemView.findViewById(R.id.mark);
            unit=itemView.findViewById(R.id.unit);
            ll_edit=itemView.findViewById(R.id.ll_edit);
            etFillBlank=itemView.findViewById(R.id.etFillBlank);
            etFillBlank.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        }
    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private MyOnItemClickListener myOnItemClickListener;

    public interface MyOnItemClickListener {
        void onItemClick();
        void onItemClick(boolean isSelect,QueOptionBean queOptionBean,int position);
        void onItemEndClick(boolean isSelect,QueOptionBean queOptionBean,int position);
    }
}
