package com.dimeno.dimenoquestion.db;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class Answer extends LitePalSupport implements Serializable {
    //id
    private Long id;
    private String answerCode;
    //答案id
    private String answerId;
    //问卷id
    private String queID;
    //问卷标题
    private String queTitle;
    // 所选的区域名称
    private String answerLoc;
    //问卷创建时间
    private String queCreateDate;
    //问卷修改时间
    private String queModifyDate;
    //答案结束时间
    private Long answerFinishTime;
    //答案开始时间
    private Long answerStartTime;
    //答案详情
    private String answerDetail;
    //题目详情
    private String queDetail;
    //用户id
    private String userId;
    //录音详情
    private String recordDetail;


    /**
     * "1":未上传录音，显示上传录音按钮
     * "0":已上传，隐藏上传录音按钮
     */
    private String test;
    /**
     * 0 是未上传(继续编辑)
     * 1 是保存在本地，未上传（上传问卷）
     * 2 是有网已上传
     */
    private Integer answerState;

    //备用1
    private String testOne;
    
    private Boolean checkboxState;
    //adpter中的位置
    private int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getRecordDetail() {
        return recordDetail;
    }

    public void setRecordDetail(String recordDetail) {
        this.recordDetail = recordDetail;
    }

    public String getQueDetail() {
        return queDetail;
    }

    public void setQueDetail(String queDetail) {
        this.queDetail = queDetail;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAnswerCode() {
        return this.answerCode;
    }

    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    public String getAnswerId() {
        return this.answerId;
    }

    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }

    public String getQueID() {
        return this.queID;
    }

    public void setQueID(String queID) {
        this.queID = queID;
    }

    public String getQueTitle() {
        return this.queTitle;
    }

    public void setQueTitle(String queTitle) {
        this.queTitle = queTitle;
    }

    public String getAnswerLoc() {
        return this.answerLoc;
    }

    public void setAnswerLoc(String answerLoc) {
        this.answerLoc = answerLoc;
    }

    public String getQueCreateDate() {
        return this.queCreateDate;
    }

    public void setQueCreateDate(String queCreateDate) {
        this.queCreateDate = queCreateDate;
    }

    public String getQueModifyDate() {
        return this.queModifyDate;
    }

    public void setQueModifyDate(String queModifyDate) {
        this.queModifyDate = queModifyDate;
    }

    public Long getAnswerFinishTime() {
        return this.answerFinishTime;
    }

    public void setAnswerFinishTime(Long answerFinishTime) {
        this.answerFinishTime = answerFinishTime;
    }

    public Long getAnswerStartTime() {
        return this.answerStartTime;
    }

    public void setAnswerStartTime(Long answerStartTime) {
        this.answerStartTime = answerStartTime;
    }

    public String getAnswerDetail() {
        return this.answerDetail;
    }

    public void setAnswerDetail(String answerDetail) {
        this.answerDetail = answerDetail;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTest() {
        return this.test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public int getAnswerState() {
        return this.answerState;
    }

    public void setAnswerState(int answerState) {
        this.answerState = answerState;
    }

    public String getTestOne() {
        return this.testOne;
    }

    public void setTestOne(String testOne) {
        this.testOne = testOne;
    }

    public Boolean getCheckboxState() {
        return this.checkboxState;
    }

    public void setCheckboxState(Boolean checkboxState) {
        this.checkboxState = checkboxState;
    }

}
