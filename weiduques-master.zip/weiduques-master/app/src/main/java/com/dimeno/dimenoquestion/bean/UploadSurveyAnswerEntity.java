package com.dimeno.dimenoquestion.bean;


import com.dimeno.dimenoquestion.mode.GlobalRecordSections;

import java.util.List;

/**
 * 上传数据实体
 * Created by cc on 2017/12/22.
 */

public class UploadSurveyAnswerEntity {

    /**
     * Answer1 : {"Answer_ID":"a0a95953-59e9-4d29-99ca-18830d132d38","Catalog_ID":"8087C37C-25F9-438F-B8F8-CBAD13CADB3F","Question_ID":"1a335177-b56c-46e7-9de2-62b95eba353e","Enter_Mark":1,"Enter_ID":"c11b8119-284f-4e2a-8aac-d1ac5463693d","Enter_Answer_ID":"1321","Start_Date":"2017-12-22 11:53:06","End_Date":"2017-12-22 11:53:32","Submit_Date":null,"Status":0,"A1":"2","B1":"564654","A2":",2,3,4,","B2":"[\"\",\"\",\"\",\"\",\"4564654\"]","A3":"123123","B3":null,"A4":"1","B4":null,"A5":"23123","B5":null,"A6":"1231","B6":null,"A7":"3212","B7":null,"A8":null,"B8":null,"A9":null,"B9":null,"A10":null,"B10":null,"A11":null,"B11":null,"A12":null,"B12":null,"A13":null,"B13":null,"A14":null,"B14":null,"A15":null,"B15":null,"A16":null,"B16":null,"A17":null,"B17":null,"A18":null,"B18":null,"A19":null,"B19":null,"A20":null,"B20":null,"A21":null,"B21":null,"A22":null,"B22":null,"A23":null,"B23":null,"A24":null,"B24":null,"A25":null,"B25":null,"A26":null,"B26":null,"A27":null,"B27":null,"A28":null,"B28":null,"A29":null,"B29":null,"A30":null,"B30":null,"A31":null,"B31":null,"A32":null,"B32":null,"A33":null,"B33":null,"A34":null,"B34":null,"A35":null,"B35":null,"A36":null,"B36":null,"A37":null,"B37":null,"A38":null,"B38":null,"A39":null,"B39":null,"A40":null,"B40":null,"A41":null,"B41":null,"A42":null,"B42":null,"A43":null,"B43":null,"A44":null,"B44":null,"A45":null,"B45":null,"A46":null,"B46":null,"A47":null,"B47":null,"A48":null,"B48":null,"A49":null,"B49":null,"A50":null,"B50":null,"A51":null,"B51":null,"A52":null,"B52":null,"A53":null,"B53":null,"A54":null,"B54":null,"A55":null,"B55":null,"A56":null,"B56":null,"A57":null,"B57":null,"A58":null,"B58":null,"A59":null,"B59":null,"A60":null,"B60":null,"A61":null,"B61":null,"A62":null,"B62":null,"A63":null,"B63":null,"A64":null,"B64":null,"A65":null,"B65":null,"A66":null,"B66":null,"A67":null,"B67":null,"A68":null,"B68":null,"A69":null,"B69":null,"A70":null,"B70":null,"A71":null,"B71":null,"A72":null,"B72":null,"A73":null,"B73":null,"A74":null,"B74":null,"A75":null,"B75":null,"A76":null,"B76":null,"A77":null,"B77":null,"A78":null,"B78":null,"A79":null,"B79":null,"A80":null,"B80":null,"A81":null,"B81":null,"A82":null,"B82":null,"A83":null,"B83":null,"A84":null,"B84":null,"A85":null,"B85":null,"A86":null,"B86":null,"A87":null,"B87":null,"A88":null,"B88":null,"A89":null,"B89":null,"A90":null,"B90":null,"A91":null,"B91":null,"A92":null,"B92":null,"A93":null,"B93":null,"A94":null,"B94":null,"A95":null,"B95":null,"A96":null,"B96":null,"A97":null,"B97":null,"A98":null,"B98":null,"A99":null,"B99":null,"A100":null,"B100":null,"Reserved1":null,"Reserved2":null,"Reserved3":null}
     * Answer2 : null
     * Answer3 : null
     * Answer4 : null
     * Answer5 : null
     * Answer6 : null
     */

    public Answer1Bean Answer1;
    public Answer2Bean Answer2;
    public Answer3Bean Answer3;
    public Answer4Bean Answer4;
    public Answer5Bean Answer5;
    public Answer6Bean Answer6;
    public List<TB_AnswerFile> AnswerFileList;
    public List<AnswerEx> AnswerExList;
    public List<GlobalRecordSections.Section> TapeTimeSlices;//全局录音时间片断

    public static class Answer1Bean {
        public String Answer_ID;
        public String ProCode;
        //public String Catalog_ID;//后台没用到了
        public String Question_ID;
        public int Enter_Mark;
        public String Enter_ID;
        public String Enter_Answer_ID;
        public String Start_Date;
        public String Answer_Start_Time_Code;
        public String End_Date;
        public String Submit_Date;
        public int Status;
        public String A_Preside;
        //全局录音
        public String TapeUrl;
        public String A1;
        public String B1;
        public String A2;
        public String B2;
        public String A3;
        public String B3;
        public String A4;
        public String B4;
        public String A5;
        public String B5;
        public String A6;
        public String B6;
        public String A7;
        public String B7;
        public String A8;
        public String B8;
        public String A9;
        public String B9;
        public String A10;
        public String B10;
        public String A11;
        public String B11;
        public String A12;
        public String B12;
        public String A13;
        public String B13;
        public String A14;
        public String B14;
        public String A15;
        public String B15;
        public String A16;
        public String B16;
        public String A17;
        public String B17;
        public String A18;
        public String B18;
        public String A19;
        public String B19;
        public String A20;
        public String B20;
        public String A21;
        public String B21;
        public String A22;
        public String B22;
        public String A23;
        public String B23;
        public String A24;
        public String B24;
        public String A25;
        public String B25;
        public String A26;
        public String B26;
        public String A27;
        public String B27;
        public String A28;
        public String B28;
        public String A29;
        public String B29;
        public String A30;
        public String B30;
        public String A31;
        public String B31;
        public String A32;
        public String B32;
        public String A33;
        public String B33;
        public String A34;
        public String B34;
        public String A35;
        public String B35;
        public String A36;
        public String B36;
        public String A37;
        public String B37;
        public String A38;
        public String B38;
        public String A39;
        public String B39;
        public String A40;
        public String B40;
        public String A41;
        public String B41;
        public String A42;
        public String B42;
        public String A43;
        public String B43;
        public String A44;
        public String B44;
        public String A45;
        public String B45;
        public String A46;
        public String B46;
        public String A47;
        public String B47;
        public String A48;
        public String B48;
        public String A49;
        public String B49;
        public String A50;
        public String B50;
        public String Reserved1;
        public String Reserved2;
        public String Reserved3;
    }

    public static class Answer2Bean {
        public String Answer2_ID;
        public String A51;
        public String B51;
        public String A52;
        public String B52;
        public String A53;
        public String B53;
        public String A54;
        public String B54;
        public String A55;
        public String B55;
        public String A56;
        public String B56;
        public String A57;
        public String B57;
        public String A58;
        public String B58;
        public String A59;
        public String B59;
        public String A60;
        public String B60;
        public String A61;
        public String B61;
        public String A62;
        public String B62;
        public String A63;
        public String B63;
        public String A64;
        public String B64;
        public String A65;
        public String B65;
        public String A66;
        public String B66;
        public String A67;
        public String B67;
        public String A68;
        public String B68;
        public String A69;
        public String B69;
        public String A70;
        public String B70;
        public String A71;
        public String B71;
        public String A72;
        public String B72;
        public String A73;
        public String B73;
        public String A74;
        public String B74;
        public String A75;
        public String B75;
        public String A76;
        public String B76;
        public String A77;
        public String B77;
        public String A78;
        public String B78;
        public String A79;
        public String B79;
        public String A80;
        public String B80;
        public String A81;
        public String B81;
        public String A82;
        public String B82;
        public String A83;
        public String B83;
        public String A84;
        public String B84;
        public String A85;
        public String B85;
        public String A86;
        public String B86;
        public String A87;
        public String B87;
        public String A88;
        public String B88;
        public String A89;
        public String B89;
        public String A90;
        public String B90;
        public String A91;
        public String B91;
        public String A92;
        public String B92;
        public String A93;
        public String B93;
        public String A94;
        public String B94;
        public String A95;
        public String B95;
        public String A96;
        public String B96;
        public String A97;
        public String B97;
        public String A98;
        public String B98;
        public String A99;
        public String B99;
        public String A100;
        public String B100;
    }

    public static class Answer3Bean {
        public String Answer3_ID;
        public String A101;
        public String B101;
        public String A102;
        public String B102;
        public String A103;
        public String B103;
        public String A104;
        public String B104;
        public String A105;
        public String B105;
        public String A106;
        public String B106;
        public String A107;
        public String B107;
        public String A108;
        public String B108;
        public String A109;
        public String B109;
        public String A110;
        public String B110;
        public String A111;
        public String B111;
        public String A112;
        public String B112;
        public String A113;
        public String B113;
        public String A114;
        public String B114;
        public String A115;
        public String B115;
        public String A116;
        public String B116;
        public String A117;
        public String B117;
        public String A118;
        public String B118;
        public String A119;
        public String B119;
        public String A120;
        public String B120;
        public String A121;
        public String B121;
        public String A122;
        public String B122;
        public String A123;
        public String B123;
        public String A124;
        public String B124;
        public String A125;
        public String B125;
        public String A126;
        public String B126;
        public String A127;
        public String B127;
        public String A128;
        public String B128;
        public String A129;
        public String B129;
        public String A130;
        public String B130;
        public String A131;
        public String B131;
        public String A132;
        public String B132;
        public String A133;
        public String B133;
        public String A134;
        public String B134;
        public String A135;
        public String B135;
        public String A136;
        public String B136;
        public String A137;
        public String B137;
        public String A138;
        public String B138;
        public String A139;
        public String B139;
        public String A140;
        public String B140;
        public String A141;
        public String B141;
        public String A142;
        public String B142;
        public String A143;
        public String B143;
        public String A144;
        public String B144;
        public String A145;
        public String B145;
        public String A146;
        public String B146;
        public String A147;
        public String B147;
        public String A148;
        public String B148;
        public String A149;
        public String B149;
        public String A150;
        public String B150;
    }

    public static class Answer4Bean {
        public String Answer4_ID;
        public String A151;
        public String B151;
        public String A152;
        public String B152;
        public String A153;
        public String B153;
        public String A154;
        public String B154;
        public String A155;
        public String B155;
        public String A156;
        public String B156;
        public String A157;
        public String B157;
        public String A158;
        public String B158;
        public String A159;
        public String B159;
        public String A160;
        public String B160;
        public String A161;
        public String B161;
        public String A162;
        public String B162;
        public String A163;
        public String B163;
        public String A164;
        public String B164;
        public String A165;
        public String B165;
        public String A166;
        public String B166;
        public String A167;
        public String B167;
        public String A168;
        public String B168;
        public String A169;
        public String B169;
        public String A170;
        public String B170;
        public String A171;
        public String B171;
        public String A172;
        public String B172;
        public String A173;
        public String B173;
        public String A174;
        public String B174;
        public String A175;
        public String B175;
        public String A176;
        public String B176;
        public String A177;
        public String B177;
        public String A178;
        public String B178;
        public String A179;
        public String B179;
        public String A180;
        public String B180;
        public String A181;
        public String B181;
        public String A182;
        public String B182;
        public String A183;
        public String B183;
        public String A184;
        public String B184;
        public String A185;
        public String B185;
        public String A186;
        public String B186;
        public String A187;
        public String B187;
        public String A188;
        public String B188;
        public String A189;
        public String B189;
        public String A190;
        public String B190;
        public String A191;
        public String B191;
        public String A192;
        public String B192;
        public String A193;
        public String B193;
        public String A194;
        public String B194;
        public String A195;
        public String B195;
        public String A196;
        public String B196;
        public String A197;
        public String B197;
        public String A198;
        public String B198;
        public String A199;
        public String B199;
        public String A200;
        public String B200;
    }

    public static class Answer5Bean {
        public String Answer5_ID;
        public String A201;
        public String B201;
        public String A202;
        public String B202;
        public String A203;
        public String B203;
        public String A204;
        public String B204;
        public String A205;
        public String B205;
        public String A206;
        public String B206;
        public String A207;
        public String B207;
        public String A208;
        public String B208;
        public String A209;
        public String B209;
        public String A210;
        public String B210;
        public String A211;
        public String B211;
        public String A212;
        public String B212;
        public String A213;
        public String B213;
        public String A214;
        public String B214;
        public String A215;
        public String B215;
        public String A216;
        public String B216;
        public String A217;
        public String B217;
        public String A218;
        public String B218;
        public String A219;
        public String B219;
        public String A220;
        public String B220;
        public String A221;
        public String B221;
        public String A222;
        public String B222;
        public String A223;
        public String B223;
        public String A224;
        public String B224;
        public String A225;
        public String B225;
        public String A226;
        public String B226;
        public String A227;
        public String B227;
        public String A228;
        public String B228;
        public String A229;
        public String B229;
        public String A230;
        public String B230;
        public String A231;
        public String B231;
        public String A232;
        public String B232;
        public String A233;
        public String B233;
        public String A234;
        public String B234;
        public String A235;
        public String B235;
        public String A236;
        public String B236;
        public String A237;
        public String B237;
        public String A238;
        public String B238;
        public String A239;
        public String B239;
        public String A240;
        public String B240;
        public String A241;
        public String B241;
        public String A242;
        public String B242;
        public String A243;
        public String B243;
        public String A244;
        public String B244;
        public String A245;
        public String B245;
        public String A246;
        public String B246;
        public String A247;
        public String B247;
        public String A248;
        public String B248;
        public String A249;
        public String B249;
        public String A250;
        public String B250;
    }

    public static class Answer6Bean {
        public String Answer6_ID;
        public String A251;
        public String B251;
        public String A252;
        public String B252;
        public String A253;
        public String B253;
        public String A254;
        public String B254;
        public String A255;
        public String B255;
        public String A256;
        public String B256;
        public String A257;
        public String B257;
        public String A258;
        public String B258;
        public String A259;
        public String B259;
        public String A260;
        public String B260;
        public String A261;
        public String B261;
        public String A262;
        public String B262;
        public String A263;
        public String B263;
        public String A264;
        public String B264;
        public String A265;
        public String B265;
        public String A266;
        public String B266;
        public String A267;
        public String B267;
        public String A268;
        public String B268;
        public String A269;
        public String B269;
        public String A270;
        public String B270;
        public String A271;
        public String B271;
        public String A272;
        public String B272;
        public String A273;
        public String B273;
        public String A274;
        public String B274;
        public String A275;
        public String B275;
        public String A276;
        public String B276;
        public String A277;
        public String B277;
        public String A278;
        public String B278;
        public String A279;
        public String B279;
        public String A280;
        public String B280;
        public String A281;
        public String B281;
        public String A282;
        public String B282;
        public String A283;
        public String B283;
        public String A284;
        public String B284;
        public String A285;
        public String B285;
        public String A286;
        public String B286;
        public String A287;
        public String B287;
        public String A288;
        public String B288;
        public String A289;
        public String B289;
        public String A290;
        public String B290;
        public String A291;
        public String B291;
        public String A292;
        public String B292;
        public String A293;
        public String B293;
        public String A294;
        public String B294;
        public String A295;
        public String B295;
        public String A296;
        public String B296;
        public String A297;
        public String B297;
        public String A298;
        public String B298;
        public String A299;
        public String B299;
        public String A300;
        public String B300;
    }

    public static class TB_AnswerFile {
        public String ID;//录音文件ID
        public String Answer_ID; //答卷ID
        public String Question_ID;// 问卷ID
        public String QueSubject_ID;// 题目ID
        public String Url;//存储地址
        public int FileType;//     //文件类别 1：录音文件  2：图片  3：签名文件 4：附件  5.视频 6.音频
        public int Status;// 状态  1：已上传 0：未上传  -1：已删除
        public String CreateDate;
    }

    public static class AnswerEx {

        /**
         * Ex_ID : 0f8c4aab-d4a1-4bba-8d99-9f33a6e848ff
         * Question_ID : 398e77a0-c4ce-4989-9632-1b27e618f3fa
         * Answer_ID : 77b0b959-4e4b-4f3d-acf5-fed296e4317f
         * Enter_ID : 79d170fe-0d50-40cb-8fc8-9f2afc94c0a6
         * Sub_ID : 7
         * Sub_Type : 8
         * Op_ID : sub-7-2
         * Op_Value : 18
         * Status : 1
         * Submit_Date : 2020-05-09 19:04:27
         * Ex_Value1 : null
         * Ex_Value2 : null
         * Ex_Value3 : null
         * Ex_Value4 : null
         * Ex_Value5 : null
         */
        public String Question_ID;//问卷ID
        public String Answer_ID;//答卷ID
        public String Enter_ID;//用户ID
        public int Sub_ID;
        public int Sub_Type;
        public String Op_ID;
        public String Op_Value;
        public Object Ex_Value1;//存储自增表格题目内自增位置
        public Object Ex_Value2;
        public Object Ex_Value3;
        public Object Ex_Value4;
        public Object Ex_Value5;

    }
}
