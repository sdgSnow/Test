package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.MatrixSingleAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.ui.adpter.MatrixSingleTitleAdapter;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static com.dimeno.dimenoquestion.utils.DimenValue.TOP_ITEM_DECORATION_10;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :矩阵单选
 */
public class MatrixSingleHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final RecyclerView rv_title;
    private final RecyclerView rv_option;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private Map<Integer, MatrixSingleAdapter> map=new HashMap<>();
    private String[] quesList;
    private SpannableStringBuilder title;
    private MatrixSingleAdapter matrixSingleAdapter;
    private QueAdapter.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public MatrixSingleHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_matrix_single);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        rv_title = findViewById(R.id.rv_title);
        rv_option = findViewById(R.id.rv_option);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
        this.onChildClickLisener=onChildClickLisener;
        Log.d("adpterFlush","矩阵单选 MatrixSingleHolder create");
    }


    @Override
    public void bind() {
        if (mData.getAttr() != null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            if(mData.getQueOption()!=null) {
                //初始化 选项
                MatrixSingleTitleAdapter singleTitleAdapter = new MatrixSingleTitleAdapter();
                if (rv_title.getItemDecorationCount() == 0) {
                    rv_title.addItemDecoration(new GridSpacesItemDecoration(itemView.getContext(), mData.getQueOption().size(), TOP_ITEM_DECORATION_10, false));
                }
                if (mData.getQueOption() != null && mData.getQueOption().size() > 1) {
                    Collections.sort(mData.getQueOption(), new Comparator<QueOptionBean>() {
                        @Override
                        public int compare(QueOptionBean o1, QueOptionBean o2) {
                            return o1.getSort() - o2.getSort();
                        }
                    });
                }
                rv_title.setLayoutManager(new GridLayoutManager(itemView.getContext(), mData.getQueOption().size(), GridLayoutManager.VERTICAL, false));
                rv_title.setAdapter(singleTitleAdapter);
                singleTitleAdapter.setData(mData.getQueOption());

                //初始化题目+问题
                if(!StringUtils.isEmpty(mData.getAttr().getQuestionList())) {
                    Log.d("adpterFlush", "矩阵单选  bind");
                    if (map.get(getAdapterPosition()) == null) {

                        //初始化题目+问题
                        quesList = mData.getAttr().getQuestionList().split("\n");
                        List<String> selectList = new ArrayList<>();

                        for (int i = 0; i < quesList.length; i++) {
                            selectList.add(quesList[i]);
                        }
                        //初始化答案
                        if (mData.getSurveyAnswer().matrixAnswers == null) {
                            ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers = new ArrayList<>();
                            mData.getSurveyAnswer().matrixAnswers = matrixAnswers;
                        }
                        if (mData.getSurveyAnswer().matrixAnswers.size() == 0) {
                            mData.getSurveyAnswer().matrixAnswers.clear();
                            for (int i = 0; i < quesList.length; i++) {
                                SurveyAnswer.MatrixAnswer matrixAnswer = new SurveyAnswer.MatrixAnswer();
                                matrixAnswer.opCodes = new HashSet<>();
                                mData.getSurveyAnswer().matrixAnswers.add(matrixAnswer);
                            }
                        }

                        matrixSingleAdapter = new MatrixSingleAdapter(selectList, mData.getQueOption(), mData.getSurveyAnswer().matrixAnswers, type);
                        rv_option.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));
                        rv_option.setAdapter(matrixSingleAdapter);
                        map.put(getAdapterPosition(), matrixSingleAdapter);
                    } else {
                        matrixSingleAdapter = map.get(getAdapterPosition());
                        rv_option.setAdapter(matrixSingleAdapter);
                    }
                    matrixSingleAdapter.setChildClickLisener(new MatrixSingleAdapter.OnChildClickLisener() {
                        @Override
                        public void onChildClick() {
                            if (mData.isError()) {
                                mData.setError(false);
                                frame_error.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void showOptionBubble(View anchor, String option) {
                            if (onChildClickLisener != null) {
                                onChildClickLisener.showOptionBubble(anchor, option);
                            }
                        }
                    });
                }
            }
        }
    }

}
