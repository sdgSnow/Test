package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

import com.blankj.utilcode.util.ZipUtils;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.dimenoquestion.bean.ExceptionLog;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.http.BaseNormalObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.DealExceptionQueView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.threadlib.ExecutorHandler;

import org.litepal.LitePal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.Constant.COPY_PATH;

public class DealExceptionQuePresent extends BasePresenter<DealExceptionQueView> {
    //所有答案
    private List<Answer> allAnswers=new ArrayList<>();
    //查询的答案
    private List<Answer> searchAnswers=new ArrayList<>();
    //每一次获取多少条数据
    private int size=10;
    public void quesList(String qId,int page){
        ExecutorHandler.getInstance().forBackgroundTasks()
                .execute(new Runnable() {
                    @Override
                    public void run() {
                        //清空查询到的数据
                        searchAnswers.clear();
                        //第一页的时候。
                        if (page == 1) {
                            //所有数据清空
                            allAnswers.clear();
                        }
                        //offset 忽略前面的个数
                        if(!StringUtils.isEmpty(qId) && !StringUtils.isEmpty(UserUtil.getUserId())) {
                            searchAnswers = LitePal.where("QueID=? and UserId = ?", qId, UserUtil.getUserId()).order("answerState asc,AnswerFinishTime desc").limit(size).offset(allAnswers.size()).find(Answer.class);
                        }
                       //查询的数据不为空
                        if(searchAnswers.size()!=0) {
                            //添加到allAnswers
                            allAnswers.addAll(searchAnswers);
                            //searchAnswers的数小于size，则证明没有更多数据
                            if (searchAnswers.size() < size) {
                                //防止activity销毁还进行该方法造成崩溃
                                if(getMvpView()!=null) {
                                    //false没有更多数据
                                    getMvpView().initQuesList(false, allAnswers);
                                }
                            } else {
                                //防止activity销毁还进行该方法造成崩溃
                                if(getMvpView()!=null) {
                                    //true有更多数据
                                    getMvpView().initQuesList(true, allAnswers);
                                }
                            }
                        }else {
                            //防止activity销毁还进行该方法造成崩溃
                            if(getMvpView()!=null) {
                                //false没有更多数据
                                getMvpView().initQuesList(false, allAnswers);
                            }
                        }
                    }
                });
    }
    /**
     * @param inputfile  压缩文件路径
     * @param outputfile 输出的文件路径
     */
    public void uploadExceptionData(AppCompatActivity activity, String inputfile, String outputfile) {
        try {
            //压缩成功否
            boolean isSuccess = ZipUtils.zipFile(inputfile, outputfile);
            //activity没有销毁
            if(!activity.isDestroyed()){
                if (isSuccess) {
                    //成功，上次oss
                    getOssInfo(activity,outputfile);
                } else {
                    //失败，提示
                    ProgressHelper.getInstance().cancel();
                    MyToast.showShortToast("文件直传失败");
                }
            }

        } catch (IOException e) {
            //activity没有销毁
            if(!activity.isDestroyed()) {
                //失败，提示
                ProgressHelper.getInstance().cancel();
                MyToast.showLongToast("文件直传失败：" + e.getMessage());
            }
            e.printStackTrace();
        }
    }

    /**
     * 获取token值
     * @param activity
     * @param uploadFilepath 上传的文件本地路径
     * */
    public void getOssInfo(AppCompatActivity activity,String uploadFilepath){
        Observable<OssInfoEntity> observable = RetrofitManager.getInstance().getAppService()
                .getOssInfo(RetrofitManager.getInstance().getCacheControl());
        RetrofitUtil.get().request(activity, false,this, observable, new BaseNormalObserver<OssInfoEntity>(false)  {
            @Override
            protected void onHandleSuccess(OssInfoEntity res) {
                //防止activity销毁还进行该方法造成崩溃
                if(getMvpView()!=null) {
                    //oss成功回调
                    getMvpView().success(res, uploadFilepath);
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //oss失败回调
                MyToast.showShortToast(error);
            }
        });
    }


    public void exceptionLog(Context context,ExceptionLog exceptionLog){
        Observable<Res<String>> observable = RetrofitManager.getInstance().getAppService()
                .exceptionLog(exceptionLog);
        RetrofitUtil.get().request(context, false,this, observable, new BaseNormalObserver<Res<String>>(false)  {
            @Override
            protected void onHandleSuccess(Res<String> res) {
                //Flag==0成功
                if(res.Flag==0){
                    //防止activity销毁还进行该方法造成崩溃
                    if(getMvpView()!=null) {
                        //成功回调
                        getMvpView().sucess(true,"");
                    }
                }else {
                    //防止activity销毁还进行该方法造成崩溃
                    if(getMvpView()!=null) {
                        //失败回调
                        getMvpView().sucess(false,res.ResultObj);
                    }
                }

            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //防止activity销毁还进行该方法造成崩溃
                if(getMvpView()!=null) {
                    //失败回调
                    getMvpView().sucess(false,error);
                }
            }
        });
    }
}
