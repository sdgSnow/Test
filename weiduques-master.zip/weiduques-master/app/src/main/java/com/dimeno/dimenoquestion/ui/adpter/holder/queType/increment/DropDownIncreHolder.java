package com.dimeno.dimenoquestion.ui.adpter.holder.queType.increment;

import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.blankj.utilcode.util.RegexUtils;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.AutoIncrementAdapter2;
import com.dimeno.dimenoquestion.ui.adpter.SpinnerIncreAdapter;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.TextViewUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :下拉
 */
public class DropDownIncreHolder extends RecyclerViewHolder<AttrBean> {
    private SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer;
    private TextView mLeftText;
    private Spinner spinner;
    private SpannableStringBuilder title;
    private AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;
    private int index;
    private List<String> list =new ArrayList<>();
    private Map<Integer, SpinnerIncreAdapter> map=new HashMap<>();
    private String value;

    /**
     * DropDownIncreHolder
     * @param parent
     * @param index
     * @param mAutoIncrementAnswer
     * @param onChildClickLisener
     * @param type
     */
    public DropDownIncreHolder(@NonNull ViewGroup parent, int index, SurveyAnswer.AutoIncrementAnswer mAutoIncrementAnswer, AutoIncrementAdapter2.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_auto_increment_blank_dropdown);
        this.mAutoIncrementAnswer = mAutoIncrementAnswer;
        mLeftText =findViewById(R.id.tv_title);
        spinner = findViewById(R.id.spinner_drop_down);
        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
        this.index=index;
    }

    @Override
    public void bind() {
        if(type.equals("look")) {
            //查看状态不可滑动
            spinner.setEnabled(false);
        }else {
            //编辑状态滑动
            spinner.setEnabled(true);
        }
        //获取title
        title= StringUtils.getTitle(mData.getTitle(),mData.isMust());
        //设置title
        mLeftText.setText(title);
        //判空
        if(mAutoIncrementAnswer!=null && mAutoIncrementAnswer.mAnswers!=null) {
            if (mAutoIncrementAnswer.mAnswers.size() > index && mAutoIncrementAnswer.mAnswers.get(index).size() > getAdapterPosition()) {
                if (!StringUtils.isEmpty(mData.getOpText())) {
                    list.clear();
                    list.add(TextViewUtil.getString(R.string.please_select));
                    String[] opt = mData.getOpText().split(",");
                    list.addAll(Arrays.asList(opt));
                    //判空，防止再次刷新时，状态重置
                    if (map.get(getAdapterPosition()) == null) {
                        SpinnerIncreAdapter spinnerAdapter = new SpinnerIncreAdapter(itemView.getContext(), list);
                        spinner.setAdapter(spinnerAdapter);
                        map.put(getAdapterPosition(), spinnerAdapter);
                    } else {
                        SpinnerIncreAdapter spinnerAdapter = map.get(getAdapterPosition());
                        spinner.setAdapter(spinnerAdapter);
                    }

                    value = (String) mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).get(QueFormat.KEY_VALUE);
                    if (!StringUtils.isEmpty(value)) {
                        for (int i = 0; i < list.size(); i++) {
                            String opCode = list.get(i);
                            if (value.contains(opCode)) {
                                spinner.setSelection(i, true);
                                break;
                            }
                        }
                    }
                    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            mAutoIncrementAnswer.mAnswers.get(index).get(getAdapterPosition()).put(QueFormat.KEY_VALUE, list.get(position));
                            //0的时候是“请选择”
                            if (position >= 1) {
                                if (onChildClickLisener != null) {
                                    onChildClickLisener.onChildClick();
                                }
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
                }
            }
        }
    }

    private boolean checkValue(String pattern, Object value) {
        return RegexUtils.isMatch(pattern, String.valueOf(value));
    }
}
