package com.dimeno.dimenoquestion.ui.adpter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.actvity.AnswerListActivity;
import com.dimeno.dimenoquestion.ui.actvity.DoSurveyActivity;
import com.dimeno.dimenoquestion.ui.actvity.EditSurveyActivity;
import com.dimeno.dimenoquestion.ui.presenter.EditSurePresenter;

import java.io.Serializable;

import static com.blankj.utilcode.util.ActivityUtils.startActivity;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AnswerListAdapter extends BaseQuickAdapter<Answer, BaseViewHolder> {
    private Context mContext;

    /**
     * 构造器
     * @param mContext
     * @param layoutId
     */
    public AnswerListAdapter(Context mContext, int layoutId) {
        super(layoutId);
        this.mContext = mContext;
    }

    @Override
    protected void convert(final BaseViewHolder helper, final Answer item) {
        //这里的答卷编号只是页面展示，没什么作用
        helper.setText(R.id.tvAnswerCode, "答卷编码: " + item.getAnswerStartTime());
        helper.setText(R.id.tvTime, "答题时间: " + TimeUtil.getTime(item.getAnswerStartTime()));

        helper.setGone(R.id.rlUploadBtnLayout, TextUtils.isEmpty(item.getTest()) ? false : (item.getTest().equals("1") ? true : false));
        helper.setGone(R.id.btnUploadRecord, TextUtils.isEmpty(item.getTest()) ? false : (item.getTest().equals("1") ? true : false));
        int state = item.getAnswerState();

        /**
         * 0 是未上传(继续编辑)
         * 1 是有网已上传
         * 2 是保存在本地，未上传（上传问卷）
         */
        if (state == AnswerState.EDIT) {
            //未提交
            helper.setGone(R.id.rlUploadBtnLayout, true);
            helper.setGone(R.id.btnUpload, false);
            helper.setGone(R.id.edit_answer, true);
            helper.setGone(R.id.ivDone, false);
            helper.setGone(R.id.tvUploadStatus, false);
        }else if (state == AnswerState.COMPLETE) {
            //等待上传
            helper.setGone(R.id.rlUploadBtnLayout, true);
            helper.setGone(R.id.btnUpload, true);
            helper.setGone(R.id.edit_answer, false);
            helper.setGone(R.id.ivDone, false);
            helper.setGone(R.id.tvUploadStatus, false);
        } else if (state == AnswerState.UPLOAD) {
            //已上传
            helper.setGone(R.id.edit_answer, false);
            helper.setGone(R.id.btnUpload, false);
            helper.setGone(R.id.ivDone, false);
            helper.setGone(R.id.tvUploadStatus, true);
            if (TextUtils.isEmpty(item.getTest()) && "1".equals(item.getTest())) {
                helper.setGone(R.id.rlUploadBtnLayout, true);
            } else {
                helper.setGone(R.id.rlUploadBtnLayout, false);
            }
        }

        //编辑答题
        helper.setOnClickListener(R.id.edit_answer, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //继续编辑
                Intent intent = new Intent();
                intent.setClass(mContext, EditSurveyActivity.class);
                intent.putExtra("type", "edit");
                intent.putExtra("answerID", item.getId() + "");
                ((Activity) mContext).startActivityForResult(intent, 1);
            }
        });

        //上传答案
        helper.setOnClickListener(R.id.btnUpload, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //上传答案
                if (myOnItemClickListener != null) {
                    myOnItemClickListener.onItemClick(helper.getAdapterPosition(), item);
                }
            }
        });

        //查看&编辑
        helper.setOnClickListener(R.id.llItem, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (state == AnswerState.COMPLETE) {
//                    //查看
//                    Intent intent = new Intent();
//                    intent.setClass(mContext, EditSurveyActivity.class);
//                    intent.putExtra("type", "edit");
//                    intent.putExtra("answerID", item.getId() + "");
//                    startActivity(intent);
//                }
                if (state == AnswerState.UPLOAD) {
                    //查看
                    Intent intent = new Intent();
                    intent.setClass(mContext, EditSurveyActivity.class);
                    intent.putExtra("type", "look");
                    intent.putExtra("answerID", item.getId() + "");
                    startActivity(intent);
                }
            }
        });

        //删除答案
        helper.setOnLongClickListener(R.id.llItem, new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (state == AnswerState.UPLOAD) {
                    if (myOnItemClickListener != null) {
                        myOnItemClickListener.onItemLongClick(helper.getAdapterPosition(), item);
                    }
                }
                return true;
            }
        });
    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private MyOnItemClickListener myOnItemClickListener;

    public interface MyOnItemClickListener {
        void onItemClick(int positon, Answer answer);

        void onItemLongClick(int positon, Answer answer);
    }
}
