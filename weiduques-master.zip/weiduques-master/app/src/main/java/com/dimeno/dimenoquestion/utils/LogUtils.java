package com.dimeno.dimenoquestion.utils;

import android.content.Context;
import android.os.Environment;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.DeviceUtils;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.constant.Constant;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.db.UserOperationLog;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by PNJ
 * Time 2021/4/27
 * Describe 日记工具类
 */
public class LogUtils {

    /**
     * 是否把日志写入文件
     */
    public static Boolean MYLOG_WRITE_TO_FILE = true;
    /**
     * 允许输出log等级
     */
    private static int mDebuggable = LogUtils.LEVEL_ALL;


    /**
     * 日志输出时的TAG
     */
    private static String mTag = "Infoss";


    /**
     * 日志输出级别NONE
     */
    public static final int LEVEL_OFF = 0;
    /**
     * 日志输出级别NONE
     */
    public static final int LEVEL_ALL = 7;

    /**
     * 日志输出级别V
     */
    public static final int LEVEL_VERBOSE = 1;
    /**
     * 日志输出级别D
     */
    public static final int LEVEL_DEBUG = 2;
    /**
     * 日志输出级别I
     */
    public static final int LEVEL_INFO = 3;
    /**
     * 日志输出级别W
     */
    public static final int LEVEL_WARN = 4;
    /**
     * 日志输出级别E
     */
    public static final int LEVEL_ERROR = 5;
    /**
     * 日志输出级别S,自定义定义的一个级别
     */
    public static final int LEVEL_SYSTEM = 6;

    /**
     * 用于记时的变量
     */
    private static long mTimestamp = 0;
    /**
     * 写文件的锁对象
     */
    private static final Object mLogLock = new Object();

    private static String MYLOGFILEName = "_weiduques.txt";// 本类输出的日志文件名
    private static String MYLOG_PATH_SDCARD_DIR = "weiduques/diary";// 日志文件在sdcard中的路径
    public static String MYLOG_PATH = Constant.MYLOG_PATH;//日记保存地址
    private static int SDCARD_LOG_FILE_SAVE_DAYS = 2;// sd卡中日志文件的最多保存天
    private static SimpleDateFormat myLogSdf = new SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss");// 日志的输出格�??
    private static SimpleDateFormat logfile = new SimpleDateFormat("yyyy-MM-dd");// 日志文件格式
    /**---------------日志输出,已固定TAG  begin---------------**/
    /**
     * 以级别为 d 的形式输出LOG
     */
    public static void v(String msg) {
        if (mDebuggable >= LEVEL_VERBOSE) {
            Log.v(mTag, msg);
        }
    }

    /**
     * 以级别为 d 的形式输出LOG
     */
    public static void d(String msg) {
        if (mDebuggable >= LEVEL_DEBUG) {
            Log.d(mTag, msg);
        }
    }

    /**
     * 以级别为 i 的形式输出LOG
     */
    public static void i(String msg) {
        if (mDebuggable >= LEVEL_INFO) {
            Log.i(mTag, msg);
        }
    }

    /**
     * 以级别为 w 的形式输出LOG
     */
    public static void w(String msg) {
        if (mDebuggable >= LEVEL_WARN) {
            Log.w(mTag, msg);
        }
    }

    /**
     * 以级别为 w 的形式输出Throwable
     */
    public static void w(Throwable tr) {
        if (mDebuggable >= LEVEL_WARN) {
            Log.w(mTag, "", tr);
        }
    }

    /**
     * 以级别为 w 的形式输出LOG信息和Throwable
     */
    public static void w(String msg, Throwable tr) {
        if (mDebuggable >= LEVEL_WARN && null != msg) {
            Log.w(mTag, msg, tr);
        }
    }

    /**
     * 以级别为 e 的形式输出LOG
     */
    public static void e(String msg) {
        if (mDebuggable >= LEVEL_ERROR) {
            Log.e(mTag, msg);
        }
    }

    /**
     * 以级别为 s 的形式输出LOG,主要是为了System.out.println,稍微格式化了一下
     */
    public static void sf(String msg) {
        if (mDebuggable >= LEVEL_ERROR) {
            System.out.println("----------" + msg + "----------");
        }
    }

    /**
     * 以级别为 s 的形式输出LOG,主要是为了System.out.println
     */
    public static void s(String msg) {
        if (mDebuggable >= LEVEL_ERROR) {
            System.out.println(msg);
        }
    }

    /**
     * 以级别为 e 的形式输出Throwable
     */
    public static void e(Throwable tr) {
        if (mDebuggable >= LEVEL_ERROR) {
            Log.e(mTag, "", tr);
        }
    }

    /**
     * 以级别为 e 的形式输出LOG信息和Throwable
     */
    public static void e(String msg, Throwable tr) {
        if (mDebuggable >= LEVEL_ERROR && null != msg) {
            Log.e(mTag, msg, tr);
        }
    }

    /**---------------日志输出,已固定TAG  end---------------**/

    /**---------------日志输出,未固定TAG  begin---------------**/
    /**
     * 以级别为 d 的形式输出LOG
     */
    public static void v(String tag, String msg) {
        if (mDebuggable >= LEVEL_VERBOSE) {
            Log.v(tag, msg);
        }
    }

    /**
     * 以级别为 d 的形式输出LOG
     */
    public static void d(String tag, String msg) {
        if (mDebuggable >= LEVEL_DEBUG) {
            Log.d(tag, msg);
        }
    }

    /**
     * 以级别为 d 的形式输出LOG
     */
    public static void dw(String tag, String msg) {
        if (mDebuggable >= LEVEL_DEBUG) {
            Log.d(tag, msg);
            if (MYLOG_WRITE_TO_FILE)
                writeLogtoFile(String.valueOf(mDebuggable), tag, msg);
        }
    }

    /**
     * 以级别为 i 的形式输出LOG
     */
    public static void i(String tag, String msg) {
        if (mDebuggable >= LEVEL_INFO) {
            Log.i(tag, msg);
        }
    }

    /**
     * 以级别为 w 的形式输出LOG
     */
    public static void w(String tag, String msg) {
        if (mDebuggable >= LEVEL_WARN) {
            Log.w(tag, msg);
        }
    }

    /**
     * 以级别为 e 的形式输出LOG
     */
    public static void e(String tag, String msg) {
        if (mDebuggable >= LEVEL_ERROR) {
            Log.e(tag, msg);
            if (MYLOG_WRITE_TO_FILE)
                writeLogtoFile(String.valueOf(mDebuggable), tag, msg);
        }
    }

    /**---------------日志输出,未固定TAG  end---------------**/

    /**
     * 把Log存储到文件中
     *
     * @param log  需要存储的日志
     * @param path 存储路径
     */
    public static void log2File(String log, String path) {
        log2File(log, path, true);
    }

    public static void log2File(String log, String path, boolean append) {
        synchronized (mLogLock) {
            FileUtils.writeFile(log + "\r\n", path, append);
        }
    }

    /**
     * 以级别为 e 的形式输出msg信息,附带时间戳，用于输出一个时间段起始点
     *
     * @param msg 需要输出的msg
     */
    public static void msgStartTime(String msg) {
        mTimestamp = System.currentTimeMillis();
        if (!TextUtils.isEmpty(msg)) {
            e("[Started：" + mTimestamp + "]" + msg);
        }
    }

    /**
     * 以级别为 e 的形式输出msg信息,附带时间戳，用于输出一个时间段结束点* @param msg 需要输出的msg
     */
    public static void elapsed(String msg) {
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - mTimestamp;
        mTimestamp = currentTime;
        e("[Elapsed：" + elapsedTime + "]" + msg);
    }

    public static <T> void printList(List<T> list) {
        if (list == null || list.size() < 1) {
            return;
        }
        int size = list.size();
        i("---begin---");
        for (int i = 0; i < size; i++) {
            i(i + ":" + list.get(i).toString());
        }
        i("---end---");
    }

    public static <T> void printArray(T[] array) {
        if (array == null || array.length < 1) {
            return;
        }
        int length = array.length;
        i("---begin---");
        for (int i = 0; i < length; i++) {
            i(i + ":" + array[i].toString());
        }
        i("---end---");
    }

    /**
     * 根据tag, msg和等级，输出日志
     *
     * @param tag
     * @param msg
     * @param level
     * @return void
     * @since v 1.0
     */
    private static void log(String tag, String msg, char level) {
        if (mDebuggable >= LEVEL_ERROR) {
            if (MYLOG_WRITE_TO_FILE)
                writeLogtoFile(String.valueOf(level), tag, msg);
        }
    }

    private static String getLogPath() {
        String path = "";
        // 获取扩展SD卡设备状�??
        String sDStateString = android.os.Environment.getExternalStorageState();

        // 拥有可读可写权限
        if (sDStateString.equals(android.os.Environment.MEDIA_MOUNTED)) {
            // 获取扩展存储设备的文件目�??
            File SDFile = android.os.Environment.getExternalStorageDirectory();
            path = SDFile.getAbsolutePath() + File.separator
                    + MYLOG_PATH_SDCARD_DIR;
        }
        return path;

    }

    /**
     * 打开日志文件并写入日�??
     *
     * @return
     **/
    private static void writeLogtoFile(String mylogtype, String tag, String text) {// 新建或打�??日志文件
        Date nowtime = new Date();
        String needWriteFiel = logfile.format(nowtime);
        String needWriteMessage =
                "---------------------------------------------------------\n" +
                        myLogSdf.format(nowtime) + "\n"
                        + tag + "    " + mylogtype + "\n" + text +
                        "\n---------------------------------------------------------\n\n";


        // 取得日志存放目录
        String path = MYLOG_PATH;
        if (path != null && !"".equals(path)) {
            try {
                // 创建目录
                File dir = new File(path);
                if (!dir.exists())
                    dir.mkdir();
                // 打开文件
                File file = new File(path + File.separator + needWriteFiel
                        + MYLOGFILEName);
                FileWriter filerWriter = new FileWriter(file, true);// 后面这个参数代表是不是要接上文件中原来的数据，不进行覆盖
                BufferedWriter bufWriter = new BufferedWriter(filerWriter);
                bufWriter.write(needWriteMessage);
                bufWriter.newLine();
                bufWriter.close();
                filerWriter.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

//    /**
//     * 删除制定的日志文�??
//     * */
//    public static void delFile() {// 删除日志文件
//        // 取得日志存放目录
//        String path = getLogPath();
//        if (path != null && !"".equals(path)) {
//            String needDelFiel = logfile.format(getDateBefore());
//            File file = new File(path, needDelFiel + MYLOGFILEName);
//            if (file.exists()) {
//                file.delete();
//            }
//        }
//    }

    /**
     * 得到现在时间前的几天日期，用来得到需要删除的日志文件�??
     */
    private static Date getDateBefore() {
        Date nowtime = new Date();
        Calendar now = Calendar.getInstance();
        now.setTime(nowtime);
        now.set(Calendar.DATE, now.get(Calendar.DATE)
                - SDCARD_LOG_FILE_SAVE_DAYS);
        return now.getTime();
    }

    /**
     * 删除超过时间规定的日志文件
     */
    public static void delFile() {
        // 取得日志存放目录
        String path = MYLOG_PATH;
        if (path != null && !"".equals(path)) {
            File file = new File(path);
            if (file.exists()) {
                File[] files = file.listFiles();// 读取
                if (files != null && files.length > 0) {
                    getFileName(files);
                }
            }
        }
    }


    private static void getFileName(File[] files) {
        if (files != null) {// 先判断目录是否为空，否则会报空指针
            //最迟保留的时间
            String needDay = logfile.format(getDateBefore());
            for (File file : files) {
                if (file.isDirectory()) {
                    getFileName(file.listFiles());
                } else {
                    String fileName = file.getName();
                    if (fileName.endsWith(MYLOGFILEName)) {
                        String fileDay = fileName.substring(0,
                                fileName.lastIndexOf(MYLOGFILEName)).toString();
                        if (!compareDate(needDay, fileDay)) {
                            file.delete();
                        }
                    }
                }
            }
        }
    }

    /**
     * 比较两个时间
     *
     * @param nowDate
     * @param compareDate
     * @return
     */
    public static boolean compareDate(String nowDate, String compareDate) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date now = df.parse(nowDate);
            Date compare = df.parse(compareDate);
            if (now.before(compare)) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 获取文件
     *
     * @return
     */
    public static List<String> getFile() {
        File file = new File(MYLOG_PATH);
        if (file.exists()) {
            List<String> list = new ArrayList<>();
            String[] files = file.list();// 读取
            if (files != null && files.length > 0) {
                list.addAll(Arrays.asList(files));
                return list;
            }
        }
        return null;
    }

    /**
     * @desc 添加日志到本地数据库，以便查询各种操作信息等
     * @param api 接口的api
     * @param operationType 操作类型
     * @param operationDesc 操作详情描述
     * @param data 待保存的数据
     */
    public static void addLog(String api,int operationType, String queId,Long answerStartTime,String operationDesc, String data) {
        UserOperationLog log = new UserOperationLog();
        log.queId=queId;
        log.answerStartTime=answerStartTime;
        log.logId = UUIDUtil.getUUID();
        log.userId = UserUtil.getUserId();
        log.userName = UserUtil.getUserName();
        log.userAccount = UserUtil.getAccount();
        log.createTime = TimeUtil.getCurrentTime();
        log.appVersionCode = AppUtils.getAppVersionCode();
        log.appVersionName = AppUtils.getAppVersionName();
        log.versionName = DeviceUtils.getSDKVersionName();
        log.versionCode = DeviceUtils.getSDKVersionCode();
        log.manufacturer = DeviceUtils.getManufacturer();
        log.model = DeviceUtils.getModel();
        log.api = api;
        log.operationType = operationType;
        log.operationDesc = operationDesc;
        log.isUpload = ConstantType.UserOperationLog_isUpload.NO_UPLOAD;
        log.data = data;
        log.type = 2;
        log.save();
    }

    /**
     * @desc 添加日志到本地数据库，以便查询各种操作信息等
     * @param api 接口的api
     * @param operationType 操作类型
     * @param operationDesc 操作详情描述
     * @param data 待保存的数据
     */
    public static UserOperationLog addLog2(String api,int operationType, String queId,Long answerStartTime,String operationDesc, String data) {
        UserOperationLog log = new UserOperationLog();
        log.queId=queId;
        log.answerStartTime=answerStartTime;
        log.logId = UUIDUtil.getUUID();
        log.userId = UserUtil.getUserId();
        log.userName = UserUtil.getUserName();
        log.userAccount = UserUtil.getAccount();
        log.createTime = TimeUtil.getCurrentTime();
        log.appVersionCode = AppUtils.getAppVersionCode();
        log.appVersionName = AppUtils.getAppVersionName();
        log.versionName = DeviceUtils.getSDKVersionName();
        log.versionCode = DeviceUtils.getSDKVersionCode();
        log.manufacturer = DeviceUtils.getManufacturer();
        log.model = DeviceUtils.getModel();
        log.api = api;
        log.operationType = operationType;
        log.operationDesc = operationDesc;
        log.isUpload = ConstantType.UserOperationLog_isUpload.NO_UPLOAD;
        log.data = data;
        log.type = 2;
        log.save();

        return log;
    }
}
