package com.dimeno.dimenoquestion.bean;

import java.util.List;
import java.util.Map;

/**
 * DataEntity
 * Created by wangzhen on 2020/5/11.
 */
public class DataEntity {
    public List<String> provinces;
    public Map<String, List<String>> citiesMap;
    public Map<String, List<String>> districtsMap;
    public Map<String, List<String>> streetsMap;
}
