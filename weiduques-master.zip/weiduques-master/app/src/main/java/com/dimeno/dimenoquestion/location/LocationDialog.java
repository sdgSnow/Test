package com.dimeno.dimenoquestion.location;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.Poi;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.PoiInfo;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.poi.OnGetPoiSearchResultListener;
import com.baidu.mapapi.search.poi.PoiDetailResult;
import com.baidu.mapapi.search.poi.PoiDetailSearchResult;
import com.baidu.mapapi.search.poi.PoiIndoorResult;
import com.baidu.mapapi.search.poi.PoiNearbySearchOption;
import com.baidu.mapapi.search.poi.PoiResult;
import com.baidu.mapapi.search.poi.PoiSearch;
import com.blankj.utilcode.util.Utils;
import com.dimeno.dimenoquestion.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 定位选择弹窗
 * Created by wangzhen on 2020/9/9.
 */
public class LocationDialog extends DialogFragment implements onSyncAddressCallback {
    private static final float ZOOM = 18.0f;
    private LocationClient mLocationClient;
    private BaiduMap mBaiduMap;
    private MapView mMapView;
    private TextView mTvAddress;
    private Callback mCallback;
    private String mAddress;
    private double mLatitude;
    private double mLongitude;
    // 是否可自定义选点
    private boolean mCustomLocation = false;
    private PoiAdapter mPoiAdapter;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.LocationDialog);
        View view = View.inflate(getActivity(), R.layout.dialog_location, null);
        initViews(view);
        builder.setView(view);
        return builder.create();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getCurrentLocation();
    }

    /**
     * 获取并显示当前位置
     */
    private void getCurrentLocation() {
        mLocationClient = getClient();
        mLocationClient.registerLocationListener(new BDAbstractLocationListener() {

            @Override
            public void onReceiveLocation(BDLocation location) {
                mLatitude = location.getLatitude();
                mLongitude = location.getLongitude();
                mAddress = location.getAddrStr();

                mBaiduMap.clear();
                // 显示当前位置
                MyLocationData locationData = new MyLocationData.Builder().latitude(mLatitude).longitude(mLongitude).build();
                mBaiduMap.setMyLocationData(locationData);
                mBaiduMap.animateMapStatus(
                        MapStatusUpdateFactory.newLatLngZoom(new LatLng(mLatitude, mLongitude), ZOOM)
                );
                mTvAddress.setText(mAddress);

                // 显示poi列表
                List<Poi> poiList = location.getPoiList();
                if (poiList != null && !poiList.isEmpty()) {
                    List<PoiEntity> list = new ArrayList<>();
                    for (Poi poi : poiList) {
                        PoiEntity entity = new PoiEntity();
                        entity.name = poi.getName();
                        entity.address = poi.getAddr();
                        entity.latitude = 0;
                        entity.longitude = 0;
                        list.add(entity);
                    }
                    mPoiAdapter.setData(list);
                }
            }
        });
        LocationClientOption option = new LocationClientOption();
        // 默认gcj02，设置返回的定位结果坐标系，如果配合百度地图使用，建议设置为bd09ll
        option.setCoorType("bd09ll");
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);
        option.setOnceLocation(true);
        option.setIsNeedAddress(true);
        option.setNeedDeviceDirect(true);
        option.setIsNeedLocationPoiList(true);
        mLocationClient.setLocOption(option);
        mLocationClient.start();
    }

    private LocationClient getClient() {
        if (mLocationClient == null) {
            return mLocationClient = new LocationClient(getActivity());
        }
        return mLocationClient;
    }

    private void initViews(View view) {
        view.findViewById(R.id.btn_get_location).setOnClickListener((v) -> getCurrentLocation());
        view.findViewById(R.id.btn_cancel).setOnClickListener((v) -> dismiss());
        view.findViewById(R.id.btn_confirm).setOnClickListener((v) -> {
            dismissWithValue();
        });

        RecyclerView recycler = view.findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(recycler.getContext()));
        recycler.setAdapter(mPoiAdapter = new PoiAdapter(null, this));

        mTvAddress = view.findViewById(R.id.tv_address);
        mMapView = view.findViewById(R.id.map);
        mMapView.showZoomControls(false);

        if (mCustomLocation) {
            recycler.setVisibility(View.VISIBLE);
        } else {
            recycler.setVisibility(View.GONE);
        }

        mBaiduMap = mMapView.getMap();
        mBaiduMap.setMyLocationEnabled(true);
        mBaiduMap.setOnMapClickListener(mCustomLocation ? new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                addMarker(latLng);
            }

            @Override
            public void onMapPoiClick(MapPoi mapPoi) {
                addMarker(mapPoi.getPosition(), mapPoi.getName());
            }
        } : null);
    }

    /**
     * 显示地图选点并逆解析地址
     *
     * @param latLng latLng
     */
    private void addMarker(LatLng latLng) {
        addMarker(latLng, null);
    }

    /**
     * 显示地图选点并逆解析地址
     *
     * @param latLng  latLng
     * @param poiName poi name
     */
    private void addMarker(LatLng latLng, String poiName) {
        mLatitude = latLng.latitude;
        mLongitude = latLng.longitude;

        mBaiduMap.clear();
        mBaiduMap.animateMapStatus(
                MapStatusUpdateFactory.newLatLngZoom(new LatLng(mLatitude, mLongitude), ZOOM)
        );
        mBaiduMap.addOverlay(new MarkerOptions().position(latLng).icon(
                BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_marker)
        ));

        GeoCoder geoCoder = GeoCoder.newInstance();
        geoCoder.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {
            @Override
            public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {

            }

            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {
                mAddress = reverseGeoCodeResult.getAddress();
                if (!TextUtils.isEmpty(poiName)) {
                    mAddress += poiName;
                }
                mTvAddress.setText(mAddress);
                searchPoiNearby(latLng, mAddress);
            }
        });
        geoCoder.reverseGeoCode(new ReverseGeoCodeOption().location(latLng));
    }

    /**
     * 搜索附近poi
     *
     * @param location location
     * @param keyword  keyword
     */
    private void searchPoiNearby(LatLng location, String keyword) {
        PoiSearch poiSearch = PoiSearch.newInstance();
        poiSearch.setOnGetPoiSearchResultListener(new OnGetPoiSearchResultListener() {
            @Override
            public void onGetPoiResult(PoiResult poiResult) {
                List<PoiInfo> allPoi = poiResult.getAllPoi();
                if (allPoi != null && !allPoi.isEmpty()) {
                    List<PoiEntity> list = new ArrayList<>();
                    for (PoiInfo poi : allPoi) {
                        PoiEntity entity = new PoiEntity();
                        entity.name = poi.name;
                        entity.address = poi.address;
                        entity.latitude = poi.location.latitude;
                        entity.longitude = poi.location.longitude;
                        list.add(entity);
                    }
                    mPoiAdapter.setData(list);
                }
            }

            @Override
            public void onGetPoiDetailResult(PoiDetailResult poiDetailResult) {

            }

            @Override
            public void onGetPoiDetailResult(PoiDetailSearchResult poiDetailSearchResult) {

            }

            @Override
            public void onGetPoiIndoorResult(PoiIndoorResult poiIndoorResult) {

            }
        });
        poiSearch.searchNearby(new PoiNearbySearchOption().keyword(keyword).location(location).radius(500));
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null) {
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            Window window = dialog.getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.width = Utils.getApp().getResources().getDisplayMetrics().widthPixels * 9 / 10;
            window.setAttributes(attributes);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mMapView.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();
    }

    public LocationDialog setCustomLocation(boolean custom) {
        this.mCustomLocation = custom;
        return this;
    }

    public LocationDialog setCallback(Callback callback) {
        this.mCallback = callback;
        return this;
    }

    @Override
    public void onSync(PoiEntity entity) {
        this.mAddress = entity.address;
        if (!TextUtils.isEmpty(entity.name)) {
            this.mAddress += entity.name;
        }
        this.mLatitude = entity.latitude;
        this.mLongitude = entity.longitude;
        dismissWithValue();
    }

    public void dismissWithValue() {
        if (mCallback != null) {
            mCallback.onConfirm(mAddress, mLatitude, mLongitude);
        }
        super.dismiss();
    }

    public interface Callback {
        void onConfirm(String address, double latitude, double longitude);
    }
}
