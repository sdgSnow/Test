package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.db.Answer;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface DiaryUpView extends BaseView {
    /**
     * oss成功回调
     * @param ossInfoEntity
     * @param filepath
     */
    void success(OssInfoEntity ossInfoEntity,String filepath);
    void success(UploadEntity entity,Answer answer);
}
