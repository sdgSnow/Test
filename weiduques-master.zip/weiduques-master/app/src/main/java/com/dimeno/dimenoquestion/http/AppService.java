package com.dimeno.dimenoquestion.http;



import com.dimeno.dimenoquestion.bean.AboutUsBean;
import com.dimeno.dimenoquestion.bean.ExceptionLog;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.ResultBean;
import com.dimeno.dimenoquestion.bean.UploadEntity;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.db.UserOperationLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PartMap;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

/**
 * Created by ali on 2017/2/16.
 */

public interface AppService {
    /**
     * 登录
     *
     * @param cacheControl 缓存
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @POST("api/QueApp/EntryStaffLogin")
    Observable<Res<UserEntity>> loginUser(@Header("Cache-Control") String cacheControl, @QueryMap(encoded = true) Map<String, String> params);
    /**
     * 修改密码
     *
     * @param cacheControl 缓存
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @POST("api/des/updatePwd")
    Observable<Res<UserEntity>> updatePwd(@Header("Cache-Control") String cacheControl, @QueryMap(encoded = true) Map<String, String> params);

    /**
     * 获得问卷列表
     *
     * @param cacheControl 缓存
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @GET("api/QueApp/GetQueListByUid")
    Observable<Res<ArrayList<NewQuesBean>>> loadQuesList(@Header("Cache-Control") String cacheControl, @QueryMap(encoded = true) Map<String, String> params);
    /**
     * 获得问卷
     *
     * @param cacheControl 缓存
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @GET("api/Que/GetQueDetailsById")
    Observable<Res<ResultBean>> loadQues(@Header("Cache-Control") String cacheControl, @QueryMap(encoded = true) Map<String, String> params);


    /**
     * ‘关于我们’信息
     *
     * @param cacheControl
     * @param ProCode
     * @return
     */
    @GET("api/Que/GetAboutUs")
    Observable<Res<AboutUsBean>> getAboutUs(@Header("Cache-Control") String cacheControl, @Query("ProCode") String ProCode);


    /**
     * 获取OSS信息
     *
     * @param cacheControl
     * @return QueApp/
     */

    @POST("api/AliYun/GetToken")
    Observable<OssInfoEntity> getOssInfo(@Header("Cache-Control") String cacheControl);

    /**
     * 修改密码
     *
     * @param cacheControl @Header("Cache-Control") 是缓存
     * @param params       params
     * @return Observable
     */
//    @PUT("/api/EntryStaff/ModifyPwd")
//    Observable<ModifyPwdEntity> modifyPwd(@Header("Cache-Control") String cacheControl, @QueryMap(encoded = true) Map<String, String> params);


    /**
     * 上传答卷
     * <P @FieldMap的post提交一定要加@FormUrlEncoded注解,不然报错
     *
     * @param cacheControl 缓存
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @Multipart//需要添加头
    @POST("api/Answer/SaveAnswer")
    Observable<UploadEntity> saveAnswer(@Header("Cache-Control") String cacheControl, @PartMap() Map<String, RequestBody> maps);
    /**
     * 上传答卷
     * <P @FieldMap的post提交一定要加@FormUrlEncoded注解,不然报错
     *
     * @return Observable
     * @Header("Cache-Control") String cacheControl是缓存 />
     */
    @POST("api/quescore/queLog/addBatch")
    Observable<Res<String>> addBatch( @Body List<UserOperationLog> list);

    @POST("api/quescore/exceptionLog/add")
    Observable<Res<String>> exceptionLog( @Body ExceptionLog exceptionLog);

    /**
     * 通知消息列表
     *
     * @param cacheControl
     * @return
     */
    @GET("api/AppInfo/getAppMessages")
    Observable<Res<MessageEntity>> getAppMessages(@Header("Cache-Control") String cacheControl, @QueryMap() Map<String, Object> maps);
}
