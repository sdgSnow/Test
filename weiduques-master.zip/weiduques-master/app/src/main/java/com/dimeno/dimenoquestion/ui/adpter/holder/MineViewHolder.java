package com.dimeno.dimenoquestion.ui.adpter.holder;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.MineBean;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class MineViewHolder extends RecyclerViewHolder<MineBean> {

    private final ImageView iv_mine_icon;
    private final TextView tv_mine_content;

    /**
     * 构造器
     * @param parent
     */
    public MineViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_mine);
        iv_mine_icon = findViewById(R.id.iv_mine_icon);
        tv_mine_content = findViewById(R.id.tv_mine_content);
    }

    @Override
    public void bind() {
        iv_mine_icon.setImageResource(mData.icon);
        tv_mine_content.setText(mData.name);
    }
}
