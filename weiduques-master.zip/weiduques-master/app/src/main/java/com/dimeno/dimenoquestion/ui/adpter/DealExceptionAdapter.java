package com.dimeno.dimenoquestion.ui.adpter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.actvity.EditSurveyActivity;

import java.util.ArrayList;
import java.util.List;

import static com.blankj.utilcode.util.ActivityUtils.startActivity;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class DealExceptionAdapter extends BaseQuickAdapter<Answer, BaseViewHolder> {
    private Context mContext;

    private List<Integer> list=new ArrayList<>();

    /**
     * DealExceptionAdapter构造器
     * @param mContext
     * @param layoutId
     */
    public DealExceptionAdapter(Context mContext, int layoutId) {
        super(layoutId);
        this.mContext = mContext;
    }

    @Override
    protected void convert(final BaseViewHolder helper, final Answer item) {
        //这里的答卷编号只是页面展示，没什么作用
        helper.setText(R.id.tvAnswerCode, "答卷编码: " + item.getAnswerStartTime());
        helper.setText(R.id.tvTime, "答题时间: " + TimeUtil.getTime(item.getAnswerStartTime()));
        //list包含该position
        if(list.contains(helper.getAdapterPosition())){
            //选择
            helper.setChecked(R.id.cbox,true);
        }else {
            //不选择
            helper.setChecked(R.id.cbox,false);
        }

        if(helper.getAdapterPosition()==0){
            //第一个位置显示
            helper.setGone(R.id.other,true);
        }else {
            //隐藏
            helper.setGone(R.id.other,false);
        }
        //监听
        helper.setOnClickListener(R.id.llItem, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //如果包含
                if(list.contains(helper.getAdapterPosition())){
                    //清空
                    list.clear();
                }else {
                    //不包含，清空
                    list.clear();
                    //添加
                    list.add(helper.getAdapterPosition());
                }
                if(myOnItemClickListener!=null){
                    //监听器不为空，回调
                    myOnItemClickListener.onItemClick(helper.getAdapterPosition(),item);
                }
                //刷新
                notifyDataSetChanged();
            }
        });

    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private MyOnItemClickListener myOnItemClickListener;

    /**
     * 监听器
     */
    public interface MyOnItemClickListener {
        void onItemClick(int positon, Answer answer);
        void onItemLongClick(int positon, Answer answer);
    }
}
