package com.dimeno.dimenoquestion.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.dimeno.common.base.BaseApplication;
import com.dimeno.dimenoquestion.constant.SpConstant;


public class SpUtil {

    private static SpUtil sInstance;
    public static SpUtil get() {
        if (sInstance == null)
            sInstance = new SpUtil();
        return sInstance;
    }

    private void setValue(String spType,String spName,String value){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(spName,value).commit();
    }

    private String getStringValue(String spType,String spName){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        String spValue = sp.getString(spName, "");
        return spValue;
    }

    private void setValue(String spType,String spName,int value){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putInt(spName,value).commit();
    }

    private int getIntValue(String spType,String spName){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        int spValue = sp.getInt(spName, 0);
        return spValue;
    }

    private void setValue(String spType,String spName,boolean value){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putBoolean(spName,value).commit();
    }

    private boolean getBooleanValue(String spType,String spName){
        SharedPreferences sp = BaseApplication.getContext().getSharedPreferences(spType, Context.MODE_PRIVATE);
        boolean spValue = sp.getBoolean(spName, false);
        return spValue;
    }

    public void clear(){
        setPsw("");
        setAccount("");
        setUserName("");
        setUserId("");
        setLogin(false);
        setUploadWay(1);
    }

    public void setPsw(String psw){
        setValue(SpConstant.SP_PSW,"psw",psw);
    }

    public String getPsw(){
        return getStringValue(SpConstant.SP_PSW,"psw");
    }

    public void setAccount(String account){
        setValue(SpConstant.SP_ACCOUNT,"account",account);
    }

    public String getAccount(){
        return getStringValue(SpConstant.SP_ACCOUNT,"account");
    }

    public void setUserName(String userName) {
        setValue(SpConstant.SP_NAME,"userName",userName);
    }

    public String getUserName() {
        return getStringValue(SpConstant.SP_NAME,"userName");
    }

    public void setUserId(String userId) {
        setValue(SpConstant.SP_USER_ID,"userId",userId);
    }

    public String getUserId() {
        return getStringValue(SpConstant.SP_USER_ID,"userId");
    }

    public void setLogin(boolean login) {
        setValue(SpConstant.SP_IS_LOGIN,"login",login);
    }

    public boolean isLogin() {
        return getBooleanValue(SpConstant.SP_IS_LOGIN,"login");
    }

    public void setUploadWay(int uploadWay) {
        setValue(SpConstant.SP_UPLOAD_WAY,"uploadWay",uploadWay);
    }

    public int getUploadWay() {
        return getIntValue(SpConstant.SP_UPLOAD_WAY,"uploadWay");
    }


    public void setsInstance(boolean login) {
        setValue(SpConstant.SInitialize,"SInitialize",login);
    }

    public boolean isInitialize() {
        return getBooleanValue(SpConstant.SInitialize,"SInitialize");
    }


    public void setQueLst(String que) {
        setValue(SpConstant.QuesList,"QuesList",que);
    }

    public String getQueList() {
        return getStringValue(SpConstant.QuesList,"QuesList");
    }

    public void setInstall(boolean install) {
        setValue(SpConstant.SP_IS_INSTALL,"install",install);
    }

    public boolean isInstall() {
        return getBooleanValue(SpConstant.SP_IS_INSTALL,"install");
    }

    public void setInstallTime(String installTime) {
        setValue(SpConstant.SP_INSTALL_TIME,"installTime",installTime);
    }

    public String getInstallTime() {
        return getStringValue(SpConstant.SP_INSTALL_TIME,"installTime");
    }

    public void setCreateDirTime(String createDirTime) {
        setValue(SpConstant.SP_CREATE_DIR_TIME,"createDirTime",createDirTime);
    }

    public String getCreateDirTime() {
        return getStringValue(SpConstant.SP_CREATE_DIR_TIME,"createDirTime");
    }

    public void setBackupTime(String backupTime) {
        setValue(SpConstant.SP_BACKUP_TIME,"backupTime",backupTime);
    }

    public String getBackupTime() {
        return getStringValue(SpConstant.SP_BACKUP_TIME,"backupTime");
    }
}
