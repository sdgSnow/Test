package com.dimeno.dimenoquestion.bean;

import java.util.List;

public class MessageEntity {

    private Integer current;
    private Integer pages;
    private Boolean searchCount;
    private Integer size;
    private Integer total;
    private List<RecordsBean> records;

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public Boolean getSearchCount() {
        return searchCount;
    }

    public void setSearchCount(Boolean searchCount) {
        this.searchCount = searchCount;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List<RecordsBean> getRecords() {
        return records;
    }

    public void setRecords(List<RecordsBean> records) {
        this.records = records;
    }

    public static class RecordsBean {
        /**
         * createTime : 2021-10-29 11:54:55
         * createUser : 1
         * endDate : 2021-11-06 00:00:00
         * id : 1453933336900788225
         * isRead : null
         * isRelease : true
         * msgContent : iiiii
         * msgImgUrl : null
         * msgTitle : ooo
         * msgType : 3
         * queId :
         * readTime : null
         * recuserId : null
         * sendTime : null
         * startDate : 2021-10-28 00:00:00
         * status : 1
         * topTime : 2021-10-29 11:54:55
         * updateTime : 2021-11-04 14:30:28
         * updateUser : 1
         */

        private String createTime;
        private String createUser;
        private String endDate;
        private String id;
        private Boolean isRead;
        private Boolean isRelease;
        private String msgContent;
        private String msgImgUrl;
        private String msgTitle;
        private Integer msgType;
        private String queId;
        private String readTime;
        private String recuserId;
        private String sendTime;
        private String startDate;
        private Integer status;
        private String topTime;
        private String updateTime;
        private String updateUser;

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getCreateUser() {
            return createUser;
        }

        public void setCreateUser(String createUser) {
            this.createUser = createUser;
        }

        public String getEndDate() {
            return endDate;
        }

        public void setEndDate(String endDate) {
            this.endDate = endDate;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Boolean getRead() {
            return isRead;
        }

        public void setRead(Boolean read) {
            isRead = read;
        }

        public Boolean getRelease() {
            return isRelease;
        }

        public void setRelease(Boolean release) {
            isRelease = release;
        }

        public String getMsgContent() {
            return msgContent;
        }

        public void setMsgContent(String msgContent) {
            this.msgContent = msgContent;
        }

        public String getMsgImgUrl() {
            return msgImgUrl;
        }

        public void setMsgImgUrl(String msgImgUrl) {
            this.msgImgUrl = msgImgUrl;
        }

        public String getMsgTitle() {
            return msgTitle;
        }

        public void setMsgTitle(String msgTitle) {
            this.msgTitle = msgTitle;
        }

        public Integer getMsgType() {
            return msgType;
        }

        public void setMsgType(Integer msgType) {
            this.msgType = msgType;
        }

        public String getQueId() {
            return queId;
        }

        public void setQueId(String queId) {
            this.queId = queId;
        }

        public String getReadTime() {
            return readTime;
        }

        public void setReadTime(String readTime) {
            this.readTime = readTime;
        }

        public String getRecuserId() {
            return recuserId;
        }

        public void setRecuserId(String recuserId) {
            this.recuserId = recuserId;
        }

        public String getSendTime() {
            return sendTime;
        }

        public void setSendTime(String sendTime) {
            this.sendTime = sendTime;
        }

        public String getStartDate() {
            return startDate;
        }

        public void setStartDate(String startDate) {
            this.startDate = startDate;
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }

        public String getTopTime() {
            return topTime;
        }

        public void setTopTime(String topTime) {
            this.topTime = topTime;
        }

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public String getUpdateUser() {
            return updateUser;
        }

        public void setUpdateUser(String updateUser) {
            this.updateUser = updateUser;
        }
    }
}
