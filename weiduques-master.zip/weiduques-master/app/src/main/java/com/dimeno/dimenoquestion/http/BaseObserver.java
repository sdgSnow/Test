package com.dimeno.dimenoquestion.http;

import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.utils.MyToast;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import retrofit2.HttpException;

/**
 * Create by   :PNJ
 * Date        :2021/3/23
 * Description :
 * 规则接口格式{
 *     "flag":
 *     "msg":
 *     "ResultObj":{}
 * }
 */
public abstract class BaseObserver<T> implements Observer<Res<T>> {
    /**
     * hideLoading 是否隱藏等待框
     * 默認為true
     */
    private boolean hideLoading=true;
    /**
     * 无参构造器
     */
    public BaseObserver(){

    }
    /**
     * 有参构造器
     * @param hideLoading
     */
    public BaseObserver(boolean hideLoading){
        this.hideLoading=hideLoading;
    }
    /**
     * onSubscribe
     * @param d
     */
    @Override
    public void onSubscribe(@NonNull Disposable d) {

    }

    /**
     * onNext
     * @param tRes
     */
    @Override
    public void onNext(@NonNull Res<T> tRes) {
        onHandleSuccess(tRes);
    }

    /**
     * onError
     * @param e
     */
    @Override
    public void onError(@NonNull Throwable e) {
        e.printStackTrace();
        if(e instanceof HttpException){
            int code = ((HttpException) e).code();
            onHandleFaild(code,e.getMessage());
            if(code == 404){
                MyToast.showShortToast("数据访问异常");
            }else if (code == 500){
                MyToast.showShortToast("连接异常，请稍后重试或联系管理员处理");
            }else if (code == 502){
                MyToast.showShortToast("网络连接不可用，请稍后重试");
            }else if (code == 504){
                MyToast.showShortToast("网络连接不可用，请稍后重试");
            }else {
                MyToast.showLongToast(e.getMessage());
            }
        }else {
            onHandleFaild(500,e.getMessage());
            MyToast.showLongToast(e.getMessage());
        }
        if(hideLoading){
            ProgressHelper.getInstance().cancel();
        }
    }

    /**
     * onComplete
     * 完成
     */
    @Override
    public void onComplete() {
        if(hideLoading){
            ProgressHelper.getInstance().cancel();
        }
    }
    /**
     * 成功回调
     * @param res
     */
    protected abstract void onHandleSuccess(Res<T> res);
    /**
     * 失败回调
     * @param code
     * @param error
     */
    protected abstract void onHandleFaild(int code,String error);

}
