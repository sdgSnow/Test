package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.AboutUsBean;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.HttpConstant;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.AboutAsView;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.UserUtil;

import java.util.Map;

import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.Constant.PRO_CODE;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class AboutAsPresenter extends BasePresenter<AboutAsView> {
    /**
     * 接口获取关于我们的信息
     * @param context
     */
    public void AboutUs(Context context){
        Observable<Res<AboutUsBean>> observable= RetrofitManager.getInstance().getAppService()
                .getAboutUs(HttpConstant.sCACHE_CONTROL_AGE,PRO_CODE);
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<AboutUsBean>() {
            @Override
            protected void onHandleSuccess(Res<AboutUsBean> aboutUs) {
                //判空是否成功
                if(aboutUs.Flag==0){
                    //防止activity已经销毁，崩溃
                    if(getMvpView() != null){
                        //成功回调
                        getMvpView().OnSucess(aboutUs.ResultObj);
                    }
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //失败回调
            }
        });
    }
}
