package com.dimeno.dimenoquestion.constant;

public class AnswerState {

    /**
     * 0 是未上传(继续编辑)
     * 1 是保存在本地，未上传（上传问卷）
     * 2 是有网已上传
     */
    public static final int EDIT = 0;
    public static final int COMPLETE = 1;
    public static final int UPLOAD = 2;

}
