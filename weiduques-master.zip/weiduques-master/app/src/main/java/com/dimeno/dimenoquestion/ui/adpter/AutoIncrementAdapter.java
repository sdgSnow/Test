package com.dimeno.dimenoquestion.ui.adpter;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AutoIncrementAdapter extends BaseQuickAdapter<List<AttrBean>, BaseViewHolder> {

    //    private Map<Integer,AutoIncrementBlankAdapter> map=new HashMap<>();
    //map保存适配器
    private Map<Integer,AutoIncrementAdapter2> map=new HashMap<>();
    private PageSubjectBean subject;
    //add新添加，edit编辑，look查看
    private String type;
    //规则校验状态
    private boolean flag;
    private Map<Integer, Map<String, Object>> mapAnswer;
    //输入类型
    private int format;
    private Object formatObject;
    private String value;

    /**
     * 构造器
     * @param data
     * @param subject
     * @param type
     */
    public AutoIncrementAdapter(@Nullable List<List<AttrBean>> data, PageSubjectBean subject,String type) {
        super(R.layout.item_auto_increment_content, data);
        this.subject = subject;
        this.type = type;
    }

    @Override
    protected void convert(BaseViewHolder helper, List<AttrBean> item) {
        RecyclerView recyclerView = helper.getView(R.id.rcy_auto_increment_blank);
        //设置方向
        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 1, GridLayoutManager.VERTICAL, false));
        //map是否含有
        if(map.get(helper.getAdapterPosition())==null) {
//            AutoIncrementBlankAdapter autoIncrementBlankAdapter = new AutoIncrementBlankAdapter(item, subject,helper.getAdapterPosition(),type);
           //不含有，创建适配器
            AutoIncrementAdapter2 autoIncrementBlankAdapter = new AutoIncrementAdapter2(item,helper.getAdapterPosition(),subject.getSurveyAnswer().mAutoIncrementAnswer,type);
           //设置适配器
            recyclerView.setAdapter(autoIncrementBlankAdapter);
            //map保存适配器
            map.put(helper.getAdapterPosition(),autoIncrementBlankAdapter);
            //适配器点击事件
            autoIncrementBlankAdapter.setChildClickLisener(new AutoIncrementAdapter2.OnChildClickLisener() {
                @Override
                public void onChildClick() {
                    //规则校验
                    check();
                }
            });
        }else {
            //含有，map中获取适配器
            AutoIncrementAdapter2 autoIncrementBlankAdapter=map.get(helper.getAdapterPosition());
            //适配器设置数据
            autoIncrementBlankAdapter.setData(item,subject.getSurveyAnswer().mAutoIncrementAnswer);
            //设置适配器
            recyclerView.setAdapter(autoIncrementBlankAdapter);
            //适配器监听
            autoIncrementBlankAdapter.setChildClickLisener(new AutoIncrementAdapter2.OnChildClickLisener() {
                @Override
                public void onChildClick() {
                    //规则校验
                    check();
                }
            });
//            autoIncrementBlankAdapter.setChildClickLisener(new AutoIncrementBlankAdapter.OnChildClickLisener() {
//                @Override
//                public void onChildClick() {
//                    if(onChildClickLisener!=null){
//                        onChildClickLisener.onChildClick();
//                    }
//                }
//            });
        }
    }
    private int listSize;
    public void check(){
        //初始化状态
        flag=false;
        //判空
        if(subject.getSurveyAnswer().mAutoIncrementAnswer!=null && subject.getSurveyAnswer().mAutoIncrementAnswer.mAnswers!=null
                && subject.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size()!=0 ) {
            //循环
            for (int i = 0; i < subject.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.size(); i++) {
                mapAnswer=subject.getSurveyAnswer().mAutoIncrementAnswer.mAnswers.get(i);
                //判空
                if(mapAnswer!=null && mapAnswer.size()!=0){
                    listSize=0;
                    for (int y=0;y<mapAnswer.size();y++) {
                        //是否是必须
                        boolean isMust = (boolean) mapAnswer.get(y).get(QueFormat.KEY_MUST);
                        //判空
                        if (StringUtils.isEmpty((String) mapAnswer.get(y).get(QueFormat.KEY_VALUE))) {
                            if(isMust) {
                                flag = true;
                            }else {
                                //不必须
                                listSize++;
                            }
                        } else {
                            formatObject=mapAnswer.get(y).get(QueFormat.KEY_FORMAT);
                            format = (int) Double.parseDouble(formatObject.toString()+"");
                            value = (String) mapAnswer.get(y).get(QueFormat.KEY_VALUE);
                            switch (format) {
                                case CharFormat.EMAIL:
                                    //1 邮箱
                                    if (!StringUtils.checkValue(CharFormatPattern.EMAIL, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.TEXT:
                                    //2 中文
                                    if (!StringUtils.checkValue(CharFormatPattern.TEXT, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.ENGLISH:
                                    //3 英文
                                    if (!StringUtils.checkValue(CharFormatPattern.ENGLISH, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.WEBSITE:
                                    //4 网址
                                    if (!StringUtils.checkValue(CharFormatPattern.WEBSITE, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.ID:
                                    //5 身份证号码
                                    if (!StringUtils.checkValue(CharFormatPattern.ID, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.QQ:
                                    //6 QQ号
                                    if (!StringUtils.checkValue(CharFormatPattern.QQ, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.MOBILE_PHONE:
                                    //7 电话号码
                                    if (!StringUtils.checkValue(CharFormatPattern.MOBILE_PHONE, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.TELEPHONE:
                                    //8 固定电话号码
                                    if (!StringUtils.checkValue(CharFormatPattern.TELEPHONE, value)) {
                                        flag = true;
                                    }
                                    break;
                                case CharFormat.NUMBER:
                                    //9 数值
                                    if (!StringUtils.checkValue(CharFormatPattern.NUM, value)) {
                                        flag = true;
                                    }
                                    break;
                                default:
                            }
                        }
                    }
                    //如果不必须都为空，则更新状态
                    if(listSize==mapAnswer.size()){
                        flag = false;
                    }
                }
            }
        }
        if(!flag){
            if(onChildClickLisener!=null){
                //回调
                onChildClickLisener.onChildClick();
            }
        }
    }
    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick();
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
