package com.dimeno.dimenoquestion.bean;

import android.os.Parcel;
import android.os.Parcelable;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * 题目的答案实体
 */
public class SurveyAnswer implements Serializable {
    /**
     * 题目ID：uuid
     * 9a93c438-d2c5-0748-0534-79a9b77712fc
     */
    public String subUuid;
    /**
     * 题目编号
     * 4
     */
    public int subId;
    public String queId;
    public int sort;
    public int subType;
    public boolean subIsRepeat;
    public boolean isMust;

    /**
     * 旧
     * 2=隐藏
     * 0=显示
     *
     * 改为
     * 1显示
     * 0隐藏
     */
    public int logicShow;
    public String subTitle;
    //新加：题目录音路径
    public String subRecordPath = "";
    //录音key = TB_AnswerFile.ID
    public String recordKey;
    //录音播放喇叭
    public boolean isImgPlaying;


    /**
     * 文本填空
     */
    //填空，最多字数
    public int lenghtMax;
    //填空，最少字数
    public int lenghtMin;

    /**
     * 数值填空
     */
    //最小的数
    public double rangeStart;
    //最大的数
    public double rangeEnd;
    //小数点后几位
    public int pointCount;
    //多选，最多选择
    public int MaxCount;
    //多选，最少选择
    public int MinCount;
    /**
     * 单选、多选
     */
    public List<QueOptionBean> choiceList;

    /**
     * 填空题
     */
    public String answerFillContent = "";
    /**
     * 连续填空题
     */
    public ArrayList<MultiFillBlank> multiFillBlankList;

    /**
     * 填空题输入格式：0=无限制 7=手机号码
     */
    public int answerFillContentCharFormat = 0;
    /**
     * 存储选项中的输入内容
     */
    public ArrayList<OptionListFill> optionListFills;
    /**
     * 存储单选/多选/下拉选选项
     */
    public LinkedHashSet<String> OptionList;
    /**
     * 下拉上次默认选择的，用于刷新adpter的时候，不用每次都设置默认
     */
    public String dropDownOpCode;
    /**
     * 存储矩阵单/多选 /量表题/
     */
    public ArrayList<MatrixAnswer> matrixAnswers;
    /**
     * 存储组合填空/组合下拉
     */
    public ArrayList<ChildSubAnswer> childSubAnswers;
    /**
     * 自增表格题
     */
    public AutoIncrementAnswer mAutoIncrementAnswer;

    /**
     * 0 不限制
     * 1 图片
     * 2 音频
     * 3 视频
     */
    public int annexFileType = 0;

    /**
     * 附件题/签名
     */
    public List<AnnexEntity> annexList;

    /**
     * 存储多级下拉
     */
    public List<String> multi_dropdown_value;

    /**
     * 定位题答案
     */
    public String mLocationAddress;
    public double mLocationLatitude;
    public double mLocationLongitude;

    public SurveyAnswer() {
    }


    public static class AutoIncrementAnswer implements Serializable {
        public HashMap<Integer, Map<Integer, Map<String, Object>>> mAnswers;

        public AutoIncrementAnswer() {
        }

        protected AutoIncrementAnswer(Parcel in) {
        }

//        @Override
//        public void writeToParcel(Parcel dest, int flags) {
//        }
//
//        @Override
//        public int describeContents() {
//            return 0;
//        }
//
//        public static final Creator<AutoIncrementAnswer> CREATOR = new Creator<AutoIncrementAnswer>() {
//            @Override
//            public AutoIncrementAnswer createFromParcel(Parcel in) {
//                return new AutoIncrementAnswer(in);
//            }
//
//            @Override
//            public AutoIncrementAnswer[] newArray(int size) {
//                return new AutoIncrementAnswer[size];
//            }
//        };
    }

    public static class MultiFillBlank implements Serializable {
        public boolean isMust;
        public String opCode;
        public String fillText;
        public int format;//格式，邮箱，中英文等格式
        public String pattern;//题目格式：你叫()某某

        public MultiFillBlank() {
        }

        protected MultiFillBlank(Parcel in) {
            isMust = in.readByte() != 0;
            opCode = in.readString();
            fillText = in.readString();
            format = in.readInt();
            pattern = in.readString();
        }

//        @Override
//        public void writeToParcel(Parcel dest, int flags) {
//            dest.writeByte((byte) (isMust ? 1 : 0));
//            dest.writeString(opCode);
//            dest.writeString(fillText);
//            dest.writeInt(format);
//            dest.writeString(pattern);
//        }
//
//        @Override
//        public int describeContents() {
//            return 0;
//        }
//
//        public static final Creator<MultiFillBlank> CREATOR = new Creator<MultiFillBlank>() {
//            @Override
//            public MultiFillBlank createFromParcel(Parcel in) {
//                return new MultiFillBlank(in);
//            }
//
//            @Override
//            public MultiFillBlank[] newArray(int size) {
//                return new MultiFillBlank[size];
//            }
//        };
    }

    public static class OptionListFill implements Serializable {
//        public static final Creator<OptionListFill> CREATOR = new Creator<OptionListFill>() {
//            @Override
//            public OptionListFill createFromParcel(Parcel source) {
//                return new OptionListFill(source);
//            }
//
//            @Override
//            public OptionListFill[] newArray(int size) {
//                return new OptionListFill[size];
//            }
//        };
        public boolean isMust;
        public boolean isFill;
        public String opCode;
        public String fillText;

        public OptionListFill() {
        }

        protected OptionListFill(Parcel in) {
            this.isMust = in.readByte() != 0;
            this.isFill = in.readByte() != 0;
            this.opCode = in.readString();
            this.fillText = in.readString();
        }

//        @Override
//        public int describeContents() {
//            return 0;
//        }
//
//        @Override
//        public void writeToParcel(Parcel dest, int flags) {
//            dest.writeByte(this.isMust ? (byte) 1 : (byte) 0);
//            dest.writeByte(this.isFill ? (byte) 1 : (byte) 0);
//            dest.writeString(this.opCode);
//            dest.writeString(this.fillText);
//        }
    }

    public static class ChildSubAnswer implements Serializable {
//        public static final Creator<ChildSubAnswer> CREATOR = new Creator<ChildSubAnswer>() {
//            @Override
//            public ChildSubAnswer createFromParcel(Parcel source) {
//                return new ChildSubAnswer(source);
//            }
//
//            @Override
//            public ChildSubAnswer[] newArray(int size) {
//                return new ChildSubAnswer[size];
//            }
//        };
        public int subId;
        public String subType;
        public boolean subIsMust;
        public boolean subIsRepeat;
        public int optionId;
        public String AnswerFillContent;

        public ChildSubAnswer() {
        }

        protected ChildSubAnswer(Parcel in) {
            this.subId = in.readInt();
            this.subType = in.readString();
            this.subIsMust = in.readByte() != 0;
            this.subIsRepeat = in.readByte() != 0;
            this.optionId = in.readInt();
            this.AnswerFillContent = in.readString();
        }

//        @Override
//        public int describeContents() {
//            return 0;
//        }
//
//        @Override
//        public void writeToParcel(Parcel dest, int flags) {
//            dest.writeInt(this.subId);
//            dest.writeString(this.subType);
//            dest.writeByte(this.subIsMust ? (byte) 1 : (byte) 0);
//            dest.writeByte(this.subIsRepeat ? (byte) 1 : (byte) 0);
//            dest.writeInt(this.optionId);
//            dest.writeString(this.AnswerFillContent);
//        }
    }

    public static class MatrixAnswer implements Serializable {
//        public static final Creator<MatrixAnswer> CREATOR = new Creator<MatrixAnswer>() {
//            @Override
//            public MatrixAnswer createFromParcel(Parcel source) {
//                return new MatrixAnswer(source);
//            }
//
//            @Override
//            public MatrixAnswer[] newArray(int size) {
//                return new MatrixAnswer[size];
//            }
//        };
        public int pos;
        public HashSet<String> opCodes;

        public MatrixAnswer() {
        }

        protected MatrixAnswer(Parcel in) {
            this.pos = in.readInt();
            this.opCodes = (HashSet<String>) in.readSerializable();
        }

//        @Override
//        public int describeContents() {
//            return 0;
//        }
//
//        @Override
//        public void writeToParcel(Parcel dest, int flags) {
//            dest.writeInt(this.pos);
//            dest.writeSerializable(this.opCodes);
//        }
    }
}