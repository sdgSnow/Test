package com.dimeno.dimenoquestion.bean;

/**
 * Create by   :PNJ
 * Date        :2021/3/25
 * Description :签名文件
 */
public class SignFileBean {
    //本地路径
    private String localPath;
    //开始时间
    private String startTime;
    //结束时间
    private String endTime;
    //ossPath
    private String ossPath;
    //项目代码
    private String ProCode;
    //问卷ID
    private String queId;
    //答卷ID
    private String answerId;

    public String getProCode() {
        return ProCode;
    }

    public void setProCode(String proCode) {
        ProCode = proCode;
    }

    public String getQueId() {
        return queId;
    }

    public void setQueId(String queId) {
        this.queId = queId;
    }

    public String getAnswerId() {
        return answerId;
    }

    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }

    public String getLocalPath() {
        return localPath;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getOssPath() {
        return ossPath;
    }

    public void setOssPath(String ossPath) {
        this.ossPath = ossPath;
    }
}
