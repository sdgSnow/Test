package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.TimePickerView;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :7 时间填空题
 */
public class FillTimeHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_data;
    private final TextView tv_right_text;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;
    //日期格式化
    private Calendar currentDate;
    private int year;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public FillTimeHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_fill_time);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        tv_data = findViewById(R.id.tv_fill_data_blank);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
        currentDate = Calendar.getInstance();
        currentDate.setTime(new Date());
        year=currentDate.get(Calendar.YEAR);//获取年份
    }


    @Override
    public void bind() {
        if (mData.getAttr() != null) {
            title = StringUtils.getTitle(mData.getAttr().getLeftText(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }

            tv_data.setText(StringUtils.isEmpty(mData.getSurveyAnswer().answerFillContent) ? "" : mData.getSurveyAnswer().answerFillContent);
            //时间选择器
            TimePickerView pvTime = new TimePickerBuilder(itemView.getContext(), new OnTimeSelectListener() {
                @Override
                public void onTimeSelect(Date date, View v) {
                    SimpleDateFormat format = new SimpleDateFormat(StringUtils.getTimeFormat(mData.getAttr().getCharFormat()), Locale.CHINESE);
                    tv_data.setText(format.format(date));
                    mData.getSurveyAnswer().answerFillContent = format.format(date);
                    if (mData.isError()) {
                        mData.setError(false);
                        frame_error.setVisibility(View.GONE);
                    }
                }
            }).setDate(currentDate).setType(StringUtils.getTimeTypes(mData.getAttr().getCharFormat())).build();
            tv_data.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!type.equals("look")) {
                        pvTime.show();
                    }
                }
            });
        }
    }



}
