package com.dimeno.dimenoquestion.constant;

public class ApiConstant {
    //登录
    public static final String loginUser = "api/QueApp/EntryStaffLogin";
    //修改密码
    public static final String updatePwd = "api/des/updatePwd";
    //获得问卷列表
    public static final String loadQuesList = "api/QueApp/GetQueListByUid";
    //获得问卷
    public static final String loadQues = "api/Que/GetQueDetailsById";
    //‘关于我们’信息
    public static final String getAboutUs = "api/Que/GetAboutUs";
    //获取OSS信息
    public static final String getOssInfo = "api/AliYun/GetToken";
    //上传答卷
    public static final String saveAnswer = "api/Answer/SaveAnswer";
}
