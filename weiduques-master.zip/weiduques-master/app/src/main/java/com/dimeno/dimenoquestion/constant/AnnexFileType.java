package com.dimeno.dimenoquestion.constant;

/**
 * Create by   :PNJ
 * Date        :2021/9/11
 * Description :附件题型中的几种类型
 */
public class AnnexFileType {
    //不限制
    public static final int ALL = 0;
    //图片
    public static final int IMAGE= 1;
    //音频 (.cda,.wav,.mp3,.mid,.wma,.ra,.vqf,.ape,.aif,.aiff)
    public static final int AUDIO = 2;
    //视频
    public static final int VIDEO = 3;
    //文档(.doc,.docx,.xls,.xlsx,.pdf,.ppt,.txt,.zip,.tar,.7z,.rar)
    public static final int FILE = 4;
}
