package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.AbsTextWatcher;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :4 问答题
 */
public class QuestionAnswerHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final EditText etMutiText;
    private SpannableStringBuilder title;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public QuestionAnswerHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_ques_answer);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        etMutiText = findViewById(R.id.etMutiText);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        etMutiText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        this.type=type;
    }


    @Override
    public void bind() {
        Log.d("adpterFlush","问答题 flush position="+getAdapterPosition());
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            //设置行高
            int rowCount = mData.getAttr().getRowCount();
            if (rowCount <= 1) {
                etMutiText.setInputType(InputType.TYPE_CLASS_TEXT);
            } else {
                etMutiText.setInputType(InputType.TYPE_TEXT_FLAG_MULTI_LINE);
                etMutiText.setHorizontallyScrolling(false);
                etMutiText.setMinLines(rowCount);
                etMutiText.setMaxLines(rowCount);
            }
        }
        if(type.equals("look")){
            etMutiText.setClickable(false);
            etMutiText.setEnabled(false);
        }else {
            etMutiText.setHint("请输入");
        }
        etMutiText.setText((StringUtils.isEmpty(mData.getSurveyAnswer().answerFillContent)?"":mData.getSurveyAnswer().answerFillContent));
        if(mData.isError()){
            frame_error.setVisibility(View.VISIBLE);
        }else {
            frame_error.setVisibility(View.GONE);
        }
        //editText软键盘的EditorAction监控
        etMutiText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //禁止掉下一页
                if(actionId== EditorInfo.IME_ACTION_NEXT){
                    return true;
                }
                return false;
            }
        });
        etMutiText.addTextChangedListener(new AbsTextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                mData.getSurveyAnswer().answerFillContent = s.toString();
                if(!StringUtils.isEmpty(s.toString()) && mData.isError()){
                    mData.setError(false);
                    frame_error.setVisibility(View.GONE);
                }
            }
        });

    }

}
