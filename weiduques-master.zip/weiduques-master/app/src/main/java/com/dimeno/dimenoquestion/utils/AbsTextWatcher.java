package com.dimeno.dimenoquestion.utils;

import android.text.TextWatcher;

/**
 * AbsTextWatcher
 * Created by wangzhen on 2020/5/8.
 */
public abstract class AbsTextWatcher implements TextWatcher {
    /**
     * beforeTextChanged
     * @param s
     * @param start
     * @param count
     * @param after
     */
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    /**
     * onTextChanged
     * @param s
     * @param start
     * @param before
     * @param count
     */
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}
