package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.listener.OnChildClickLisener;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.MultiBlankAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.ChinaTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EmailHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.EnglishHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.IdCardHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.PhoneHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.QQHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.text.WebHolder;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :8 多项填空题,连续填空
 */
public class MultiBlankHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final RecyclerView recyclerView;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private MultiBlankAdapter multiBlankAdapter;
    private SpannableStringBuilder title;
    //防止同一页有多个连续填空
    private Map<Integer,MultiBlankAdapter> map=new HashMap<>();
    //add新添加，edit编辑，look查看
    private String type;
    private boolean flag;
    private int listSize;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public MultiBlankHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_multi_blanks);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        recyclerView = findViewById(R.id.rcy_multi_blank);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getLeftText(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "???" : title);
            tvTitle.setVisibility(title == null ? View.GONE : View.VISIBLE);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }
            if (mData.getAttr().getCusAttr() != null) {
                if (map.get(getAdapterPosition()) == null) {
                    if (mData.getSurveyAnswer().multiFillBlankList == null) {
                        ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlankList = new ArrayList<>();
                        //初始化答案，没有则创建
                        for (int i = 0; i < mData.getAttr().getCusAttr().size(); i++) {
                            SurveyAnswer.MultiFillBlank multiFillBlank = new SurveyAnswer.MultiFillBlank();
                            multiFillBlank.isMust = mData.getAttr().getCusAttr().get(i).isMust();
                            multiFillBlank.format = mData.getAttr().getCusAttr().get(i).getCharFormat();
                            StringBuilder builder = new StringBuilder();
                            if (!TextUtils.isEmpty(mData.getAttr().getCusAttr().get(i).getLeftText())) {
                                builder.append(mData.getAttr().getCusAttr().get(i).getLeftText());
                            }
                            builder.append("( )");
                            if (!TextUtils.isEmpty(mData.getAttr().getCusAttr().get(i).getRightText())) {
                                builder.append(mData.getAttr().getCusAttr().get(i).getRightText());
                            }
                            multiFillBlank.pattern = builder.toString();
                            multiFillBlankList.add(i, multiFillBlank);
                        }
                        mData.getSurveyAnswer().multiFillBlankList = multiFillBlankList;
                    }
                    recyclerView.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));
                    multiBlankAdapter = new MultiBlankAdapter(mData.getAttr().getCusAttr(), mData.getSurveyAnswer().multiFillBlankList, type);
                    recyclerView.setAdapter(multiBlankAdapter);
                    map.put(getAdapterPosition(), multiBlankAdapter);
                } else {
                    multiBlankAdapter = map.get(getAdapterPosition());
                    //重新刷新holder
                    recyclerView.setAdapter(multiBlankAdapter);
                }
                multiBlankAdapter.setChildClickLisener(new MultiBlankAdapter.OnChildClickLisener() {
                    @Override
                    public void onChildClick() {
                        flag = false;
                        if (mData.getSurveyAnswer().multiFillBlankList != null && mData.getSurveyAnswer().multiFillBlankList.size() != 0) {
                            listSize = 0;
                            for (int i = 0; i < mData.getSurveyAnswer().multiFillBlankList.size(); i++) {
                                //如果是必填的，则检查内容是否有值
                                if (mData.getSurveyAnswer().multiFillBlankList.get(i).isMust) {
                                    if (StringUtils.isEmpty(mData.getSurveyAnswer().multiFillBlankList.get(i).fillText)) {
                                        flag = true;
                                    } else {
                                        isFlag(mData.getSurveyAnswer().multiFillBlankList.get(i).format, mData.getSurveyAnswer().multiFillBlankList.get(i).fillText);
                                    }
                                } else {
                                    //不是必须的，如果有值，则检测 type是否合格
                                    if (!StringUtils.isEmpty(mData.getSurveyAnswer().multiFillBlankList.get(i).fillText)) {
                                        isFlag(mData.getSurveyAnswer().multiFillBlankList.get(i).format, mData.getSurveyAnswer().multiFillBlankList.get(i).fillText);
                                    } else {
                                        //没有值
                                        listSize++;
                                    }
                                }
                            }
                            if (listSize == mData.getSurveyAnswer().multiFillBlankList.size()) {
                                //不是必须，都没有值
                                flag = false;
                            }
                        }
                        if (!flag && mData.isError()) {
                            mData.setError(false);
                            frame_error.setVisibility(View.GONE);
                        }
                    }
                });
            }
        }
    }
    public void isFlag(int format,String str){
        switch (format){
            case CharFormat.EMAIL://1 邮箱
                if(!StringUtils.checkValue(CharFormatPattern.EMAIL, str)){
                    flag = true;
                }
                break;
            case CharFormat.TEXT://2 中文
                if(!StringUtils.checkValue(CharFormatPattern.TEXT, str)){
                    flag = true;
                }
                break;
            case CharFormat.ENGLISH://3 英文
                if(!StringUtils.checkValue(CharFormatPattern.ENGLISH, str)){
                    flag = true;
                }
                break;
            case CharFormat.WEBSITE://4 网址
                if(!StringUtils.checkValue(CharFormatPattern.WEBSITE, str)){
                    flag = true;
                }
                break;
            case CharFormat.ID://5 身份证号码
                if(!StringUtils.checkValue(CharFormatPattern.ID, str)){
                    flag = true;
                }
                break;
            case CharFormat.QQ://6 QQ号
                if(!StringUtils.checkValue(CharFormatPattern.QQ, str)){
                    flag = true;
                }
                break;
            case CharFormat.MOBILE_PHONE://7 电话号码
                if(!StringUtils.checkValue(CharFormatPattern.MOBILE_PHONE, str)){
                    flag = true;
                }
                break;
            case CharFormat.TELEPHONE://8 固定电话号码
                if(!StringUtils.checkValue(CharFormatPattern.TELEPHONE, str)){
                    flag = true;
                }
                break;
            case CharFormat.NUMBER://9 数值
                if(!StringUtils.checkValue(CharFormatPattern.NUM, str)){
                    flag = true;
                }
                break;
            case CharFormat.DATE://10 日期
                if(StringUtils.isEmpty(str)){
                    flag = true;
                }
                break;

            default:

        }
    }
}
