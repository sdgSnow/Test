package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.db.Answer;

import java.util.List;

public interface DealExceptionQueView extends BaseView {
    /**
     * 获取token值 成功回调
     * @param ossInfoEntity
     * @param filepath
     */
    void success(OssInfoEntity ossInfoEntity,String filepath);

    /**
     * 获取答卷列表 回调
     * @param loadMore
     * @param quesBeanList
     */
    void initQuesList(boolean loadMore, List<Answer> quesBeanList);

    /**
     * 日志上传成功回调
     * @param sucess
     * @param msg
     */
    void sucess(boolean sucess,String msg);
}
