package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.adpter.holder.AnswerListViewHolder;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AnswerListRecyclerAdapter extends RecyclerAdapter<Answer> {
    private Context mContext;

    /**
     * 构造器
     * @param mContext
     */
    public AnswerListRecyclerAdapter(Context mContext, List<Answer> answerList) {
        super(answerList);
        this.mContext = mContext;
    }

    public void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private MyOnItemClickListener myOnItemClickListener;

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new AnswerListViewHolder(mContext,parent,myOnItemClickListener);
    }

    public interface MyOnItemClickListener {
        void onItemClick(int positon, Answer answer);

        void onItemLongClick(int positon, Answer answer);
    }
}
