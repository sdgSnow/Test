package com.dimeno.dimenoquestion.ui.actvity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.dimeno.dimenoquestion.widget.TitleToolbar;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Create by   :PNJ
 * Date        :2021/3/16
 * Description :
 */
public class BaseInfoActivity extends BaseActivity {
    @BindView(R.id.tv_username)
    TextView tv_username;
    @BindView(R.id.tv_useraccount)
    TextView tv_useraccount;

    /**
     * 设置布局
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.activity_base_info;
    }

    /**
     * initThings
     * @param savedInstanceState 缓存数据
     *                           <p>
     */
    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
    }

    /**
     * Toolbar
     * @return
     */
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this,"基本信息");
    }

    /**
     * initViews
     */
    @Override
    protected void initViews() {
        //显示调查员名称
        tv_username.setText(UserUtil.getUserName());
        //显示调查员账号
        tv_useraccount.setText(UserUtil.getAccount());
    }

    /**
     * createPresenter
     * @return
     */
    @Override
    protected BasePresenter createPresenter() {
        return null;
    }

    /**
     * initListeners
     */
    @Override
    public void initListeners() {

    }
}
