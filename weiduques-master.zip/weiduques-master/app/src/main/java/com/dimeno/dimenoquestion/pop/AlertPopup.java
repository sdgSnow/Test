package com.dimeno.dimenoquestion.pop;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.utils.StringUtils;

/**
 * Create by   :PNJ
 * Date        :2021/4/19
 * Description :消息弹框
 */
public class AlertPopup extends PopupWindow {
    private View  mView;
    private LinearLayout ll_home;

    /**
     * 默认使用“取消”，“确定”
     * @param context
     * @param content
     * @param msg
     */
    public AlertPopup(Context context, String content, String msg) {
        super(context);
        LayoutInflater mInflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //设置布局
        mView = mInflate.inflate(R.layout.popup_alert, null);
        //取消按钮
        TextView cancle = (TextView) mView.findViewById(R.id.cancle);
        //确定按钮
        TextView btn_ok = (TextView) mView.findViewById(R.id.btn_ok);
        //title
        TextView tvAlertTitle = (TextView) mView.findViewById(R.id.tvAlertTitle);
        //消息内容
        TextView tvAlertMsg = (TextView) mView.findViewById(R.id.tvAlertMsg);
        //ll_home
        ll_home = (LinearLayout) mView.findViewById(R.id.ll_sexselect_isdeleter);
        //内容判空
        if(content != null&&!StringUtils.isEmpty(content)){
            tvAlertTitle.setText(content);
        }
        //信息判空
        if(msg!=null&&!StringUtils.isEmpty(msg)){
            tvAlertMsg.setText(msg);
        }
        //取消监听
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //监听器判空
                    itemClickListener.onItemClick(false);
                }
            }
        });
        //确定判空
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //监听器判空
                    itemClickListener.onItemClick(true);
                }
            }
        });
        //设置点击效果
        cancle.setBackgroundResource(R.drawable.bg_alertbutton_left);
        //确定点击效果
        btn_ok.setBackgroundResource(R.drawable.bg_alertbutton_right);

        //设置SelectPicPopupWindow的View
        this.setContentView(mView);
        //设置SelectPicPopupWindow弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体可点击
        this.setFocusable(true);
        //设置SelectPicPopupWindow弹出窗体动画效果
//        this.setAnimationStyle(R.style.showPopupAnimation);
        ll_home.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in_center));
        //实例化一个ColorDrawable颜色为半透明
        ColorDrawable dw = new ColorDrawable(0xb0000000);
        //设置透明度
        dw.setAlpha(95);
        //设置SelectPicPopupWindow弹出窗体的背景
        this.setBackgroundDrawable(dw);

    }

    /**
     * 自定义 “取消”，“确定”
     * @param context
     * @param tvCancle
     * @param tvOk
     * @param content
     * @param msg
     */
    public AlertPopup(Context context, String tvCancle, String tvOk, String content, String msg) {
        super(context);
        LayoutInflater mInflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //设置布局
        mView = mInflate.inflate(R.layout.popup_alert, null);
        //取消按钮
        TextView cancle = (TextView) mView.findViewById(R.id.cancle);
        //确定按钮
        TextView btn_ok = (TextView) mView.findViewById(R.id.btn_ok);
        //title
        TextView tvAlertTitle = (TextView) mView.findViewById(R.id.tvAlertTitle);
        //消息内容
        TextView tvAlertMsg = (TextView) mView.findViewById(R.id.tvAlertMsg);
        View other=mView.findViewById(R.id.other);
        //ll_home
        ll_home = (LinearLayout) mView.findViewById(R.id.ll_sexselect_isdeleter);
        //内容判空
        if(content != null&&!StringUtils.isEmpty(content)){
            tvAlertTitle.setText(content);
        }
        //信息判空
        if(msg!=null&&!StringUtils.isEmpty(msg)){
            tvAlertMsg.setText(msg);
        }
        //控制显示取消按钮
        if(StringUtils.isEmpty(tvCancle)){
            cancle.setVisibility(View.GONE);
            other.setVisibility(View.GONE);
        }
        //取消按钮标题设置
        cancle.setText(StringUtils.isEmpty(tvCancle) ? "":tvCancle);
        //确定按钮标题设置
        btn_ok.setText(StringUtils.isEmpty(tvOk) ? "":tvOk);
        //取消点击事件
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //判空监听器
                    itemClickListener.onItemClick(false);
                }
            }
        });
        //确定点击事件
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //判空监听器
                    itemClickListener.onItemClick(true);
                }
            }
        });
        //设置取消点击效果
        cancle.setBackgroundResource(R.drawable.bg_alertbutton_left);
        //设置确定点击效果
        btn_ok.setBackgroundResource(R.drawable.bg_alertbutton_right);

        //设置SelectPicPopupWindow的View
        this.setContentView(mView);
        //设置SelectPicPopupWindow弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体可点击
        this.setFocusable(true);
        //设置SelectPicPopupWindow弹出窗体动画效果
//        this.setAnimationStyle(R.style.showPopupAnimation);
        ll_home.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in_center));
        //实例化一个ColorDrawable颜色为半透明
        ColorDrawable dw = new ColorDrawable(0xb0000000);
        //设置透明度
        dw.setAlpha(95);
        //设置SelectPicPopupWindow弹出窗体的背景
        this.setBackgroundDrawable(dw);

    }
    //监听器
    private onMyItemClickListener itemClickListener = null;
    //设置监听器
    public void setonMyItemClickListener(onMyItemClickListener listener){
        itemClickListener = listener;
    }
    public interface onMyItemClickListener {
        void onItemClick(boolean flag);
    }
}
