package com.dimeno.dimenoquestion.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnItemClickListener;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.common.base.BaseFragment;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.MineBean;
import com.dimeno.dimenoquestion.ui.actvity.AboutAsActivity;
import com.dimeno.dimenoquestion.ui.actvity.BaseInfoActivity;
import com.dimeno.dimenoquestion.ui.actvity.ChangePwActivity;
import com.dimeno.dimenoquestion.ui.actvity.HelpCenterActivity;
import com.dimeno.dimenoquestion.ui.actvity.LoginActivity;
import com.dimeno.dimenoquestion.ui.adpter.MineAdapter;
import com.dimeno.dimenoquestion.utils.UserUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class MineFragment extends BaseFragment {
    private List<MineBean> list;
    private RecyclerView rcy_mine;
    private ConstraintLayout cl_head;
    private ImageView iv_portrait;
    private TextView tv_contact;
    private TextView tv_identity;
    protected AppCompatActivity mActivity;
    private AlertView alertQuitView;

    public static MineFragment newInstance() {
        MineFragment fragment = new MineFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    protected int getLayoutId() {
        return R.layout.fragment_mine;
    }

    @Override
    public BasePresenter createPresenter() {
        return null;
    }

    @Override
    protected void initThings(View view,Bundle savedInstanceState) {
        mActivity = (AppCompatActivity) getActivity();
        cl_head = view.findViewById(R.id.cl_head);
        iv_portrait = view.findViewById(R.id.iv_portrait);
        tv_contact = view.findViewById(R.id.tv_contact);
        tv_identity = view.findViewById(R.id.tv_identity);
        rcy_mine = view.findViewById(R.id.rcy_mine);
        rcy_mine.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));

    }

    @Override
    protected void initData() {
        initMineData();
        showMine();
    }

    @Override
    public void initListeners() {

    }

    private void initMineData() {
        list = new ArrayList<>();
        tv_contact.setText(UserUtil.getAccount());
        tv_identity.setText(UserUtil.getUserName());
        list.add(new MineBean(R.mipmap.user_item_info, "基本信息"));
        list.add(new MineBean(R.mipmap.user_item_aboutus, "关于我们"));
        list.add(new MineBean(R.mipmap.user_item_help, "帮助中心"));
        list.add(new MineBean(R.mipmap.user_item_password, "修改密码"));
        list.add(new MineBean(R.mipmap.user_item_logout, "退出登录"));
        cl_head.setBackgroundResource(R.mipmap.head_bg);
        iv_portrait.setImageResource(R.mipmap.mine_head);
    }
    public void showMine() {
        MineAdapter mineAdapter = new MineAdapter(list);
        mineAdapter.setOnClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClick(View itemView, int position) {
                switch (position) {
                    case 0:
                        gotoActivity(BaseInfoActivity.class);
                        break;
                    case 1:
                        gotoActivity(AboutAsActivity.class);
                        break;
                    case 2:
                        gotoActivity(HelpCenterActivity.class);
                        break;
                    case 3:
                        gotoActivity(ChangePwActivity.class);
                        break;
                    case 4:
//                        gotoActivity(DealExceptionQueActivity.class);
                        showQuitDialog();
                        break;
                }
            }
        });
        rcy_mine.setAdapter(mineAdapter);
    }
    private void showQuitDialog() {
        if (alertQuitView == null) {
            alertQuitView = new AlertView("退出", "退出系统后需要重新登录", "取消", new String[]{"确定"}, null,
                    getContext(), AlertView.Style.Alert, new OnItemClickListener() {
                @Override
                public void onItemClick(Object o, int position) {
                    if (o == alertQuitView && position == 0) {
                        quitSysTem();
                    }
                }
            });
        }
        alertQuitView.show();
    }

    private void quitSysTem() {
        UserUtil.setIsLogin(false);
        UserUtil.set2GetArea(false);
        ActivityManager.getAppManager().finishAllActivity();
        startActivity(new Intent(getActivity(), LoginActivity.class));
    }
}
