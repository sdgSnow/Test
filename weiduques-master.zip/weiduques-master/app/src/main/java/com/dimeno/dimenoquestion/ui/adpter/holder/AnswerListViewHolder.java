package com.dimeno.dimenoquestion.ui.adpter.holder;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.constant.AnswerState;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.actvity.EditSurveyActivity;
import com.dimeno.dimenoquestion.ui.adpter.AnswerListRecyclerAdapter;
import com.dimeno.dimenoquestion.ui.adpter.NewQuesAdapter;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AnswerListViewHolder extends RecyclerViewHolder<Answer> {

    private final TextView tvAnswerCode;
    private final TextView tvTime;
    private final RelativeLayout rlUploadBtnLayout;
    private final TextView btnUploadRecord;
    private final ImageView ivDone;
    private final TextView tvUploadStatus;
    private final TextView edit_answer;
    private final TextView btnUpload;
    private Context mContext;
    private AnswerListRecyclerAdapter.MyOnItemClickListener onItemClickListener;
    private final LinearLayout llItem;

    /**
     * 构造器
     * @param parent
     */
    public AnswerListViewHolder(Context context, @NonNull ViewGroup parent, AnswerListRecyclerAdapter.MyOnItemClickListener onItemClickListener) {
        super(parent, R.layout.item_answer_layout);
        this.mContext = context;
        this.onItemClickListener = onItemClickListener;
        llItem = findViewById(R.id.llItem);
        tvAnswerCode = findViewById(R.id.tvAnswerCode);
        tvTime = findViewById(R.id.tvTime);
        rlUploadBtnLayout = findViewById(R.id.rlUploadBtnLayout);
        btnUploadRecord = findViewById(R.id.btnUploadRecord);
        ivDone = findViewById(R.id.ivDone);
        tvUploadStatus = findViewById(R.id.tvUploadStatus);
        edit_answer = findViewById(R.id.edit_answer);
        btnUpload = findViewById(R.id.btnUpload);
    }

    @Override
    public void bind() {
        //这里的答卷编号只是页面展示，没什么作用
        tvAnswerCode.setText("答卷编码: " + mData.getAnswerStartTime());
        tvTime.setText("答题时间: " + TimeUtil.getTime(mData.getAnswerStartTime()));

        rlUploadBtnLayout.setVisibility(TextUtils.isEmpty(mData.getTest()) ? View.GONE : (mData.getTest().equals("1") ? View.VISIBLE : View.GONE));
        btnUploadRecord.setVisibility(TextUtils.isEmpty(mData.getTest()) ? View.GONE : (mData.getTest().equals("1") ? View.VISIBLE : View.GONE));
        int state = mData.getAnswerState();

        /**
         * 0 是未上传(继续编辑)
         * 1 是有网已上传
         * 2 是保存在本地，未上传（上传问卷）
         */
        if (state == AnswerState.EDIT) {
            //未提交
            rlUploadBtnLayout.setVisibility(View.VISIBLE);
            btnUpload.setVisibility(View.GONE);
            edit_answer.setVisibility(View.VISIBLE);
            ivDone.setVisibility(View.GONE);
            tvUploadStatus.setVisibility(View.GONE);
        }else if (state == AnswerState.COMPLETE) {
            //等待上传
            rlUploadBtnLayout.setVisibility(View.VISIBLE);
            btnUpload.setVisibility(View.VISIBLE);
            edit_answer.setVisibility(View.GONE);
            ivDone.setVisibility(View.GONE);
            tvUploadStatus.setVisibility(View.GONE);
        } else if (state == AnswerState.UPLOAD) {
            //已上传
            edit_answer.setVisibility(View.GONE);
            btnUpload.setVisibility(View.GONE);
            ivDone.setVisibility(View.GONE);
            tvUploadStatus.setVisibility(View.VISIBLE);
            if (TextUtils.isEmpty(mData.getTest()) && "1".equals(mData.getTest())) {
                rlUploadBtnLayout.setVisibility(View.VISIBLE);
            } else {
                rlUploadBtnLayout.setVisibility(View.GONE);
            }
        }

        //编辑答题
        edit_answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //继续编辑
                Intent intent = new Intent();
                intent.setClass(mContext, EditSurveyActivity.class);
                intent.putExtra("type", "edit");
                intent.putExtra("answerID", mData.getId() + "");
                ((Activity) mContext).startActivityForResult(intent, 1);
            }
        });

        //上传答案
        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //上传答案
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(getAdapterPosition(), mData);
                }
            }
        });

        //查看&编辑
        llItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (state == AnswerState.COMPLETE) {
//                    //查看
//                    Intent intent = new Intent();
//                    intent.setClass(mContext, EditSurveyActivity.class);
//                    intent.putExtra("type", "edit");
//                    intent.putExtra("answerID", item.getId() + "");
//                    startActivity(intent);
//                }
                if (state == AnswerState.UPLOAD) {
                    //查看
                    Intent intent = new Intent();
                    intent.setClass(mContext, EditSurveyActivity.class);
                    intent.putExtra("type", "look");
                    intent.putExtra("answerID", mData.getId() + "");
                    mContext.startActivity(intent);
                }
            }
        });

        //删除答案
        llItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (state == AnswerState.UPLOAD) {
                    if (onItemClickListener != null) {
                        onItemClickListener.onItemLongClick(getAdapterPosition(), mData);
                    }
                }
                return true;
            }
        });
    }

}
