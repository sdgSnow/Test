package com.dimeno.dimenoquestion.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.StringUtils;

/**
 * OptionBubble 选项气泡
 * Created by wangzhen on 2020/5/21.
 */
public class OptionBubble2 extends PopupWindow {
    private static final int DELAY_MILLIS = 3000;
    private View mView;
    private TextView mContentView;
    private Handler handler = new Handler();

    public OptionBubble2(Context context, String text) {
        super(context);
        LayoutInflater mInflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mView = mInflate.inflate(R.layout.pop_option, null);
        mContentView = (TextView) mView.findViewById(R.id.mContentView);
        if(!StringUtils.isEmpty(text)){
            mContentView.setText(text);
        }

        mView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        //设置SelectPicPopupWindow的View
        this.setContentView(mView);
//        //设置SelectPicPopupWindow弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
//        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
//        //设置SelectPicPopupWindow弹出窗体可点击
//        this.setFocusable(true);
        setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }

    public void setTitle(String title){
        if(mContentView!=null && !StringUtils.isEmpty(title)){
            mContentView.setText(title);
        }
    }

    @Override
    public void showAtLocation(View parent, int gravity, int x, int y) {
        super.showAtLocation(parent, gravity, x, y);
        MyLog.d("opthionpop","showAtLocation  x="+x+"  ,y="+y);
        handler.removeCallbacks(runnable);
        handler.postDelayed(runnable, DELAY_MILLIS);
    }

    @Override
    public void dismiss() {
        super.dismiss();
        MyLog.d("opthionpop","dismiss");
        handler.removeCallbacks(runnable);
    }

    private Runnable runnable = () -> {
        if (isShowing()) {
            MyLog.d("opthionpop","runnable dismiss");
            dismiss();
        }
    };

    public int getWidth() {
        return mContentView.getMeasuredWidth();
    }

    public int getHeight() {
        return mContentView.getMeasuredHeight();
    }
}
