package com.dimeno.dimenoquestion.pop;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.ui.adpter.DiaryUpAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.MaxHeightRecyclerView;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/4/19
 * Description :消息弹框
 */
public class AlertListPopup extends PopupWindow {
    private View mView;
    private LinearLayout ll_home;

    /**
     * 默认使用“取消”，“确定”
     * @param context
     * @param content
     */
    public AlertListPopup(Context context, String content,String msg, List<String> list) {
        super(context);
        LayoutInflater mInflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //加载布局
        mView = mInflate.inflate(R.layout.popup_alert_list, null);
        //取消按钮
        TextView cancle = (TextView) mView.findViewById(R.id.cancle);
        //确定按钮
        TextView btn_ok = (TextView) mView.findViewById(R.id.btn_ok);
        //title
        TextView tvAlertTitle = (TextView) mView.findViewById(R.id.tvAlertTitle);
        //消息内容
        TextView tvAlertMsg = (TextView) mView.findViewById(R.id.tvAlertMsg);
        //消息list
        MaxHeightRecyclerView recyclerView = (MaxHeightRecyclerView) mView.findViewById(R.id.recycler);
        //消息内容
        ll_home = (LinearLayout) mView.findViewById(R.id.ll_sexselect_isdeleter);
        //设置方向
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        //判空
        if(list!=null){
            //设置adapter
            DiaryUpAdapter adapter=new DiaryUpAdapter(list,context);
            recyclerView.setAdapter(adapter);
        }
        //判空消息内容
        if(msg!=null&&!StringUtils.isEmpty(msg)){
            tvAlertMsg.setText(msg);
        }
        //判空
        if(content != null&&!StringUtils.isEmpty(content)){
            tvAlertTitle.setText(content);
        }
        //取消监听
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //监听器判空
                    itemClickListener.onItemClick(false);
                }
            }
        });
        //确定监听
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemClickListener!=null){
                    //监听器判空
                    itemClickListener.onItemClick(true);
                }
            }
        });
        //设置点击效果
        cancle.setBackgroundResource(R.drawable.bg_alertbutton_left);
        //设置确定点击效果
        btn_ok.setBackgroundResource(R.drawable.bg_alertbutton_right);
        //设置SelectPicPopupWindow的View
        this.setContentView(mView);
        //设置SelectPicPopupWindow弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体可点击
        this.setFocusable(true);
        //设置SelectPicPopupWindow弹出窗体动画效果
        //this.setAnimationStyle(R.style.showPopupAnimation);
        ll_home.startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in_center));
        //实例化一个ColorDrawable颜色为半透明
        ColorDrawable dw = new ColorDrawable(0xb0000000);
        //设置透明度
        dw.setAlpha(95);
        //设置SelectPicPopupWindow弹出窗体的背景
        this.setBackgroundDrawable(dw);

    }

    private onMyItemClickListener itemClickListener = null;

    public void setonMyItemClickListener(onMyItemClickListener listener){
        itemClickListener = listener;
    }
    public interface onMyItemClickListener {
        void onItemClick(boolean flag);
    }
}
