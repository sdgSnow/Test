package com.dimeno.dimenoquestion.constant;

public class OperationType {
    //接口日志
    public static final int API = 10;
    //异常日志
    public static final int ERROR = 20;
    //正常操作日志
    public static final int OPERATION = 30;

}
