package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.UserEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface MessageView extends BaseView {
    /**
     * 成功回调
     * @param recordsBeans
     */
    void onSucess(List<MessageEntity.RecordsBean> recordsBeans);

    /**
     * 失败回调
     * @param msg
     */
    void onFail(String msg);
}
