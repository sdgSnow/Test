package com.dimeno.dimenoquestion.ui.adpter.holder.base;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class BaseViewHolder<T> extends RecyclerView.ViewHolder {
    protected T mData;

    /**
     * BaseViewHolder
     * @param itemView
     */
    public BaseViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    /**
     * BaseViewHolder
     * @param parent
     * @param layoutId
     */
    public BaseViewHolder(@NonNull ViewGroup parent, @LayoutRes int layoutId) {
        this(inflate(parent, layoutId, false));
    }

    /**
     * bind
     * @param data
     */
    public void bind(T data) {
        this.mData = data;
    }

    /**
     * inflate
     * @param parent
     * @param layoutId
     * @param attachToRoot
     * @return
     */
    protected static View inflate(ViewGroup parent, @LayoutRes int layoutId, boolean attachToRoot) {
        return LayoutInflater.from(parent.getContext()).inflate(layoutId, parent, attachToRoot);
    }

    /**
     * findViewById
     * @param id
     * @param <VIEW>
     * @return
     */
    protected <VIEW extends View> VIEW findViewById(@IdRes int id) {
        return itemView.findViewById(id);
    }
    /**
     * Sets the on click listener of the view.
     *
     * @param viewId   The view id.
     * @param listener The on click listener;
     * @return The BaseViewHolder for chaining.
     */
    @Deprecated
    public BaseViewHolder setOnClickListener(@IdRes int viewId, View.OnClickListener listener) {
        View view = findViewById(viewId);
        view.setOnClickListener(listener);
        return this;
    }
}
