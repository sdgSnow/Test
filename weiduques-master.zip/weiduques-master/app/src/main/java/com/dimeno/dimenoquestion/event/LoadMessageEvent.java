package com.dimeno.dimenoquestion.event;

public class LoadMessageEvent {
    public LoadMessageEvent(){
    }
}
