package com.dimeno.dimenoquestion.bean;

/**
 * Create by   :PNJ
 * Date        :2021/4/1
 * Description :排序 A
 */
public class SortA {
    /**
     * 值
     */
    public String value;
    /**
     * 排序
     */
    public String sort;

    /**
     * 构造器
     * @param value
     * @param sort
     */
    public SortA(String value, String sort) {
        this.value = value;
        this.sort = sort;
    }
}
