package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.MessageEntity;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.ui.view.MessageView;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyToast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.ApiConstant.loginUser;
import static com.dimeno.dimenoquestion.constant.OperationType.API;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class MessagePresenter extends BasePresenter<MessageView> {
    /**
     * 消息
     * @param context
     */
    public void getAppMessages(Context context,int page){
        //传参
        HashMap<String, Object> params = new HashMap<>();
        params.put("page", page);
        params.put("recPerPage", ConstantType.Load.SIZE);

        Observable<Res<MessageEntity>> observable= RetrofitManager.getInstance().getAppService()
                .getAppMessages(RetrofitManager.getInstance().getCacheControl(),params);
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<MessageEntity>() {
            @Override
            protected void onHandleSuccess(Res<MessageEntity> messageEntity) {
                if(getMvpView()!=null){
                    if(messageEntity != null && messageEntity.Flag == 0 && messageEntity.ResultObj != null){
                        if(messageEntity.ResultObj.getRecords() != null && messageEntity.ResultObj.getRecords().size() > 0){
                            getMvpView().onSucess(messageEntity.ResultObj.getRecords());
                        }else {
                            getMvpView().onFail(messageEntity.Msg);
                        }
                    }else {
                        getMvpView().onFail("数据异常");
                    }
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //添加日志
                //防止activity销毁
                if(getMvpView()!=null) {
                    //失败回调
                    getMvpView().onFail(error);
                }
            }
        });
    }

}
