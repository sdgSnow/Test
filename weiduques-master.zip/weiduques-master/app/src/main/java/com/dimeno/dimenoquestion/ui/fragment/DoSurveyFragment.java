package com.dimeno.dimenoquestion.ui.fragment;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bigkoo.alertview.AlertView;
import com.bigkoo.alertview.OnDismissListener;
import com.bigkoo.alertview.OnItemClickListener;
import com.dimeno.common.base.BaseFragment;
import com.dimeno.common.base.LazyLoadFragment;
import com.dimeno.common.event.Event;
import com.dimeno.common.event.EventBusUtils;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.QuePageBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.map.LocationOnceUtils;
import com.dimeno.dimenoquestion.pop.SignPopup;
import com.dimeno.dimenoquestion.ui.actvity.AnswerListActivity;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.ui.presenter.DoSurePresenter;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.OptionBubble;
import com.dimeno.dimenoquestion.widget.OptionBubble2;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.Serializable;
import java.util.ArrayList;

import static com.dimeno.dimenoquestion.constant.EventConstant.SURVEY_STOP;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :答题--
 */
public class DoSurveyFragment extends BaseFragment {
    private RecyclerView recyclerView;
    private int page;
    //适配器
    private QueAdapter doSurveyAdapter;
    private TextView title,remarks;
    //题目列表
    private ArrayList<PageSubjectBean> quesBeanList;
    private QuePageBean quePageBean;
    private String mTitle;
    private String type;
    private String mRemarks;
    private LinearLayoutManager mLayoutManager;
    private MyBroadcastReceiver broadcastReceiver;
    private LocalBroadcastManager localBroadcastManager;

    /**
     * 初始化DoSurveyFragment
     * @param num
     * @param type
     * @param queId
     * @param title
     * @param remarks
     * @param quePageBean
     * @return
     */
    public static DoSurveyFragment newInstance(int num,String type, String queId, String title, String remarks, QuePageBean quePageBean) {
        DoSurveyFragment fragment = new DoSurveyFragment();
        Bundle args = new Bundle();
        args.putInt("page", num);
        args.putString("queId", queId);
        args.putString("title", title);
        args.putString("type", type);
        args.putString("remarks", remarks);
//        args.putSerializable("quePageBean", (Serializable) quePageBean);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * 设置答题页
     * @param quePageBean
     */
    public void setQuePageBean(QuePageBean quePageBean){
        this.quePageBean=quePageBean;
    }

    /**
     * 设置布局
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.frag_do_sure;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        Log.d("DoSureFragment","onSaveInstanceState    page="+page);
        super.onSaveInstanceState(outState);
    }

    /**
     * createPresenter
     * @return
     */
    @Override
    public DoSurePresenter createPresenter() {
        return new DoSurePresenter();
    }

    /**
     * initThings
     * 初始化一些事情
     * @param view
     * @param savedInstanceState
     */
    @Override
    protected void initThings(View view,Bundle savedInstanceState) {
        Log.d("DoSureFragment","initThings");
        //获取页码
        page = getArguments() != null ? getArguments().getInt("page") : 0;
        Log.d("DoSureFragment","page="+page);
        //获取title
        mTitle = getArguments() != null ? getArguments().getString("title") : "";
        //获取类型
        type = getArguments() != null ? getArguments().getString("type") : "";
        //获取注释
        mRemarks = getArguments() != null ? getArguments().getString("remarks") : "";
        //quePageBean = getArguments() != null ? (QuePageBean) getArguments().getSerializable("quePageBean") : null;
        recyclerView = view.findViewById(R.id.rcy_new_ques);
        //方向
        mLayoutManager= new LinearLayoutManager(getActivity());
        //设置方向
        recyclerView.setLayoutManager(mLayoutManager);
        //初始化适配器
        doSurveyAdapter=new QueAdapter(getActivity(),new ArrayList<>(),type);
        //设置适配器
        recyclerView.setAdapter(doSurveyAdapter);
        //头部布局
        View headerView = View.inflate(getContext(), R.layout.dosurvey_header_layout, null);
        title=headerView.findViewById(R.id.title);
        remarks=headerView.findViewById(R.id.remarks);
        //设置头部
        headerView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        doSurveyAdapter.addHeader(headerView);
        //参数判空
        if(quePageBean!=null ){
            title.setText(StringUtils.isEmpty(mTitle)?"":mTitle);
            remarks.setText(StringUtils.isEmpty(mRemarks)?"":mRemarks);
            //题目列表判空
            if(quePageBean.getQueSubject()!=null && quePageBean.getQueSubject().size()>0 ){
                quesBeanList=quePageBean.getQueSubject();
                //适配器设置数据
                doSurveyAdapter.setmData(quesBeanList);
            }
        }
        //recyclerView滑动监听
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
//                doSurveyAdapter.hideOptionBubble();
                //去掉冒泡
                hideOptionBubble();
            }
        });
        //初始化广播
        initBroadcastReceiver();
    }

    @Override
    public void onDestroy() {
        LocationOnceUtils.getInstance().onStop();
        //去掉冒泡
        hideOptionBubble();
        doSurveyAdapter.unregister();
        //注销广播
        if (broadcastReceiver != null) {
            localBroadcastManager.unregisterReceiver(broadcastReceiver);
            localBroadcastManager = null;
            broadcastReceiver = null;
        }
        //冒泡控件隐藏
        if (mOptionBubble != null && mOptionBubble.isShowing()) {
            mOptionBubble.dismiss();
            mOptionBubble=null;
        }
        super.onDestroy();
    }

    @Override
    public void initListeners() {
        doSurveyAdapter.setChildClickLisener(new QueAdapter.OnChildClickLisener() {
            @Override
            public void onChildClick(View view, int position) {
                doSurveyAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildEndClick(View view,int position) {
                Integer[] list = new Integer[3];
                //获取页码
                list[0] = page;
                if(position>=0){
                    //获取end在该页的题目列表位置
                    list[1] = position;
                }else {
                    list[1] = 0;
                }
                //结束调查
                EventBusUtils.getInstance().postEvent(new Event(SURVEY_STOP, list));
            }

            @Override
            public void showOptionBubble(View anchor, String option) {
                showOption(anchor,option);
            }
        });
    }

    /**
     * 回调答案给Activity
     * @return
     */
    // 设置 接口回调 方法
    public void getQuesBeanList(FramentCallBack callBack){
        callBack.getDataList(quesBeanList);
    }


    public ArrayList<PageSubjectBean> getQuesBeanList(){
        return quesBeanList;
    }


    private class MyBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            //获取在该页的题目列表位置
            int position = intent.getIntExtra("sort", 0);
            //是否是end
            boolean isEnd = intent.getBooleanExtra("end", false);
            if (position >= doSurveyAdapter.getDatas().size()) {
                position = doSurveyAdapter.getDatas().size() - 1;
            }
            int finalPosition = position;
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if(isEnd) {
                        //选择清空
                        if (doSurveyAdapter.getDatas().get(finalPosition).getSurveyAnswer() != null) {
                            //单选，多选,排序，则清空
                            if (doSurveyAdapter.getDatas().get(finalPosition).getSurveyAnswer().choiceList != null) {
                                doSurveyAdapter.getDatas().get(finalPosition).getSurveyAnswer().choiceList.clear();
                            }
                            //下拉，则清空
                            if (doSurveyAdapter.getDatas().get(finalPosition).getSurveyAnswer().OptionList != null) {
                                doSurveyAdapter.getDatas().get(finalPosition).getSurveyAnswer().OptionList.clear();
                            }
                        }
                    }else {
                        doSurveyAdapter.getDatas().get(finalPosition).setError(true);
                        //因为含有头部，所以加一
//                        MyUtils.smoothMoveToPosition(recyclerView, finalPosition+1);
                        MyUtils.MoveToPosition(mLayoutManager, finalPosition+1);
                    }
                    doSurveyAdapter.notifyDataSetChanged();
                    Log.d("adpterFlush","MyBroadcastReceiver notifyDataSetChanged position="+(finalPosition+1));
                }
            });
        }
    }

    /**
     * 初始化广播
     */
    private void initBroadcastReceiver() {
        localBroadcastManager = LocalBroadcastManager.getInstance(getActivity());
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(page + "");
        broadcastReceiver = new MyBroadcastReceiver();
        localBroadcastManager.registerReceiver(broadcastReceiver, intentFilter);
    }

    public interface FramentCallBack {
        void getDataList(ArrayList<PageSubjectBean> list);
    }

    /**
     * 显示选项气泡
     *
     * @param anchor anchor
     * @param option option
     */
    private OptionBubble mOptionBubble;
    private void showOption(View anchor, String option) {
        hideOptionBubble();
        int[] location = new int[2];
        anchor.getLocationOnScreen(location);
        mOptionBubble = new OptionBubble(getActivity(), option);
        MyLog.d("opthionpop","option="+option);
        int x = location[0] - (mOptionBubble.getWidth() - anchor.getMeasuredWidth()) / 2;
        int y = location[1] - mOptionBubble.getHeight() - UIUtils.dip2px(MyApplication.getContext(), 2);
        MyLog.d("opthionpop","showAtLocation");
        mOptionBubble.showAtLocation(recyclerView, Gravity.NO_GRAVITY, x, y);
    }

    /**
     * 隐藏选项气泡
     */
    public void hideOptionBubble() {
        if (mOptionBubble != null && mOptionBubble.isShowing()) {
            mOptionBubble.dismiss();
        }
    }

}
