package com.dimeno.dimenoquestion.ui.presenter;

import android.content.Context;

import com.dimeno.common.base.BasePresenter;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.Res;
import com.dimeno.dimenoquestion.bean.UserEntity;
import com.dimeno.dimenoquestion.http.BaseObserver;
import com.dimeno.dimenoquestion.http.RetrofitManager;
import com.dimeno.dimenoquestion.http.RetrofitUtil;
import com.dimeno.dimenoquestion.ui.view.ChangPwView;
import com.dimeno.dimenoquestion.ui.view.LoginView;
import com.dimeno.dimenoquestion.utils.LogUtils;

import java.util.Map;

import io.reactivex.Observable;

import static com.dimeno.dimenoquestion.constant.ApiConstant.updatePwd;
import static com.dimeno.dimenoquestion.constant.OperationType.API;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class ChangePwPresenter extends BasePresenter<ChangPwView> {
    /**
     * 修改密码接口
     * @param context
     * @param params
     */
    public void ChangePw(Context context,Map<String, String> params){
        //获取observable
        Observable<Res<UserEntity>> observable= RetrofitManager.getInstance().getAppService()
                .updatePwd(RetrofitManager.getInstance().getCacheControl(),params);
        //接口
        RetrofitUtil.get().request(context,this, observable, new BaseObserver<UserEntity>() {
            @Override
            protected void onHandleSuccess(Res<UserEntity> userEntity) {
                LogUtils.e("Login",JsonUtil.toJson(userEntity));
                //接口成功
                if (userEntity.Flag == 0) {
                    //以防activity销毁奔溃
                    if(getMvpView()!=null) {
                        //成功回调
                        getMvpView().LoginSucess();
                    }
                } else {
                    //接口失败，添加日志
                    LogUtils.addLog(updatePwd,API,"",0l,"修改密码",JsonUtil.toJson(userEntity));
                    //以防activity销毁奔溃
                    if(getMvpView()!=null) {
                        //失败回调
                        getMvpView().LoginFail(userEntity.Msg);
                    }
                }
            }

            @Override
            protected void onHandleFaild(int code, String error) {
                //接口失败，添加日志
                LogUtils.addLog(updatePwd,API,"",0l,"修改密码",JsonUtil.toJson(params));
                if(getMvpView()!=null) {
                    //失败回调
                    getMvpView().LoginFail(error);
                }
            }
        });
    }

}
