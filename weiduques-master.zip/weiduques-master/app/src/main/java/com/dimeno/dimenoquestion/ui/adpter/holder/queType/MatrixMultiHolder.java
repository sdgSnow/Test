package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.ui.adpter.MatrixMultiAdapter;
import com.dimeno.dimenoquestion.ui.adpter.MatrixSingleTitleAdapter;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.GridSpacesItemDecoration;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static com.dimeno.dimenoquestion.utils.DimenValue.TOP_ITEM_DECORATION_10;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :矩阵多选
 */
public class MatrixMultiHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final RecyclerView rv_title;
    private final RecyclerView rv_option;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    private Map<Integer, MatrixMultiAdapter> map=new HashMap<>();
    private  SpannableStringBuilder title;
    //add新添加，edit编辑，look查看
    private String type;
    private boolean flag;
    private QueAdapter.OnChildClickLisener onChildClickLisener;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public MatrixMultiHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_matrix_single);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        rv_title = findViewById(R.id.rv_title);
        rv_option = findViewById(R.id.rv_option);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        this.type=type;
        this.onChildClickLisener=onChildClickLisener;
        Log.d("adpterFlush","矩阵多选 MatrixMultiHolder create");
    }


    @Override
    public void bind() {
        if(mData.getAttr()!=null && mData.getQueOption()!=null) {

            title = StringUtils.getTitle(mData.getAttr().getTitle(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);

            //初始化题目+选项
            MatrixSingleTitleAdapter singleTitleAdapter = new MatrixSingleTitleAdapter();
            if (rv_title.getItemDecorationCount() == 0) {
                rv_title.addItemDecoration(new GridSpacesItemDecoration(itemView.getContext(), mData.getQueOption().size(), TOP_ITEM_DECORATION_10, false));
            }
            if (mData.getQueOption() != null && mData.getQueOption().size() > 1) {
                Collections.sort(mData.getQueOption(), new Comparator<QueOptionBean>() {
                    @Override
                    public int compare(QueOptionBean o1, QueOptionBean o2) {
                        return o1.getSort() - o2.getSort();
                    }
                });
            }
            rv_title.setLayoutManager(new GridLayoutManager(itemView.getContext(), mData.getQueOption().size(), GridLayoutManager.VERTICAL, false));
            rv_title.setAdapter(singleTitleAdapter);
            singleTitleAdapter.setData(mData.getQueOption());
            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
            } else {
                frame_error.setVisibility(View.GONE);
            }

            if(!StringUtils.isEmpty(mData.getAttr().getQuestionList())) {

                if (map.get(getAdapterPosition()) == null) {
                    //初始化题目+问题
                    String[] quesList = mData.getAttr().getQuestionList().split("\n");
                    List<String> selectList = new ArrayList<>();
                    for (int i = 0; i < quesList.length; i++) {
                        selectList.add(quesList[i]);
                    }
                    //初始化答案
                    if (mData.getSurveyAnswer().matrixAnswers == null) {
                        ArrayList<SurveyAnswer.MatrixAnswer> matrixAnswers = new ArrayList<>();
                        mData.getSurveyAnswer().matrixAnswers = matrixAnswers;
                    }
                    if (mData.getSurveyAnswer().matrixAnswers.size() == 0) {
                        mData.getSurveyAnswer().matrixAnswers.clear();
                        for (int i = 0; i < quesList.length; i++) {
                            SurveyAnswer.MatrixAnswer answer = new SurveyAnswer.MatrixAnswer();
                            answer.opCodes = new HashSet<>();
                            mData.getSurveyAnswer().matrixAnswers.add(answer);
                        }
                    }

                    MatrixMultiAdapter matrixMultiAdapter = new MatrixMultiAdapter(selectList, mData.getQueOption(), mData.getSurveyAnswer().matrixAnswers, type);
                    rv_option.setLayoutManager(new GridLayoutManager(itemView.getContext(), 1, GridLayoutManager.VERTICAL, false));
                    rv_option.setAdapter(matrixMultiAdapter);
                    matrixMultiAdapter.setChildClickLisener(new MatrixMultiAdapter.OnChildClickLisener() {
                        @Override
                        public void onChildClick() {
                            flag = false;
                            if (mData.getSurveyAnswer() != null && mData.getSurveyAnswer().choiceList != null && mData.getSurveyAnswer().choiceList.size() != 0) {
                                for (int i = 0; i < mData.getSurveyAnswer().choiceList.size(); i++) {
                                    if (mData.getSurveyAnswer().choiceList.get(i).isFill() && mData.getSurveyAnswer().choiceList.get(i).isMust()) {
                                        if (StringUtils.isEmpty(mData.getSurveyAnswer().choiceList.get(i).getFillContent())) {
                                            flag = true;
                                        }
                                    }
                                }
                            }
                            if (!flag) {
                                if (mData.isError()) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                            }

                        }

                        @Override
                        public void showOptionBubble(View anchor, String option) {
                            //弹出气泡
                            if (onChildClickLisener != null) {
                                onChildClickLisener.showOptionBubble(anchor, option);
                            }
                        }
                    });
                    map.put(getAdapterPosition(), matrixMultiAdapter);
                    Log.d("adpterFlush", "矩阵多选 holder setadpter=" + getAdapterPosition() + "   map.size=" + map.size());
                } else {
                    MatrixMultiAdapter matrixMultiAdapter = map.get(getAdapterPosition());
                    rv_option.setAdapter(matrixMultiAdapter);
                    Log.d("adpterFlush", "矩阵多选 holder getAdapterPosition=" + getAdapterPosition() + "   map.size=" + map.size());
                    matrixMultiAdapter.setChildClickLisener(new MatrixMultiAdapter.OnChildClickLisener() {
                        @Override
                        public void onChildClick() {
                            //todo 待验证
                            flag = false;
                            if (mData.getSurveyAnswer() != null && mData.getSurveyAnswer().choiceList != null && mData.getSurveyAnswer().choiceList.size() != 0) {
                                for (int i = 0; i < mData.getSurveyAnswer().choiceList.size(); i++) {
                                    if (mData.getSurveyAnswer().choiceList.get(i).isFill() && mData.getSurveyAnswer().choiceList.get(i).isMust()) {
                                        if (StringUtils.isEmpty(mData.getSurveyAnswer().choiceList.get(i).getFillContent())) {
                                            flag = true;
                                        }
                                    }
                                }
                            }
                            if (!flag) {
                                if (mData.isError()) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                            }
//                            if (mData.isError()) {
//                                mData.setError(false);
//                                frame_error.setVisibility(View.GONE);
//                            }
                        }

                        @Override
                        public void showOptionBubble(View anchor, String option) {
                            //弹出气泡
                            if (onChildClickLisener != null) {
                                onChildClickLisener.showOptionBubble(anchor, option);
                            }
                        }
                    });
                }
            }
        }
    }
}
