package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :19.分隔符
 */
public class SeparatorHolder extends RecyclerViewHolder<PageSubjectBean> {
    private LinearLayout ll_home;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     */
    public SeparatorHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener) {
        super(parent, R.layout.item_separator);
        ll_home=findViewById(R.id.ll_home);
    }

    @Override
    public void bind() {
    }
}
