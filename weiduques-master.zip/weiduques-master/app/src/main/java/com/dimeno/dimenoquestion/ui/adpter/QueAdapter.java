package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.adapter.holder.HeaderFooterViewHolder;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.constant.ConstantUtil;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.AnnexHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.AutoIncrementHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.DropDownHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.ExplanHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.FillDataHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.FillNumTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.FillTextHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.FillTimeHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.GaugeHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.LocationHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MatrixGaugeHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MatrixMultiHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MatrixSingleHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MultiBlankHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MultiHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.MultiPullDownHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.NothingHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QuestionAnswerHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.SeparatorHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.SignHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.SingleChoiceHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.SortingHolder;
import com.dimeno.dimenoquestion.utils.MyLog;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :所有题型入口，在根据类型来选择不同的题型Holder
 */
public class QueAdapter extends RecyclerAdapter<PageSubjectBean> {
    private List<PageSubjectBean> mData=new ArrayList<>();
    private Context mContext;
    private List<AnnexHolder> annexHolderList=new ArrayList<>();
    private List<SignHolder> signHolderList=new ArrayList<>();
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param context
     * @param list
     * @param type
     */
    public QueAdapter(Context context,List<PageSubjectBean> list,String type) {
        super(list);
        this.mContext=context;
        this.type=type;
    }

    /**
     * @param list
     */
    public void setmData(List<PageSubjectBean> list) {
        setData(list);
        this.mData=list;
    }

    /**
     * 注销EventBus
     */
    public void unregister(){
        if(annexHolderList!=null && annexHolderList.size()!=0){
            for (int i = 0; i < annexHolderList.size(); i++) {
                annexHolderList.get(i).unregister();
            }
        }
        if(signHolderList!=null && signHolderList.size()!=0){
            for (int i = 0; i < signHolderList.size(); i++) {
                signHolderList.get(i).destroy();
            }
        }
    }


    @Override
    protected int getAbsItemViewType(int position) {
        MyLog.d("getAbsItemViewType","QueAdapter   data.size="+mData.size()+"   position="+position);
        if(position>=mData.size()){
            return 0;
        }
        if(mData.size()==0){
            return 0;
        }
        return mData.get(position).getSubType();
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType){
            case QueFormat.Single://1单选
                return new SingleChoiceHolder(parent,onChildClickLisener,type,mData);
            case QueFormat.Multiple://2多选
                return new MultiHolder(parent,onChildClickLisener,type,mData);
            case QueFormat.Drop_down://3 下拉题
                return new DropDownHolder(parent,onChildClickLisener,type,mData);
            case QueFormat.Question_answer://4 问答题
                return new QuestionAnswerHolder(parent,onChildClickLisener,type);
            case QueFormat.Fill_text://5 文本填空题
                return new FillTextHolder(parent,onChildClickLisener,type);
            case QueFormat.Fill_num_text://6 数值填空题
                return new FillNumTextHolder(parent,onChildClickLisener,type);
            case QueFormat.Fill_data://7 日期填空题
                return new FillDataHolder(parent,onChildClickLisener,type);
            case QueFormat.Multi_blank://8 多项填空题,连续填空
                return new MultiBlankHolder(parent,onChildClickLisener,type);
            case QueFormat.Fill_time://9 时间填空题
                return new FillTimeHolder(parent,onChildClickLisener,type);
            case QueFormat.Gauge://10 量表题
                return new GaugeHolder(parent,onChildClickLisener,type);
            case QueFormat.Matrix_single://11矩阵单选
                return new MatrixSingleHolder(parent,onChildClickLisener,type);
            case QueFormat.Matrix_multi://12矩阵多选
                return new MatrixMultiHolder(parent,onChildClickLisener,type);
            case QueFormat.Sorting://13 排序
                return new SortingHolder(parent,onChildClickLisener,type,mData);
            case QueFormat.Explan://14 文字说明
                return new ExplanHolder(parent,onChildClickLisener,type);
            case QueFormat.Annex://15 附件
                AnnexHolder annexHolder=new AnnexHolder(parent,onChildClickLisener,type);
                annexHolderList.add(annexHolder);
                return annexHolder;
            case QueFormat.Matrix_gauge://18 矩阵量表
                return new MatrixGaugeHolder(parent,onChildClickLisener,type);
            case QueFormat.Separator://19 分隔符
                return new SeparatorHolder(parent,onChildClickLisener);
            case QueFormat.Auto_increment://24 自增表格
                return new AutoIncrementHolder(parent,onChildClickLisener,type);
            case QueFormat.Multi_pull_down://25多级下拉，连续下拉
                return new MultiPullDownHolder(parent,onChildClickLisener,type);
            case QueFormat.Location://26定位
                return new LocationHolder(parent,onChildClickLisener,type);
            case QueFormat.Sign://28 签名
                SignHolder signHolder=new SignHolder(parent,onChildClickLisener,type);
                signHolderList.add(signHolder);
                return signHolder;
            default:
                return new NothingHolder(parent,onChildClickLisener);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Log.d("adpterFlush","onBindViewHolder flush --------------position="+position);
        if(holder instanceof HeaderFooterViewHolder){

        }else {
            if ((position-1)<mData.size()) {
                PageSubjectBean item = mData.get(position-1);
                SurveyAnswer answer;
                if (item.getSurveyAnswer() == null) {
                    //每个题目，初始化答案
                    answer = new SurveyAnswer();
                    answer.subType=item.getSubType();
                    answer.queId=item.getQueID();
                    answer.subId=item.getID();
                    answer.sort=item.getSort();
                    answer.subTitle=item.getAttr().getTitle();
                    answer.isMust=item.getAttr().isMust();
                    answer.answerFillContentCharFormat =item.getAttr().getCharFormat();
                }else {
                    answer=item.getSurveyAnswer();
                }
                item.setSurveyAnswer(answer);
                if (item.getIsHide()== ConstantType.queHide.GONE) {
                    //隐藏
//                    item.getSurveyAnswer().logicShow=2;
                    item.getSurveyAnswer().logicShow= ConstantUtil.GONE;
                    //如果是显示的状态，则隐藏
                    if (holder.itemView.getVisibility() == View.VISIBLE) {
                        RecyclerView.LayoutParams param = (RecyclerView.LayoutParams) holder.itemView.getLayoutParams();
                        param.height = 0;
                        param.width = 0;
                        holder.itemView.setVisibility(View.GONE);
                        item.setError(false);//去掉红色边框
                        holder.itemView.setLayoutParams(param);
                        clearAnswer(item.getSurveyAnswer(),item.getSubType());
                    }
                    holder.itemView.setTag("gone");
                } else {
                    //显示
//                    item.getSurveyAnswer().logicShow=0;
                    item.getSurveyAnswer().logicShow=ConstantUtil.VISIBLE;
                    //如果是隐藏的状态，则显示
                    if (holder.itemView.getTag()!=null && holder.itemView.getTag().equals("gone")) {
                        RecyclerView.LayoutParams param = (RecyclerView.LayoutParams) holder.itemView.getLayoutParams();
                        param.height = LinearLayout.LayoutParams.WRAP_CONTENT;
                        param.width = LinearLayout.LayoutParams.MATCH_PARENT;
                        holder.itemView.setVisibility(View.VISIBLE);
                        holder.itemView.setLayoutParams(param);
                        holder.itemView.setTag("visible");
                    }
                }
            }
        }
        super.onBindViewHolder(holder, position);
    }

    public void clearAnswer(SurveyAnswer surveyAnswer,int type){
        if(surveyAnswer==null) return;
        switch (type){
            case QueFormat.Single://1单选
            case QueFormat.Multiple://2多选
            case QueFormat.Sorting://13 排序
                if(surveyAnswer.choiceList!=null && surveyAnswer.choiceList.size()!=0){
                    surveyAnswer.choiceList.clear();
                }
                return;
            case QueFormat.Drop_down://3 下拉题
                surveyAnswer.dropDownOpCode="";
                if(surveyAnswer.OptionList!=null && surveyAnswer.OptionList.size()!=0){
                    surveyAnswer.OptionList.clear();
                }
                return;
            case QueFormat.Question_answer://4 问答题
            case QueFormat.Fill_text://5 文本填空题
            case QueFormat.Fill_num_text://6 数值填空题
            case QueFormat.Fill_data://7 日期填空题
            case QueFormat.Fill_time://9 时间填空题
                if(!StringUtils.isEmpty(surveyAnswer.answerFillContent)){
                    surveyAnswer.answerFillContent="";
                }
                return;

            case QueFormat.Multi_blank://8 多项填空题,连续填空
                if(surveyAnswer.multiFillBlankList!=null && surveyAnswer.multiFillBlankList.size()!=0){
                    for (int i = 0; i < surveyAnswer.multiFillBlankList.size(); i++) {
                        surveyAnswer.multiFillBlankList.get(i).fillText="";
                    }
                }

                return;
            case QueFormat.Gauge://10 量表题
            case QueFormat.Matrix_single://11矩阵单选
            case QueFormat.Matrix_multi://12矩阵多选
            case QueFormat.Matrix_gauge://18 矩阵量表
                if(surveyAnswer.matrixAnswers!=null && surveyAnswer.matrixAnswers.size()!=0){
                    for (int i = 0; i < surveyAnswer.matrixAnswers.size(); i++) {
                        if(surveyAnswer.matrixAnswers.get(i).opCodes!=null){
                            surveyAnswer.matrixAnswers.get(i).opCodes.clear();
                        }
                    }
                }
                return;
            case QueFormat.Annex://15 附件
            case QueFormat.Sign://28 签名
                if(surveyAnswer.annexList!=null){
                    surveyAnswer.annexList.clear();
                }
                return;

            case QueFormat.Auto_increment://24 自增表格
                if(surveyAnswer.mAutoIncrementAnswer!=null && surveyAnswer.mAutoIncrementAnswer.mAnswers!=null){
                    surveyAnswer.mAutoIncrementAnswer.mAnswers.clear();
                }
                return;
            case QueFormat.Multi_pull_down://25多级下拉，连续下拉
                if(surveyAnswer.multi_dropdown_value!=null ){
                    surveyAnswer.multi_dropdown_value.clear();
                }
                return;
            case QueFormat.Location://26定位
                surveyAnswer.mLocationAddress="";
                surveyAnswer.mLocationLatitude=0;
                surveyAnswer.mLocationLongitude=0;
                return;

        }
    }


    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick(View view, int position);
        void onChildEndClick(View view, int position);
        void showOptionBubble(View anchor, String option);
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
