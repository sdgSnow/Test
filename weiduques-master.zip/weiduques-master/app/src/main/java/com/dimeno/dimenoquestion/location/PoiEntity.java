package com.dimeno.dimenoquestion.location;

/**
 * PoiEntity
 * Created by wangzhen on 2020/9/10.
 */
public class PoiEntity {
    public String name;
    public String address;
    public double latitude;
    public double longitude;
}
