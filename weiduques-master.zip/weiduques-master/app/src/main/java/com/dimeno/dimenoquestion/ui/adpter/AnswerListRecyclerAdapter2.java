package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.LoadRecyclerAdapter;
import com.dimeno.adapter.RecyclerAdapter;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.adpter.holder.AnswerListViewHolder;
import com.dimeno.dimenoquestion.utils.UserUtil;

import org.litepal.LitePal;

import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AnswerListRecyclerAdapter2 extends LoadRecyclerAdapter<Answer> {
    private Context mContext;
    private int page = 1;
    private int size = 10;
    private String queId;
    private List<Answer> answerList;

    /**
     * 构造器
     * @param mContext
     */
    public AnswerListRecyclerAdapter2(Context mContext,String queId, List<Answer> answerList,RecyclerView parent) {
        super(answerList,parent);
        this.mContext = mContext;
        this.answerList = answerList;
        this.queId = queId;
    }

    public void setMyOnItemClickListener(AnswerListRecyclerAdapter.MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    private AnswerListRecyclerAdapter.MyOnItemClickListener myOnItemClickListener;

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new AnswerListViewHolder(mContext,parent,myOnItemClickListener);
    }

    @Override
    public void onLoadMore() {
        List<Answer> searchAnswers = LitePal.where("QueID=? and UserId = ?", queId, UserUtil.getUserId())
                .order("AnswerState asc,AnswerFinishTime desc").limit(size).offset(answerList.size()).find(Answer.class);
    }
}
