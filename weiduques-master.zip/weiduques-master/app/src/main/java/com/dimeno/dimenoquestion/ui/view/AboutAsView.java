package com.dimeno.dimenoquestion.ui.view;

import com.dimeno.common.base.BaseView;
import com.dimeno.dimenoquestion.bean.AboutUsBean;
import com.dimeno.dimenoquestion.bean.UserEntity;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface AboutAsView extends BaseView {
    /**
     * 成功回调
     */
    void OnSucess(AboutUsBean aboutUsBean);
    /**
     * 失败回调
     * @param msg
     */
    void OnFail(String msg);
}
