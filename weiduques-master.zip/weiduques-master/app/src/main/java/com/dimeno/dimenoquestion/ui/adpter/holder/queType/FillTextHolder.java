package com.dimeno.dimenoquestion.ui.adpter.holder.queType;

import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.mode.CharFormatPattern;
import com.dimeno.dimenoquestion.ui.adpter.QueAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.RecordTextView;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :5 文本填空题
 */
public class FillTextHolder extends RecyclerViewHolder<PageSubjectBean> {
    private final RecordTextView tvTitle;
    private final TextView tv_remark;
    private final TextView tv_right_text;
    private final EditText editText;
    private SpannableStringBuilder title;
    private FrameLayout frame_error;
    private LinearLayout ll_home;
    //add新添加，edit编辑，look查看
    private String type;
    private boolean flag;

    /**
     * 构造器
     * @param parent
     * @param onChildClickLisener
     * @param type
     */
    public FillTextHolder(@NonNull ViewGroup parent, QueAdapter.OnChildClickLisener onChildClickLisener,String type) {
        super(parent, R.layout.item_fill_text);
        tvTitle = findViewById(R.id.tvTitle);
        tv_remark = findViewById(R.id.tv_remark);
        editText = findViewById(R.id.et_fill_text_blank);
        tv_right_text = findViewById(R.id.tv_right_text);
        frame_error = findViewById(R.id.frame_error);
        ll_home = findViewById(R.id.ll_home);
        editText.setFilters(new InputFilter[]{MyApplication.getInputFilter()});
        this.type=type;
    }


    @Override
    public void bind() {
        ll_home.setVisibility(View.VISIBLE);
        Log.d("adpterFlush","文本填空题 flush position="+getAdapterPosition());
        if(mData.getAttr()!=null) {
            title = StringUtils.getTitle(mData.getAttr().getLeftText(), mData.getAttr().isMust());
            tvTitle.setText(title == null ? "" : title);
            tv_remark.setText(StringUtils.isEmpty(mData.getAttr().getRmk()) ? "" : mData.getAttr().getRmk());
            tv_right_text.setText(StringUtils.isEmpty(mData.getAttr().getRightText()) ? "" : mData.getAttr().getRightText());
            tv_remark.setVisibility(StringUtils.isEmpty(mData.getAttr().getRmk()) ? View.GONE : View.VISIBLE);
            mData.getSurveyAnswer().lenghtMax = mData.getAttr().getLength1();//填空，最多字数
            mData.getSurveyAnswer().lenghtMin = mData.getAttr().getLength2();//填空，最少字数
            mData.getSurveyAnswer().subTitle = mData.getAttr().getLeftText();
            switch (mData.getAttr().getCharFormat()) {
                case CharFormat.EMAIL://1 邮箱
                    editText.setHint("请输入邮箱");
                    break;
                case CharFormat.TEXT://2 中文
                    editText.setHint("请输入中文");
                    break;
                case CharFormat.ENGLISH://3 英文
                    editText.setHint("请输入英文");
                    break;
                case CharFormat.WEBSITE://4 网址
                    editText.setHint("请输入网址");
                    break;
                case CharFormat.ID://5 身份证号码
                    editText.setHint("请输入身份证号码");
                    break;
                case CharFormat.QQ://6 QQ号
                    editText.setHint("请输入QQ号");
                    break;
                case CharFormat.MOBILE_PHONE://7 电话号码
                    editText.setHint("请输入电话号码");
                    break;
                case CharFormat.TELEPHONE://8 固定电话
                    editText.setHint("请输入固定电话");
                    break;
                case CharFormat.NUMBER://9 数值
                    editText.setHint("请输入数值");
                    break;
                default:
                    editText.setHint("请输入");
                    break;
            }

            if (mData.isError()) {
                frame_error.setVisibility(View.VISIBLE);
                editText.setFocusable(true);
                editText.setFocusableInTouchMode(true);
                editText.requestFocus();
            } else {
                frame_error.setVisibility(View.GONE);
            }
            if (type.equals("look")) {
                editText.setClickable(false);
                editText.setEnabled(false);
            }

            editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    //禁止掉下一页
                    if(actionId== EditorInfo.IME_ACTION_NEXT){
                        return true;
                    }
                    return false;
                }
            });
            editText.setText(StringUtils.isEmpty(mData.getSurveyAnswer().answerFillContent) ? "" : mData.getSurveyAnswer().answerFillContent);
            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    mData.getSurveyAnswer().answerFillContent = s.toString();
                    //有最小值要求
                    if (mData.getAttr().getLength2() != 0) {
                        //有最大值要求
                        if (mData.getAttr().getLength1() != 0) {
                            //同时满足getLength2，getLength1区间，则可以判断是否去掉红框
                            if (!StringUtils.isEmpty(s.toString()) && mData.getAttr().getLength2() <= s.toString().length() && mData.getAttr().getLength1() >= s.toString().length() && mData.isError()) {
                                flag = isFlag(s.toString());
                                if (!flag) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                            }
                        } else {
                            //没有最大值要求，只需最小值要求
                            if (!StringUtils.isEmpty(s.toString()) && mData.getAttr().getLength2() <= s.toString().length() && mData.isError()) {
                                flag = isFlag(s.toString());
                                if (!flag) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                            }
                        }

                    } else {
                        //没有最小值要求
                        if (!StringUtils.isEmpty(s.toString()) && mData.isError()) {
                            flag = isFlag(s.toString());
                            //有最大值要求
                            if (mData.getAttr().getLength1() != 0) {
                                //满足最大值要求
                                if (mData.getAttr().getLength1() >= s.toString().length()) {
                                    if (!flag) {
                                        mData.setError(false);
                                        frame_error.setVisibility(View.GONE);
                                    }
                                }
                            } else {
                                //没有最大值要求
                                if (!flag) {
                                    mData.setError(false);
                                    frame_error.setVisibility(View.GONE);
                                }
                            }

                        }
                    }
                }
            });
        }
    }

    public boolean isFlag(String str){
        switch (mData.getAttr().getCharFormat()){
            case CharFormat.EMAIL://1 邮箱
                if(!StringUtils.checkValue(CharFormatPattern.EMAIL, str)){
                    return true;
                }
                break;
            case CharFormat.TEXT://2 中文
                if(!StringUtils.checkValue(CharFormatPattern.TEXT, str)){
//                    flag=true;
                    return true;
                }
                break;
            case CharFormat.ENGLISH://3 英文
                if(!StringUtils.checkValue(CharFormatPattern.ENGLISH, str)){
//                    flag=true;
                    return true;
                }
                break;
            case CharFormat.WEBSITE://4 网址
                if(!StringUtils.checkValue(CharFormatPattern.WEBSITE, str)){
                    //                    flag=true;
                    return true;
                }
                break;
            case CharFormat.ID://5 身份证号码
                if(!StringUtils.checkValue(CharFormatPattern.ID, str)){
                    //                    flag=true;
                    return true;
                }
                break;
            case CharFormat.QQ://6 QQ号
                if(!StringUtils.checkValue(CharFormatPattern.QQ, str)){
                    //                    flag=true;
                    return true;
                }
                break;
            case CharFormat.MOBILE_PHONE://7 电话号码
                if(!StringUtils.checkValue(CharFormatPattern.MOBILE_PHONE, str)){
                    //                    flag=true;
                    return true;
                }
                break;
            case CharFormat.TELEPHONE://8 固定电话
                if(!StringUtils.checkValue(CharFormatPattern.TELEPHONE, str)){
                    //                    flag=true;
                    return true;
                }
                break;
            case CharFormat.NUMBER://9 数值
                if(!StringUtils.checkValue(CharFormatPattern.NUM, str)){
                    //                    flag=true;
                    return true;
                }
        }
        return false;
//        switch (mData.getAttr().getCharFormat()){
//            case CharFormat.EMAIL://1 邮箱
//                if(!StringUtils.checkValue(CharFormatPattern.EMAIL, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.TEXT://2 中文
//                if(!StringUtils.checkValue(CharFormatPattern.TEXT, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.ENGLISH://3 英文
//                if(!StringUtils.checkValue(CharFormatPattern.ENGLISH, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.WEBSITE://4 网址
//                if(!StringUtils.checkValue(CharFormatPattern.WEBSITE, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.ID://5 身份证号码
//                if(!StringUtils.checkValue(CharFormatPattern.ID, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.QQ://6 QQ号
//                if(!StringUtils.checkValue(CharFormatPattern.QQ, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.MOBILE_PHONE://7 电话号码
//                if(!StringUtils.checkValue(CharFormatPattern.MOBILE_PHONE, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.TELEPHONE://8 固定电话
//                if(!StringUtils.checkValue(CharFormatPattern.TELEPHONE, s.toString())){
//                    flag=true;
//                }
//                break;
//            case CharFormat.NUMBER://9 数值
//                if(!StringUtils.checkValue(CharFormatPattern.NUM, s.toString())){
//                    flag=true;
//                }
//                break;
//            default:
//                flag=true;
//                break;
//        }
    }
}
