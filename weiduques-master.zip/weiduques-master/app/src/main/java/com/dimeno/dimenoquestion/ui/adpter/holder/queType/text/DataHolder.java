package com.dimeno.dimenoquestion.ui.adpter.holder.queType.text;

import android.text.SpannableStringBuilder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.TimePickerView;
import com.dimeno.adapter.base.RecyclerViewHolder;
import com.dimeno.common.utils.ActivityManager;
import com.dimeno.common.utils.TimeUtil;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AttrBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.mode.CharFormat;
import com.dimeno.dimenoquestion.ui.adpter.MultiBlankAdapter;
import com.dimeno.dimenoquestion.utils.StringUtils;

import java.util.ArrayList;
import java.util.Date;

/**
 * Create by   :PNJ
 * Date        :2021/3/27
 * Description :日期
 */
public class DataHolder extends RecyclerViewHolder<AttrBean> {

    private ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks;
    private TextView mLeftText;
    private TextView mRightText;
    private TextView editText;
    private SpannableStringBuilder title;
    private MultiBlankAdapter.OnChildClickLisener onChildClickLisener;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param parent
     * @param multiFillBlanks
     * @param onChildClickLisener
     * @param type
     */
    public DataHolder(@NonNull ViewGroup parent, ArrayList<SurveyAnswer.MultiFillBlank> multiFillBlanks, MultiBlankAdapter.OnChildClickLisener onChildClickLisener, String type) {
        super(parent, R.layout.item_multi_blank_data);
        this.multiFillBlanks = multiFillBlanks;
        mLeftText =findViewById(R.id.tv_title);
        mRightText =findViewById(R.id.tv_right_text);
        editText =findViewById(R.id.et_fill_multi_blank);
        this.onChildClickLisener=onChildClickLisener;
        this.type=type;
    }

    @Override
    public void bind() {
        if(type.equals("look")){
            //查看，editText不能编辑
            editText.setClickable(false);
            editText.setEnabled(false);
        }
        //获取title
        title= StringUtils.getTitle(mData.getLeftText(),mData.isMust());
        //设置title
        mLeftText.setText(title);
        editText.setHint("请时间");
        mRightText.setText(mData.getRightText());
        //时间选择器
        TimePickerView pvTime = new TimePickerBuilder(itemView.getContext(), new OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date, View v) {
                //设置选择的时间按
                editText.setText(TimeUtil.date2YMD(date));
                //判空
                if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
                    //设置答案
                    multiFillBlanks.get(getAdapterPosition()).fillText = TimeUtil.date2YMD(date);
                }
                if(mData.isMust()) {
                    //必须
                    if(!StringUtils.isEmpty(TimeUtil.date2YMD(date))  && onChildClickLisener!=null){
                        onChildClickLisener.onChildClick();
                    }
                }else {
                    if (onChildClickLisener != null) {
                        onChildClickLisener.onChildClick();
                    }
                }
            }
        }).build();
        //监听
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!type.equals("look")){
                    //不是查看，显示时间选择器
                    pvTime.show();
                }
            }
        });
        if(multiFillBlanks!=null && multiFillBlanks.size()>getAdapterPosition()) {
            multiFillBlanks.get(getAdapterPosition()).format = CharFormat.DATE;
            editText.setText(multiFillBlanks.get(getAdapterPosition()).fillText);
        }
    }
}
