package com.dimeno.dimenoquestion.pop;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.common.utils.UIUtils;
import com.dimeno.dimenoquestion.MyApplication;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.QuesUtil;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.widget.SignView;
import com.dimeno.threadlib.ExecutorHandler;

/**
 * Create by   :PNJ
 * Date        :2021/3/24
 * Description :签名弹框
 */
public class SignPopup extends PopupWindow {
    private View mView;
    private SignView signview;
    private LinearLayout ll_left;
    private LinearLayout ll_right;
    private TextView bt_resign;
    private TextView bt_submit_sign;
    private TextView bt_back;
    //系统设置字号大小  //0.85 小, 1 标准大小, 1.15 大，1.3 超大 ，1.45 特大
    private float sysSize;

    public SignPopup(Context context, String answerCode) {
        super(context);
        LayoutInflater mInflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //设置布局
        mView = mInflate.inflate(R.layout.activity_sign, null);
        //签名空军
        signview = (SignView) mView.findViewById(R.id.signview);
        //左边布局
        ll_left = (LinearLayout) mView.findViewById(R.id.ll_left);
        //右边布局
        ll_right = (LinearLayout) mView.findViewById(R.id.ll_right);
        //重签
        bt_resign = (TextView) mView.findViewById(R.id.bt_resign);
        //确定
        bt_submit_sign = (TextView) mView.findViewById(R.id.bt_submit_sign);
        //取消
        bt_back = (TextView) mView.findViewById(R.id.bt_back);
        //设置签名控件颜色
        signview.setLineColor(Color.BLACK);
        //签名控件画笔宽度
        signview.setLineWidth(10);
        //获取系统字体大小  0.85 小, 1 标准大小, 1.15 大，1.3 超大 ，1.45 特大
        sysSize = StringUtils.getFontSize();
        //字体大于1.3
        if (sysSize >= 1.3) {
            LinearLayout.LayoutParams ll_leftParams = (LinearLayout.LayoutParams) ll_left.getLayoutParams();
            //左边margin
            ll_leftParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 30);
            //rightMargin
            ll_leftParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 30);
            //ll_left重新设置margin
            ll_left.setLayoutParams(ll_leftParams);

            LinearLayout.LayoutParams ll_rightParams = (LinearLayout.LayoutParams) ll_right.getLayoutParams();
            //左边margin
            ll_rightParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 35);
            //rightMargin
            ll_rightParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 15);
            //ll_right重新设置margin
            ll_right.setLayoutParams(ll_rightParams);
        }
        //取消监听
        bt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signview.clearPath();
                dismiss();
            }
        });
        //重签监听
        bt_resign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signview.clearPath();
            }
        });
        //确定监听
        bt_submit_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutorHandler.getInstance().forBackgroundTasks()
                        .execute(new Runnable() {
                            @Override
                            public void run() {
                                //是否绘制过
                                if (signview.isDraw()) {
                                    //获取签名路径
                                    String path = signview.saveImageToFile("Sign", System.currentTimeMillis() + "");
                                    Log.i("test_sign", "signview: answerCode = " + answerCode);
                                    //路径不为空
                                    if (!StringUtils.isEmpty(path)) {
                                        signview.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                ToastUtils.showShort("签名成功");
                                                //清空输入,重新签名
                                                signview.clearPath();
                                                if (itemClickListener != null) {
                                                    //监听器判空，并返回路径
                                                    itemClickListener.onItemClick(path);
                                                }
                                                //弹框消失
                                                dismiss();
                                            }
                                        });
                                    }
                                }else {
                                    MyToast.showShortToast("签名未完成");
                                }
                            }
                        });
            }
        });
        //设置SelectPicPopupWindow的View
        this.setContentView(mView);
        //设置SelectPicPopupWindow弹出窗体的宽
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体的高
        this.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        //设置SelectPicPopupWindow弹出窗体可点击
        this.setFocusable(true);
        //设置SelectPicPopupWindow弹出窗体动画效果
        mView.findViewById(R.id.ll_home).startAnimation(AnimationUtils.loadAnimation(context, R.anim
                .popup_center_center));
        //实例化一个ColorDrawable颜色为半透明
        @SuppressLint("ResourceAsColor") ColorDrawable dw = new ColorDrawable(R.color.black);
        dw.setAlpha(100);
        //设置SelectPicPopupWindow弹出窗体的背景
        this.setBackgroundDrawable(dw);
        //mMenuView添加OnTouchListener监听判断获取触屏位置如果在选择框外面则销毁弹出框
//        mView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                int height = mView.findViewById(R.id.ll_sexselect_isdeleter).getTop();
//                int y = (int) event.getY();
//                if (event.getAction() == MotionEvent.ACTION_UP) {
//                    if (y < height) {
//                        dismiss();
//                    }
//                }
//                return true;
//            }
//        });


    }

    public void setParam() {
        if (sysSize != StringUtils.getFontSize()) {
            sysSize = StringUtils.getFontSize();
            LinearLayout.LayoutParams ll_leftParams = (LinearLayout.LayoutParams) ll_left.getLayoutParams();
            LinearLayout.LayoutParams ll_rightParams = (LinearLayout.LayoutParams) ll_right.getLayoutParams();
            if (sysSize >= 1.3) {
                ll_leftParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 30);
                ll_leftParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 30);

                ll_rightParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 35);
                ll_rightParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 15);
            } else {
                ll_leftParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 20);
                ll_leftParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 20);

                ll_rightParams.leftMargin = -UIUtils.dip2px(MyApplication.getContext(), 20);
                ll_rightParams.rightMargin = -UIUtils.dip2px(MyApplication.getContext(), 4);
            }
            ll_right.setLayoutParams(ll_rightParams);
            ll_left.setLayoutParams(ll_leftParams);
        }

    }

    private onMyItemClickListener itemClickListener = null;

    public void setonMyItemClickListener(onMyItemClickListener listener) {
        itemClickListener = listener;
    }

    public interface onMyItemClickListener {
        void onItemClick(String path);
    }
}
