package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.AnnexEntity;

import java.util.List;
/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class AnnexUploadAdapter extends BaseQuickAdapter<AnnexEntity, BaseViewHolder> {

    private List<AnnexEntity> beanList;
    private Context mContext;
    //add新添加，edit编辑，look查看
    private String type;

    /**
     * 构造器
     * @param data
     * @param context
     * @param type
     */
    public AnnexUploadAdapter(@Nullable List<AnnexEntity> data, Context context,String type) {
        super(R.layout.item_annex_upload, data);
        this.beanList = data;
        this.mContext = context;
        this.type=type;
    }

    /**
     * 设置数据
     * @param data
     */
    public void setData(List<AnnexEntity> data){
        this.beanList=data;
        //刷新
        notifyDataSetChanged();
    }

    @Override
    protected void convert(BaseViewHolder helper, AnnexEntity item) {
        TextView tv_single_choose = helper.getView(R.id.tv_single_choose);
        Button btn_delete = helper.getView(R.id.btn_delete);
        tv_single_choose.setText(item.fileName);
        //根据type类型判断是否显示删除按钮
        if(type.equals("look")){
            btn_delete.setVisibility(View.GONE);
        }else {
            btn_delete.setVisibility(View.VISIBLE);
        }
        //删除点击事件
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData().remove(item);
                notifyDataSetChanged();
            }
        });

    }
}
