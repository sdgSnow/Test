package com.dimeno.dimenoquestion.db;

import org.litepal.crud.LitePalSupport;

public class Que extends LitePalSupport {
    //问卷id
    private String queId;
    //问卷实体
    private String queBean;
    //用户id
    private String UserID;//":
    //问卷详情
    private String queDetail;

    public String getQueId() {
        return queId;
    }

    public void setQueId(String queId) {
        this.queId = queId;
    }

    public String getQueBean() {
        return queBean;
    }

    public void setQueBean(String queBean) {
        this.queBean = queBean;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getQueDetail() {
        return queDetail;
    }

    public void setQueDetail(String queDetail) {
        this.queDetail = queDetail;
    }
}
