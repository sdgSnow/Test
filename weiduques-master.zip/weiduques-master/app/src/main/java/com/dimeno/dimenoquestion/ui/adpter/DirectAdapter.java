package com.dimeno.dimenoquestion.ui.adpter;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;

import java.util.List;

public class DirectAdapter extends BaseQuickAdapter<NewQuesBean, BaseViewHolder> {
    /**
     * 构造器
     * @param data
     * @param context
     */
    public DirectAdapter(@Nullable List<NewQuesBean> data, Context context) {
        super(R.layout.item_direct, data);
        this.mContext = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, NewQuesBean item) {
        View view=helper.getView(R.id.other);
        if(helper.getAdapterPosition()==0){
            //第一个显示
            view.setVisibility(View.VISIBLE);
        }else {
            //隐藏
            view.setVisibility(View.GONE);
        }
        TextView tv_single_choose = helper.getView(R.id.tv_title);
        tv_single_choose.setText(item.getQueTitle());
    }
}
