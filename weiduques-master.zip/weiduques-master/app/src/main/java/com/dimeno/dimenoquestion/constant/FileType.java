package com.dimeno.dimenoquestion.constant;

/**
 * AnnexFileType
 * Created by wangzhen on 2020/5/22.
 *
 * 文件类型
 */
public class FileType {
    public static final int CODE_BROWSE_FILE = 0x11;

    //无限制(all)
    //图片(jpg,png,bmp,gif)
    //音频(mp3)
    //视频(avi,rmvb,wmv)
    //文档(doc,docx,xls,xlsx,pdf,ppt,txt)
    //签名题
    //录音

    //文件类别 1：录音文件  2：图片  3：签名文件 4：附件  5.视频 6.音频,7.文档


    //不限制
    public static final int ALL = 0;
    //录音
    public static final int RECORD  = 1;
    //图片
    public static final int IMAGE= 2;
    //签名题
    public static final int SIGN  = 3;
    //附件题
    public static final int FILE = 4;
    //视频
    public static final int VIDEO = 5;
    //音频
    public static final int AUDIO = 6;
    //文档
    public static final int DOCUMENT = 7;

    //图片
    public static final String TYPE_IMAGE = "jpg,png,bmp,gif";
    //视频
    public static final String TYPE_VIDEO = "avi,rmvb,wmv,mp4";
    //音频
    public static final String TYPE_AUDIO = "cda,wav,mp3,mid,wma,ra,vqf,ape,aif,aiff";
    //文档
    public static final String TYPE_DOCUMENT = "doc,docx,xls,xlsx,pdf,ppt,txt,zip,tar,7z,rar";
}
