package com.dimeno.dimenoquestion.ui.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.common.base.BaseFragment;
import com.dimeno.common.base.BasePresenter;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.ui.adpter.NewQuesAdapter;
import com.dimeno.dimenoquestion.ui.presenter.NewQuesPresenter;
import com.dimeno.dimenoquestion.ui.view.NewQuesView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class CompleteQuesFragment extends BaseFragment<NewQuesPresenter>  implements NewQuesView {
    private List<NewQuesBean> newQuesBeans;
    private RecyclerView rcy_new_ques;
    public SmartRefreshLayout mRefreshLayout;
    private NewQuesAdapter newQuesAdapter ;
    private LinearLayout ll_Empty ;
    private TextView tv_Empty_Msg ;

    /**
     * 初始化CompleteQuesFragment
     * @return
     */
    public static CompleteQuesFragment newInstance() {
        CompleteQuesFragment fragment = new CompleteQuesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * 设置布局
     * @return
     */
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_new_ques;
    }

    /**
     * createPresenter
     * @return
     */
    @Override
    public NewQuesPresenter createPresenter() {
        return new NewQuesPresenter();
    }

    /**
     * initThings
     * 初始化一些事情
     * @param view
     * @param savedInstanceState
     */
    @Override
    protected void initThings(View view,Bundle savedInstanceState) {
        ll_Empty = view.findViewById(R.id.ll_Empty);
        tv_Empty_Msg = view.findViewById(R.id.tv_Empty_Msg);
        //设置上下拉刷新配置
        mRefreshLayout = view.findViewById(R.id.refresh_Layout);
        mRefreshLayout.setPrimaryColorsId(R.color.app_back2, R.color.ba3);
        mRefreshLayout.setBackgroundColor(getResources().getColor(R.color.f5f4));
        mRefreshLayout.setRefreshHeader(new ClassicsHeader(getContext()));
        mRefreshLayout.setRefreshFooter(new ClassicsFooter(getContext()).setSpinnerStyle(SpinnerStyle.Scale));

        rcy_new_ques = view.findViewById(R.id.rcy_new_ques);
        //设置方向
        rcy_new_ques.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.VERTICAL, false));
    }

    /**
     * initData
     * 初始化数据
     */
    @Override
    protected void initData() {
        //创建适配器
        newQuesAdapter = new NewQuesAdapter(newQuesBeans);
        //适配器点击事件
        newQuesAdapter.setChildClickLisener(new NewQuesAdapter.OnChildClickLisener() {
            @Override
            public void onChildClick(View view,NewQuesBean newQuesBean) {
                switch (view.getId()){
                    case R.id.tv_see:
                        //查看答案
                        MyToast.showShortToast("查看答案");
                        break;
                    case R.id.tv_start_survey:
                        //立即调查
                        MyToast.showShortToast("立即调查");
//                        gotoActivity(SurveyActivity.class);
                        break;
                }
            }
        });
        //设置适配器
        rcy_new_ques.setAdapter(newQuesAdapter);
        //网络请求数据
        presenter.loadQuesList(getActivity());
    }

    /**
     * initListeners
     * 初始化事件监听者
     */
    @Override
    public void initListeners() {
        //没有数据点击事件
        tv_Empty_Msg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //获取数据
                presenter.loadQuesList(getActivity());
            }
        });
        //下拉加载
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(final RefreshLayout refreshlayout) {
                mRefreshLayout.setNoMoreData(false);//恢复没有更多数据的原始状态 1.0.5
                presenter.loadQuesList(getActivity());
            }
        });
        //上拉加载更多
        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(final RefreshLayout refreshlayout) {
                presenter.loadQuesList(getActivity());
            }
        });
    }


    @Override
    public void initQuesList(boolean loadMore, ArrayList<NewQuesBean> quesBeanList) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //设置数据
                newQuesAdapter.setData(quesBeanList);
                //Refreshing状态，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                //Loading状态，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
                if(quesBeanList.size() == 0){
                    //数据为空，没有数据显示
                    ll_Empty.setVisibility(View.VISIBLE);
                }else {
                    //有数据，隐藏没有数据
                    if(ll_Empty.getVisibility()==View.VISIBLE){
                        ll_Empty.setVisibility(View.GONE);
                    }
                }
                if (!loadMore) {
                    //没有更多，结束加载更多
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    @Override
    public void loadFailure(boolean sucess, String message) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //Refreshing状态，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                //Loading状态，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
            }
        });
    }
}
