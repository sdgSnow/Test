package com.dimeno.dimenoquestion.ui.adpter;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.dimenoquestion.bean.QueOptionBean;
import com.dimeno.dimenoquestion.bean.PageSubjectBean;
import com.dimeno.dimenoquestion.ui.adpter.holder.base.BaseViewHolder;
import com.dimeno.dimenoquestion.ui.adpter.holder.queType.QueFormat;

import java.util.ArrayList;
import java.util.List;


/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class DoSurveyAdapter extends RecyclerView.Adapter<BaseViewHolder>{
    private boolean isShowFooter;
    // 用于存放头部view和尾部view
    private List<View> mHeaderViews;
    private List<View> mFooterViews;
    private ArrayList<PageSubjectBean> quesList=new ArrayList<>();
    private ArrayList<QueOptionBean> queOptList=new ArrayList<>();

    /**
     * DoSurveyAdapter
     *
     */
    public DoSurveyAdapter(){
    }

    /**
     * setData
     * 设置数据
     * @param data
     */
    public void setData(ArrayList<PageSubjectBean> data){
        this.quesList=data;
        this.queOptList=queOptList;
        notifyDataSetChanged();
    }

    /**
     * getItemViewType
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        int realPosition = position;
        if (mHeaderViews != null && mHeaderViews.size() > 0) {
            realPosition = position - mHeaderViews.size();
        }

        if (mHeaderViews != null && position < mHeaderViews.size()) {
            return QueFormat.Header;
        }

        if (mFooterViews != null && mFooterViews.size() > 0) {
            if (realPosition >= quesList.size()) {
                return QueFormat.Footer;
            }
        }

        return quesList.get(realPosition).getSubType();
    }

    /**
     * onCreateViewHolder
     * @param parent
     * @param viewType
     * @return
     */
    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType){
            case QueFormat.Header:
                return new HeaderViewHolder(mHeaderViews.get(0));
            case QueFormat.Footer:
                return new FooterViewHolder(mFooterViews.get(0));
//            case QueFormat.Single:
//                return  new SingleChoiceHolder(parent,onChildClickLisener);
//            case QueFormat.Multiple:
            default:
                return new FooterViewHolder(mFooterViews.get(0));
        }
    }

    /**
     * onBindViewHolder
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        if(holder instanceof HeaderViewHolder){

        }else if(holder instanceof HeaderViewHolder){

        }else {
            final int realPosition = position - (mHeaderViews == null ? 0 : mHeaderViews.size());
            holder.bind(quesList.get(realPosition));
        }

    }

    /**
     * getItemCount
     * @return
     */
    @Override
    public int getItemCount() {
        // 无数据源肯定count为0
        if (quesList == null)
            return 0;

        int count = 0;
        if (mHeaderViews != null) {
            // 添加header view的size个数
            count += mHeaderViews.size();
        }
        // 添加footer view的size个数，并且多一个外部开关来控制底部view的显示与否，方便数据加载完后隐藏底部view
        if (mFooterViews != null && isShowFooter) {
            count += mFooterViews.size();
        }

        return count + quesList.size();
    }

    /**
     * 暂时只支持HeaderView为1
     * @param headView
     */
    public void setHeaderView(View headView) {
        if (mHeaderViews == null) {
            mHeaderViews = new ArrayList<>();
        }
        mHeaderViews.clear();
        mHeaderViews.add(headView);
    }

    /**
     * setFooterView
     * @param footerView
     */
    public void setFooterView(View footerView) {
        if (mFooterViews == null) {
            mFooterViews = new ArrayList<>();
        }
        mFooterViews.clear();
        mFooterViews.add(footerView);
    }

    /**
     * setShowFooter
     * @param showFooter
     */
    public void setShowFooter(boolean showFooter) {
        isShowFooter = showFooter;
    }

    /**
     * isShowFooter
     *
     * @return
     */
    public boolean isShowFooter() {
        return isShowFooter;
    }

    /**
     * FooterViewHolder
     */
    private class FooterViewHolder extends BaseViewHolder {
        FooterViewHolder(View itemView) {
            super(itemView);
        }
    }

    /**
     * HeaderViewHolder
     */
    private class HeaderViewHolder extends BaseViewHolder {
        HeaderViewHolder(View itemView) {
            super(itemView);
        }
    }

    /**
     * getCount
     * @return
     */
    public int getCount() {
        return quesList.size();
    }

    private OnChildClickLisener onChildClickLisener;

    public interface OnChildClickLisener {
        void onChildClick(View view, PageSubjectBean newQuesBean);
    }
    public void setChildClickLisener(OnChildClickLisener onChildClickLisener){
        this.onChildClickLisener = onChildClickLisener;
    }
}
