package com.dimeno.dimenoquestion.utils;

import com.blankj.utilcode.util.ToastUtils;

public class MyToast {

    public static void showShortToast(String msg) {
        ToastUtils.showShort(msg);
    }

    public static void showLongToast(String msg) {
        ToastUtils.showLong(msg);
    }
}
