package com.dimeno.dimenoquestion.ui.actvity;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.dimeno.common.base.BaseActivity;
import com.dimeno.common.helper.ProgressHelper;
import com.dimeno.common.utils.JsonUtil;
import com.dimeno.dimenoquestion.bean.AnnexEntity;
import com.dimeno.dimenoquestion.bean.ExceptionLog;
import com.dimeno.dimenoquestion.bean.NewQuesBean;
import com.dimeno.dimenoquestion.bean.SurveyAnswer;
import com.dimeno.dimenoquestion.bean.SurveyAnswerEntity;
import com.dimeno.dimenoquestion.constant.ConstantType;
import com.dimeno.dimenoquestion.db.Answer;
import com.dimeno.dimenoquestion.ui.adpter.DealExceptionAdapter;
import com.dimeno.dimenoquestion.utils.FileUtils;
import com.dimeno.dimenoquestion.utils.LogUtils;
import com.dimeno.dimenoquestion.utils.MyUtils;
import com.dimeno.dimenoquestion.utils.OSSManager;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.dimeno.commons.utils.T;
import com.dimeno.dimenoquestion.R;
import com.dimeno.dimenoquestion.bean.OssInfoEntity;
import com.dimeno.dimenoquestion.ui.presenter.DealExceptionQuePresent;
import com.dimeno.dimenoquestion.ui.view.DealExceptionQueView;
import com.dimeno.dimenoquestion.utils.MyToast;
import com.dimeno.dimenoquestion.utils.StringUtils;
import com.dimeno.dimenoquestion.utils.UserUtil;
import com.dimeno.dimenoquestion.widget.BackToolbar;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.socks.library.KLog;

import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.dimeno.dimenoquestion.constant.Constant.AUDIO_BASE_PATH;
import static com.dimeno.dimenoquestion.constant.Constant.COPY_PATH;
import static com.dimeno.dimenoquestion.constant.Constant.DB_PATHDIR;
import static com.dimeno.dimenoquestion.constant.Constant.ZIP_PATH;

/**
 * DealExceptionQueActivity
 * Created by sdg on 2021/3/30.
 */
public class DealExceptionQueActivity extends BaseActivity<DealExceptionQuePresent> implements DealExceptionQueView {
    @BindView(R.id.recycler)
    RecyclerView recycler;
    @BindView(R.id.refresh_Layout)
    SmartRefreshLayout mRefreshLayout;
    @BindView(R.id.ll_Empty)
    LinearLayout ll_Empty;
    @BindView(R.id.tv_Empty_Msg)
    TextView tv_Empty_Msg;
    @BindView(R.id.tv_upfile)
    TextView tv_upfile;

    private DealExceptionAdapter adapter;
    private NewQuesBean newQuesBean;
    private List<Answer> searchAnswers = new ArrayList<>();
    private int page = 1;
    private String qId;
    private Answer selectAnswer;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_deal_exception_que;
    }

    @Override
    protected void initThings(Bundle savedInstanceState) {
        ButterKnife.bind(this);
        //获取参数
        newQuesBean = (NewQuesBean) getIntent().getSerializableExtra("newQuesBean");
        //上下拉刷新设置
        mRefreshLayout.setPrimaryColorsId(R.color.f5f4, R.color.app_back2);
        mRefreshLayout.setBackgroundColor(getResources().getColor(R.color.f5f4));
        mRefreshLayout.setRefreshHeader(new ClassicsHeader(this));
        mRefreshLayout.setRefreshFooter(new ClassicsFooter(this).setSpinnerStyle(SpinnerStyle.Scale));
        //判空
        if (newQuesBean != null) {
            qId = newQuesBean.ID;
            presenter.quesList(newQuesBean.ID, 1);
        }
    }

    @Override
    protected void initViews() {
        //设置方向
        recycler.setLayoutManager(new LinearLayoutManager(DealExceptionQueActivity.this));
        //adapter
        adapter = new DealExceptionAdapter(this, R.layout.item_deal_exception);
        //设置adapter
        recycler.setAdapter(adapter);
        tv_Empty_Msg.setVisibility(View.GONE);
    }

    @Override
    protected void initData() {
        super.initData();

    }


    public void quesList() {

    }

    /**
     * 设置Toolbar
     * @return
     */
    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new BackToolbar(this, "数据直传");
    }

    /**
     * Presenter
     * @return
     */
    @Override
    protected DealExceptionQuePresent createPresenter() {
        return new DealExceptionQuePresent();
    }

    @Override
    public void initListeners() {
        //adapter监听
        adapter.setMyOnItemClickListener(new DealExceptionAdapter.MyOnItemClickListener() {
            @Override
            public void onItemClick(int positon, Answer answer) {
                selectAnswer = answer;
            }

            @Override
            public void onItemLongClick(int positon, Answer answer) {

            }
        });
        //下拉从新加载
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(final RefreshLayout refreshlayout) {
                //恢复没有更多数据的原始状态 1.0.5
                mRefreshLayout.setNoMoreData(false);
                //判空
                if (!StringUtils.isEmpty(qId)) {
                    //从第一页开始
                    page = 1;
                    //网络请求
                    presenter.quesList(qId, page);
                }
            }
        });
        //上拉加载更多
        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(final RefreshLayout refreshlayout) {
                //判空
                if (!StringUtils.isEmpty(qId)) {
                    //页码加一
                    page++;
                    //网络请求
                    presenter.quesList(qId, page);
                }
            }
        });
        //文件直传
        tv_upfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //判空
                        if (selectAnswer != null) {
                            //展示进度
                            ProgressHelper.getInstance().show(DealExceptionQueActivity.this, "上传中...", false);
                            //上传db文件
                            com.blankj.utilcode.util.FileUtils.deleteAllInDir(COPY_PATH);
                            //拷贝数据库
                            com.blankj.utilcode.util.FileUtils.copy(DB_PATHDIR, COPY_PATH + "/database/");
                            //上传附件和签名文件
                            String answerDetail = selectAnswer.getAnswerDetail();
                            //判空
                            if (!StringUtils.isEmpty(answerDetail)) {
                                //上传答案实体
                                SurveyAnswerEntity surveyAnswerEntity = JsonUtil.toObj(answerDetail, SurveyAnswerEntity.class);
                                //判空
                                if (surveyAnswerEntity != null && surveyAnswerEntity.surveyAnswers != null && surveyAnswerEntity.surveyAnswers.size() > 0) {
                                    //循环答案，分页
                                    for (SurveyAnswerEntity.AnswerPage surveyAnswer : surveyAnswerEntity.surveyAnswers) {
                                        //该页中，答案不为空
                                        if (surveyAnswer.getSurveyAnswers() != null && surveyAnswer.getSurveyAnswers().size() > 0) {
                                            //循环答案
                                            for (SurveyAnswer answer : surveyAnswer.getSurveyAnswers()) {
                                                //该答案中附件或签名文件不为空
                                                if (answer.annexList != null && answer.annexList.size() > 0) {
                                                    //循环附件或签名文件
                                                    for (AnnexEntity annexEntity : answer.annexList) {
                                                        //上传附件和签名文件
                                                        if (FileUtils.checkFile(annexEntity.path)) {
                                                            //最后一个/的位置
                                                            int last = annexEntity.path.lastIndexOf("/");
                                                            //获取名称
                                                            String name = annexEntity.path.substring(last, annexEntity.path.length());
                                                            //拷贝附件和签名文件
                                                            com.blankj.utilcode.util.FileUtils.copy(new File(annexEntity.path), new File(COPY_PATH + "/Sign/" + name));
//                                                            presenter.getOssInfo(mActivity, annexEntity.path);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            //上传录音
                            String zipDir = AUDIO_BASE_PATH + selectAnswer.getQueID() + "/" + selectAnswer.getAnswerCode() + "/";
                            LogUtils.d("路径==" + zipDir);
                            //拷贝录音文件
                            com.blankj.utilcode.util.FileUtils.copy(zipDir, COPY_PATH + "/audio/" + selectAnswer.getQueID() + "/" + selectAnswer.getAnswerCode() + "/");
                            //压缩
                            presenter.uploadExceptionData(DealExceptionQueActivity.this, COPY_PATH, ZIP_PATH + "/" + selectAnswer.getQueID() + "_copy.zip");
                        }
                    }
                }).start();
            }
        });
    }

    @Override
    public void success(OssInfoEntity ossInfoEntity, String filepath) {
        OSSManager.get()
                .setContext(mContext)
                .accessKeyId(ossInfoEntity.AccessKeyId)
                .accessKeySecret(ossInfoEntity.AccessKeySecret)
                .securityToken(ossInfoEntity.SecurityToken)
                .endPoint(ossInfoEntity.endpoint)
                .bucket(ossInfoEntity.BucketName)
                .directory(ossInfoEntity.Directory)
                .queId(newQuesBean.getID())
//                .file(filepath)
                .callback(new OSSManager.Callback() {
                    @Override
                    public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
//                        String progress = MyUtils.getProgress(currentSize, totalSize);
//                        MyLog.i("currentSize:" + currentSize + ",totalSize:" + totalSize + ",progress:" + progress);
                    }

                    @Override
                    public void onSuccess(String ossPath) {
//                        MyToast.showShortToast("上传成功");
                        //判空
                        if (selectAnswer != null) {
                            //创建日志实体
                            ExceptionLog exceptionLog = new ExceptionLog();
                            //设置问卷id
                            exceptionLog.setQueId(selectAnswer.getQueID());
                            //设置用户id
                            exceptionLog.setUserId(UserUtil.getUserId());
                            //上传附件和签名文件
                            String answerDetail = selectAnswer.getAnswerDetail();
                            //判空
                            if (!StringUtils.isEmpty(answerDetail)) {
                                //获取答案实体
                                SurveyAnswerEntity surveyAnswerEntity = JsonUtil.toObj(answerDetail, SurveyAnswerEntity.class);
                                //判空。
                                if (surveyAnswerEntity != null && surveyAnswerEntity.answerStartTime != null) {
                                    //设置日志的答卷编码
                                    exceptionLog.setEnterAnswerId(surveyAnswerEntity.answerStartTime + "");
                                    //设置日志的创建时间
                                    exceptionLog.setCreateTime(surveyAnswerEntity.answerFinishTime + "");
                                }
                            }
                            //1问卷，2答卷
                            exceptionLog.setFileType(ConstantType.LogFileType.ANSWER);
                            exceptionLog.setUpdateTime(System.currentTimeMillis() + "");
                            exceptionLog.setFileUrl(ossInfoEntity.Directory + MyUtils.getOssPath(filepath, selectAnswer.getQueID()));
                            presenter.exceptionLog(DealExceptionQueActivity.this, exceptionLog);
                        }

                        KLog.i("上传成功");
                    }

                    @Override
                    public void onFailure(String message) {
                        T.show(message);
                    }
                }).upload(0,0,filepath);
    }

    @Override
    public void initQuesList(boolean loadMore, List<Answer> quesBeanList) {
        //根据开始时间排序
        Collections.sort(quesBeanList, new Comparator<Answer>() {
            @Override
            public int compare(Answer bean1, Answer bean2) {
                return bean1.getAnswerStartTime().compareTo(bean2.getAnswerStartTime());
            }
        });
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //判空
                if (quesBeanList != null) {
                    //不为空
                    if (quesBeanList.size() == 0) {
                        ll_Empty.setVisibility(View.VISIBLE);
                    } else {
                        ll_Empty.setVisibility(View.GONE);
                    }
                }
                //设置新数据
                adapter.setNewData(quesBeanList);
                //Refreshing状态的时候，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Refreshing) {
                    mRefreshLayout.finishRefresh(true);
                }
                //Loading状态的时候，结束刷新
                if (mRefreshLayout.getState() == RefreshState.Loading) {
                    mRefreshLayout.finishLoadMore(true);
                }
                //结束加载更多
                if (!loadMore) {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    @Override
    public void sucess(boolean sucess, String msg) {
        //activity没有销毁的时候
        if (!isFinishing()) {
            if (sucess) {
                //成功
                MyToast.showShortToast("上传成功");
            } else {
                //失败
                MyToast.showShortToast(msg);
            }
            //取消loading
            ProgressHelper.getInstance().cancel();
            //删除拷贝到文件
            com.blankj.utilcode.util.FileUtils.deleteAllInDir(COPY_PATH);
        }
    }

}