package com.dimeno.common.event;

import org.greenrobot.eventbus.EventBus;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class EventBusUtils implements IEvent  {

    static volatile EventBusUtils mEventBusUtils;
    private  EventBus mEventBus;

    /**
     * EventBusUtils
     */
    private EventBusUtils() {
        mEventBus = EventBus.getDefault();
    }

    /**
     * getInstance
     * 获取单例
     * @return
     */
    public static EventBusUtils getInstance() {
        if (mEventBusUtils == null) {
            synchronized (EventBusUtils.class) {
                if (mEventBusUtils == null) {
                    mEventBusUtils = new EventBusUtils();
                }
            }
        }
        return mEventBusUtils;
    }

    @Override
    public void postEvent(Event mEvent) {
        mEventBus.post(mEvent);
    }

    @Override
    public void postStickEvent(Event event) {
        mEventBus.postSticky(event);
    }

    @Override
    public void register(Object context) {
        if (!mEventBus.isRegistered(context)) {
            mEventBus.register(context);
        }
    }

    @Override
    public void unregister(Object context) {
        if (mEventBus.isRegistered(context)) {
            mEventBus.unregister(context);
        }
    }
}
