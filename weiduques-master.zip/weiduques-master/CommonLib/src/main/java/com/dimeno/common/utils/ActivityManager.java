package com.dimeno.common.utils;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

/**
 * ActivityManager
 * Created by wangzhen on 2020/5/16.
 */
public class ActivityManager {
    /**
     *堆栈
     */
    private static Stack<Activity> activityStack;
    private static ActivityManager instance;

    /**
     * 空构造器
     */
    private ActivityManager() {
    }

    /**
     * 获取单例
     * @return
     */
    public static ActivityManager getAppManager() {
        if(instance == null) {
            instance = new ActivityManager();
        }

        return instance;
    }

    /**
     * 添加activity
     * @param activity
     */
    public void addActivity(Activity activity) {
        //判空
        if(activityStack == null) {
            //创建
            activityStack = new Stack();
        }
        //大于零
        if(activityStack.size() > 0) {
            //获取最后一个
            Activity act = (Activity)activityStack.lastElement();
            Log.i("appmanager", "******************" + act.getClass());
            //相等
            if(act != null && act.getClass().equals(activity.getClass())) {
                this.finishLastActivity();
            }
        }
        //添加
        activityStack.add(activity);
    }

    /**
     * 获取当前的activity
     * @return
     */
    public Activity currentActivity() {
        Activity activity = (Activity)activityStack.lastElement();
        return activity;
    }

    /**
     * 结束当前activity
     */
    public void finishActivity() {
        Activity activity = (Activity)activityStack.lastElement();
        this.finishActivity(activity);
    }

    /**
     * 结束指定activity
     * @param activity
     */
    public void finishActivity(Activity activity) {
        if(activity != null) {
            this.removeActivityStack(activity);
            activity.finish();
            activity = null;
        }

    }

    /**
     * 移除指定activity
     * @param activity
     */
    public void removeActivityStack(Activity activity) {
        activityStack.remove(activity);
    }

    /**
     * 结束最后一个activity
     */
    public void finishLastActivity() {
        Activity activity = (Activity)activityStack.lastElement();
        if(activity != null) {
            activityStack.remove(activity);
            activity.finish();
            activity = null;
        }

    }

    /**
     * 结束指定activity
     * @param cls
     */
    public void finishActivity(Class<?> cls) {
        Iterator i$ = activityStack.iterator();

        while(i$.hasNext()) {
            Activity activity = (Activity)i$.next();
            if(activity.getClass().equals(cls)) {
                this.finishActivity(activity);
            }
        }

    }
    /**
     * 结束全部Activity
     *
     */
    public void finishAllActivity() {
        int i = 0;
        for(int size = activityStack.size(); i < size; ++i) {
            if(null != activityStack.get(i)) {
                ((Activity)activityStack.get(i)).finish();
            }
        }
        activityStack.clear();
    }

    /**
     * Activity
     * @param activity
     */
    public void getActivity(Activity activity) {
        if(activity != null) {
            activityStack.remove(activity);
            activity.finish();
            activity = null;
        }

    }

    /**
     * 获取activity总数
     * @return
     */
    public int getActivityCount() {
        return activityStack.size();
    }
}
