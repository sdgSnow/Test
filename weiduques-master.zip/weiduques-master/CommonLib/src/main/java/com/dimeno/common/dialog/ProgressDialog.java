package com.dimeno.common.dialog;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.common.widget.UploadCircleProgressBar;
import com.example.common.R;


/**
 * @author sdg
 * createTime 2020/12/18
 * desc:上传进度类dialog
 * */
public class ProgressDialog extends BaseDialog{

    private AppCompatActivity context;
    private boolean isCancelableDismiss = false;//点击返回键和触摸dialog之外区域是否消失
    private UploadCircleProgressBar progressBar;

    public ProgressDialog(ProgressDialogBuilder builder) {
        this.context = builder.context;
    }

    @Override
    protected int windowWidth() {
        return ViewGroup.LayoutParams.MATCH_PARENT;
    }

    @Override
    protected int windowHeight() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    @Override
    protected int getDialogLayoutResId() {
        return R.layout.dialog_progress;
    }

    @Override
    protected void onInflated(View container, Bundle savedInstanceState) {
        progressBar = container.findViewById(R.id.progressBar);
    }

    public ProgressDialog setCancelableDismiss(boolean isCancelableDismiss) {
        this.isCancelableDismiss = isCancelableDismiss;
        return this;
    }

    public void setProgress(int progress) {
        progressBar.setProgress(progress);
    }

    public static class ProgressDialogBuilder {
        private final AppCompatActivity context;

        public ProgressDialogBuilder(AppCompatActivity context) {
            this.context = context;
        }

        public ProgressDialog build() {
            return new ProgressDialog(this);
        }
    }

    public ProgressDialog showDialog() {
        setCancelable(isCancelableDismiss);
        show(context.getSupportFragmentManager(),"");
        return this;
    }
}
