package com.dimeno.common.base;

/**
 * baseview
 */
public interface BaseView {

}
