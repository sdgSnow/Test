package com.dimeno.common.event;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public interface IEvent<T> {
    void postEvent(Event event);
    void postStickEvent(Event event);
    void  register(T context);
    void  unregister(T context);
}
