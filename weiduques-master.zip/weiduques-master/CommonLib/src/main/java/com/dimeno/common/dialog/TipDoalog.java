package com.dimeno.common.dialog;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.common.R;


/**
 * @author sdg
 * createTime 2020/12/18
 * desc:提示类dialog
 * */
public class TipDoalog extends BaseDialog{

    private String content = "";
    private AppCompatActivity context;
    private TypeInterface typeInterface;
    //点击返回键和触摸dialog之外区域是否消失
    private boolean isCancelableDismiss = false;

    /**
     * 构造器
     * @param builder
     */
    public TipDoalog(TipDoalogBuilder builder) {
        this.content = builder.content;
        this.context = builder.context;
        this.typeInterface = builder.typeInterface;
    }

    @Override
    protected int windowWidth() {
        return ViewGroup.LayoutParams.MATCH_PARENT;
    }

    @Override
    protected int windowHeight() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    @Override
    protected int getDialogLayoutResId() {
        return R.layout.dialog_tip;
    }

    public String getContent() {
        return content;
    }

    public TipDoalog setCancelableDismiss(boolean isCancelableDismiss) {
        this.isCancelableDismiss = isCancelableDismiss;
        return this;
    }

    @Override
    protected void onInflated(View container, Bundle savedInstanceState) {
        TextView tv_content = container.findViewById(R.id.content);
        TextView tv_sure = container.findViewById(R.id.sure);
        tv_content.setText(content);
        tv_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                typeInterface.sure();
                dismiss();
            }
        });
    }

    public static class TipDoalogBuilder {
        private String content;
        private final AppCompatActivity context;
        private TypeInterface typeInterface;

        public TipDoalogBuilder(AppCompatActivity context) {
            this.context = context;
        }

        public TipDoalogBuilder setContent(String content) {
            this.content = content;
            return this;
        }

        public TipDoalogBuilder setTypeInterface(TypeInterface typeInterface) {
            this.typeInterface = typeInterface;
            return this;
        }

        public TipDoalog build() {
            return new TipDoalog(this);
        }
    }

    public void showDialog() {
        setCancelable(isCancelableDismiss);
        show(context.getSupportFragmentManager(),"");
    }

    public interface TypeInterface {
        void sure();
    }
}
