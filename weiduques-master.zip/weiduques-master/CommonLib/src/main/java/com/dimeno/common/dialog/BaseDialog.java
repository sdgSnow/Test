package com.dimeno.common.dialog;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

/**
 * @author sdg
 * createTime 2020/12/18
 * desc:基类dialog
 * */
public abstract class BaseDialog extends DialogFragment {

    protected View mContainer;

    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (inflater == null) {
            return null;
        }
        return mContainer = inflater.inflate(getDialogLayoutResId(), container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mContainer != null) {
            onInflated(mContainer, savedInstanceState);
            setWindowStyle(getDialog().getWindow());
        }
    }

    /**
     * 返回当前自定义dialog的view布局
     *
     * @return int
     */
    protected abstract int windowWidth();

    /**
     * 返回当前自定义dialog的view布局
     *
     * @return int
     */
    protected abstract int windowHeight();

    /**
     * 返回当前自定义dialog的view布局
     *
     * @return int
     */
    protected abstract int getDialogLayoutResId();

    /**
     * 在此方法中对view进行初始化
     *
     * @param container 当前的view，通过该view findViewById可以找到子view
     * @param savedInstanceState 保存的Fragment状态
     */
    protected abstract void onInflated(View container, Bundle savedInstanceState);

    /**
     * 设置当前window的样式
     *
     * @param window 可以通过该window设置dialog window
     *
     */
    protected void setWindowStyle(Window window) {
        if (window == null || getContext() == null) {
            return;
        }
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // 设置上下左右的边距，如果都设置0并且height和width都设置MATCH_PARENT，布局会充满整个屏幕
        window.getDecorView().setPadding(30, 30, 30, 30);
        window.setAttributes(getLayoutParams(window.getAttributes()));
    }

    /**
     * 设置dialog布局参数
     *
     * @param params 通过该参数设置相应的属性
     *
     */
    protected WindowManager.LayoutParams getLayoutParams(WindowManager.LayoutParams params) {
        if (params == null) {
            return new WindowManager.LayoutParams();
        }
        // 这里可以设置dialog布局的大小以及显示的位置
        params.width = windowWidth();
        params.height = windowHeight();
        params.gravity = Gravity.CENTER;
        return params;
    }

}
