package com.dimeno.common.dialog;

import androidx.appcompat.app.AppCompatActivity;

import com.dimeno.common.utils.ActivityManager;

public class DialogManage {

    private static DialogManage dialogManage = null;
    private LoadingDialog loadingDialog = null;

    /**
     * get
     * 获取单例
     * @return
     */
    public static DialogManage get() {
        if (dialogManage == null) {
            dialogManage = new DialogManage();
        }
        return dialogManage;
    }

    /**
     * 显示
     */
    public void showDialog() {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
        } else {
            loadingDialog = new LoadingDialog((AppCompatActivity) ActivityManager.getAppManager().currentActivity());
        }
        if(ActivityManager.getAppManager().currentActivity() instanceof AppCompatActivity){
            loadingDialog.showDialog();
        }
    }

    /**
     * dismiss
     */
    public void hideDialog(){
        if (loadingDialog != null && loadingDialog.isVisible()) {
            loadingDialog.dismiss();
        }
    }
}
