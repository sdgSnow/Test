package com.dimeno.common.helper;//package com.dimeno.dimenoquestion.helper;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import com.dimeno.common.utils.UIUtils;
import com.example.common.R;


/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class ProgressHelper {
    private Animation animation;
    private static ProgressHelper sInstance = null;

    public static ProgressHelper getInstance() {
        if (sInstance == null) {
            synchronized (ProgressHelper.class) {
                if (sInstance == null) {
                    sInstance = new ProgressHelper();
                }
            }
        }
        return sInstance;
    }

    private ProgressDialog mDialog = null;
    private  TextView title=null;
    private ProgressHelper() {
    }

    public void show(final Context context, final boolean isCancel) {
        if (Looper.getMainLooper() != Looper.myLooper()) {
            UIUtils.post(new Runnable() {
                @Override
                public void run() {
                    show(context, isCancel);
                }
            });
            return;
        }

        cancel();

        mDialog = new ProgressDialog(context,ProgressDialog.STYLE_HORIZONTAL);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setCancelable(isCancel);
        mDialog.show();
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null);
        ImageView iv_loading = v.findViewById(R.id.loading);
        WindowManager.LayoutParams params = mDialog.getWindow().getAttributes();
        params.width = UIUtils.dp2px(150);
        params.height = UIUtils.dp2px(130);
        mDialog.getWindow().setAttributes(params);
        mDialog.setContentView(v);
        initAnimation(context,iv_loading);
    }

    public void show(final Context context, final String message, final boolean isCancel) {
        if (Looper.getMainLooper() != Looper.myLooper()) {
            UIUtils.post(new Runnable() {
                @Override
                public void run() {
                    show(context,message, isCancel);
                }
            });
            return;
        }
        cancel();
        mDialog = new ProgressDialog(context,ProgressDialog.STYLE_HORIZONTAL);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.setCancelable(isCancel);
        mDialog.show();
        WindowManager.LayoutParams params = mDialog.getWindow().getAttributes();
        params.width = UIUtils.dp2px(150);
        params.height = UIUtils.dp2px(130);
        mDialog.getWindow().setAttributes(params);
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_loading, null);
        title=v.findViewById(R.id.tv_message);
        if(title!=null){
            title.setText(message);
        }
        ImageView iv_loading = v.findViewById(R.id.loading);
        mDialog.setContentView(v);
        initAnimation(context,iv_loading);
    }

    /**
     * 初始化默认的动画
     * */
    public void initAnimation(Context context,ImageView iv_loading){
        if(iv_loading!=null){
            Animation rotateAnimation = AnimationUtils.loadAnimation(context, R.anim.loading);
            LinearInterpolator lin = new LinearInterpolator();
            rotateAnimation.setInterpolator(lin);
            if(animation == null){
                iv_loading.startAnimation(rotateAnimation);
            }else {
                iv_loading.startAnimation(animation);
            }
        }
    }
    public void setTitle(String message){
        if(title!=null){
            title.setText(message);
        }
    }
    /**
     * 修改Just
     *
     * @return
     */
    public boolean isShow() {
        return mDialog != null && mDialog.isShowing();
    }

    public void cancel() {

        if (Looper.getMainLooper() != Looper.myLooper()) {
            UIUtils.post(new Runnable() {
                @Override
                public void run() {
                    cancel();
                }
            });
            return;
        }

        if (mDialog != null && mDialog.isShowing()) {

            mDialog.dismiss();
        }
    }

    /**
     * 销毁，防止内存泄露
     */
    public void destory(){
        if (mDialog != null && mDialog.isShowing()) {
            mDialog.dismiss();
        }
        if (mDialog != null ) {
            mDialog=null;
        }
    }
}
