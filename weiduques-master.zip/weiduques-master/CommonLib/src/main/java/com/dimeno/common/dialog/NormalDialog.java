package com.dimeno.common.dialog;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.common.R;


/**
 * @author sdg
 * createTime 2020/12/18
 * desc:上传进度类dialog
 * */
public class NormalDialog extends BaseDialog {

    private String title = "";
    private String content = "";
    private boolean isShowClose = true;//是否显示右上角叉叉
    private AppCompatActivity context;
    private TypeInterface typeInterface;
    private boolean isCancelableDismiss = false;//点击返回键和触摸dialog之外区域是否消失

    public NormalDialog(NormalDialogBuilder builder) {
        this.title = builder.title;
        this.content = builder.content;
        this.isShowClose = builder.isShowClose;
        this.context = builder.context;
        this.typeInterface = builder.typeInterface;
    }

    @Override
    protected int windowWidth() {
        return ViewGroup.LayoutParams.MATCH_PARENT;
    }

    @Override
    protected int windowHeight() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    @Override
    protected int getDialogLayoutResId() {
        return R.layout.dialog_normal;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public NormalDialog setCancelableDismiss(boolean isCancelableDismiss) {
        this.isCancelableDismiss = isCancelableDismiss;
        return this;
    }

    @Override
    protected void onInflated(View container, Bundle savedInstanceState) {
        TextView tv_title = container.findViewById(R.id.title);
        ImageView iv_close = container.findViewById(R.id.close);
        TextView tv_content = container.findViewById(R.id.content);
        TextView tv_cancle = container.findViewById(R.id.cancle);
        TextView tv_sure = container.findViewById(R.id.sure);
        tv_title.setText(title);
        tv_content.setText(content);
        iv_close.setVisibility(isShowClose ? View.VISIBLE : View.GONE);
        tv_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(typeInterface != null) {
                    typeInterface.cancle();
                }
                dismiss();
            }
        });
        tv_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(typeInterface != null) {
                    typeInterface.sure();
                }
                dismiss();
            }
        });
    }

    public static class NormalDialogBuilder {
        private String title;
        private String content;
        private boolean isShowClose = true;
        private final AppCompatActivity context;
        private TypeInterface typeInterface;

        public NormalDialogBuilder(AppCompatActivity context) {
            this.context = context;
        }

        public NormalDialogBuilder setTitle(String title) {
            this.title = title;
            return this;
        }

        public NormalDialogBuilder setContent(String content) {
            this.content = content;
            return this;
        }

        public NormalDialogBuilder setShowClose(boolean isShowClose) {
            this.isShowClose = isShowClose;
            return this;
        }

        public NormalDialogBuilder setTypeInterface(TypeInterface typeInterface) {
            this.typeInterface = typeInterface;
            return this;
        }

        public NormalDialog build() {
            return new NormalDialog(this);
        }
    }

    public void showDialog() {
        setCancelable(isCancelableDismiss);
        show(context.getSupportFragmentManager(),"");
    }

    public interface TypeInterface {
        void sure();

        void cancle();
    }
}
