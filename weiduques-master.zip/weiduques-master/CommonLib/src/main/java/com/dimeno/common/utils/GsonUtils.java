package com.dimeno.common.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Created by lenovo on 2017/3/24.
 */

public class GsonUtils {
    private static Gson mInstance;

    /**
     * getInstance
     * 获取单例
     * @return
     */
    public static Gson getInstance()
    {
        if (mInstance == null)
        {
            synchronized (GsonUtils.class)
            {
                if (mInstance == null)
                {
                    mInstance= new GsonBuilder().serializeNulls().create();
                }
            }
        }
        return mInstance;
    }
}
