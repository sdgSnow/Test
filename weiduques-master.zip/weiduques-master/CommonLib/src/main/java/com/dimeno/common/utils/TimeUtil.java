package com.dimeno.common.utils;


import android.text.format.DateFormat;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class TimeUtil {
    /**
     * 获取当前时间并格式化为 yyyy-MM-dd HH:mm:ss
     * */
    public static String getCurrentTime(){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long l = System.currentTimeMillis();
        String timestr = df.format(new Date(l));
        return timestr;
    }
    /**
     * 把时间戳转化为格式 yyyy-MM-dd HH:mm:ss
     * */
    public static String getTime(long time){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timestr = df.format(new Date(time));
        return timestr;
    }

    /**
     * 将 yyyy-MM-dd HH:mm:ss 时间格式化为 yyyy-MM-dd
     * */
    public static String formatYMD(String time){
        long lastHistoryTime = 0;
        try {
            lastHistoryTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(time).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String timestr = sdf.format(new Date(lastHistoryTime));


        return timestr;
    }

    /**
     * 将 Date 时间格式化为 yyyy-MM-dd
     * */
    public static String date2YMD(Date date){
        String timestr = DateFormat.format("yyyy-MM-dd", date).toString();
        return timestr;
    }

    /**
     * 将 Date 时间格式化为 yyyy-MM-dd HH:mm:ss
     * */
    public static String date2YMDhms(Date date){
        String timestr = DateFormat.format("yyyy-MM-dd HH:mm:ss", date).toString();
        return timestr;
    }

    /**
     * 获取年
     * @return
     */
    public static String getYear(){
        Calendar cd = Calendar.getInstance();
        return  cd.get(Calendar.YEAR) + "";
    }
    /**
     * 获取月
     * @return
     */
    public static String getMonth(){
        Calendar cd = Calendar.getInstance();
        return  cd.get(Calendar.MONTH)+1 + "";
    }
    /**
     * 获取日
     * @return
     */
    public static int getDay(){
        Calendar cd = Calendar.getInstance();
        return  cd.get(Calendar.DATE);
    }
    /**
     * 获取时
     * @return
     */
    public static int getHour(){
        Calendar cd = Calendar.getInstance();
        return  cd.get(Calendar.HOUR);
    }
    /**
     * 获取分
     * @return
     */
    public static int getMinute(){
        Calendar cd = Calendar.getInstance();
        return  cd.get(Calendar.MINUTE);

    }

    /**
     * 获取当前时间的时间戳
     * @return
     */
    public static long getCurrentTimeMillis(){
        return System.currentTimeMillis();
    }

    /**
     * 比较当前时间和服务器返回时间大小
     *
     * @param nowDate
     * @param compareDate
     * @return
     */
    public boolean compareDate(String nowDate, String compareDate) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            Date now = df.parse(nowDate);
            Date compare = df.parse(compareDate);
            if (now.before(compare)) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 计时器 00:00:00 格式
     *
     * @param time
     * @return
     */
    public static String getFormatHMS(long time) {
        time = time / 1000;//总秒数
        int s = (int) (time % 60);//秒
        int m = (int) (time / 60);//分
        int h = (int) (time / 3600);//秒
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    /**
     * @param currentTrim 当前时间
     * @param loginTime 上次登录时间
     * */
    public static int loginDays(long currentTrim,long loginTime) {
        int loginDays = 0;

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date1 = formatter.format(loginTime);
        String date2 = formatter.format(currentTrim);
        // 获取服务器返回的时间戳 转换成"yyyy-MM-dd HH:mm:ss"
        // 计算的时间差
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date d1 = df.parse(date1);
            Date d2 = df.parse(date2);
            // 这样得到的差值是微秒级别
            long diff = d1.getTime() - d2.getTime();
            long days = diff / (1000 * 60 * 60 * 24);
            long hours = (diff - days * (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
            long minutes = (diff - days * (1000 * 60 * 60 * 24) - hours * (1000 * 60 * 60)) / (1000 * 60);
            loginDays = (int) days;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return loginDays;
    }

}
