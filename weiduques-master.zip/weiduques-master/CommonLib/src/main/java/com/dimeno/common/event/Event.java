package com.dimeno.common.event;

/**
 * Create by   :PNJ
 * Date        :2021/3/11
 * Description :
 */
public class Event {
    public int arg1;
    public Object data;



    public Event(int arg1, Object data) {
        this.data=data;
        this.arg1=arg1;
    }
    public Event(int arg1) {
        this.arg1 = arg1;
    }

    public int getTag() {
        return arg1;
    }
}
