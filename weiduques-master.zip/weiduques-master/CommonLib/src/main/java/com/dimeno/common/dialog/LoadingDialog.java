package com.dimeno.common.dialog;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.common.R;

/**
 * @author sdg
 * createTime 2020/12/18
 * desc:加载类dialog
 * */
public class LoadingDialog extends BaseDialog{

    private static AppCompatActivity activity;
    private Animation animation;
    //点击返回键和触摸dialog之外区域是否消失
    private boolean isCancelableDismiss = false;
    private ImageView iv_loading;

    /**
     * LoadingDialog
     * @param activity
     */
    public LoadingDialog(AppCompatActivity activity) {
        this.activity = activity;
    }

    /**
     * LoadingDialog
     * @param builder
     */
    public LoadingDialog(LoadingDialogBuilder builder) {
        this.activity = builder.activity;
    }

    @Override
    protected int windowWidth() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    @Override
    protected int windowHeight() {
        return ViewGroup.LayoutParams.WRAP_CONTENT;
    }

    @Override
    protected int getDialogLayoutResId() {
        return R.layout.dialog_loading;
    }



    public LoadingDialog setCancelableDismiss(boolean isCancelableDismiss) {
        this.isCancelableDismiss = isCancelableDismiss;
        return this;
    }

    public LoadingDialog setAnimation(Animation animation) {
        this.animation = animation;
        return this;
    }

    @Override
    protected void onInflated(View container, Bundle savedInstanceState) {
        iv_loading = container.findViewById(R.id.loading);
        initAnimation();
    }

    /**
     * 初始化默认的动画
     * */
    public void initAnimation(){
        Animation rotateAnimation = AnimationUtils.loadAnimation(activity, R.anim.loading);
        LinearInterpolator lin = new LinearInterpolator();
        rotateAnimation.setInterpolator(lin);
        if(animation == null){
            iv_loading.startAnimation(rotateAnimation);
        }else {
            iv_loading.startAnimation(animation);
        }

    }

    public static class LoadingDialogBuilder {
        private final AppCompatActivity activity;

        public LoadingDialogBuilder(AppCompatActivity activity) {
            this.activity = activity;
        }

        public LoadingDialog build() {
            return new LoadingDialog(this);
        }
    }

    public void showDialog() {
        setCancelable(isCancelableDismiss);
        show(activity.getSupportFragmentManager(),"");
    }

}
