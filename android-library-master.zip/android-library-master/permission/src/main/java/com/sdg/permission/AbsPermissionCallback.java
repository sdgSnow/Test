package com.sdg.permission;

import com.dimeno.permission.callback.PermissionCallback;

public abstract class AbsPermissionCallback implements PermissionCallback {

    @Override
    public void onGrant(String[] permissions) {
        
    }
}
