package com.sdg.androidlibrary.adapter.dimeno;

import android.view.View;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.dimeno.adapter.callback.OnItemChildClickCallback;
import com.dimeno.adapter.callback.OnItemChildLongClickCallback;
import com.dimeno.adapter.callback.OnItemClickCallback;
import com.dimeno.adapter.callback.OnItemLongClickCallback;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.sdg.adapter.GridSpacesItemDecoration;
import com.sdg.androidlibrary.R;
import com.sdg.common.base.BaseActivity;
import com.sdg.common.base.BasePresenter;
import com.sdg.common.toolbar.BackLeftToolbar;
import com.socks.library.KLog;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DimenoAdapterActivity extends BaseActivity {

    private RecyclerView rcyDimeno;
    private List<DimenoBean> dimenoBeanList;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_dimeno_adapter;
    }

    @Override
    protected void initViews() {
        rcyDimeno = findViewById(R.id.rcyDimeno);
        if(rcyDimeno.getItemDecorationCount() == 0) {
            rcyDimeno.addItemDecoration(new GridSpacesItemDecoration(this, 1, 10));
        }
        rcyDimeno.setLayoutManager(new GridLayoutManager(mContext, 1, GridLayoutManager.VERTICAL, false));
    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new BackLeftToolbar(this,"DimenoAdapter");
    }

    @Override
    protected void initData() {
        dimenoBeanList = new ArrayList<>();
        for (int i = 0;i < 20; i++){
            DimenoBean dimenoBean = new DimenoBean();
            dimenoBean.setTitle("测试标题" + i);
            dimenoBean.setDesc("测试说明" + i);
            dimenoBeanList.add(dimenoBean);
        }

        showAdapter();
    }

    private void showAdapter() {
        DimenoAdapter dimenoAdapter = new DimenoAdapter(dimenoBeanList);
        rcyDimeno.setAdapter(dimenoAdapter);
        dimenoAdapter.setOnClickCallback((itemView, position) -> {
            ToastUtils.showShort("条目点击事件:" + position);
        });
        dimenoAdapter.setOnLongClickCallback((itemView, position) -> {
            ToastUtils.showShort("条目长按事件:" + position);
        });
        dimenoAdapter.setOnChildClickCallback((itemView, position) -> {
            switch (itemView.getId()){
                case R.id.title:
                    ToastUtils.showShort("条目子控件点击事件:" + dimenoBeanList.get(position).getTitle());
                    break;
                case R.id.desc:
                    ToastUtils.showShort("条目子控件点击事件:" + dimenoBeanList.get(position).getDesc());
                    break;
            }
        });
        dimenoAdapter.setOnChildLongClickCallback((itemView, position) -> {
            switch (itemView.getId()){
                case R.id.title:
                    ToastUtils.showShort("条目子控件长按事件:" + dimenoBeanList.get(position).getTitle());
                    break;
                case R.id.desc:
                    ToastUtils.showShort("条目子控件长按事件:" + dimenoBeanList.get(position).getDesc());
                    break;
            }
        });
    }

    @Override
    protected BasePresenter createPresenter() {
        return null;
    }
}