package com.sdg.androidlibrary.adapter.dimeno;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.dimeno.adapter.RecyclerAdapter;

import java.util.List;

public class DimenoAdapter extends RecyclerAdapter<DimenoBean> {

    public DimenoAdapter(List<DimenoBean> list) {
        super(list);
    }

    @Override
    public RecyclerView.ViewHolder onAbsCreateViewHolder(ViewGroup parent, int viewType) {
        return new DimenoViewHolder(parent);
    }
}
