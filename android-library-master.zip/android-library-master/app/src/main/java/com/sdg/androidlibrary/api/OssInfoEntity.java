package com.sdg.androidlibrary.api;

public class OssInfoEntity {

    public String SecurityToken;
    public String endpoint;
    public String BucketName;
    public Integer code;
    public String AccessKeyId;
    public Boolean success;
    public String AccessKeySecret;
    public String Expiration;
    public String Host;
    public String Directory;
}
