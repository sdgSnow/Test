package com.sdg.androidlibrary.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBinding;

import com.dimeno.commons.toolbar.ToolbarActivity;
import com.sdg.common.base.ActivityManager;
import com.sdg.common.base.BaseApplication;
import com.sdg.common.base.BasePresenter;
import com.sdg.common.base.BaseView;
import com.wangzhen.statusbar.DarkStatusBar;
import com.wangzhen.statusbar.listener.StatusBar;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public abstract class BaseBindActivity<T extends ViewBinding,P extends BasePresenter>  extends ToolbarActivity implements BaseView {
    public Context mContext;
    public AppCompatActivity mActivity;
    public P mPresenter;
    public T mBinding;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Type superclass = getClass().getGenericSuperclass();
        Class<?> aClass = (Class<?>) ((ParameterizedType) superclass).getActualTypeArguments()[0];
        try {
            Method method = aClass.getDeclaredMethod("inflate", LayoutInflater.class);
            mBinding = (T) method.invoke(null, getLayoutInflater());
            setContentView(mBinding.getRoot());
        } catch (NoSuchMethodException | IllegalAccessException| InvocationTargetException e) {
            e.printStackTrace();
        }
        BaseApplication.getRefWatcher().watch(this);
        //配置为竖屏
        this.mPresenter =  createPresenter();
        if (mPresenter != null) {
            mPresenter.attachView(this);
        }
        mContext = this;
        mActivity = this;
        //初始化控件，一般在BaseActivity中通过ButterKnife来绑定，所以该方法内部一般我们初始化界面相关的操作
        initViews();
        //获取数据
        initData();

        ActivityManager.getAppManager().addActivity(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityManager.getAppManager().removeActivityStack(this);
        killPresenter();
    }

    public void fitDarkStatusBar(boolean dark){
        StatusBar statusBar = DarkStatusBar.get();
        if(dark) statusBar.fitDark(this);
    }


    /**
     * 初始化界面
     */
    protected abstract void initViews();

    /**
     * 获取数据
     */
    protected void initData(){}

    /**
     * 实例化presenter
     */
    protected abstract P createPresenter();
    /**
     * 解绑Presenter
     */
    public void killPresenter() {
        if (mPresenter != null) {
            mPresenter.detachView();
        }
    }

    //打开一个Activity 默认 不关闭当前activity
    public void gotoActivity(Class<?> clz) {
        gotoActivity(clz, false, null);
    }

    public void gotoActivity(Class<?> clz, boolean isCloseCurrentActivity) {
        gotoActivity(clz, isCloseCurrentActivity, null);
    }

    public void gotoActivity(Class<?> clz, boolean isCloseCurrentActivity, Bundle ex) {
        Intent intent = new Intent(mContext, clz);
        if (ex != null)
            intent.putExtras(ex);
        startActivity(intent);
        if (isCloseCurrentActivity) {
            ((BaseBindActivity) mContext).finish();
        }
    }


    /**
     * 隐藏软键盘(只适用于Activity，不适用于Fragment)
     */
    public static void hideSoftKeyboard(Activity activity) {
        View view = activity.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

}