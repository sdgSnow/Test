package com.sdg.androidlibrary.adapter.brvah;

import android.content.Context;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.sdg.adapter.test.LibraryBean;
import com.sdg.androidlibrary.R;
import com.sdg.objectbox.Test;

import java.util.List;

public class DemoAdapter extends BaseQuickAdapter<Test, BaseViewHolder> {

    private Context mContext;
    private List<Test> mData;

    public DemoAdapter(Context context, @Nullable List<Test> data) {
        super(R.layout.item_demo_adapter, data);
        this.mContext = context;
        this.mData = data;
    }

    @Override
    protected void convert(BaseViewHolder helper, Test item) {
        helper.addOnClickListener(R.id.title);
        helper.addOnClickListener(R.id.desc);
        helper.setText(R.id.title,item.name);
        helper.setText(R.id.desc,item.desc);
    }
}
