package com.sdg.androidlibrary.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dimeno.commons.toolbar.impl.Toolbar;
import com.sdg.androidlibrary.R;
import com.sdg.common.base.BaseActivity;
import com.sdg.common.base.BasePresenter;
import com.sdg.common.toolbar.TitleToolbar;
import com.sdg.ui.MyEditText;

import org.jetbrains.annotations.Nullable;

public class UiActivity extends BaseActivity {

    @Override
    protected int getLayoutId() {
        return R.layout.activity_ui;
    }

    @Override
    protected void initViews() {
        MyEditText myet = findViewById(R.id.myet);
    }

    @Override
    protected void initData() {

    }

    @Nullable
    @Override
    public Toolbar createToolbar() {
        return new TitleToolbar(this,"UI");
    }

    @Override
    protected BasePresenter createPresenter() {
        return null;
    }
}