package com.sdg.androidlibrary.adapter.brvah;

public class DemoBean {

    public String title;
    public String desc;

    public DemoBean(String title, String desc) {
        this.title = title;
        this.desc = desc;
    }
}
