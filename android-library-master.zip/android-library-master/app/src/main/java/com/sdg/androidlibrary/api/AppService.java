package com.sdg.androidlibrary.api;

import com.sdg.api.Res;

import java.util.ArrayList;
import java.util.Map;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface AppService {

    /**
     * 获取OSS信息
     */
    @POST("api/AliYun/GetToken")
    Observable<OssInfoEntity> getToken();

    /**
     * ‘关于我们’信息
     *
     * @param ProCode
     * @return
     */
    @GET("api/Que/GetAboutUs")
    Observable<Res<AboutUsBean>> getAboutUs(@Query("ProCode") String ProCode);

    @GET("api/QueApp/GetQueListByUid")
    Observable<Res<ArrayList<NewQuesBean>>> loadQuesList(@QueryMap(encoded = true) Map<String, String> params);
}
