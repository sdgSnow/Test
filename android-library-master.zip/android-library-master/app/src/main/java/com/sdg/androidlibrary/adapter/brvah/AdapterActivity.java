package com.sdg.androidlibrary.adapter.brvah;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dimeno.commons.toolbar.impl.Toolbar;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.sdg.adapter.GridSpacesItemDecoration;
import com.sdg.androidlibrary.R;
import com.sdg.common.base.BaseActivity;
import com.sdg.common.base.BasePresenter;
import com.sdg.common.toolbar.BackMenuToolbar;
import com.sdg.objectbox.ObjectBoxManager;
import com.sdg.objectbox.Test;

import java.util.ArrayList;
import java.util.List;

import io.objectbox.Box;

public class AdapterActivity extends BaseActivity {

    private RecyclerView rcyDemo;
    private List<Test> list;
    private DemoAdapter adapter;
    private int page;
    private int size;
    private Box<Test> testBox;
    private SmartRefreshLayout refresh_layout;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_adapter;
    }

    @Override
    protected void initViews() {
        rcyDemo = findViewById(R.id.rcyDemo);
        refresh_layout = findViewById(R.id.refresh_Layout);
        refresh_layout.setRefreshHeader(new ClassicsHeader(this));
        refresh_layout.setRefreshFooter(new ClassicsFooter(this).setSpinnerStyle(SpinnerStyle.Scale));
        if(rcyDemo.getItemDecorationCount() == 0) {
            rcyDemo.addItemDecoration(new GridSpacesItemDecoration(this, 1, 10));
        }
        rcyDemo.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));
    }

    @Override
    protected void initData() {
        testBox = ObjectBoxManager.get().boxFor(Test.class);
        list = new ArrayList<>();
        page = 1;
        size = 20;
        showAdapter();
    }

    public void initTestData(){


    }

    public void showAdapter(){
        adapter = new DemoAdapter(mContext,list);
        if(list.size() == 0){
            List<Test> fylist = testBox.query().build().find(list.size(), size);
            adapter.addData(fylist);
        }
        rcyDemo.setAdapter(adapter);
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                ToastUtils.showShort("条目点击事件：" + list.get(position).name);
            }
        });

        refresh_layout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                List<Test> fylist = testBox.query().build().find(adapter.getData().size(), size);
                adapter.addData(fylist);
            }
        });
    }


    @Override
    public Toolbar createToolbar() {
        return new BackMenuToolbar(this,"adapter演示");
    }

    @Override
    protected BasePresenter createPresenter() {
        return null;
    }


}