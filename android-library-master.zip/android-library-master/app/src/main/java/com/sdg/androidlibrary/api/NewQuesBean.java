package com.sdg.androidlibrary.api;

import java.io.Serializable;

/**
 * Create by   :PNJ
 * Date        :2021/3/17
 * Description :
 */
public class NewQuesBean implements Serializable {

    /**
     * ID : 9c55e84b-09d5-4fbd-9087-46c061a757c1
     * QueTitle : 问卷标题123
     * IsDelete : false
     * IsRelease : true
     * IsCustomArea: true,
     * Creator : 86e92e66-c979-4bae-8184-ded9f0870398
     * CreateDate : 2017-12-20 14:22:54
     * Modifier : 86e92e66-c979-4bae-8184-ded9f0870398
     * ModifyDate : 2017-12-20 14:48:27
     * CatalogID : b959dc42-5f4f-4646-9dfd-711117071520
     * Rmk : 问卷备注说明456
     * IsCusView : false
     */
    public String CatalogID;//":null,
    public String ComplateStatus;//":null,
    public String CreateDate;//":"2020-11-19 16:31:35",
    public String CreateUserName;//":null,
    public String CreateUserRoles;//":null,
    public String Creator;//":"1",
    public String CustomAreaList;//":null,
    public String Divisions;//":"440300",
    public String DoneCount;//":null,
    public String ID;//":"1329341540904730625",
    public String IntExt1;//":null,
    public String IntExt2;//":null,
    public String IntExt3;//":null,
    public String IntExt4;//":null,
    public String IntExt5;//":null,
    public String IsCusView;//":null,
    public boolean IsCustomArea;//":false,
    public boolean IsDelete;//":false,
    public int IsPublic;//":1,
    public String IsPublic_Show;//":"是",
    public String IsRatio;//":null,
    public boolean IsRelease;//":true,
    public boolean IsTape;//":false,
    public int MaxCount;//":100,
    public String Modifier;//":"1",
    public String ModifyDate;//":"2020-12-08 09:10:58",
    public String NumFormat;//":null,
    public String ProCode;//":"gdnbs",
    public String QueAreaType;//":null,
    public String QueCategory;//":1,
    public String QueObject;//":null,
    public String QueObject_Show;//":"",
    public String QueStatus;//":2,
    public String QueTitle;//":"测试",
    public String QueType;//":null,
    public String QueTypeName;//":null,
    public String Rmk;//":"问卷备注说明",
    public String StatusText;//":"未发布",
    public String StrExt1;//":null,
    public String Uid;//":null,
    public String isNew;//":

    public String getCatalogID() {
        return CatalogID;
    }

    public void setCatalogID(String catalogID) {
        CatalogID = catalogID;
    }

    public String getComplateStatus() {
        return ComplateStatus;
    }

    public void setComplateStatus(String complateStatus) {
        ComplateStatus = complateStatus;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String createDate) {
        CreateDate = createDate;
    }

    public String getCreateUserName() {
        return CreateUserName;
    }

    public void setCreateUserName(String createUserName) {
        CreateUserName = createUserName;
    }

    public String getCreateUserRoles() {
        return CreateUserRoles;
    }

    public void setCreateUserRoles(String createUserRoles) {
        CreateUserRoles = createUserRoles;
    }

    public String getCreator() {
        return Creator;
    }

    public void setCreator(String creator) {
        Creator = creator;
    }

    public String getCustomAreaList() {
        return CustomAreaList;
    }

    public void setCustomAreaList(String customAreaList) {
        CustomAreaList = customAreaList;
    }

    public String getDivisions() {
        return Divisions;
    }

    public void setDivisions(String divisions) {
        Divisions = divisions;
    }

    public String getDoneCount() {
        return DoneCount;
    }

    public void setDoneCount(String doneCount) {
        DoneCount = doneCount;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getIntExt1() {
        return IntExt1;
    }

    public void setIntExt1(String intExt1) {
        IntExt1 = intExt1;
    }

    public String getIntExt2() {
        return IntExt2;
    }

    public void setIntExt2(String intExt2) {
        IntExt2 = intExt2;
    }

    public String getIntExt3() {
        return IntExt3;
    }

    public void setIntExt3(String intExt3) {
        IntExt3 = intExt3;
    }

    public String getIntExt4() {
        return IntExt4;
    }

    public void setIntExt4(String intExt4) {
        IntExt4 = intExt4;
    }

    public String getIntExt5() {
        return IntExt5;
    }

    public void setIntExt5(String intExt5) {
        IntExt5 = intExt5;
    }

    public String getIsCusView() {
        return IsCusView;
    }

    public void setIsCusView(String isCusView) {
        IsCusView = isCusView;
    }

    public boolean isCustomArea() {
        return IsCustomArea;
    }

    public void setCustomArea(boolean customArea) {
        IsCustomArea = customArea;
    }

    public boolean isDelete() {
        return IsDelete;
    }

    public void setDelete(boolean delete) {
        IsDelete = delete;
    }

    public int getIsPublic() {
        return IsPublic;
    }

    public void setIsPublic(int isPublic) {
        IsPublic = isPublic;
    }

    public String getIsPublic_Show() {
        return IsPublic_Show;
    }

    public void setIsPublic_Show(String isPublic_Show) {
        IsPublic_Show = isPublic_Show;
    }

    public String getIsRatio() {
        return IsRatio;
    }

    public void setIsRatio(String isRatio) {
        IsRatio = isRatio;
    }

    public boolean isRelease() {
        return IsRelease;
    }

    public void setRelease(boolean release) {
        IsRelease = release;
    }

    public boolean isTape() {
        return IsTape;
    }

    public void setTape(boolean tape) {
        IsTape = tape;
    }

    public int getMaxCount() {
        return MaxCount;
    }

    public void setMaxCount(int maxCount) {
        MaxCount = maxCount;
    }

    public String getModifier() {
        return Modifier;
    }

    public void setModifier(String modifier) {
        Modifier = modifier;
    }

    public String getModifyDate() {
        return ModifyDate;
    }

    public void setModifyDate(String modifyDate) {
        ModifyDate = modifyDate;
    }

    public String getNumFormat() {
        return NumFormat;
    }

    public void setNumFormat(String numFormat) {
        NumFormat = numFormat;
    }

    public String getProCode() {
        return ProCode;
    }

    public void setProCode(String proCode) {
        ProCode = proCode;
    }

    public String getQueAreaType() {
        return QueAreaType;
    }

    public void setQueAreaType(String queAreaType) {
        QueAreaType = queAreaType;
    }

    public String getQueCategory() {
        return QueCategory;
    }

    public void setQueCategory(String queCategory) {
        QueCategory = queCategory;
    }

    public String getQueObject() {
        return QueObject;
    }

    public void setQueObject(String queObject) {
        QueObject = queObject;
    }

    public String getQueObject_Show() {
        return QueObject_Show;
    }

    public void setQueObject_Show(String queObject_Show) {
        QueObject_Show = queObject_Show;
    }

    public String getQueStatus() {
        return QueStatus;
    }

    public void setQueStatus(String queStatus) {
        QueStatus = queStatus;
    }

    public String getQueTitle() {
        return QueTitle;
    }

    public void setQueTitle(String queTitle) {
        QueTitle = queTitle;
    }

    public String getQueType() {
        return QueType;
    }

    public void setQueType(String queType) {
        QueType = queType;
    }

    public String getQueTypeName() {
        return QueTypeName;
    }

    public void setQueTypeName(String queTypeName) {
        QueTypeName = queTypeName;
    }

    public String getRmk() {
        return Rmk;
    }

    public void setRmk(String rmk) {
        Rmk = rmk;
    }

    public String getStatusText() {
        return StatusText;
    }

    public void setStatusText(String statusText) {
        StatusText = statusText;
    }

    public String getStrExt1() {
        return StrExt1;
    }

    public void setStrExt1(String strExt1) {
        StrExt1 = strExt1;
    }

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }
}
