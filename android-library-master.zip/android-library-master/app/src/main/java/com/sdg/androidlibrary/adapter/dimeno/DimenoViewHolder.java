package com.sdg.androidlibrary.adapter.dimeno;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.dimeno.adapter.base.RecyclerViewHolder;
import com.sdg.androidlibrary.R;

public class DimenoViewHolder extends RecyclerViewHolder<DimenoBean> {

    private final TextView title;
    private final TextView desc;

    public DimenoViewHolder(@NonNull ViewGroup parent) {
        super(parent, R.layout.item_demo_adapter);
        title = findViewById(R.id.title);
        desc = findViewById(R.id.desc);
    }

    @Override
    public void bind() {
        title.setText(mData.getTitle());
        desc.setText(mData.getDesc());
    }
}
