package com.sdg.androidlibrary.api;

public class AboutUsBean {
    private String C_ID;
    private String C_Website;
    private String C_ServicePhone;
    private String C_QQ;
    private String C_CreateUser;
    private String C_CreateTime;
    private String C_ModifyUser;
    private String C_ModifyTime;

    public String getC_ID() {
        return C_ID;
    }

    public void setC_ID(String c_ID) {
        C_ID = c_ID;
    }

    public String getC_Website() {
        return C_Website;
    }

    public void setC_Website(String c_Website) {
        C_Website = c_Website;
    }

    public String getC_ServicePhone() {
        return C_ServicePhone;
    }

    public void setC_ServicePhone(String c_ServicePhone) {
        C_ServicePhone = c_ServicePhone;
    }

    public String getC_QQ() {
        return C_QQ;
    }

    public void setC_QQ(String c_QQ) {
        C_QQ = c_QQ;
    }

    public String getC_CreateUser() {
        return C_CreateUser;
    }

    public void setC_CreateUser(String c_CreateUser) {
        C_CreateUser = c_CreateUser;
    }

    public String getC_CreateTime() {
        return C_CreateTime;
    }

    public void setC_CreateTime(String c_CreateTime) {
        C_CreateTime = c_CreateTime;
    }

    public String getC_ModifyUser() {
        return C_ModifyUser;
    }

    public void setC_ModifyUser(String c_ModifyUser) {
        C_ModifyUser = c_ModifyUser;
    }

    public String getC_ModifyTime() {
        return C_ModifyTime;
    }

    public void setC_ModifyTime(String c_ModifyTime) {
        C_ModifyTime = c_ModifyTime;
    }
}
