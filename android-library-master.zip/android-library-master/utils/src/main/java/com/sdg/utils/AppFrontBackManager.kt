package com.sdg.utils

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle

/**
 * AppFrontBackManager
 * Created by wangzhen on 2022/1/27
 */
object AppFrontBackManager {
    private val list: MutableList<Callback?> = mutableListOf()

    @JvmStatic
    fun register(ctx: Context, callback: Callback?) {
        if (ctx.applicationContext is Application) {
            (ctx.applicationContext as Application).apply {
                unregisterActivityLifecycleCallbacks(impl)
                registerActivityLifecycleCallbacks(impl)
            }
        }
        list.add(callback)
    }

    @JvmStatic
    fun unRegister(callback: Callback?){
        list.remove(callback)
    }

    private val impl = object : Application.ActivityLifecycleCallbacks {
        private var activityCount = 0
        override fun onActivityCreated(activity: Activity, extra: Bundle?) {

        }

        override fun onActivityStarted(activity: Activity) {
            activityCount++
            if (activityCount == 1) {
                for (callback in list) {
                    callback?.onFront()
                }
            }
        }

        override fun onActivityResumed(activity: Activity) {

        }

        override fun onActivityPaused(activity: Activity) {

        }

        override fun onActivityStopped(activity: Activity) {
            activityCount--
            if (activityCount == 0) {
                for (callback in list) {
                    callback?.onBack()
                }
            }
        }

        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

        }


        override fun onActivityDestroyed(activity: Activity) {
            if (activityCount == 0) {
                for (callback in list) {
                    callback?.onExit()
                }
            }
        }

    }

    interface Callback {
        fun onFront()
        fun onBack()
        fun onExit()
    }
}