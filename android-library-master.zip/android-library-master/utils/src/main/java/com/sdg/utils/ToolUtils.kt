package com.sdg.bec.utils

import android.text.TextUtils

class ToolUtils {
    companion object{
        fun isEmpty(any: Any?): Boolean {
            any?.let { data ->
                when (data) {
                    is String -> {
                        return TextUtils.isEmpty(data)
                    }
                    is Collection<*> -> {
                        return data.isEmpty()
                    }
                    is Map<*, *> -> {
                        return data.isEmpty()
                    }
                    is Array<*> -> {
                        return data.isEmpty()
                    }
                    is IntArray -> {
                        return data.isEmpty()
                    }
                    is LongArray -> {
                        return data.isEmpty()
                    }
                    else -> return false
                }
            } ?: let {
                return true
            }
        }
    }

}