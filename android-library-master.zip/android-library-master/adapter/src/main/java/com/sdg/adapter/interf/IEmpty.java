package com.sdg.adapter.interf;

public interface IEmpty {

    void retry();

}
