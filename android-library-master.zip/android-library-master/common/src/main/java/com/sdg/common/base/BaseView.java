package com.sdg.common.base;

public interface BaseView {

}
