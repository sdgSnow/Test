package com.sdg.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;

import java.util.regex.Pattern;

public class MyEditText extends AppCompatEditText {

    //各正则表达式
    public static final String EMAIL = "^[a-z0-9]+([._\\\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$";//邮箱
    public static final String TXT = "^([\\u4e00-\\u9fa5])*$";//中文
    public static final String ENGLISH = "^([a-zA-Z])*$";//英文
    public static final String WEBSITE = "[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\\.?";//网址
    public static final String ID = "^\\d{6}(18|19|20|21)?\\d{2}((0[1-9])|(1[0-2]))((0[1-9])|([1-2]\\d)|(3[0-1]))\\d{3}(\\d|X)$";//身份证号码
    public static final String QQ = "^[1-9][0-9]{4,11}$";//QQ号
    public static final String MOBILE_PHONE = "^0?(13|14|15|16|17|18|19)[0-9]{9}$";//手机号
    public static final String TELEPHONE = "^(\\(\\d{3,4}\\)|\\d{3,4}-|\\s)?\\d{7,14}$";//固话
    public static final String NUM = "[0-9]*";//数值
    public static final String PASSWORD = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*?.]).{8,18}$";//密码

    //
    public static final int txt = 1;
    public static final int pwd = 2;
    public static final int email = 3;
    public static final int English = 4;
    public static final int IDCard = 5;
    public static final int number = 6;
    public static final int phone = 7;
    public static final int qq = 8;
    public static final int telephone = 9;
    public static final int web = 10;

    private int type = 1;

    public MyEditText(@NonNull Context context) {
        super(context);
    }

    public MyEditText(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context,attrs);

    }

    public MyEditText(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void initView(Context context, @Nullable AttributeSet attrs){
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.MyEditText);
        int indexCount = array.getIndexCount();
        type = array.getInt(R.styleable.MyEditText_regular,0);

        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                isMatch(s.toString());
            }
        });
    }

    /**
     * Return whether input matches the regex.
     * @return {@code true}: yes<br>{@code false}: no
     */
    public boolean isMatch(String text) {
        boolean isMatch = false;
        if(text != null && text.length() > 0) {
            switch (type) {
                case txt:
                    isMatch = Pattern.matches(TXT, text);
                    break;
                case pwd:
                    isMatch = Pattern.matches(PASSWORD, text);
                    break;
                case email:
                    isMatch = Pattern.matches(EMAIL, text);
                    break;
                case English:
                    isMatch = Pattern.matches(ENGLISH, text);
                    break;
                case IDCard:
                    isMatch = Pattern.matches(ID, text);
                    break;
                case number:
                    isMatch = Pattern.matches(NUM, text);
                    break;
                case phone:
                    isMatch = Pattern.matches(MOBILE_PHONE, text);
                    break;
                case qq:
                    isMatch = Pattern.matches(QQ, text);
                    break;
                case telephone:
                    isMatch = Pattern.matches(TELEPHONE, text);
                    break;
                case web:
                    isMatch = Pattern.matches(WEBSITE, text);
                    break;
            }
        }
        Toast.makeText(getContext(),"是否符合" + isMatch,Toast.LENGTH_SHORT).show();
        Log.i("MyEt", "是否符合" + isMatch);
        return isMatch;
    }

}
