package com.sdg.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

/**
 * 在tv中插入图片
 * */
public class MyTextView extends AppCompatTextView {

    public MyTextView(@NonNull Context context) {
        super(context);
    }

    public MyTextView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyTextView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * 设置单个文本图片
     * @param text 被插入的图片的文本
     * @param start 插入的图片开始位置
     * @param end 插入的图片结束位置
     * */
    public void setTextImage(String text,int start,int end){

    }

    /**
     * 通过规则批量设置文本图片
     * @param text 被插入的图片的文本
     * @param regex 插入的图片的规则
     * */
    public void setTextImage(String text,String regex){

    }
}
