package com.sdg.mvvm_livedata

import androidx.lifecycle.MutableLiveData
import com.kunminx.architecture.ui.callback.UnPeekLiveData
import com.sdg.library.base.BaseVM

class MainM : BaseVM() {

//    var changeData = MutableLiveData<String>()
    private var changeData: UnPeekLiveData<String> = UnPeekLiveData.Builder<String>()
        .setAllowNullValue(false)
        .create()

    public fun getData():UnPeekLiveData<String>{
        return changeData
    }

    public fun change(string: String){
        changeData.value = string
    }
}