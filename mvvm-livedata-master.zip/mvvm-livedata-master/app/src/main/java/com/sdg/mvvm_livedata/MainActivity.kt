package com.sdg.mvvm_livedata

import android.view.View
import com.sdg.library.base.BaseBVMActivity
import com.sdg.mvvm_livedata.databinding.ActivityMainBinding

class MainActivity : BaseBVMActivity<ActivityMainBinding,MainM>() {

    fun change(view: View) {
        mViewModel?.change("changeText")
    }

    override fun initData() {

    }

    override fun liveDataObsver() {
        mViewModel?.getData()?.observe(this,{
            mBinding.tvTest.text = it
        })
    }
}