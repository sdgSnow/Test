package com.sdg.mvvm_livedata;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;

import com.sdg.library.base.BaseActivity;
import com.sdg.library.base.BaseVM;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

abstract public class BaseAc<VB extends ViewBinding,VM extends BaseVM> extends BaseActivity {
    ViewModel mViewModel;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewModel = createViewModel();
        initData();
    }

    private ViewModel createViewModel() {
        if (mViewModel == null) {
            Class modelClass;
            Type type = getClass().getGenericSuperclass();
            if (type instanceof ParameterizedType) {
                modelClass = (Class) ((ParameterizedType) type).getActualTypeArguments()[1];
            } else {
                //如果没有指定泛型参数，则默认使用BaseViewModel
                modelClass = BaseVM.class;
            }
            mViewModel = (VM) new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(modelClass);
        }
        return mViewModel;
    }

    abstract void initData();
}
