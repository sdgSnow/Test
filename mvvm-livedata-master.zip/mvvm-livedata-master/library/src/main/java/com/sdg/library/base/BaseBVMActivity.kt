package com.sdg.library.base

import android.os.Bundle
import android.view.LayoutInflater
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory
import androidx.viewbinding.ViewBinding
import com.sdg.library.getVmClazz
import java.lang.reflect.ParameterizedType

abstract class BaseBVMActivity<VB : ViewBinding,VM : BaseVM> : BaseActivity() {

    var mViewModel: VM? = null

    protected val mBinding: VB by lazy {
        //使用反射得到viewbinding的class
        val type = javaClass.genericSuperclass as ParameterizedType
        val aClass = type.actualTypeArguments[0] as Class<*>
        val method = aClass.getDeclaredMethod("inflate", LayoutInflater::class.java)
        method.invoke(null, layoutInflater) as VB
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(mBinding.root)
        mViewModel = createViewModel()
        liveDataObsver()
        initData()
    }

    private fun createViewModel(): VM {
        if (mViewModel == null) {
            val modelClass: Class<BaseVM>
            val type = javaClass.genericSuperclass
            modelClass = if (type is ParameterizedType) {
                (type as ParameterizedType).actualTypeArguments[1] as Class<BaseVM>
            } else {
                //如果没有指定泛型参数，则默认使用BaseViewModel
                BaseVM::class.java
            }
            mViewModel = ViewModelProvider(this, NewInstanceFactory()).get(modelClass) as VM
        }
        return mViewModel as VM
    }

    abstract fun liveDataObsver()

    abstract fun initData()

}

