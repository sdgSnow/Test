package com.sdg.library.base

interface BaseV {
}