package com.sdg.library.base

import androidx.lifecycle.ViewModel

open class BaseVM : ViewModel() {
}